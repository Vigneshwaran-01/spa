globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/[root-of-the-server]__2745fc6b._.js",
      "static/chunks/bb85f_next_dist_compiled_478a8bd8._.js",
      "static/chunks/bb85f_next_dist_shared_lib_341d133c._.js",
      "static/chunks/bb85f_next_dist_client_f119dd61._.js",
      "static/chunks/bb85f_next_dist_fc047aea._.js",
      "static/chunks/bb85f_next_14ba3495._.js",
      "static/chunks/bb85f_react_ee0360d4._.js",
      "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
      "static/chunks/bb85f_react-dom_32881ed3._.js",
      "static/chunks/bb85f_react-slick_lib_2b41c6f2._.js",
      "static/chunks/bb85f_framer-motion_dist_es_e20017bf._.js",
      "static/chunks/bb85f_swiper_22feb0e3._.js",
      "static/chunks/bb85f_react-icons_c6d4dc96._.js",
      "static/chunks/_22ccd80b._.js",
      "static/chunks/bb85f_9c219b4a._.css",
      "static/chunks/spam-cloud-25-11-25_pages_index_2da965e7._.js",
      "static/chunks/turbopack-spam-cloud-25-11-25_pages_index_ab369a3c._.js"
    ],
    "/_app": [
      "static/chunks/spam-cloud-25-11-25_5b526bf6._.js",
      "static/chunks/[root-of-the-server]__4ac899b1._.js",
      "static/chunks/bb85f_next_dist_compiled_615e306c._.js",
      "static/chunks/bb85f_next_dist_shared_lib_64748e05._.js",
      "static/chunks/bb85f_next_dist_client_aa07e0da._.js",
      "static/chunks/bb85f_next_dist_fc047aea._.js",
      "static/chunks/bb85f_next_ce63c46b._.js",
      "static/chunks/bb85f_react_ee0360d4._.js",
      "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
      "static/chunks/bb85f_react-dom_32881ed3._.js",
      "static/chunks/bb85f_63962f7c._.js",
      "static/chunks/spam-cloud-25-11-25_260e5d7b._.css",
      "static/chunks/spam-cloud-25-11-25_pages__app_2da965e7._.js",
      "static/chunks/turbopack-spam-cloud-25-11-25_pages__app_69ba058c._.js"
    ],
    "/services/email-security": [
      "static/chunks/[root-of-the-server]__7375df3d._.js",
      "static/chunks/bb85f_next_dist_compiled_615e306c._.js",
      "static/chunks/bb85f_next_dist_shared_lib_4c7539ba._.js",
      "static/chunks/bb85f_next_dist_client_aa07e0da._.js",
      "static/chunks/bb85f_next_dist_fc047aea._.js",
      "static/chunks/bb85f_next_1d9dd7db._.js",
      "static/chunks/bb85f_react_ee0360d4._.js",
      "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
      "static/chunks/bb85f_react-dom_32881ed3._.js",
      "static/chunks/bb85f_abb0647d._.js",
      "static/chunks/spam-cloud-25-11-25_pages_services_email-security_jsx_2da965e7._.js",
      "static/chunks/turbopack-spam-cloud-25-11-25_pages_services_email-security_jsx_4781d138._.js"
    ],
    "/services/endpoint-security": [
      "static/chunks/[root-of-the-server]__8bff09a0._.js",
      "static/chunks/bb85f_next_dist_compiled_478a8bd8._.js",
      "static/chunks/bb85f_next_dist_shared_lib_cbd6f651._.js",
      "static/chunks/bb85f_next_dist_client_261b0bf4._.js",
      "static/chunks/bb85f_next_dist_fc047aea._.js",
      "static/chunks/bb85f_next_4c2fe7a4._.js",
      "static/chunks/bb85f_react_ee0360d4._.js",
      "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
      "static/chunks/bb85f_react-dom_32881ed3._.js",
      "static/chunks/bb85f_a9571811._.js",
      "static/chunks/spam-cloud-25-11-25_pages_services_endpoint-security_jsx_2da965e7._.js",
      "static/chunks/turbopack-spam-cloud-25-11-25_pages_services_endpoint-security_jsx_398a01bf._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];