module.exports = [
"[externals]/react-gtm-module [external] (react-gtm-module, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-gtm-module", () => require("react-gtm-module"));

module.exports = mod;
}),
];