module.exports = [
"[externals]/bootstrap/dist/js/bootstrap.js [external] (bootstrap/dist/js/bootstrap.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("bootstrap/dist/js/bootstrap.js", () => require("bootstrap/dist/js/bootstrap.js"));

module.exports = mod;
}),
];