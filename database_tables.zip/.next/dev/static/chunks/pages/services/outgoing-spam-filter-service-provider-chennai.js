__turbopack_load_page_chunks__("/services/outgoing-spam-filter-service-provider-chennai", [
  "static/chunks/[root-of-the-server]__a211926d._.js",
  "static/chunks/bb85f_next_dist_compiled_478a8bd8._.js",
  "static/chunks/bb85f_next_dist_shared_lib_341d133c._.js",
  "static/chunks/bb85f_next_dist_client_f119dd61._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_14ba3495._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_framer-motion_dist_es_e20017bf._.js",
  "static/chunks/bb85f_swiper_22feb0e3._.js",
  "static/chunks/_00a3869a._.js",
  "static/chunks/bb85f_swiper_8fbd5b5c._.css",
  "static/chunks/c34ff_pages_services_outgoing-spam-filter-service-provider-chennai_jsx_2da965e7._.js",
  "static/chunks/d57a6_pages_services_outgoing-spam-filter-service-provider-chennai_jsx_33df846a._.js"
])
