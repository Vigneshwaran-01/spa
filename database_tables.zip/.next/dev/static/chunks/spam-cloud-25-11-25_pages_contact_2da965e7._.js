(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__3f7b17d9._.js",
  "static/chunks/bb85f_next_dist_compiled_478a8bd8._.js",
  "static/chunks/bb85f_next_dist_shared_lib_341d133c._.js",
  "static/chunks/bb85f_next_dist_client_f119dd61._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_14ba3495._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_framer-motion_dist_es_bf08e466._.js",
  "static/chunks/_00a3869a._.js"
],
    source: "entry"
});
