(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__4139ed98._.js",
  "static/chunks/bb85f_next_dist_compiled_478a8bd8._.js",
  "static/chunks/bb85f_next_dist_shared_lib_341d133c._.js",
  "static/chunks/bb85f_next_dist_client_f119dd61._.js",
  "static/chunks/bb85f_next_dist_31c80b63._.js",
  "static/chunks/bb85f_next_14ba3495._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_swiper_22feb0e3._.js",
  "static/chunks/bb85f_framer-motion_dist_es_e20017bf._.js",
  "static/chunks/_9e2ceecb._.js",
  "static/chunks/bb85f_72f94b5f._.css"
],
    source: "entry"
});
