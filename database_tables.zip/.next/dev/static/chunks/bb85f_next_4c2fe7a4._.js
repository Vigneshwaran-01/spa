(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/spam-cloud-25-11-25/node_modules/next/head.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/shared/lib/head.js [client] (ecmascript)");
}),
"[project]/spam-cloud-25-11-25/node_modules/next/image.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/shared/lib/image-external.js [client] (ecmascript)");
}),
"[project]/spam-cloud-25-11-25/node_modules/next/link.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/client/link.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=bb85f_next_4c2fe7a4._.js.map