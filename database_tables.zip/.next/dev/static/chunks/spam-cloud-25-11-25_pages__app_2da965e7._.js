(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/spam-cloud-25-11-25_5b526bf6._.js",
  "static/chunks/[root-of-the-server]__4ac899b1._.js",
  "static/chunks/bb85f_next_dist_compiled_615e306c._.js",
  "static/chunks/bb85f_next_dist_shared_lib_64748e05._.js",
  "static/chunks/bb85f_next_dist_client_aa07e0da._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_ce63c46b._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_63962f7c._.js",
  "static/chunks/spam-cloud-25-11-25_260e5d7b._.css"
],
    source: "entry"
});
