module.exports=[70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},52360,(e,t,r)=>{t.exports=e.x("mysql2/promise",()=>require("mysql2/promise"))},91557,e=>{"use strict";var t=e.i(40968),r=e.i(25639),a=e.i(96266),n=e.i(50814),s=e.i(52360);async function i(e,t){if("GET"!==e.method)return t.status(405).json({message:"Method not allowed"});try{let e=await s.default.createConnection({host:process.env.DB_HOST,port:process.env.DATABASE_PORT,database:process.env.DB_NAME,user:process.env.DB_USER,password:process.env.DB_PASSWORD,ssl:"true"===process.env.DATABASE_SSL}),[r]=await e.execute(`
      SELECT title, excerpt, content, created_at, slug 
      FROM blog_posts 
      WHERE published = 1 
      ORDER BY created_at DESC 
      LIMIT 10
    `);await e.end();let a=process.env.NEXT_PUBLIC_BASE_URL,n=`<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0">
  <channel>
    <title>Your Blog Name</title>
    <link>${a}</link>
    <description>Your blog description</description>
    <language>en-us</language>
    ${r.map(e=>`
      <item>
        <title>${o(e.title)}</title>
        <link>${a}/blog/${e.slug}</link>
        <description>${o(e.excerpt)}</description>
        <pubDate>${new Date(e.created_at).toUTCString()}</pubDate>
        <guid>${a}/blog/${e.slug}</guid>
      </item>
    `).join("")}
  </channel>
</rss>`;t.setHeader("Content-Type","application/xml"),t.write(n),t.end()}catch(e){console.error("Error generating RSS feed:",e),t.status(500).json({message:"Internal server error"})}}function o(e){return e.replace(/[<>&'"]/g,e=>{switch(e){case"<":return"&lt;";case">":return"&gt;";case"&":return"&amp;";case"'":return"&apos;";case'"':return"&quot;"}})}e.s(["default",()=>i],61636);var l=e.i(61636),p=e.i(68537),u=e.i(7488),d=e.i(30391);let c=(0,n.hoist)(l,"default"),g=(0,n.hoist)(l,"config"),m=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/rss",pathname:"/api/rss",bundlePath:"",filename:""},userland:l,distDir:".next",relativeProjectDir:""});async function v(e,r,a){m.isDev&&(0,d.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let n="/api/rss";n=n.replace(/\/index$/,"")||"/";let s=await m.prepare(e,r,{srcPage:n});if(!s){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:i,params:o,prerenderManifest:l,routerServerContext:c}=s;try{let t=e.method||"GET",a=(0,p.getTracer)(),s=a.getActiveScopeSpan(),d=m.instrumentationOnRequestError.bind(m),g=async s=>m.render(e,r,{query:{...i,...o},params:o,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:l.preview,propagateError:!1,dev:m.isDev,page:"/api/rss",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>d(e,...t)}).finally(()=>{if(!s)return;s.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;s.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),s.updateName(e)}else s.updateName(`${t} ${n}`)});s?await g(s):await a.withPropagatedContext(e.headers,()=>a.trace(u.BaseServerSpan.handleRequest,{spanName:`${t} ${n}`,kind:p.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},g))}catch(e){if(m.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,g,"default",0,c,"handler",()=>v],91557)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__8a5d90d0._.js.map