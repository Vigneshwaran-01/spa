module.exports=[28890,(a,b,c)=>{b.exports=a.x("react-quill",()=>require("react-quill"))}];

//# sourceMappingURL=%5Bexternals%5D_react-quill_f702956b._.js.map