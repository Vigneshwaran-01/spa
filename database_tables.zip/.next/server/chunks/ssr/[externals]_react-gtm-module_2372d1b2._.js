module.exports=[45038,(a,b,c)=>{b.exports=a.x("react-gtm-module",()=>require("react-gtm-module"))}];

//# sourceMappingURL=%5Bexternals%5D_react-gtm-module_2372d1b2._.js.map