module.exports=[82345,(a,b,c)=>{b.exports=a.x("bootstrap/dist/js/bootstrap.js",()=>require("bootstrap/dist/js/bootstrap.js"))}];

//# sourceMappingURL=%5Bexternals%5D_bootstrap_dist_js_bootstrap_a91d2c06.js.map