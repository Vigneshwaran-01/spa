globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/3b6d4ab1c6599460.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3c7c808ed9b074e6.js",
      "static/chunks/3983cc3dc3dc2f4f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/d0e0fd389b510d0d.js",
      "static/chunks/528fc8df933fd07c.css",
      "static/chunks/cd4224f4486f39fb.css",
      "static/chunks/turbopack-1ebdda745f514529.js"
    ],
    "/Forms/ContactUsForm": [
      "static/chunks/504dc3b629e29e22.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-a33382104e184bff.js"
    ],
    "/_app": [
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/e30babda0df434ea.js",
      "static/chunks/63451a51c8310b5e.css",
      "static/chunks/f6a0ce11ad5d52ad.css",
      "static/chunks/bc8470f73e47345d.css",
      "static/chunks/56d1988c4ef1b667.css",
      "static/chunks/8408fd31875ecef0.css",
      "static/chunks/127f826a7077ee71.css",
      "static/chunks/turbopack-61c498bc982ea18d.js"
    ],
    "/_error": [
      "static/chunks/c651eb4482691c49.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-c419c36bce320499.js"
    ],
    "/about": [
      "static/chunks/de08b4444a31593b.js",
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3983cc3dc3dc2f4f.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/cd4224f4486f39fb.css",
      "static/chunks/turbopack-7550b9f4dd4fc589.js"
    ],
    "/acceptable-use-policy": [
      "static/chunks/3d20144e765d6658.js",
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/turbopack-5326ea4393c2dc56.js"
    ],
    "/admin/categories": [
      "static/chunks/7c9a9e19ec51aade.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-723f76729715b671.js"
    ],
    "/admin/categories/[id]/edit": [
      "static/chunks/a3a2f4462983a97c.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-18dc275ac0be4bdc.js"
    ],
    "/admin/categories/new": [
      "static/chunks/aeefc1d1cfec8237.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/turbopack-a18acce36d826d6f.js"
    ],
    "/admin/dashboard": [
      "static/chunks/a34ea8af09603be8.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-17a8c6ebcdb49907.js"
    ],
    "/admin/forms": [
      "static/chunks/25b4e9b69c23064e.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-b5cfbec08fa1baf7.js"
    ],
    "/admin/forms/contact-form": [
      "static/chunks/3603d542749a8625.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-9c103701ef2fc0f0.js"
    ],
    "/admin/forms/home-form": [
      "static/chunks/62b46e6ec2af8e63.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-19aa14bb57739b12.js"
    ],
    "/admin/login": [
      "static/chunks/30f8a689c3d383c5.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-168cd387b4f8b90f.js"
    ],
    "/admin/posts": [
      "static/chunks/6621f94613a19de4.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-410e5c26561f2820.js"
    ],
    "/admin/posts/[id]/edit": [
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/03112da8667a8a57.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/636c9e56e227c812.css",
      "static/chunks/turbopack-b5706659befb24f2.js"
    ],
    "/admin/posts/new": [
      "static/chunks/f249515070924b58.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-0864237e301f269d.js"
    ],
    "/admin/users": [
      "static/chunks/251cff4cd23f5a4d.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/turbopack-6cf6101f42c56c48.js"
    ],
    "/blog": [
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/dc5f51f3a1b08c80.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-d34428e0d7da62aa.js"
    ],
    "/blog/[slug]": [
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/fe4e5570db379787.js",
      "static/chunks/107693836de0bdb2.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/turbopack-9ca4e1b5a621e730.js"
    ],
    "/client": [
      "static/chunks/285f9c82e124617c.js",
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/turbopack-8b282388289cad54.js"
    ],
    "/contact": [
      "static/chunks/9665984985158c45.js",
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/turbopack-5453a89f201f388c.js"
    ],
    "/footer": [
      "static/chunks/795cc2bff06e9834.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-c7d87006ab29a216.js"
    ],
    "/header": [
      "static/chunks/4429f034388bca6c.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/turbopack-a2c8d426e1c9d80e.js"
    ],
    "/privacy-policy": [
      "static/chunks/05f5cdd0d1ed2034.js",
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/turbopack-b2d49ae6da04e2b4.js"
    ],
    "/section/Blogslider": [
      "static/chunks/d0794aef583ff9b7.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/40e544d288f045ad.js",
      "static/chunks/3983cc3dc3dc2f4f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/cd4224f4486f39fb.css",
      "static/chunks/turbopack-77a66c0d5b8a1969.js"
    ],
    "/section/CardHoverEffectDemo": [
      "static/chunks/f32451919026ba5e.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-b5c6740530f6cbcc.js"
    ],
    "/section/CardHoverEffectoutgoing": [
      "static/chunks/299ab16caeaed8d9.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-399d734979073b78.js"
    ],
    "/section/ContactSec": [
      "static/chunks/88e4b294a183cede.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/turbopack-f928a67d3b639fd6.js"
    ],
    "/section/FAQSection": [
      "static/chunks/d02631f95008029d.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/7099c5a2215ff608.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/bc8470f73e47345d.css",
      "static/chunks/turbopack-086ec155f63f44e7.js"
    ],
    "/section/ProofpointCarousel": [
      "static/chunks/20d9962b6f8fa243.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3c7c808ed9b074e6.js",
      "static/chunks/turbopack-d4d70d9110623938.js"
    ],
    "/section/TimeLineIncome": [
      "static/chunks/e326554d49b4ef27.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/turbopack-d2260a8b5f61695d.js"
    ],
    "/section/TimeLineOutgoing": [
      "static/chunks/6671c692bec9633e.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ff35a4d402356b4e.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-18821d559d2bef8a.js"
    ],
    "/section/globecomponent": [
      "static/chunks/0eb857a0319fb562.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/turbopack-40f015152d886c6e.js"
    ],
    "/section/slider": [
      "static/chunks/d46c33c1bfd3577f.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3b6d4ab1c6599460.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/528fc8df933fd07c.css",
      "static/chunks/turbopack-a2de209ba96a0afd.js"
    ],
    "/services/email-security-gateway": [
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/e2b04a8083a9d94a.js",
      "static/chunks/turbopack-39573521c30c8da4.js"
    ],
    "/services/firewall-network-security": [
      "static/chunks/3bc5e8a90987df44.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/40d334eb7669564d.js",
      "static/chunks/turbopack-220517911be437d3.js"
    ],
    "/services/immunify360-security": [
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/0bc6522414920219.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/turbopack-288474bdd7beb979.js"
    ],
    "/services/incoming-spam-filter-service-provider-chennai": [
      "static/chunks/7099c5a2215ff608.js",
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/3983cc3dc3dc2f4f.js",
      "static/chunks/b2b483caff19f9e3.js",
      "static/chunks/bc8470f73e47345d.css",
      "static/chunks/cd4224f4486f39fb.css",
      "static/chunks/turbopack-e7cb96392f6fcd82.js"
    ],
    "/services/outgoing-spam-filter-service-provider-chennai": [
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/4b98352f3cfd027d.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3983cc3dc3dc2f4f.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/cd4224f4486f39fb.css",
      "static/chunks/turbopack-6bb58e528a72f54b.js"
    ],
    "/services/seqrite-endpoint-security": [
      "static/chunks/99d07ccff5e351c3.js",
      "static/chunks/3bc5e8a90987df44.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/d78e64124b195700.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/turbopack-06d7dd5548a5fb34.js"
    ],
    "/terms-and-condition": [
      "static/chunks/7841e0dc3ffbdea0.js",
      "static/chunks/4d674e9a00edfe3b.js",
      "static/chunks/a23b5d855a4ebddc.js",
      "static/chunks/19c4a40471764ddb.js",
      "static/chunks/3347e2f607470269.js",
      "static/chunks/ab60f0582ada94e1.js",
      "static/chunks/ab89c23d732d046d.js",
      "static/chunks/0870c8434b08bf3f.js",
      "static/chunks/3960bbf99db8320d.js",
      "static/chunks/turbopack-be6dee82a6b57d9e.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];