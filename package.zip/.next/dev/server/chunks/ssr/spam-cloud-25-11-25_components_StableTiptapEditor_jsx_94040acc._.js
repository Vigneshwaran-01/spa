module.exports = [
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[root-of-the-server]__17cc3fe5._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript, next/dynamic entry)");
    });
});
}),
];