module.exports = [
"[project]/spam-cloud-25-11-25/components/TawkMessenger.js [ssr] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/spam-cloud-25-11-25_2694b79e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/spam-cloud-25-11-25/components/TawkMessenger.js [ssr] (ecmascript, next/dynamic entry)");
    });
});
}),
"[externals]/bootstrap/dist/js/bootstrap.js [external] (bootstrap/dist/js/bootstrap.js, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[externals]_bootstrap_dist_js_bootstrap_a91d2c06.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[externals]/bootstrap/dist/js/bootstrap.js [external] (bootstrap/dist/js/bootstrap.js, cjs)");
    });
});
}),
"[externals]/react-gtm-module [external] (react-gtm-module, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[externals]_react-gtm-module_2372d1b2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[externals]/react-gtm-module [external] (react-gtm-module, cjs)");
    });
});
}),
];