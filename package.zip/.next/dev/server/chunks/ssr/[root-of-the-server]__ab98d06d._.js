module.exports = [
"[externals]/mysql2/promise [external] (mysql2/promise, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mysql2/promise", () => require("mysql2/promise"));

module.exports = mod;
}),
"[externals]/framer-motion [external] (framer-motion, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("framer-motion");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/clsx [external] (clsx, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("clsx");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/tailwind-merge [external] (tailwind-merge, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("tailwind-merge");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/spam-cloud-25-11-25/lib/utils.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "cn",
    ()=>cn,
    "formatShortDate",
    ()=>formatShortDate
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$clsx__$5b$external$5d$__$28$clsx$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/clsx [external] (clsx, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$tailwind$2d$merge__$5b$external$5d$__$28$tailwind$2d$merge$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/tailwind-merge [external] (tailwind-merge, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$clsx__$5b$external$5d$__$28$clsx$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f$tailwind$2d$merge__$5b$external$5d$__$28$tailwind$2d$merge$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$clsx__$5b$external$5d$__$28$clsx$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f$tailwind$2d$merge__$5b$external$5d$__$28$tailwind$2d$merge$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$tailwind$2d$merge__$5b$external$5d$__$28$tailwind$2d$merge$2c$__esm_import$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$clsx__$5b$external$5d$__$28$clsx$2c$__esm_import$29$__["clsx"])(inputs));
}
function formatShortDate(input) {
    const date = input instanceof Date ? input : new Date(input);
    if (Number.isNaN(date.getTime())) return '';
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${mm}/${dd}/${yyyy}`;
}
// CommonJS fallback for small scripts/tests that use require()
/* istanbul ignore next */ if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "BackgroundBeams",
    ()=>BackgroundBeams
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/framer-motion [external] (framer-motion, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$utils$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/lib/utils.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$utils$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$utils$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"use client";
;
;
;
;
const BackgroundBeams = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["default"].memo(({ className })=>{
    const paths = [
        "M-380 -189C-380 -189 -312 216 152 343C616 470 684 875 684 875",
        "M-373 -197C-373 -197 -305 208 159 335C623 462 691 867 691 867",
        "M-366 -205C-366 -205 -298 200 166 327C630 454 698 859 698 859",
        "M-359 -213C-359 -213 -291 192 173 319C637 446 705 851 705 851",
        "M-352 -221C-352 -221 -284 184 180 311C644 438 712 843 712 843",
        "M-345 -229C-345 -229 -277 176 187 303C651 430 719 835 719 835",
        "M-338 -237C-338 -237 -270 168 194 295C658 422 726 827 726 827",
        "M-331 -245C-331 -245 -263 160 201 287C665 414 733 819 733 819",
        "M-324 -253C-324 -253 -256 152 208 279C672 406 740 811 740 811",
        "M-317 -261C-317 -261 -249 144 215 271C679 398 747 803 747 803",
        "M-310 -269C-310 -269 -242 136 222 263C686 390 754 795 754 795",
        "M-303 -277C-303 -277 -235 128 229 255C693 382 761 787 761 787",
        "M-296 -285C-296 -285 -228 120 236 247C700 374 768 779 768 779",
        "M-289 -293C-289 -293 -221 112 243 239C707 366 775 771 775 771",
        "M-282 -301C-282 -301 -214 104 250 231C714 358 782 763 782 763",
        "M-275 -309C-275 -309 -207 96 257 223C721 350 789 755 789 755",
        "M-268 -317C-268 -317 -200 88 264 215C728 342 796 747 796 747",
        "M-261 -325C-261 -325 -193 80 271 207C735 334 803 739 803 739",
        "M-254 -333C-254 -333 -186 72 278 199C742 326 810 731 810 731",
        "M-247 -341C-247 -341 -179 64 285 191C749 318 817 723 817 723",
        "M-240 -349C-240 -349 -172 56 292 183C756 310 824 715 824 715",
        "M-233 -357C-233 -357 -165 48 299 175C763 302 831 707 831 707",
        "M-226 -365C-226 -365 -158 40 306 167C770 294 838 699 838 699",
        "M-219 -373C-219 -373 -151 32 313 159C777 286 845 691 845 691",
        "M-212 -381C-212 -381 -144 24 320 151C784 278 852 683 852 683",
        "M-205 -389C-205 -389 -137 16 327 143C791 270 859 675 859 675",
        "M-198 -397C-198 -397 -130 8 334 135C798 262 866 667 866 667",
        "M-191 -405C-191 -405 -123 0 341 127C805 254 873 659 873 659",
        "M-184 -413C-184 -413 -116 -8 348 119C812 246 880 651 880 651",
        "M-177 -421C-177 -421 -109 -16 355 111C819 238 887 643 887 643",
        "M-170 -429C-170 -429 -102 -24 362 103C826 230 894 635 894 635",
        "M-163 -437C-163 -437 -95 -32 369 95C833 222 901 627 901 627",
        "M-156 -445C-156 -445 -88 -40 376 87C840 214 908 619 908 619",
        "M-149 -453C-149 -453 -81 -48 383 79C847 206 915 611 915 611",
        "M-142 -461C-142 -461 -74 -56 390 71C854 198 922 603 922 603",
        "M-135 -469C-135 -469 -67 -64 397 63C861 190 929 595 929 595",
        "M-128 -477C-128 -477 -60 -72 404 55C868 182 936 587 936 587",
        "M-121 -485C-121 -485 -53 -80 411 47C875 174 943 579 943 579",
        "M-114 -493C-114 -493 -46 -88 418 39C882 166 950 571 950 571",
        "M-107 -501C-107 -501 -39 -96 425 31C889 158 957 563 957 563",
        "M-100 -509C-100 -509 -32 -104 432 23C896 150 964 555 964 555",
        "M-93 -517C-93 -517 -25 -112 439 15C903 142 971 547 971 547",
        "M-86 -525C-86 -525 -18 -120 446 7C910 134 978 539 978 539",
        "M-79 -533C-79 -533 -11 -128 453 -1C917 126 985 531 985 531",
        "M-72 -541C-72 -541 -4 -136 460 -9C924 118 992 523 992 523",
        "M-65 -549C-65 -549 3 -144 467 -17C931 110 999 515 999 515",
        "M-58 -557C-58 -557 10 -152 474 -25C938 102 1006 507 1006 507",
        "M-51 -565C-51 -565 17 -160 481 -33C945 94 1013 499 1013 499",
        "M-44 -573C-44 -573 24 -168 488 -41C952 86 1020 491 1020 491",
        "M-37 -581C-37 -581 31 -176 495 -49C959 78 1027 483 1027 483"
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$utils$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["cn"])("absolute  h-full w-full inset-0  [mask-size:40px] [mask-repeat:no-repeat] flex items-center justify-center", className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
            className: " z-0 h-full w-full pointer-events-none absolute ",
            width: "100%",
            height: "100%",
            viewBox: "0 0 696 316",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                    d: "M-380 -189C-380 -189 -312 216 152 343C616 470 684 875 684 875M-373 -197C-373 -197 -305 208 159 335C623 462 691 867 691 867M-366 -205C-366 -205 -298 200 166 327C630 454 698 859 698 859M-359 -213C-359 -213 -291 192 173 319C637 446 705 851 705 851M-352 -221C-352 -221 -284 184 180 311C644 438 712 843 712 843M-345 -229C-345 -229 -277 176 187 303C651 430 719 835 719 835M-338 -237C-338 -237 -270 168 194 295C658 422 726 827 726 827M-331 -245C-331 -245 -263 160 201 287C665 414 733 819 733 819M-324 -253C-324 -253 -256 152 208 279C672 406 740 811 740 811M-317 -261C-317 -261 -249 144 215 271C679 398 747 803 747 803M-310 -269C-310 -269 -242 136 222 263C686 390 754 795 754 795M-303 -277C-303 -277 -235 128 229 255C693 382 761 787 761 787M-296 -285C-296 -285 -228 120 236 247C700 374 768 779 768 779M-289 -293C-289 -293 -221 112 243 239C707 366 775 771 775 771M-282 -301C-282 -301 -214 104 250 231C714 358 782 763 782 763M-275 -309C-275 -309 -207 96 257 223C721 350 789 755 789 755M-268 -317C-268 -317 -200 88 264 215C728 342 796 747 796 747M-261 -325C-261 -325 -193 80 271 207C735 334 803 739 803 739M-254 -333C-254 -333 -186 72 278 199C742 326 810 731 810 731M-247 -341C-247 -341 -179 64 285 191C749 318 817 723 817 723M-240 -349C-240 -349 -172 56 292 183C756 310 824 715 824 715M-233 -357C-233 -357 -165 48 299 175C763 302 831 707 831 707M-226 -365C-226 -365 -158 40 306 167C770 294 838 699 838 699M-219 -373C-219 -373 -151 32 313 159C777 286 845 691 845 691M-212 -381C-212 -381 -144 24 320 151C784 278 852 683 852 683M-205 -389C-205 -389 -137 16 327 143C791 270 859 675 859 675M-198 -397C-198 -397 -130 8 334 135C798 262 866 667 866 667M-191 -405C-191 -405 -123 0 341 127C805 254 873 659 873 659M-184 -413C-184 -413 -116 -8 348 119C812 246 880 651 880 651M-177 -421C-177 -421 -109 -16 355 111C819 238 887 643 887 643M-170 -429C-170 -429 -102 -24 362 103C826 230 894 635 894 635M-163 -437C-163 -437 -95 -32 369 95C833 222 901 627 901 627M-156 -445C-156 -445 -88 -40 376 87C840 214 908 619 908 619M-149 -453C-149 -453 -81 -48 383 79C847 206 915 611 915 611M-142 -461C-142 -461 -74 -56 390 71C854 198 922 603 922 603M-135 -469C-135 -469 -67 -64 397 63C861 190 929 595 929 595M-128 -477C-128 -477 -60 -72 404 55C868 182 936 587 936 587M-121 -485C-121 -485 -53 -80 411 47C875 174 943 579 943 579M-114 -493C-114 -493 -46 -88 418 39C882 166 950 571 950 571M-107 -501C-107 -501 -39 -96 425 31C889 158 957 563 957 563M-100 -509C-100 -509 -32 -104 432 23C896 150 964 555 964 555M-93 -517C-93 -517 -25 -112 439 15C903 142 971 547 971 547M-86 -525C-86 -525 -18 -120 446 7C910 134 978 539 978 539M-79 -533C-79 -533 -11 -128 453 -1C917 126 985 531 985 531M-72 -541C-72 -541 -4 -136 460 -9C924 118 992 523 992 523M-65 -549C-65 -549 3 -144 467 -17C931 110 999 515 999 515M-58 -557C-58 -557 10 -152 474 -25C938 102 1006 507 1006 507M-51 -565C-51 -565 17 -160 481 -33C945 94 1013 499 1013 499M-44 -573C-44 -573 24 -168 488 -41C952 86 1020 491 1020 491M-37 -581C-37 -581 31 -176 495 -49C959 78 1027 483 1027 483M-30 -589C-30 -589 38 -184 502 -57C966 70 1034 475 1034 475M-23 -597C-23 -597 45 -192 509 -65C973 62 1041 467 1041 467M-16 -605C-16 -605 52 -200 516 -73C980 54 1048 459 1048 459M-9 -613C-9 -613 59 -208 523 -81C987 46 1055 451 1055 451M-2 -621C-2 -621 66 -216 530 -89C994 38 1062 443 1062 443M5 -629C5 -629 73 -224 537 -97C1001 30 1069 435 1069 435M12 -637C12 -637 80 -232 544 -105C1008 22 1076 427 1076 427M19 -645C19 -645 87 -240 551 -113C1015 14 1083 419 1083 419",
                    stroke: "url(#paint0_radial_242_278)",
                    strokeOpacity: "0.05",
                    strokeWidth: "0.5"
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                    lineNumber: 74,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                paths.map((path, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["motion"].path, {
                        d: path,
                        stroke: `url(#linearGradient-${index})`,
                        strokeOpacity: "0.4",
                        strokeWidth: "0.5"
                    }, `path-` + index, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("defs", {
                    children: [
                        paths.map((path, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["motion"].linearGradient, {
                                id: `linearGradient-${index}`,
                                initial: {
                                    x1: "0%",
                                    x2: "0%",
                                    y1: "0%",
                                    y2: "0%"
                                },
                                animate: {
                                    x1: [
                                        "0%",
                                        "100%"
                                    ],
                                    x2: [
                                        "0%",
                                        "95%"
                                    ],
                                    y1: [
                                        "0%",
                                        "100%"
                                    ],
                                    y2: [
                                        "0%",
                                        `${93 + Math.random() * 8}%`
                                    ]
                                },
                                transition: {
                                    duration: Math.random() * 10 + 10,
                                    ease: "easeInOut",
                                    repeat: Infinity,
                                    delay: Math.random() * 10
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("stop", {
                                        stopColor: "#18CCFC",
                                        stopOpacity: "0"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                        lineNumber: 111,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("stop", {
                                        stopColor: "#18CCFC"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                        lineNumber: 112,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("stop", {
                                        offset: "32.5%",
                                        stopColor: "#6344F5"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                        lineNumber: 113,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("stop", {
                                        offset: "100%",
                                        stopColor: "#AE48FF",
                                        stopOpacity: "0"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                        lineNumber: 114,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, `gradient-${index}`, true, {
                                fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("radialGradient", {
                            id: "paint0_radial_242_278",
                            cx: "0",
                            cy: "0",
                            r: "1",
                            gradientUnits: "userSpaceOnUse",
                            gradientTransform: "translate(352 34) rotate(90) scale(555 1560.62)",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("stop", {
                                    offset: "0.0666667",
                                    stopColor: "var(--neutral-300)"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                    lineNumber: 125,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("stop", {
                                    offset: "0.243243",
                                    stopColor: "var(--neutral-300)"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                    lineNumber: 126,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("stop", {
                                    offset: "0.43594",
                                    stopColor: "white",
                                    stopOpacity: "0"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                                    lineNumber: 127,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                            lineNumber: 118,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
                    lineNumber: 88,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
            lineNumber: 67,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx",
        lineNumber: 62,
        columnNumber: 6
    }, ("TURBOPACK compile-time value", void 0));
});
BackgroundBeams.displayName = "BackgroundBeams";
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[externals]/react-animations/lib/fade-in.js [external] (react-animations/lib/fade-in.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/fade-in.js", () => require("react-animations/lib/fade-in.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/slide-in-up.js [external] (react-animations/lib/slide-in-up.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/slide-in-up.js", () => require("react-animations/lib/slide-in-up.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/slide-in-down.js [external] (react-animations/lib/slide-in-down.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/slide-in-down.js", () => require("react-animations/lib/slide-in-down.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/tada.js [external] (react-animations/lib/tada.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/tada.js", () => require("react-animations/lib/tada.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/zoom-in-down.js [external] (react-animations/lib/zoom-in-down.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/zoom-in-down.js", () => require("react-animations/lib/zoom-in-down.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/slide-in-left.js [external] (react-animations/lib/slide-in-left.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/slide-in-left.js", () => require("react-animations/lib/slide-in-left.js"));

module.exports = mod;
}),
"[externals]/aphrodite [external] (aphrodite, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("aphrodite", () => require("aphrodite"));

module.exports = mod;
}),
"[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "getServerSideProps",
    ()=>getServerSideProps
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mysql2$2f$promise__$5b$external$5d$__$28$mysql2$2f$promise$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mysql2/promise [external] (mysql2/promise, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$head$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/head.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$ui$2f$background$2d$beams$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/components/ui/background-beams.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/fade-in.js [external] (react-animations/lib/fade-in.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/slide-in-up.js [external] (react-animations/lib/slide-in-up.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/slide-in-down.js [external] (react-animations/lib/slide-in-down.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$tada$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$tada$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/tada.js [external] (react-animations/lib/tada.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/zoom-in-down.js [external] (react-animations/lib/zoom-in-down.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/slide-in-left.js [external] (react-animations/lib/slide-in-left.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$aphrodite__$5b$external$5d$__$28$aphrodite$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/aphrodite [external] (aphrodite, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/link.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$ui$2f$background$2d$beams$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$ui$2f$background$2d$beams$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
;
;
;
;
;
;
;
;
;
;
const styles = __TURBOPACK__imported__module__$5b$externals$5d2f$aphrodite__$5b$external$5d$__$28$aphrodite$2c$__cjs$29$__["StyleSheet"].create({
    fadeIn: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '2s'
    },
    slideInUp: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '2s'
    },
    slideInDown: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '2s'
    },
    tada: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$tada$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$tada$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '15s'
    },
    zoomInDown: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '4s'
    },
    slideInLeft: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '4s'
    }
});
function BlogPost({ post, relatedPosts }) {
    const [isClient, setIsClient] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const [headings, setHeadings] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(true);
    const [processedContent, setProcessedContent] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])('');
    const [readProgress, setReadProgress] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        setIsClient(true);
        // Extract H2 headings from post content and inject anchor ids for deep linking
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = post.content || '';
        const h2Elements = tempDiv.querySelectorAll("h2");
        const extractedHeadings = Array.from(h2Elements).map((h2, index)=>{
            const id = `heading-${index}`;
            h2.setAttribute('id', id);
            return h2.innerText;
        });
        setHeadings(extractedHeadings);
        setProcessedContent(tempDiv.innerHTML);
        // Simulate loading delay for related posts
        const t = setTimeout(()=>{
            setIsLoading(false);
        }, 300);
        // Reading progress handler
        const handleScroll = ()=>{
            const article = document.getElementById('blog-article');
            if (!article) return;
            const rect = article.getBoundingClientRect();
            const total = article.scrollHeight - window.innerHeight;
            const scrolled = window.scrollY - (article.offsetTop || 0);
            const progress = Math.max(0, Math.min(100, scrolled / Math.max(total, 1) * 100));
            setReadProgress(progress);
        };
        window.addEventListener('scroll', handleScroll);
        return ()=>{
            clearTimeout(t);
            window.removeEventListener('scroll', handleScroll);
        };
    }, [
        post.content
    ]);
    if (!post) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        children: "Post not found"
    }, void 0, false, {
        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
        lineNumber: 69,
        columnNumber: 21
    }, this);
    const formatDate = (dateString)=>{
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    };
    const shareUrl = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : "";
    const readingTime = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useMemo"])(()=>{
        if (!post?.content) return 0;
        // Server-safe: strip HTML tags without using document
        const text = (post.content || '').replace(/<[^>]*>/g, ' ');
        const words = text.trim().split(/\s+/).filter(Boolean).length;
        return Math.max(1, Math.round(words / 200)); // ~200 wpm
    }, [
        post?.content
    ]);
    const seoTitle = post.seo_title || post.title;
    const seoDescription = post.seo_description || post.excerpt || '';
    const seoKeywords = post.seo_keywords || '';
    const seoCanonical = post.seo_canonical_url || '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$head$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("title", {
                        children: seoTitle
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    seoDescription && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        name: "description",
                        content: seoDescription
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                        lineNumber: 95,
                        columnNumber: 28
                    }, this),
                    seoKeywords && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        name: "keywords",
                        content: seoKeywords
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                        lineNumber: 96,
                        columnNumber: 25
                    }, this),
                    seoCanonical && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("link", {
                        rel: "canonical",
                        href: seoCanonical
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                        lineNumber: 97,
                        columnNumber: 26
                    }, this),
                    post.schema_json && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: post.schema_json
                        }
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                        lineNumber: 99,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "about-banner-sec",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "relative w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "relative w-full overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-black",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "max-w-6xl mx-auto px-4 py-14 md:py-20",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "text-slate-300 text-sm mb-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                    href: "/",
                                                    className: "hover:underline",
                                                    children: "Home"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 112,
                                                    columnNumber: 17
                                                }, this),
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                    className: "opacity-70",
                                                    children: "/"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 112,
                                                    columnNumber: 66
                                                }, this),
                                                " ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                    href: "/blog",
                                                    className: "hover:underline",
                                                    children: "Blog"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 112,
                                                    columnNumber: 104
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 111,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                                            className: `text-white text-3xl md:text-5xl font-extrabold tracking-tight leading-tight ${isClient ? (0, __TURBOPACK__imported__module__$5b$externals$5d2f$aphrodite__$5b$external$5d$__$28$aphrodite$2c$__cjs$29$__["css"])(styles.slideInUp) : ''}`,
                                            children: post.title
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 114,
                                            columnNumber: 15
                                        }, this),
                                        post.excerpt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                            className: "mt-4 max-w-3xl text-slate-300 text-base md:text-lg",
                                            children: post.excerpt
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 116,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "mt-6 flex flex-wrap items-center gap-4 text-slate-200/90 text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                    className: "inline-flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                            className: "w-4 h-4 text-slate-400",
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: "2",
                                                                d: "M8 7V3m8 4V3M5 11h14M5 19h14M5 11a2 2 0 012-2h10a2 2 0 012 2M5 19a2 2 0 002 2h10a2 2 0 002-2"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                                lineNumber: 120,
                                                                columnNumber: 113
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                            lineNumber: 120,
                                                            columnNumber: 19
                                                        }, this),
                                                        formatDate(post.created_at)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 119,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                    className: "opacity-60",
                                                    children: "•"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 123,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        readingTime,
                                                        " min read"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 124,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                    href: "#blog-article",
                                                    className: "ml-auto inline-flex items-center gap-2 rounded-md bg-emerald-500 hover:bg-emerald-400 text-black font-semibold px-4 py-2 transition-colors",
                                                    children: [
                                                        "Read Article",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                            className: "w-4 h-4",
                                                            viewBox: "0 0 24 24",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                                strokeLinecap: "round",
                                                                strokeLinejoin: "round",
                                                                strokeWidth: "2",
                                                                d: "M9 5l7 7-7 7"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                                lineNumber: 126,
                                                                columnNumber: 98
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                            lineNumber: 126,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 125,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 118,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                    lineNumber: 110,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$ui$2f$background$2d$beams$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["BackgroundBeams"], {}, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                    lineNumber: 130,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "h-1 w-full bg-slate-800",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                style: {
                                    width: `${readProgress}%`
                                },
                                className: "h-full bg-emerald-500 transition-[width] duration-150"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                lineNumber: 134,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                            lineNumber: 133,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                    lineNumber: 108,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "max-w-8xl  grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-12 px-4 py-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("aside", {
                        className: "md:col-span-3 hidden md:block p-6 bg-gradient-to-br from-blue-800 via-blue-600 to-blue-400 border border-blue-300 rounded-xl sticky top-24 h-max shadow-xl",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                    className: "font-bold text-white mb-6 text-lg tracking-tight",
                                    children: "Table of Contents"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                    lineNumber: 145,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("ul", {
                                    className: "space-y-3 text-sm",
                                    children: headings.length > 0 ? headings.map((heading, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                href: `#heading-${index}`,
                                                className: "text-blue-100 hover:text-white transition-colors duration-200 block py-1 px-2 rounded hover:bg-white/10",
                                                children: heading
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                lineNumber: 150,
                                                columnNumber: 21
                                            }, this)
                                        }, index, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 149,
                                            columnNumber: 19
                                        }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                                        className: "text-blue-100",
                                        children: "No headings available"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 154,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                    lineNumber: 146,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "mt-6 p-4 bg-white/10 border border-white/20 rounded-lg post-share backdrop-blur-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                            className: "font-semibold text-white mb-3",
                                            children: "Share this post"
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 158,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "flex space-x-4 icon",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                    href: `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    className: "text-white hover:text-blue-200 transition-colors duration-200",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                        className: "fa-brands fa-facebook text-lg"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                        lineNumber: 160,
                                                        columnNumber: 202
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 160,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                    href: `https://twitter.com/intent/tweet?url=${shareUrl}&text=${post.title}`,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    className: "text-white hover:text-blue-200 transition-colors duration-200",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                        className: "fa-brands fa-x-twitter text-lg"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                        lineNumber: 161,
                                                        columnNumber: 213
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 161,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                    href: `https://www.linkedin.com/shareArticle?url=${shareUrl}`,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    className: "text-white hover:text-blue-200 transition-colors duration-200",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                        className: "fa-brands fa-linkedin text-lg"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                        lineNumber: 162,
                                                        columnNumber: 199
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 162,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                    href: `https://api.whatsapp.com/send?text=${post.title} - ${shareUrl}`,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    className: "text-white hover:text-green-300 transition-colors duration-200",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                        className: "fa-brands fa-whatsapp text-lg"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                        lineNumber: 163,
                                                        columnNumber: 209
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 163,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 159,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                    lineNumber: 157,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                            lineNumber: 144,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("article", {
                        id: "blog-article",
                        className: "md:col-span-8 px-[20px] py-[20px] relative",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "hidden lg:flex flex-col gap-3 absolute -left-16 top-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                        href: `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm grid place-items-center text-blue-600",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                            className: "fa-brands fa-facebook"
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 173,
                                            columnNumber: 240
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 173,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                        href: `https://twitter.com/intent/tweet?url=${shareUrl}&text=${post.title}`,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm grid place-items-center text-blue-400",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                            className: "fa-brands fa-x-twitter"
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 174,
                                            columnNumber: 251
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 174,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                        href: `https://www.linkedin.com/shareArticle?url=${shareUrl}`,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm grid place-items-center text-blue-700",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                            className: "fa-brands fa-linkedin"
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                            lineNumber: 175,
                                            columnNumber: 237
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 175,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                lineNumber: 172,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "text-gray-600 mb-6 flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "inline-flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                className: "w-4 h-4 text-slate-500",
                                                viewBox: "0 0 24 24",
                                                fill: "none",
                                                stroke: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: "2",
                                                    d: "M8 7V3m8 4V3M5 11h14M5 19h14M5 11a2 2 0 012-2h10a2 2 0 012 2M5 19a2 2 0 002 2h10a2 2 0 002-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                    lineNumber: 180,
                                                    columnNumber: 109
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                lineNumber: 180,
                                                columnNumber: 15
                                            }, this),
                                            formatDate(post.created_at)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 179,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "text-slate-400",
                                        children: "•"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 183,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        children: [
                                            readingTime,
                                            " min read"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 184,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                lineNumber: 178,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "prose prose-slate max-w-none prose-headings:scroll-mt-28",
                                dangerouslySetInnerHTML: {
                                    __html: processedContent
                                }
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                lineNumber: 186,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "container mx-auto px-6 py-8 shadow-sm rounded-xl mt-8 border border-slate-200 bg-white",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                        className: "text-2xl font-bold mb-4",
                                        children: "About the Author"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 188,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: "text-gray-700",
                                        children: [
                                            "Written by ",
                                            post.author || 'Guest Author',
                                            "."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 189,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: "text-gray-700",
                                        children: post.author_bio
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 190,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                lineNumber: 187,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "container mx-auto px-6 py-8 text-center shadow-sm rounded-xl mt-8 bg-slate-900 text-white",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                        className: "text-2xl font-bold",
                                        children: "Stay updated"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 194,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: "opacity-90",
                                        children: "Subscribe for new posts and insights."
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 195,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "mt-4 flex items-center justify-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                                type: "email",
                                                placeholder: "Enter your email",
                                                className: "px-4 py-2 rounded-l-md border border-slate-700 bg-slate-800 placeholder-slate-400 text-white"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                lineNumber: 197,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                                className: "px-6 py-2 rounded-r-md bg-emerald-500 text-black font-semibold",
                                                children: "Subscribe"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                                lineNumber: 198,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                        lineNumber: 196,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                                lineNumber: 193,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                lineNumber: 140,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "max-w-6xl mx-auto px-4 pb-12",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "mt-8 grid grid-cols-1 md:grid-cols-2 gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                            href: "/blog",
                            className: "inline-flex items-center justify-center px-4 py-3 rounded-lg border border-slate-200 hover:border-slate-300 text-slate-700",
                            children: "← Back to Blog"
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                            lineNumber: 237,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                            href: "#top",
                            className: "inline-flex items-center justify-center px-4 py-3 rounded-lg border border-slate-200 hover:border-slate-300 text-slate-700",
                            children: "Back to Top ↑"
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                            lineNumber: 238,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                    lineNumber: 236,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/blog/[slug].jsx",
                lineNumber: 235,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
async function getServerSideProps({ params }) {
    try {
        const pool = __TURBOPACK__imported__module__$5b$externals$5d2f$mysql2$2f$promise__$5b$external$5d$__$28$mysql2$2f$promise$2c$__cjs$29$__["default"].createPool({
            host: process.env.DB_HOST,
            port: process.env.DATABASE_PORT,
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            ssl: process.env.DATABASE_SSL === 'true',
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });
        const connection = await pool.getConnection();
        // Fetch current post
        const [posts] = await connection.execute('SELECT * FROM blog_posts WHERE slug = ? AND published = 1', [
            params.slug
        ]);
        if (posts.length === 0) {
            return {
                notFound: true
            };
        }
        const post = posts[0];
        // Fetch related articles (same category, excluding the current post, sorted by latest)
        const [relatedPosts] = await connection.execute('SELECT * FROM blog_posts WHERE category_id = ? AND slug != ? AND published = 1 ORDER BY created_at DESC LIMIT 5', [
            post.category_id,
            post.slug
        ]);
        await connection.release();
        return {
            props: {
                post: JSON.parse(JSON.stringify(post)),
                relatedPosts: JSON.parse(JSON.stringify(relatedPosts))
            }
        };
    } catch (error) {
        console.error('Database error:', error.message);
        return {
            notFound: true
        };
    }
}
const __TURBOPACK__default__export__ = BlogPost;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ab98d06d._.js.map