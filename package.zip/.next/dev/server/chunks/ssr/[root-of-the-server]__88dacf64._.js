module.exports = [
"[externals]/@tiptap/react [external] (@tiptap/react, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("@tiptap/react");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/@tiptap/starter-kit [external] (@tiptap/starter-kit, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("@tiptap/starter-kit");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/@tiptap/extension-link [external] (@tiptap/extension-link, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("@tiptap/extension-link");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/@tiptap/extension-horizontal-rule [external] (@tiptap/extension-horizontal-rule, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("@tiptap/extension-horizontal-rule");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/lowlight [external] (lowlight, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("lowlight");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>StableTiptapEditor
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$react__$5b$external$5d$__$2840$tiptap$2f$react$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@tiptap/react [external] (@tiptap/react, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$starter$2d$kit__$5b$external$5d$__$2840$tiptap$2f$starter$2d$kit$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@tiptap/starter-kit [external] (@tiptap/starter-kit, esm_import)");
(()=>{
    const e = new Error("Cannot find module '@tiptap/extension-table'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@tiptap/extension-table-row'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@tiptap/extension-table-cell'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@tiptap/extension-table-header'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$link__$5b$external$5d$__$2840$tiptap$2f$extension$2d$link$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@tiptap/extension-link [external] (@tiptap/extension-link, esm_import)");
(()=>{
    const e = new Error("Cannot find module '@tiptap/extension-image'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$horizontal$2d$rule__$5b$external$5d$__$2840$tiptap$2f$extension$2d$horizontal$2d$rule$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@tiptap/extension-horizontal-rule [external] (@tiptap/extension-horizontal-rule, esm_import)");
(()=>{
    const e = new Error("Cannot find module '@tiptap/extension-text-align'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '@tiptap/extension-code-block-lowlight'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$externals$5d2f$lowlight__$5b$external$5d$__$28$lowlight$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/lowlight [external] (lowlight, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$react__$5b$external$5d$__$2840$tiptap$2f$react$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$starter$2d$kit__$5b$external$5d$__$2840$tiptap$2f$starter$2d$kit$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$link__$5b$external$5d$__$2840$tiptap$2f$extension$2d$link$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$horizontal$2d$rule__$5b$external$5d$__$2840$tiptap$2f$extension$2d$horizontal$2d$rule$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f$lowlight__$5b$external$5d$__$28$lowlight$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$react__$5b$external$5d$__$2840$tiptap$2f$react$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$starter$2d$kit__$5b$external$5d$__$2840$tiptap$2f$starter$2d$kit$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$link__$5b$external$5d$__$2840$tiptap$2f$extension$2d$link$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$horizontal$2d$rule__$5b$external$5d$__$2840$tiptap$2f$extension$2d$horizontal$2d$rule$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f$lowlight__$5b$external$5d$__$28$lowlight$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function StableTiptapEditor({ value, onChange, placeholder = 'Write your content here...' }) {
    const [showLinkDialog, setShowLinkDialog] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const [linkUrl, setLinkUrl] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])('');
    const [linkText, setLinkText] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])('');
    const [imageUrl, setImageUrl] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])('');
    const lowlight = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$lowlight__$5b$external$5d$__$28$lowlight$2c$__esm_import$29$__["createLowlight"])();
    const editor = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$react__$5b$external$5d$__$2840$tiptap$2f$react$2c$__esm_import$29$__["useEditor"])({
        extensions: [
            __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$starter$2d$kit__$5b$external$5d$__$2840$tiptap$2f$starter$2d$kit$2c$__esm_import$29$__["default"],
            Table.configure({
                resizable: true
            }),
            TableRow,
            TableHeader,
            TableCell,
            __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$link__$5b$external$5d$__$2840$tiptap$2f$extension$2d$link$2c$__esm_import$29$__["default"].configure({
                openOnClick: false
            }),
            Image,
            __TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$extension$2d$horizontal$2d$rule__$5b$external$5d$__$2840$tiptap$2f$extension$2d$horizontal$2d$rule$2c$__esm_import$29$__["default"],
            TextAlign.configure({
                types: [
                    'heading',
                    'paragraph'
                ]
            }),
            CodeBlockLowlight.configure({
                lowlight
            })
        ],
        content: value || '',
        immediatelyRender: false,
        editorProps: {
            attributes: {
                class: 'prose max-w-none min-h-[200px] px-4 py-3 focus:outline-none'
            }
        },
        onUpdate ({ editor }) {
            if (typeof onChange === 'function') {
                onChange(editor.getHTML());
            }
        }
    });
    const addLink = ()=>{
        if (linkUrl) {
            editor.chain().focus().setLink({
                href: linkUrl
            }).run();
            setShowLinkDialog(false);
            setLinkUrl('');
            setLinkText('');
        }
    };
    const addImage = ()=>{
        if (imageUrl) {
            editor.chain().focus().setImage({
                src: imageUrl
            }).run();
            setImageUrl('');
        }
    };
    const insertTable = ()=>{
        editor.chain().focus().insertTable({
            rows: 3,
            cols: 3,
            withHeaderRow: true
        }).run();
    };
    // Keep editor content in sync if "value" prop changes from outside
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if (!editor) return;
        const current = editor.getHTML();
        if (value != null && value !== current) {
            editor.commands.setContent(value, false);
        }
    }, [
        value,
        editor
    ]);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        return ()=>{
            if (editor) {
                editor.destroy();
            }
        };
    }, [
        editor
    ]);
    if (!editor) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "min-h-[200px] px-4 py-3 text-sm text-slate-500",
            children: "Loading editor..."
        }, void 0, false, {
            fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
            lineNumber: 106,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "border-t border-gray-200 bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "border-b border-gray-200 bg-gray-50 px-2 py-1 text-xs text-gray-500 flex items-center justify-between",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    children: "Rich text editor"
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                    lineNumber: 115,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                lineNumber: 114,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "border-b border-gray-200 bg-white p-2 flex gap-1 flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleBold().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('bold') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Bold"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 119,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleItalic().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('italic') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Italic"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleStrike().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('strike') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Strike"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 133,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleCode().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('code') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Code"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 140,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-px bg-gray-300 mx-1"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleHeading({
                                level: 1
                            }).run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('heading', {
                            level: 1
                        }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "H1"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 151,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleHeading({
                                level: 2
                            }).run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('heading', {
                            level: 2
                        }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "H2"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 158,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-px bg-gray-300 mx-1"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().setTextAlign('left').run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive({
                            textAlign: 'left'
                        }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Left"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 169,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().setTextAlign('center').run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive({
                            textAlign: 'center'
                        }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Center"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().setTextAlign('right').run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive({
                            textAlign: 'right'
                        }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Right"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 183,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-px bg-gray-300 mx-1"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 191,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleBulletList().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('bulletList') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Bullet List"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 194,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleOrderedList().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('orderedList') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Numbered List"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleBlockquote().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('blockquote') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Quote"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-px bg-gray-300 mx-1"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setShowLinkDialog(true),
                        className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                        children: "Link"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 219,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().toggleCodeBlock().run(),
                        className: `px-2 py-1 text-xs border rounded ${editor.isActive('codeBlock') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                        children: "Code Block"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 226,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().setHorizontalRule().run(),
                        className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                        children: "Divider"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 233,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: insertTable,
                        className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                        children: "Insert Table"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 240,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-px bg-gray-300 mx-1"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 248,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().undo().run(),
                        className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                        children: "Undo"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 251,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>editor.chain().focus().redo().run(),
                        className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                        children: "Redo"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 258,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            showLinkDialog && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "border-b border-gray-200 bg-gray-50 p-3 flex gap-2 items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                        type: "text",
                        placeholder: "Enter URL",
                        value: linkUrl,
                        onChange: (e)=>setLinkUrl(e.target.value),
                        className: "flex-1 px-2 py-1 text-xs border rounded"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 270,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: addLink,
                        className: "px-2 py-1 text-xs border rounded bg-blue-500 text-white hover:bg-blue-600",
                        children: "Add Link"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 277,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setShowLinkDialog(false),
                        className: "px-2 py-1 text-xs border rounded bg-gray-300 hover:bg-gray-400",
                        children: "Cancel"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 284,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                lineNumber: 269,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "border-b border-gray-200 bg-gray-50 p-2 flex gap-2 items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                        type: "text",
                        placeholder: "Enter image URL",
                        value: imageUrl,
                        onChange: (e)=>setImageUrl(e.target.value),
                        className: "flex-1 px-2 py-1 text-xs border rounded"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 296,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: addImage,
                        className: "px-2 py-1 text-xs border rounded bg-green-500 text-white hover:bg-green-600",
                        children: "Add Image"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 303,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                lineNumber: 295,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "min-h-[200px]",
                children: [
                    !value && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "px-4 pt-3 text-xs text-gray-400 select-none pointer-events-none",
                        children: placeholder
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 313,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f40$tiptap$2f$react__$5b$external$5d$__$2840$tiptap$2f$react$2c$__esm_import$29$__["EditorContent"], {
                        editor: editor
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 317,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                lineNumber: 311,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__88dacf64._.js.map