module.exports = [
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx'\n\nExpected '</', got '{'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [ssr] (ecmascript)"));
}),
];