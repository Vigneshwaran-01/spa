module.exports = [
"[externals]/aphrodite [external] (aphrodite, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("aphrodite", () => require("aphrodite"));

module.exports = mod;
}),
"[externals]/react-animations/lib/fade-in.js [external] (react-animations/lib/fade-in.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/fade-in.js", () => require("react-animations/lib/fade-in.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/slide-in-up.js [external] (react-animations/lib/slide-in-up.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/slide-in-up.js", () => require("react-animations/lib/slide-in-up.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/slide-in-down.js [external] (react-animations/lib/slide-in-down.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/slide-in-down.js", () => require("react-animations/lib/slide-in-down.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/tada.js [external] (react-animations/lib/tada.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/tada.js", () => require("react-animations/lib/tada.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/zoom-in-down.js [external] (react-animations/lib/zoom-in-down.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/zoom-in-down.js", () => require("react-animations/lib/zoom-in-down.js"));

module.exports = mod;
}),
"[externals]/react-animations/lib/slide-in-left.js [external] (react-animations/lib/slide-in-left.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-animations/lib/slide-in-left.js", () => require("react-animations/lib/slide-in-left.js"));

module.exports = mod;
}),
"[externals]/react-slick [external] (react-slick, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-slick", () => require("react-slick"));

module.exports = mod;
}),
"[project]/spam-cloud-25-11-25/pages/section/slider.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$slick__$5b$external$5d$__$28$react$2d$slick$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-slick [external] (react-slick, cjs)");
;
;
;
;
;
const ClientSlider = ()=>{
    // Settings for the first row (left to right)
    const settingsRow1 = {
        infinite: true,
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        speed: 5000,
        autoplaySpeed: 0,
        cssEase: "linear",
        arrows: false,
        pauseOnHover: false,
        rtl: false,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }
        ]
    };
    // Settings for the second row (right to left)
    const settingsRow2 = {
        infinite: true,
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        speed: 5000,
        autoplaySpeed: 0,
        cssEase: "linear",
        arrows: false,
        pauseOnHover: false,
        rtl: true,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    rtl: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    rtl: true
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    rtl: true
                }
            }
        ]
    };
    const logos = [
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496948/butterfly-logo_lihzni.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496948/mtutor_ax0010.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496947/imc-logo_gt8kwt.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496946/kshema_ivekpp.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496946/dahnay-logo_wnik6h.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496945/nccr-logo_ucqyqo.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496945/vcare-logo_w3muev.png",
        // "https://res.cloudinary.com/daggx9p24/image/upload/v1745496944/voltech-logo_bpdevu.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496914/efiling-logo_cnargm.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745496509/bonton-logo_rwl4lf.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745647539/hlf-services-logo_zi5nmc.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745647653/vcerp-logo_vouehe.png"
    ];
    const logos2 = [
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559668/marg_aamtoc.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559667/gro_b2ah8v.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559666/hhf_qqrolg.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559666/kingfa_rxzrmw.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559666/panimalar_bptaem.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559666/power_bwpxtm.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559665/ifluids_vnt9u9.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559665/sahara_x8parw.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559662/marg-logo_omqdhz.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559650/hoec-logo_py4wmy.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559650/jamal_mohamed_-logo_r8bx6a.png"
    ];
    const logos3 = [
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559665/rock_worth_m8q5qt.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559664/spl_udjjtm.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559664/tech_india_wntwyx.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559663/tvs_wftk3c.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559663/tnlp-logo_syybbk.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559663/velammal_mytbsr.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559663/vecura_h0gvgr.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559662/vasanth_tv_bjwec1.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559662/ashok_leyalnd_hrcwkc.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559650/makkal-logo_fod6pu.png",
        "https://res.cloudinary.com/daggx9p24/image/upload/v1745559650/vijaytv-logo_unqnnc.png"
    ];
    // Combine all logos for better distribution
    const allLogos = [
        ...logos,
        ...logos2,
        ...logos3
    ];
    const row1Logos = allLogos.slice(0, Math.ceil(allLogos.length / 2));
    const row2Logos = allLogos.slice(Math.ceil(allLogos.length / 2));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
        className: "w-full bg-[#011333] py-12 overflow-hidden",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "w-full space-y-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$slick__$5b$external$5d$__$28$react$2d$slick$2c$__cjs$29$__["default"], {
                        ...settingsRow1,
                        children: row1Logos.map((logo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "px-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "flex items-center p-3 justify-center  h-28 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden mx-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                                        src: logo,
                                        alt: `Client logo ${index + 1}`,
                                        className: "min-h-28 w-auto object-contain filter scale-[1.3]  hover:grayscale-0 transition-all duration-300",
                                        loading: "lazy"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                                        lineNumber: 135,
                                        columnNumber: 37
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                                    lineNumber: 134,
                                    columnNumber: 33
                                }, ("TURBOPACK compile-time value", void 0))
                            }, `row1-${index}`, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                                lineNumber: 133,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                        lineNumber: 131,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                    lineNumber: 130,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$slick__$5b$external$5d$__$28$react$2d$slick$2c$__cjs$29$__["default"], {
                        ...settingsRow2,
                        children: row2Logos.map((logo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "px-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "flex items-center p-3 justify-center h-28 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow overflow-hidden p-2 duration-300 mx-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                                        src: logo,
                                        alt: `Client logo ${index + 1}`,
                                        className: "min-h-28 object-contain filter scale-[1.3]  hover:grayscale-0 transition-all duration-300",
                                        loading: "lazy"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                                        lineNumber: 153,
                                        columnNumber: 37
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                                    lineNumber: 152,
                                    columnNumber: 33
                                }, ("TURBOPACK compile-time value", void 0))
                            }, `row2-${index}`, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                                lineNumber: 151,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                        lineNumber: 149,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
                    lineNumber: 148,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
            lineNumber: 128,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/spam-cloud-25-11-25/pages/section/slider.jsx",
        lineNumber: 114,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ClientSlider;
}),
"[externals]/react-dom [external] (react-dom, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-dom", () => require("react-dom"));

module.exports = mod;
}),
"[externals]/framer-motion [external] (framer-motion, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("framer-motion");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "AnimatedTooltip",
    ()=>AnimatedTooltip
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/framer-motion [external] (framer-motion, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"use client";
;
;
;
;
const AnimatedTooltip = ({ items, onHover })=>{
    const [hoveredIndex, setHoveredIndex] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(null);
    const springConfig = {
        stiffness: 100,
        damping: 5
    };
    const x = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["useMotionValue"])(0);
    const rotate = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["useSpring"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["useTransform"])(x, [
        -100,
        100
    ], [
        -45,
        45
    ]), springConfig);
    const translateX = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["useSpring"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["useTransform"])(x, [
        -100,
        100
    ], [
        -50,
        50
    ]), springConfig);
    const handleMouseMove = (event)=>{
        const halfWidth = event.target.offsetWidth / 2;
        x.set(event.nativeEvent.offsetX - halfWidth);
    };
    const handleHover = (id)=>{
        setHoveredIndex(id);
        if (onHover) {
            onHover(id);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: items.map((item, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "-mr-4 relative group",
                onMouseEnter: ()=>handleHover(item.id),
                onMouseLeave: ()=>handleHover(null),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        onMouseMove: handleMouseMove,
                        height: 100,
                        width: 100,
                        src: item.image,
                        alt: item.name,
                        className: "object-cover !m-0 !p-0 object-top rounded-full h-14 w-14 border-2 group-hover:scale-105 group-hover:z-30 border-white relative transition duration-500"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                        lineNumber: 42,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["AnimatePresence"], {
                        mode: "popLayout",
                        children: hoveredIndex === item.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$framer$2d$motion__$5b$external$5d$__$28$framer$2d$motion$2c$__esm_import$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                y: -20,
                                scale: 0.6
                            },
                            animate: {
                                opacity: 1,
                                y: 0,
                                scale: 1,
                                transition: {
                                    type: "spring",
                                    stiffness: 260,
                                    damping: 10
                                }
                            },
                            exit: {
                                opacity: 0,
                                y: -20,
                                scale: 0.6
                            },
                            style: {
                                translateX: translateX,
                                rotate: rotate,
                                whiteSpace: "nowrap"
                            },
                            className: "absolute top-full mt-2 -left-1/2 translate-x-1/2 flex text-xs flex-col items-center rounded-md bg-black z-50 shadow-xl px-4 py-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-x-10 top-0 z-30 w-[20%] -top-px bg-gradient-to-r from-transparent via-emerald-500 to-transparent h-px"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                                    lineNumber: 71,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "absolute left-10 top-0 w-[40%] z-30 -top-px bg-gradient-to-r from-transparent via-sky-500 to-transparent h-px"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                                    lineNumber: 72,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "font-bold text-white relative z-30 text-base",
                                    children: item.name
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                                    lineNumber: 73,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "text-white text-xs",
                                    children: item.designation
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                                    lineNumber: 76,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                            lineNumber: 52,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                        lineNumber: 50,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, item.name, true, {
                fileName: "[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx",
                lineNumber: 37,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)))
    }, void 0, false);
};
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/spam-cloud-25-11-25/lib/data/testi.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "people",
    ()=>people
]);
const people = [
    {
        id: 1,
        name: "Sethu Murugan",
        designation: "Hinduja Leyland",
        image: "https://res.cloudinary.com/daggx9p24/image/upload/v1745822051/Sethu_Murugan_pye7z1.png",
        testimonial: "Our e-commerce site had growth only after installing SSL certification. They give you complete guidance right from installation to changing the site into HTTPS."
    },
    // {
    //   id: 2,
    //   name: "Anitha",
    //   designation: "Bhoomi and Buildings Pvt Ltd",
    //   image:
    //     "https://res.cloudinary.com/daggx9p24/image/upload/v1736167400/patient_alrgfg.png",
    //     testimonial: "We used to get flooded with spam daily. Ever since we switched to this filter,  Total game-changer!"
    // },
    {
        id: 3,
        name: "Chalapathirao Sajjarao",
        designation: "ROCKWORTH",
        image: "https://res.cloudinary.com/daggx9p24/image/upload/v1745822051/Chalapathirao_Sajjarao_v3jp3v.png",
        testimonial: "A distinct and cost-effective solution can be acquired here. It is sure that your dedicated server will be power-packed with resources that have outperforming features."
    },
    {
        id: 4,
        name: "Balu",
        designation: "Makkal TV",
        image: "https://res.cloudinary.com/daggx9p24/image/upload/v1745822051/Balu_myr3m5.png",
        testimonial: "We received our VPS hosting at a reasonable cost on the requested date. They consistently deliver the services on schedule."
    },
    {
        id: 5,
        name: "Manikandan",
        designation: "Chrysalis Homeneeds Pvt. Ltd.",
        image: "https://res.cloudinary.com/daggx9p24/image/upload/v1745822051/Manikandan_zusqiw.png",
        testimonial: "Professional guidance with unlimited resource availability. They allow you to easily scale the service at any time."
    },
    {
        id: 6,
        name: "Richard",
        designation: "Shankara Building Products Ltd.",
        image: "https://res.cloudinary.com/daggx9p24/image/upload/v1745822052/Richard_i420sn.png",
        testimonial: "Lower or increase your cloud storage based on your requirement since their service is redundant and flexible payment is available."
    }
];
}),
"[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactSec
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
;
;
function ContactSec() {
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])({
        Fname: '',
        Lname: '',
        email: '',
        phone: '',
        message: ''
    });
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const handleChange = (e)=>{
        const { name, value } = e.target;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const onSubmit = async (e)=>{
        e.preventDefault();
        setIsLoading(true);
        try {
            const response = await fetch('/api/submit-contact-form', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            if (!response.ok) throw new Error('Submission failed');
            alert('Form submitted successfully!');
            setFormData({
                Fname: '',
                Lname: '',
                email: '',
                phone: '',
                message: ''
            });
        } catch (error) {
            console.error('Error:', error);
            alert('Submission failed. Please try again.');
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "bg-gradient-to-r from-[#011333] to-[#011333] text-white py-16 ",
        id: "contactForm",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                    className: "text-3xl font-bold text-center mb-6",
                    children: "Get In Touch With our Anti Spam Experts"
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "grid md:grid-cols-2 gap-6 bg-white p-2 rounded-lg shadow-lg",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "hidden md:flex justify-center items-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                                src: "https://res.cloudinary.com/daggx9p24/image/upload/v1741238633/mail-sent-concept-illustration_rzzfkp.png",
                                alt: "Contact Illustration",
                                className: "w-80"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("form", {
                            onSubmit: onSubmit,
                            className: "p-3 rounded-xl",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "space-y-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-2 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "Fname",
                                                placeholder: "First Name",
                                                className: "p-3 border border-gray-700 rounded-lg text-gray-600 w-full bg-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition duration-300 ease-in-out",
                                                value: formData.Fname,
                                                onChange: handleChange,
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                                lineNumber: 59,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "Lname",
                                                placeholder: "Last Name",
                                                className: "p-3 border border-gray-700 rounded-lg text-gray-600 w-full bg-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition duration-300 ease-in-out",
                                                value: formData.Lname,
                                                onChange: handleChange,
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                                lineNumber: 68,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                        lineNumber: 58,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-2 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                                type: "email",
                                                name: "email",
                                                placeholder: "Email Address",
                                                className: "p-3 border border-gray-700 rounded-lg text-gray-600 w-full bg-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition duration-300 ease-in-out",
                                                value: formData.email,
                                                onChange: handleChange,
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                                lineNumber: 80,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                name: "phone",
                                                placeholder: "Phone No.",
                                                className: "p-3 border border-gray-700 rounded-lg text-gray-600 w-full bg-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition duration-300 ease-in-out",
                                                value: formData.phone,
                                                onChange: handleChange,
                                                required: true
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                                lineNumber: 89,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                        lineNumber: 79,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("textarea", {
                                        name: "message",
                                        placeholder: "Message",
                                        className: "p-3 border border-gray-700 rounded-lg text-gray-600 w-full bg-gray-200 h-28 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none transition duration-300 ease-in-out",
                                        value: formData.message,
                                        onChange: handleChange,
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                        lineNumber: 100,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        className: "bg-blue-600 text-white px-6 py-3 rounded-lg w-full hover:bg-blue-500 hover:shadow-lg hover:shadow-blue-500/50 transition duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50",
                                        disabled: isLoading,
                                        children: isLoading ? 'Sending...' : 'Send'
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                        lineNumber: 109,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                                lineNumber: 57,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
            lineNumber: 44,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
}),
"[externals]/swiper/react [external] (swiper/react, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("swiper/react");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/swiper/modules [external] (swiper/modules, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("swiper/modules");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

// Optimized Blogslider with performance best practices
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$react__$5b$external$5d$__$28$swiper$2f$react$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/swiper/react [external] (swiper/react, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$modules__$5b$external$5d$__$28$swiper$2f$modules$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/swiper/modules [external] (swiper/modules, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/link.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$react__$5b$external$5d$__$28$swiper$2f$react$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$modules__$5b$external$5d$__$28$swiper$2f$modules$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$react__$5b$external$5d$__$28$swiper$2f$react$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$modules__$5b$external$5d$__$28$swiper$2f$modules$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
;
;
;
;
;
;
// Optimized loading skeleton component
const BlogCardSkeleton = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-2xl overflow-hidden border border-slate-200 animate-pulse",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "w-full h-56 bg-slate-200"
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 14,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "p-6 space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "h-6 w-20 bg-slate-200 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                            lineNumber: 17,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 16,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "h-6 bg-slate-200 rounded w-3/4"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                lineNumber: 20,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "h-6 bg-slate-200 rounded w-1/2"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                lineNumber: 21,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 19,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "h-4 bg-slate-200 rounded w-24"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 23,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-slate-200 rounded"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                lineNumber: 25,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-slate-200 rounded w-5/6"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                lineNumber: 26,
                                columnNumber: 9
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 24,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "h-8 bg-slate-200 rounded w-24"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 28,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 15,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
        lineNumber: 13,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
function Blogslider() {
    const [posts, setPosts] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        let isMounted = true;
        async function fetchPosts() {
            try {
                const res = await fetch('/api/blogslider', {
                    headers: {
                        'Accept': 'application/json',
                        'Cache-Control': 'max-age=300' // 5 minutes cache
                    }
                });
                if (!res.ok) throw new Error('Failed to fetch');
                const data = await res.json();
                if (isMounted) {
                    setPosts(data.posts || []);
                    setError(null);
                }
            } catch (error) {
                console.error('Failed to fetch posts:', error);
                if (isMounted) {
                    setError(error.message);
                }
            } finally{
                if (isMounted) {
                    setLoading(false);
                }
            }
        }
        fetchPosts();
        return ()=>{
            isMounted = false;
        };
    }, []);
    // Memoized date formatter for performance
    const formatDate = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useCallback"])((dateString)=>{
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        return new Date(dateString).toLocaleDateString('en-US', options);
    }, []);
    // Memoized category extraction
    const getCategoryFromTitle = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useCallback"])((title)=>{
        if (title.toLowerCase().includes('security')) return 'Email Security';
        if (title.toLowerCase().includes('spam')) return 'Spam Protection';
        if (title.toLowerCase().includes('ssl')) return 'Web Security';
        return 'Technology';
    }, []);
    // Memoized swiper configuration
    const swiperConfig = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useMemo"])(()=>({
            modules: [
                __TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$modules__$5b$external$5d$__$28$swiper$2f$modules$2c$__esm_import$29$__["Navigation"],
                __TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$modules__$5b$external$5d$__$28$swiper$2f$modules$2c$__esm_import$29$__["Pagination"]
            ],
            spaceBetween: 32,
            navigation: {
                nextEl: '.blog-swiper-button-next',
                prevEl: '.blog-swiper-button-prev'
            },
            pagination: {
                clickable: true,
                dynamicBullets: true,
                el: '.blog-swiper-pagination'
            },
            speed: 600,
            breakpoints: {
                0: {
                    slidesPerView: 1
                },
                768: {
                    slidesPerView: 2
                },
                1024: {
                    slidesPerView: 3
                }
            }
        }), []);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "w-full",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8",
                children: [
                    ...Array(3)
                ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(BlogCardSkeleton, {}, i, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 117,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 115,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
            lineNumber: 114,
            columnNumber: 7
        }, this);
    }
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center py-16",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                            className: "w-8 h-8 text-red-500",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                lineNumber: 130,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                            lineNumber: 129,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 128,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold text-gray-900 mb-2",
                        children: "Unable to load blog posts"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 133,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                        className: "text-gray-600",
                        children: "Please try again later"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 134,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 127,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
            lineNumber: 126,
            columnNumber: 7
        }, this);
    }
    if (!posts.length) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center py-16",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                            className: "w-8 h-8 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                lineNumber: 146,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                            lineNumber: 145,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 144,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold text-gray-900 mb-2",
                        children: "No blog posts available"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 149,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                        className: "text-gray-600",
                        children: "Check back soon for new content"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 150,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 143,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
            lineNumber: 142,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "relative w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$react__$5b$external$5d$__$28$swiper$2f$react$2c$__esm_import$29$__["Swiper"], {
                ...swiperConfig,
                className: "!pb-12 swiper-equal-height",
                children: posts.map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$swiper$2f$react__$5b$external$5d$__$28$swiper$2f$react$2c$__esm_import$29$__["SwiperSlide"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("article", {
                            className: "bg-white rounded-2xl overflow-hidden border border-slate-200 hover:border-blue-200 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 h-full group flex flex-col",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "relative h-56 overflow-hidden bg-slate-100",
                                    children: [
                                        post.featured_image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            src: post.featured_image,
                                            alt: post.title,
                                            fill: true,
                                            sizes: "(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw",
                                            className: "object-cover transition-transform duration-300 group-hover:scale-105",
                                            priority: false,
                                            loading: "lazy",
                                            onError: (e)=>{
                                                e.target.style.display = 'none';
                                                e.target.nextSibling.style.display = 'flex';
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                            lineNumber: 165,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "w-full h-full bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                className: "w-12 h-12 text-slate-400",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 1.5,
                                                    d: "M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                                    lineNumber: 181,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                                lineNumber: 180,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                            lineNumber: 179,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "absolute top-4 left-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                className: "inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-500 text-white shadow-lg",
                                                children: getCategoryFromTitle(post.title)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                                lineNumber: 188,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                            lineNumber: 187,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                    lineNumber: 163,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "p-6 flex flex-col flex-grow",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 mb-3",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("time", {
                                                className: "text-sm font-medium text-slate-500",
                                                dateTime: post.created_at,
                                                children: formatDate(post.created_at)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                                lineNumber: 197,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                            lineNumber: 196,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                            className: "text-xl font-bold text-slate-900 mb-3 line-clamp-2 group-hover:text-blue-600 transition-colors duration-200",
                                            children: post.title
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                            lineNumber: 202,
                                            columnNumber: 17
                                        }, this),
                                        post.excerpt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                            className: "text-slate-600 text-sm leading-relaxed mb-4 line-clamp-3",
                                            children: post.excerpt
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                            lineNumber: 207,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: `/blog/${post.slug}`,
                                            className: "inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 font-semibold text-sm transition-colors duration-200 group/link mt-auto",
                                            prefetch: false,
                                            children: [
                                                "READ MORE",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                    className: "w-4 h-4 transition-transform duration-200 group-hover/link:translate-x-1",
                                                    fill: "none",
                                                    stroke: "currentColor",
                                                    viewBox: "0 0 24 24",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        strokeWidth: 2,
                                                        d: "M9 5l7 7-7 7"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                                        lineNumber: 219,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                                    lineNumber: 218,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                            lineNumber: 212,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                                    lineNumber: 195,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                            lineNumber: 161,
                            columnNumber: 13
                        }, this)
                    }, post.id, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 158,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "blog-swiper-button-prev absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-10 h-10 bg-white rounded-full shadow-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:text-blue-600 hover:border-blue-200 transition-all duration-200 cursor-pointer",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M15 19l-7-7 7-7"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 231,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                    lineNumber: 230,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 229,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "blog-swiper-button-next absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-10 h-10 bg-white rounded-full shadow-lg border border-slate-200 flex items-center justify-center text-slate-600 hover:text-blue-600 hover:border-blue-200 transition-all duration-200 cursor-pointer",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M9 5l7 7-7 7"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                        lineNumber: 237,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                    lineNumber: 236,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 235,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "blog-swiper-pagination flex justify-center mt-8"
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
                lineNumber: 242,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx",
        lineNumber: 157,
        columnNumber: 5
    }, this);
}
const __TURBOPACK__default__export__ = Blogslider;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/spam-cloud-25-11-25/lib/data/schema.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// home page schema
__turbopack_context__.s([
    "AcceptableUsePolicySchema",
    ()=>AcceptableUsePolicySchema,
    "PrivacyPolicySchema",
    ()=>PrivacyPolicySchema,
    "TermsOfServiceSchema",
    ()=>TermsOfServiceSchema,
    "aboutSchema",
    ()=>aboutSchema,
    "blogSchema",
    ()=>blogSchema,
    "clientSchema",
    ()=>clientSchema,
    "contactSchema",
    ()=>contactSchema,
    "homeSchema",
    ()=>homeSchema,
    "incomingSpamFilterSchema",
    ()=>incomingSpamFilterSchema,
    "outgoingSpamFilterSchema",
    ()=>outgoingSpamFilterSchema
]);
const homeSchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam,",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        }
    },
    {
        "@context": "https://schema.org",
        "@type": "Corporation",
        "name": "Spam Cloud",
        "alternateName": "Spam Cloud",
        "url": "https://spamcloud.in",
        "logo": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png"
    }
];
const aboutSchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in/about",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressRegion": "Tamil Nadu",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        },
        "description": "get to know about how Spam Cloud's incoming and outgoing spam filters protect your inbox from junk emails and phishing threats and enhance email security."
    }
];
const AcceptableUsePolicySchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in/acceptable-use-policy",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressRegion": "Tamil Nadu",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        },
        "description": "Discover how Spam Cloud's filters shield your inbox from spam and phishing, fortifying your email security. Learn more in our Acceptable Use Policy."
    }
];
const clientSchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in/client",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressRegion": "Tamil Nadu",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        },
        "description": "Examine how our clients benefit and get value from using Spam Cloud services to meet their email security requirements. contact us today to get the best offer."
    }
];
const blogSchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in/blog",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressRegion": "Tamil Nadu",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        },
        "description": "Read the latest blog posts from Spam Cloud on email security, spam protection, and digital safety tips."
    },
    {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": "Blog - Spam Cloud",
        "url": "https://spamcloud.in/blog",
        "description": "Read the latest blog posts from Spam Cloud on email security, spam protection, and digital safety tips.",
        "publisher": {
            "@type": "Organization",
            "name": "Spam Cloud",
            "url": "https://spamcloud.in",
            "logo": {
                "@type": "ImageObject",
                "url": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png"
            }
        }
    }
];
const contactSchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in/contact",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressRegion": "Tamil Nadu",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        },
        "description": "Reach out to Spam Cloud today to secure your inbox effectively and protect it from spam emails and cyber threats. Contact us now for unparalleled email security"
    }
];
const PrivacyPolicySchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in/privacy-policy",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressRegion": "Tamil Nadu",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        },
        "description": "Protect your inbox from spam with Spam Cloud's reliable filters. Find out more about our privacy policy and how we safeguard your data."
    }
];
const TermsOfServiceSchema = [
    {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Spam Cloud",
        "image": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png",
        "@id": "https://spamcloud.in/privacy-policy",
        "url": "https://spamcloud.in",
        "telephone": "(044) 43869199",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Sixth Star Technologies, Siri Towers, 1st Floor, No.3 & 4, Fourrts Avenue, Annai Indira Nagar, Thoraipakkam",
            "addressLocality": "Chennai",
            "postalCode": "600097",
            "addressRegion": "Tamil Nadu",
            "addressCountry": "IN"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": 12.9294261,
            "longitude": 80.2334966
        },
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday"
            ],
            "opens": "09:30",
            "closes": "18:30"
        },
        "description": "Protect your inbox from spam with Spam Cloud's reliable filters. Find out more about our privacy policy and how we safeguard your data."
    }
];
const incomingSpamFilterSchema = [
    {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": "Incoming Spam Filter - Spam Cloud",
        "url": "https://spamcloud.in/incoming-spam-filter-service-provider-chennai",
        "description": "Spam Cloud provides a reliable incoming spam filter service in Chennai, designed to protect your inbox from unwanted emails and cyber threats effectively.",
        "publisher": {
            "@type": "Organization",
            "name": "Spam Cloud",
            "url": "https://spamcloud.in/services/incoming-spam-filter-service-provider-chennai",
            "logo": {
                "@type": "ImageObject",
                "url": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png"
            }
        }
    },
    {
        "@context": "https://schema.org",
        "@type": "Service",
        "name": "Incoming Spam Filter",
        "provider": {
            "@type": "Organization",
            "name": "Spam Cloud",
            "url": "https://spamcloud.in/services/incoming-spam-filter-service-provider-chennai"
        },
        "serviceType": "Email Filtering Service",
        "areaServed": {
            "@type": "Country",
            "name": "India"
        },
        "description": "Spam Cloud provides a reliable incoming spam filter service in Chennai, designed to protect your inbox from unwanted emails and cyber threats effectively."
    },
    {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "What is an Incoming Spam Filter?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "An Incoming Spam Filter blocks unwanted emails like spam, phishing attempts, and viruses before they reach your inbox."
                }
            },
            {
                "@type": "Question",
                "name": "How does Spam Cloud's filter work?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Spam Cloud uses advanced filtering algorithms to scan and block malicious or unsolicited emails before they hit your mail server."
                }
            },
            {
                "@type": "Question",
                "name": "Do I need to install software?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "No installation is required. Spam Cloud filters emails in the cloud before delivery to your mail server."
                }
            }
        ]
    }
];
const outgoingSpamFilterSchema = [
    {
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": "Outgoing Spam Filter - Spam Cloud",
        "url": "https://spamcloud.in/services/outgoing-spam-filter-service-provider-chennai",
        "description": "Spam Cloud offers efficient outgoing spam filter services in Chennai to safeguard your emails and enhance security from external threads and fishing attacks.",
        "publisher": {
            "@type": "Organization",
            "name": "Spam Cloud",
            "url": "https://spamcloud.in",
            "logo": {
                "@type": "ImageObject",
                "url": "https://res.cloudinary.com/daggx9p24/image/upload/v1729667110/SPAM_CLOUD_tuomse.png"
            }
        }
    },
    {
        "@context": "https://schema.org",
        "@type": "Service",
        "name": "Outgoing Spam Filter",
        "provider": {
            "@type": "Organization",
            "name": "Spam Cloud",
            "url": "https://spamcloud.in/services/outgoing-spam-filter-service-provider-chennai"
        },
        "serviceType": "Email Outbound Filtering",
        "areaServed": {
            "@type": "Country",
            "name": "India"
        },
        "description": "Spam Cloud offers efficient outgoing spam filter services in Chennai to safeguard your emails and enhance security from external threads and fishing attacks."
    },
    {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": "What is an Outgoing Spam Filter?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "An Outgoing Spam Filter ensures that emails sent from your server are clean and not flagged as spam, protecting your reputation and deliverability."
                }
            },
            {
                "@type": "Question",
                "name": "Why do I need outgoing filtering?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "It prevents accidental spam or malware from being sent out of your network, which could lead to blacklisting of your domain or IP address."
                }
            },
            {
                "@type": "Question",
                "name": "Will it slow down my emails?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "No, the filter works in real-time with minimal delay, ensuring fast and secure email delivery."
                }
            }
        ]
    }
];
}),
"[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/react-icons/fi/index.mjs [ssr] (ecmascript)");
;
;
;
;
const ProofpointCarousel = ()=>{
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(0);
    const carouselTrackRef = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useRef"])(null);
    const [isTransitioning, setIsTransitioning] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const cards = [
        {
            type: 'story',
            content: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                        children: "Numbers only ever tell part of the story."
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/contact",
                        className: "proofpoint-cta-link",
                        children: [
                            "See customer stories ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                className: "fa-solid fa-arrow-right"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                                lineNumber: 17,
                                columnNumber: 34
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                        lineNumber: 16,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true)
        },
        {
            type: 'stat',
            badge: 'STOPPING',
            number: '200k',
            label: 'BEC attacks per year'
        },
        {
            type: 'stat',
            badge: 'PROTECTING',
            number: '25k+',
            label: 'customers worldwide'
        },
        {
            type: 'stat',
            badge: 'SECURING',
            number: '83',
            label: 'of the F100 use our solutions'
        }
    ];
    const currentSlide = (index)=>{
        if (isTransitioning) return;
        setIsTransitioning(true);
        // Ensure index is within bounds
        const newIndex = (index + cards.length) % cards.length;
        setCurrentIndex(newIndex);
        setTimeout(()=>{
            setIsTransitioning(false);
            if (carouselTrackRef.current) {
                const card = carouselTrackRef.current.children[0];
                const cardWidth = card?.offsetWidth || 0;
                carouselTrackRef.current.scrollTo({
                    left: cardWidth * newIndex,
                    behavior: "smooth"
                });
            }
        }, 100);
    };
    const nextSlide = ()=>{
        currentSlide(currentIndex + 1);
    };
    const prevSlide = ()=>{
        currentSlide(currentIndex - 1);
    };
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if (carouselTrackRef.current) {
            const card = carouselTrackRef.current.children[0];
            const cardWidth = card?.offsetWidth || 0;
            carouselTrackRef.current.scrollTo({
                left: cardWidth * currentIndex,
                behavior: "smooth"
            });
        }
    }, [
        currentIndex
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "col-lg-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "proofpoint-carousel-container relative overflow-hidden",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                    onClick: prevSlide,
                    className: "absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white text-gray-800 p-2 rounded-full shadow-md hover:shadow-lg transition-all duration-300 ml-2",
                    "aria-label": "Previous slide",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                        className: "h-5 w-5"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                        lineNumber: 91,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                    lineNumber: 86,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                    onClick: nextSlide,
                    className: "absolute right-0  top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white text-gray-800 p-2 rounded-full shadow-md hover:shadow-lg transition-all duration-300 mr-2",
                    "aria-label": "Next slide",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["FiChevronRight"], {
                        className: "h-5 w-5"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                        lineNumber: 99,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "carousel-wrapper relative",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        ref: carouselTrackRef,
                        className: "carousel-track flex transition-all duration-500 ease-in-out overflow-hidden",
                        id: "carouselTrack",
                        children: cards.map((card, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: `proofpoint-carousel-card flex-shrink-0 w-full sm:w-[40%] md:w-[80%] lg:w-[60%] px-4 ${card.type === 'stat' ? 'stat-card' : ''} ${index === currentIndex ? 'active' : ''}`,
                                style: {
                                    filter: index !== currentIndex ? 'blur(5px)' : 'none',
                                    opacity: index !== currentIndex ? 0.5 : 1,
                                    transition: 'filter 0.5s ease, opacity 0.5s ease'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "card-content",
                                    children: card.type === 'story' ? card.content : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "stat-badge",
                                                children: card.badge
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                                                lineNumber: 125,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                                className: "stat-number",
                                                children: card.number
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                                                lineNumber: 126,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                className: "stat-label",
                                                children: card.label
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                                                lineNumber: 127,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true)
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                                    lineNumber: 120,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, index, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                                lineNumber: 109,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
            lineNumber: 84,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx",
        lineNumber: 83,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ProofpointCarousel;
}),
"[project]/spam-cloud-25-11-25/components/SantaAnimation.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$jsx$2f$style$2e$js__$5b$external$5d$__$28$styled$2d$jsx$2f$style$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/styled-jsx/style.js [external] (styled-jsx/style.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
'use client';
;
;
;
const SantaAnimation = ()=>{
    const [isClient, setIsClient] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        setIsClient(true);
    }, []);
    if (!isClient) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        style: {
            position: 'fixed',
            top: '15%',
            left: '-200px',
            zIndex: 999,
            pointerEvents: 'none',
            animation: 'santa-ride 12s linear ',
            animationIterationCount: 4
        },
        className: "jsx-ff759c07f609f509",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                src: "/Pngtreesanta.png",
                alt: "Santa Claus",
                style: {
                    width: '150px',
                    height: '100px',
                    objectFit: 'contain'
                },
                className: "jsx-ff759c07f609f509"
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/components/SantaAnimation.jsx",
                lineNumber: 27,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$jsx$2f$style$2e$js__$5b$external$5d$__$28$styled$2d$jsx$2f$style$2e$js$2c$__cjs$29$__["default"], {
                id: "ff759c07f609f509",
                children: "@keyframes santa-ride{0%{opacity:0;transform:translate(0)translateY(0)}5%{opacity:1}25%{transform:translate(25vw)translateY(-20px)}50%{transform:translate(50vw)translateY(20px)}75%{transform:translate(75vw)translateY(-15px)}95%{opacity:1}to{opacity:0;transform:translate(calc(100vw + 400px))translateY(0)}}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/spam-cloud-25-11-25/components/SantaAnimation.jsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = SantaAnimation;
}),
"[project]/spam-cloud-25-11-25/pages/index.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>New
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$head$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/head.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$aphrodite__$5b$external$5d$__$28$aphrodite$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/aphrodite [external] (aphrodite, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/fade-in.js [external] (react-animations/lib/fade-in.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/slide-in-up.js [external] (react-animations/lib/slide-in-up.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/slide-in-down.js [external] (react-animations/lib/slide-in-down.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$tada$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$tada$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/tada.js [external] (react-animations/lib/tada.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/zoom-in-down.js [external] (react-animations/lib/zoom-in-down.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-animations/lib/slide-in-left.js [external] (react-animations/lib/slide-in-left.js, cjs)"); // Importing zoomInDown
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$slider$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/pages/section/slider.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$ui$2f$animated$2d$tooltip$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/components/ui/animated-tooltip.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$data$2f$testi$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/lib/data/testi.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$ContactSec$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/pages/section/ContactSec.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$Blogslider$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/pages/section/Blogslider.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$data$2f$schema$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/lib/data/schema.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$ProofpointCarousel$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/pages/section/ProofpointCarousel.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2d$check$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MailCheck$3e$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/lucide-react/dist/esm/icons/mail-check.js [ssr] (ecmascript) <export default as MailCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2d$open$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MailOpen$3e$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/lucide-react/dist/esm/icons/mail-open.js [ssr] (ecmascript) <export default as MailOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$SantaAnimation$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/components/SantaAnimation.jsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$ui$2f$animated$2d$tooltip$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$Blogslider$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$ui$2f$animated$2d$tooltip$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$Blogslider$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const styles = __TURBOPACK__imported__module__$5b$externals$5d2f$aphrodite__$5b$external$5d$__$28$aphrodite$2c$__cjs$29$__["StyleSheet"].create({
    fadeIn: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$fade$2d$in$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '2s'
    },
    slideInUp: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$up$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '2s'
    },
    slideInDown: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$down$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '2s'
    },
    tada: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$tada$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$tada$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '15s'
    },
    zoomInDown: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$zoom$2d$in$2d$down$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '4s'
    },
    slideInLeft: {
        animationName: __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js__$5b$external$5d$__$28$react$2d$animations$2f$lib$2f$slide$2d$in$2d$left$2e$js$2c$__cjs$29$__["default"],
        animationDuration: '4s'
    }
});
function New({ homeData, error }) {
    const [activeTestimonial, setActiveTestimonial] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$data$2f$testi$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["people"][0].testimonial);
    const [isClient, setIsClient] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const [currentSlideIndex, setCurrentSlideIndex] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(1);
    const [isPaused, setIsPaused] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        setIsClient(true);
    }, []);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        const track = document.getElementById('carouselTrack');
        if (track) {
            const translateX = (currentSlideIndex - 1) * -340; // 320px card width + 20px gap
            track.style.transform = `translateX(${translateX}px)`;
            const dots = document.querySelectorAll('.dot');
            dots.forEach((dot, index)=>{
                dot.classList.toggle('active', index === currentSlideIndex - 1);
            });
        }
    }, [
        currentSlideIndex
    ]);
    const currentSlide = (n)=>{
        setCurrentSlideIndex(n);
    };
    const handleMouseEnter = ()=>{
        setIsPaused(true);
    };
    const handleMouseLeave = ()=>{
        setIsPaused(false);
    };
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            children: "Error loading data"
        }, void 0, false, {
            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
            lineNumber: 125,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$components$2f$SantaAnimation$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 131,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$head$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("title", {
                        children: "Email Security Service Provider | Spamcloud "
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 133,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        name: "description",
                        content: "SpamCloud Email Security Services protects your information, prevents financial fraud, and maintains organizational trust with an intrusion prevention service"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 134,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("link", {
                        rel: "canonical",
                        href: "https://spamcloud.in"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 136,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        property: "og:locale",
                        content: "en_US"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 137,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        property: "og:type",
                        content: "website"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 138,
                        columnNumber: 2
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        property: "og:title",
                        content: "Anti spam cloud Service Provider in Chennai | Spam Cloud"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 139,
                        columnNumber: 2
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        property: "og:description",
                        content: "SpamCloud Email Security Services protects your information, prevents financial fraud, and maintains organizational trust with an intrusion prevention service"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 140,
                        columnNumber: 2
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        property: "og:url",
                        content: "https://spamcloud.in"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 141,
                        columnNumber: 2
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("meta", {
                        property: "og:site_name",
                        content: "Sixth Star Technologies"
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 142,
                        columnNumber: 2
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$lib$2f$data$2f$schema$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["homeSchema"])
                        }
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 143,
                        columnNumber: 3
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 132,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "relative h-screen overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-cover bg-center bg-no-repeat",
                        style: {
                            backgroundImage: 'url("https://res.cloudinary.com/daggx9p24/image/upload/v1728965707/884_zbmo91.jpg")'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "absolute inset-0 bg-[#0c1221]/90"
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 159,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 152,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 opacity-20",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "absolute inset-0",
                            style: {
                                backgroundImage: `
              linear-gradient(rgba(34, 197, 94, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(34, 197, 94, 0.1) 1px, transparent 1px)
            `,
                                backgroundSize: '50px 50px',
                                animation: 'grid-move 20s linear infinite'
                            }
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "absolute w-full h-1 bg-gradient-to-r  to-transparent opacity-60 animate-scan"
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 178,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 177,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "h-full flex relative z-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "w-full lg:w-1/2 flex items-center justify-start px-6 lg:px-16 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "w-full max-w-2xl",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                                                className: "text-4xl lg:text-10xl xl:text-6xl font-bold mb-6 leading-tight text-left relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                        className: "  text-white  text-transparent",
                                                        children: "Protect Your Business"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 193,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 196,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                        className: "text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-slate-400",
                                                        children: "With Our Advanced"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 197,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 200,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                        className: "text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300",
                                                        children: "Email Protection"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 201,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 192,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                className: "text-lg lg:text-xl ml-2 text-gray-300 mb-8 leading-relaxed max-w-lg font-light",
                                                children: "SpamCloud Protects and Maintains Your Organizational Trust with Advanced Email Security Solutions"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 209,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col sm:flex-row gap-4 mb-6",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "#contactForm",
                                                        className: `group relative inline-flex items-center justify-center bg-blue-600 hover:bg-blue-500 text-white  px-6 py-3 rounded-full font-bold text-base transition-all duration-300  hover:-translate-y-1 overflow-hidden ${isClient ? (0, __TURBOPACK__imported__module__$5b$externals$5d2f$aphrodite__$5b$external$5d$__$28$aphrodite$2c$__cjs$29$__["css"])(styles.slideInDown) : ""}`,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                className: "absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 217,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                                className: "relative flex items-center",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                                        className: "w-5 h-5 mr-2",
                                                                        fill: "none",
                                                                        stroke: "currentColor",
                                                                        viewBox: "0 0 24 24",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                                            strokeLinecap: "round",
                                                                            strokeLinejoin: "round",
                                                                            strokeWidth: 2,
                                                                            d: "M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 220,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 219,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    "Get Protected",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                                        className: "w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform",
                                                                        fill: "none",
                                                                        stroke: "currentColor",
                                                                        viewBox: "0 0 24 24",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                                            strokeLinecap: "round",
                                                                            strokeLinejoin: "round",
                                                                            strokeWidth: 2,
                                                                            d: "M9 5l7 7-7 7"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 224,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 223,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 218,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 216,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "/contact",
                                                        className: `group relative inline-flex items-center justify-center border-2 border-blue-600 text-white hover:border-blue-400 hover:text-white hover:bg-emerald-500/10 px-6 py-3 rounded-full font-semibold text-base transition-all duration-300 backdrop-blur-sm ${isClient ? (0, __TURBOPACK__imported__module__$5b$externals$5d2f$aphrodite__$5b$external$5d$__$28$aphrodite$2c$__cjs$29$__["css"])(styles.slideInDown) : ""}`,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                            className: "relative flex items-center",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                                    className: "w-5 h-5 mr-2",
                                                                    fill: "none",
                                                                    stroke: "currentColor",
                                                                    viewBox: "0 0 24 24",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: 2,
                                                                        d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 233,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 232,
                                                                    columnNumber: 23
                                                                }, this),
                                                                "Talk to Solution Consultant"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 231,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 230,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 214,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 187,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 186,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 183,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "hidden lg:flex lg:w-1/2 relative items-center justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "w-full max-w-md",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-sm border border-emerald-400/20 rounded-2xl p-6 relative overflow-hidden",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between mb-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                className: "w-3 h-3 bg-emerald-400 rounded-full animate-pulse mr-2"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 251,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                                className: "text-emerald-300 text-sm font-semibold",
                                                                children: "SpamCloud Filter"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 252,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 250,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-400",
                                                        children: "Real-time Protection"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 254,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 249,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "space-y-3 mb-6",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-400 mb-2",
                                                        children: "Incoming Emails"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 260,
                                                        columnNumber: 19
                                                    }, this),
                                                    [
                                                        {
                                                            type: 'spam',
                                                            subject: 'Win $1000 Now!',
                                                            sender: 'noreply@fake-lottery.com',
                                                            status: 'blocked',
                                                            delay: '0s'
                                                        },
                                                        {
                                                            type: 'phishing',
                                                            subject: 'Urgent: Verify Account',
                                                            sender: 'security@fake-bank.net',
                                                            status: 'blocked',
                                                            delay: '1s'
                                                        },
                                                        {
                                                            type: 'legitimate',
                                                            subject: 'Meeting Reminder',
                                                            sender: 'team@company.com',
                                                            status: 'delivered',
                                                            delay: '2s'
                                                        },
                                                        {
                                                            type: 'spam',
                                                            subject: 'Free Pills Online',
                                                            sender: 'offers@spam-pharmacy.biz',
                                                            status: 'blocked',
                                                            delay: '3s'
                                                        }
                                                    ].map((email, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: `group flex items-center justify-between p-3 rounded-lg border transition-all duration-300 cursor-pointer transform hover:scale-[1.02] hover:shadow-lg ${email.status === 'blocked' ? 'bg-red-500/10 border-red-500/30 hover:bg-red-500/20 hover:border-red-500/50 animate-pulse' : 'bg-emerald-500/10 border-emerald-500/30 hover:bg-emerald-500/20 hover:border-emerald-500/50'}`,
                                                            style: {
                                                                animationDelay: email.delay,
                                                                animation: `slideInFilter 0.8s ease-out ${email.delay} both`
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center flex-1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                            className: `w-2 h-2 rounded-full mr-3 transition-all duration-300 group-hover:scale-125 ${email.status === 'blocked' ? 'bg-red-400 group-hover:bg-red-300' : 'bg-emerald-400 group-hover:bg-emerald-300'}`
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 282,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                            className: "flex-1 min-w-0",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                                    className: `text-sm font-medium transition-all duration-300 group-hover:font-semibold truncate ${email.status === 'blocked' ? 'text-red-300 group-hover:text-red-200' : 'text-emerald-300 group-hover:text-emerald-200'}`,
                                                                                    children: email.subject
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                                    lineNumber: 286,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                                    className: "text-xs text-gray-400 group-hover:text-gray-300 transition-colors duration-300 truncate",
                                                                                    children: [
                                                                                        "From: ",
                                                                                        email.sender
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                                    lineNumber: 291,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                                    className: "text-xs text-gray-500 group-hover:text-gray-400 transition-colors duration-300",
                                                                                    children: email.type === 'spam' ? 'Spam Email' : email.type === 'phishing' ? 'Phishing Attempt' : 'Legitimate Email'
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                                    lineNumber: 294,
                                                                                    columnNumber: 27
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 285,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 281,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: `text-xs font-semibold px-3 py-1 rounded-full transition-all duration-300 group-hover:px-4 group-hover:shadow-md ${email.status === 'blocked' ? 'bg-red-500/20 text-red-300 group-hover:bg-red-500/30 group-hover:text-red-200' : 'bg-emerald-500/20 text-emerald-300 group-hover:bg-emerald-500/30 group-hover:text-emerald-200'}`,
                                                                    children: email.status === 'blocked' ? 'BLOCKED' : 'DELIVERED'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 300,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, index, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 269,
                                                            columnNumber: 21
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 258,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "absolute inset-0 opacity-5 pointer-events-none",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0",
                                                    style: {
                                                        backgroundImage: `
                      linear-gradient(45deg, rgba(34, 197, 94, 0.1) 25%, transparent 25%),
                      linear-gradient(-45deg, rgba(34, 197, 94, 0.1) 25%, transparent 25%),
                      linear-gradient(45deg, transparent 75%, rgba(34, 197, 94, 0.1) 75%),
                      linear-gradient(-45deg, transparent 75%, rgba(34, 197, 94, 0.1) 75%)
                    `,
                                                        backgroundSize: '20px 20px',
                                                        backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 315,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 314,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 247,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 245,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 244,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 181,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-8 left-1/2 transform -translate-x-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center animate-bounce",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "text-emerald-400 text-xs font-mono mb-2",
                                    children: "SCROLL TO EXPLORE"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 342,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "w-6 h-10 border-2 border-emerald-400/50 rounded-full flex justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "w-1 h-3 bg-emerald-400 rounded-full mt-2 animate-pulse"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 344,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 343,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 341,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 340,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 150,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$slider$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 354,
                columnNumber: 3
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "proofpoint-services-sec",
                id: "service",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "bg-[#035bfb] py-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "container-fluid",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "row align-items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "col-lg-6",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "proofpoint-hero-content",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h6", {
                                                    className: "proofpoint-badge",
                                                    children: "WE ARE EMAIL SECURITY EXPERTS"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 363,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                                    className: "proofpoint-main-title ",
                                                    children: "Protect your inbox and safeguard your business reputation  With advanced email filter solutions. "
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 364,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 362,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 361,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$ProofpointCarousel$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 369,
                                        columnNumber: 12
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 360,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 359,
                            columnNumber: 9
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 358,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "proofpoint-services-cards-section",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "container",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "row g-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "col-lg-3 col-md-6",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "proofpoint-service-card",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "service-icon",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2d$open$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MailOpen$3e$__["MailOpen"], {
                                                        className: "w-10 h-10"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 381,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 380,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                    className: "text-black",
                                                    children: "Stop Incoming Threats"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 383,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                    className: "text-justify  text-justify",
                                                    children: "Protect against inbound spam, phishing, and malware with advanced AI-based detection."
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 384,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/services/incoming-spam-filter-service-provider-chennai",
                                                    className: "service-link",
                                                    children: [
                                                        "Learn more ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                            className: "fa-solid fa-arrow-right"
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 386,
                                                            columnNumber: 30
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 385,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 379,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 378,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "col-lg-3 col-md-6",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "proofpoint-service-card",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "service-icon",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2d$check$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MailCheck$3e$__["MailCheck"], {
                                                        className: "w-10 h-10"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 394,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 393,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                    className: "text-black",
                                                    children: "Secure Outbound Communications"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 396,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                    className: "text-justify",
                                                    children: "Monitor and protect outgoing emails to prevent data loss and ensure compliance."
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 397,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/services/outgoing-spam-filter-service-provider-chennai",
                                                    className: "service-link",
                                                    children: [
                                                        "Learn more ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                            className: "fa-solid fa-arrow-right"
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 399,
                                                            columnNumber: 30
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 398,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 392,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 391,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "col-lg-3 col-md-6",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "proofpoint-service-card",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "service-icon",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                        className: "fi fi-bs-mailbox-envelope"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 407,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 406,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                    className: "text-black",
                                                    children: "Email Archiving & Compliance"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 409,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                    className: "text-justify",
                                                    children: "Comprehensive email archiving solution for regulatory compliance and data management."
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 410,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/contact",
                                                    className: "service-link",
                                                    children: [
                                                        "Learn more ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                            className: "fa-solid fa-arrow-right"
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 412,
                                                            columnNumber: 30
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 411,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 405,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 404,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "col-lg-3 col-md-6",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "proofpoint-service-card",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "service-icon",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                        className: "fi fi-ss-email-pending"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 420,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 419,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                    className: "text-black",
                                                    children: "Carbonio Mail Platform"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 422,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                    className: "text-justify ",
                                                    children: "Modern, secure email platform with advanced collaboration tools and enterprise security."
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 423,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/contact",
                                                    className: "service-link",
                                                    children: [
                                                        "Learn more ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                            className: "fa-solid fa-arrow-right"
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 425,
                                                            columnNumber: 30
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 424,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 418,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 417,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 377,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 376,
                            columnNumber: 9
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 375,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 357,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "modern-stats-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "modern-stats-container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "stats-content-area",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "stats-badge",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "badge-text",
                                        children: "WE ARE EMAIL SECURITY EXPERTS"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 447,
                                        columnNumber: 13
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 446,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                    className: "stats-main-title text-red-500 text-justify",
                                    children: "SpamCloud is  trusted  by top industries in Chennai for over 18 years with compliance driven email security solutions"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 449,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                    className: "stats-description",
                                    children: "Protecting businesses worldwide with cutting-edge email security solutions and advanced threat detection."
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 452,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 445,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "stats-image-area",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "stats-image-container",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                                    src: "https://res.cloudinary.com/daggx9p24/image/upload/v1729659698/spamcloud-bene_gl7za1.jpg",
                                    alt: "Email Security Statistics Dashboard",
                                    className: "stats-dashboard-image"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 460,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 459,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 458,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                    lineNumber: 443,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 442,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "modern-features-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "modern-features-container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "features-list-area",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "features-grid",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "feature-item",
                                        "data-feature": "quarantine",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-icon",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                    className: "fa-solid fa-shield-halved"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 489,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 488,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-content",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                        children: "Email Quarantine System"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 492,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                        children: "How email identified as spam - Quarantined, tagged, and delivered with advanced filtering."
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 493,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 491,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 487,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "feature-item",
                                        "data-feature": "accuracy",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-icon",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                    className: "fa-solid fa-bullseye"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 499,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 498,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-content",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                        children: "High Accuracy Rate"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 502,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                        children: "Rate of false positives - The number of authenticated emails get blocked is minimized."
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 503,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 501,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 497,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "feature-item",
                                        "data-feature": "reporting",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-icon",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                    className: "fa-solid fa-chart-line"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 509,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 508,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-content",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                        children: "Advanced Reporting"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 512,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                        children: "The reporting options are available to detect whitelist and blacklist senders effectively."
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 513,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 511,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 507,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "feature-item",
                                        "data-feature": "protection",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-icon",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                    className: "fa-solid fa-virus-slash"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 521,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 520,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                className: "feature-content",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                        children: "Virus Protection"
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 524,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                        children: "Best antivirus software protects your business from malware activities and threats."
                                                    }, void 0, false, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 525,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 523,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 519,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 485,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 484,
                            columnNumber: 1
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "features-content-area",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "features-badge",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "badge-text",
                                        children: "ANTI SPAM CLOUD FILTER"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 535,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 534,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                    className: "features-main-title",
                                    children: "Essential Features of Email Filtering Services"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 537,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                    className: "features-description",
                                    children: "We substantially illustrate the immense verifiable levels of spam and virus detection service for your business."
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 540,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 533,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "features-bg-elements",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "grid-pattern"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 550,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 549,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                    lineNumber: 481,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 480,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "modern-tab-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "modern-tab-container",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "modern-tab-nav",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("ul", {
                                    className: "nav nav-tabs",
                                    id: "modernTab",
                                    role: "tablist",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                                            className: "nav-item",
                                            role: "presentation",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                                className: "nav-link active",
                                                id: "unique-tab",
                                                "data-bs-toggle": "tab",
                                                "data-bs-target": "#unique",
                                                type: "button",
                                                role: "tab",
                                                "aria-controls": "unique",
                                                "aria-selected": "true",
                                                children: "WHAT MAKES US UNIQUE"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 570,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 569,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                                            className: "nav-item",
                                            role: "presentation",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                                className: "nav-link",
                                                id: "choose-tab",
                                                "data-bs-toggle": "tab",
                                                "data-bs-target": "#choose",
                                                type: "button",
                                                role: "tab",
                                                "aria-controls": "choose",
                                                "aria-selected": "false",
                                                children: "WHY CHOOSE SIXTHSTAR"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 575,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 574,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                                            className: "nav-item",
                                            role: "presentation",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                                className: "nav-link",
                                                id: "solution-tab",
                                                "data-bs-toggle": "tab",
                                                "data-bs-target": "#solution",
                                                type: "button",
                                                role: "tab",
                                                "aria-controls": "solution",
                                                "aria-selected": "false",
                                                children: "SPAM SOLUTION"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 580,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 579,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 568,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 567,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "tab-content modern-tab-content",
                                id: "modernTabContent",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "tab-pane fade show active",
                                        id: "unique",
                                        role: "tabpanel",
                                        "aria-labelledby": "unique-tab",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "modern-tab-layout",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "tab-features-list",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 596,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 595,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Effortless Usability"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 599,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Easily manage and transfer messages in no time."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 600,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 598,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 594,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 606,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 605,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "High Detection Rate"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 609,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Accurately blocks viruses & malware before they enter your network"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 610,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 608,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 604,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 616,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 615,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Seamless Email Flow"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 619,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Ensures smooth & secure email delivery with an extra protective layer"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 620,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 618,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 614,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 626,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 625,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "24/7 Expert Support"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 629,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Get instant help from our native email security specialists anytime"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 630,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 628,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 624,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 593,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "tab-cta-area",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                        className: "cta-content",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                                children: [
                                                                    "Talk To our Spam Filter ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                                        className: "text-blue",
                                                                        children: "Experts"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 637,
                                                                        columnNumber: 51
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 637,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                href: "/contact",
                                                                className: "cta-button-tab",
                                                                children: "Contact us Now"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 638,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 636,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 635,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 592,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 591,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "tab-pane fade",
                                        id: "choose",
                                        role: "tabpanel",
                                        "aria-labelledby": "choose-tab",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "modern-tab-layout",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "tab-features-list",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 652,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 651,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Incoming Spam Filter"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 655,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "SixthStar provides you an excellent incoming spam filter in which users send mails to the recipient."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 656,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 654,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 650,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 662,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 661,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Outgoing Spam Filter"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 665,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "SixthStar provides a cloud-based outgoing spam filter that verifies and blocks spams to provide the most secure email delivery."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 666,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 664,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 660,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 649,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "tab-cta-area",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                        className: "cta-content",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                                children: [
                                                                    "Talk To our Spam Filter ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                                        className: "text-blue",
                                                                        children: "Experts"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 673,
                                                                        columnNumber: 51
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 673,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                href: "/contact",
                                                                className: "cta-button-tab",
                                                                children: "Contact us Now"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 674,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 672,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 671,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 648,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 647,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "tab-pane fade",
                                        id: "solution",
                                        role: "tabpanel",
                                        "aria-labelledby": "solution-tab",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "modern-tab-layout",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "tab-features-list",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 688,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 687,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Lightning-Fast Performance"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 691,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Ensures seamless email filtering without delays."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 692,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 690,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 686,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 698,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 697,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Customizable Solutions"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 701,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Tailored security settings to fit your business needs."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 702,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 700,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 696,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 708,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 707,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Scalable for All"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 711,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Perfect for individuals, startups & enterprises alike."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 712,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 710,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 706,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "feature-item-tab",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-check",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                                                        className: "fa-solid fa-check"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 718,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 717,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "feature-content-tab",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h4", {
                                                                            children: "Proven Expertise"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 721,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            children: "Trusted by businesses for top-notch email security solutions."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 722,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 720,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 716,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 685,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "tab-cta-area",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                        className: "cta-content",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                                children: [
                                                                    "Talk To our Spam Filter ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                                        className: "text-blue",
                                                                        children: "Experts"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 729,
                                                                        columnNumber: 51
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 729,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                href: "/contact",
                                                                className: "cta-button-tab",
                                                                children: "Contact us Now"
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 730,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                        lineNumber: 728,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 727,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 684,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 683,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 588,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 564,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                    lineNumber: 563,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 562,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "modern-blog-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "modern-blog-container",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "blog-header",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                    className: "blog-title",
                                    children: "OUR BLOG"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 750,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 749,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "blog-slider-wrapper",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$Blogslider$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 755,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 754,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "blog-footer",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/blog",
                                    className: "view-all-blogs",
                                    children: [
                                        "View All Articles",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("i", {
                                            className: "fa-solid fa-arrow-right"
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 762,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                    lineNumber: 760,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 759,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 746,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                    lineNumber: 745,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 744,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$pages$2f$section$2f$ContactSec$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 772,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
                className: "py-16 bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50 relative overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 opacity-5",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "absolute inset-0",
                            style: {
                                backgroundImage: `radial-gradient(circle at 1px 1px, rgb(59 130 246) 1px, transparent 0)`,
                                backgroundSize: '40px 40px'
                            }
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                            lineNumber: 779,
                            columnNumber: 5
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 778,
                        columnNumber: 3
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "container mx-auto px-4 relative z-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "text-center mb-12",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-xl mb-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                            className: "w-6 h-6 text-blue-600",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                lineNumber: 790,
                                                columnNumber: 11
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 789,
                                            columnNumber: 9
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 788,
                                        columnNumber: 7
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                                        className: "text-3xl lg:text-4xl font-bold text-slate-900 mb-3 tracking-tight",
                                        children: "Frequently Asked Questions"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 793,
                                        columnNumber: 7
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                        className: "text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed",
                                        children: "Get answers to common questions about our email security services and spam protection solutions."
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 796,
                                        columnNumber: 7
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 787,
                                columnNumber: 5
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "grid lg:grid-cols-2 gap-8 lg:gap-12 items-start",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "relative order-2 lg:order-1",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "relative bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 shadow-xl",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 bg-gradient-to-br from-blue-400/20 to-transparent rounded-3xl"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 805,
                                                    columnNumber: 11
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    src: "https://res.cloudinary.com/daggx9p24/image/upload/v1729661580/1_spmzxs.png",
                                                    alt: "Email Security FAQ Illustration",
                                                    width: 500,
                                                    height: 400,
                                                    className: "relative z-10 w-full h-auto rounded-2xl shadow-lg",
                                                    priority: false,
                                                    loading: "lazy"
                                                }, void 0, false, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 806,
                                                    columnNumber: 11
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 804,
                                            columnNumber: 9
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 803,
                                        columnNumber: 7
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "order-1 lg:order-2",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "space-y-3",
                                            children: [
                                                {
                                                    id: 'faq-1',
                                                    question: 'What happens to a spam-detected message?',
                                                    answer: 'For inbound messages: This filtering will be done based on the IP address of the sender. As a default process, content-filter spam is sent to the junk folder of the recipient. All these actions can be controlled by you. For outbound messages: Here, the email delivery status can be easily known by the sender whether the email is bounced or not delivered through a message status.',
                                                    defaultOpen: false
                                                },
                                                {
                                                    id: 'faq-2',
                                                    question: 'Do I need to configure the service to provide anti-spam protection?',
                                                    answer: 'Once you get the spam filter, service will be automatically enabled as per anti-spam policies. If you want any alteration in the policies based on your organizational structure, you can tailor it according to it.',
                                                    defaultOpen: false
                                                },
                                                {
                                                    id: 'faq-3',
                                                    question: 'Does the service have URL filtering?',
                                                    answer: 'Yes, the service provides URL filtering. If the read URL has any spam content, then it will be marked as a spam message.',
                                                    defaultOpen: false
                                                },
                                                {
                                                    id: 'faq-4',
                                                    question: 'Is bulk email filtering works automatically?',
                                                    answer: 'This email filtering works differently for new and migrated customers. So make sure if the service is automatically enabled or not.',
                                                    defaultOpen: false
                                                },
                                                {
                                                    id: 'faq-5',
                                                    question: 'Can I get spam reports?',
                                                    answer: 'Yes, you will get spam reports about the volume of messages present in the account.',
                                                    defaultOpen: false
                                                }
                                            ].map((faq, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    className: "bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all duration-300",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                                            className: "w-full px-5 py-3 text-left focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-2xl group",
                                                            type: "button",
                                                            "data-bs-toggle": "collapse",
                                                            "data-bs-target": `#${faq.id}`,
                                                            "aria-expanded": faq.defaultOpen,
                                                            "aria-controls": faq.id,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-start gap-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                                className: "flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                                                    className: "text-sm font-bold text-blue-600",
                                                                                    children: index + 1
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                                    lineNumber: 869,
                                                                                    columnNumber: 23
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                                lineNumber: 868,
                                                                                columnNumber: 21
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                                                                className: "text-lg font-semibold text-slate-900 group-hover:text-blue-600 transition-colors duration-200 pr-4",
                                                                                children: faq.question
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                                lineNumber: 871,
                                                                                columnNumber: 21
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 867,
                                                                        columnNumber: 19
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                        className: "flex-shrink-0 ml-4",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                                                            className: "w-5 h-5 text-slate-500 transform transition-transform duration-200 group-hover:text-blue-600",
                                                                            fill: "none",
                                                                            stroke: "currentColor",
                                                                            viewBox: "0 0 24 24",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                                                                strokeLinecap: "round",
                                                                                strokeLinejoin: "round",
                                                                                strokeWidth: 2,
                                                                                d: "M19 9l-7 7-7-7"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                                lineNumber: 877,
                                                                                columnNumber: 23
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 876,
                                                                            columnNumber: 21
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                        lineNumber: 875,
                                                                        columnNumber: 19
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 866,
                                                                columnNumber: 17
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 858,
                                                            columnNumber: 15
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            id: faq.id,
                                                            className: `accordion-collapse collapse ${faq.defaultOpen ? 'show' : ''}`,
                                                            "aria-labelledby": `${faq.id}-heading`,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                className: "px-5 pb-4",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                    className: "pl-12",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                                            className: "w-full h-px bg-gradient-to-r from-slate-200 to-transparent mb-3"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 890,
                                                                            columnNumber: 21
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                                                            className: "text-slate-600 leading-relaxed text-justify",
                                                                            children: faq.answer
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                            lineNumber: 891,
                                                                            columnNumber: 21
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                    lineNumber: 889,
                                                                    columnNumber: 19
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                                lineNumber: 888,
                                                                columnNumber: 17
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                            lineNumber: 883,
                                                            columnNumber: 15
                                                        }, this)
                                                    ]
                                                }, faq.id, true, {
                                                    fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                                    lineNumber: 857,
                                                    columnNumber: 13
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                            lineNumber: 824,
                                            columnNumber: 9
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                        lineNumber: 823,
                                        columnNumber: 7
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                                lineNumber: 801,
                                columnNumber: 5
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                        lineNumber: 785,
                        columnNumber: 3
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
                lineNumber: 776,
                columnNumber: 1
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/spam-cloud-25-11-25/pages/index.jsx",
        lineNumber: 130,
        columnNumber: 5
    }, this);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__24b472cc._.js.map