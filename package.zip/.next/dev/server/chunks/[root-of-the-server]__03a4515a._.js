module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/mysql2/promise [external] (mysql2/promise, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mysql2/promise", () => require("mysql2/promise"));

module.exports = mod;
}),
"[project]/spam-cloud-25-11-25/pages/api/posts/index.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mysql2$2f$promise__$5b$external$5d$__$28$mysql2$2f$promise$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mysql2/promise [external] (mysql2/promise, cjs)");
;
async function handler(req, res) {
    const { page = 1, limit = 10, search = '' } = req.query;
    const offset = (page - 1) * limit;
    try {
        // Log environment variables for debugging
        const pool = __TURBOPACK__imported__module__$5b$externals$5d2f$mysql2$2f$promise__$5b$external$5d$__$28$mysql2$2f$promise$2c$__cjs$29$__["default"].createPool({
            host: process.env.DB_HOST,
            port: process.env.DATABASE_PORT,
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            ssl: process.env.DATABASE_SSL === 'true',
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });
        const connection = await pool.getConnection();
        let whereClause = 'WHERE published = 1';
        let params = [];
        if (search) {
            whereClause += ' AND (title LIKE ? OR content LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }
        // Get total count
        const [countResult] = await connection.execute(`SELECT COUNT(*) as total FROM blog_posts ${whereClause}`, params);
        // Get paginated results
        const [posts] = await connection.execute(`SELECT * FROM blog_posts ${whereClause} 
       ORDER BY created_at DESC LIMIT ? OFFSET ?`, [
            ...params,
            parseInt(limit),
            parseInt(offset)
        ]);
        await connection.release();
        const totalPosts = countResult[0].total;
        const totalPages = Math.ceil(totalPosts / limit);
        // Format posts with proper URL validation
        const formattedPosts = posts.map((post)=>{
            const newPost = {
                ...post
            };
            // Validate and format featured_image URL
            if (post.featured_image) {
                // Remove any leading/trailing whitespace
                const cleanImageUrl = post.featured_image.trim();
                // If URL doesn't start with http://, https://, or /, add leading slash
                if (!cleanImageUrl.match(/^https?:\/\//) && !cleanImageUrl.startsWith('/')) {
                    newPost.featured_image = '/' + cleanImageUrl;
                } else {
                    newPost.featured_image = cleanImageUrl;
                }
            }
            return newPost;
        });
        return res.status(200).json({
            posts: formattedPosts,
            pagination: {
                currentPage: parseInt(page),
                totalPages,
                totalPosts,
                hasMore: page < totalPages
            }
        });
    } catch (error) {
        console.error('Error fetching posts:', error.message, error.stack);
        return res.status(500).json({
            message: 'Internal server error',
            error: error.message
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__03a4515a._.js.map