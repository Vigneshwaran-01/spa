var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/check.js")
R.c("server/chunks/bb85f_next_dist_1b9296b7._.js")
R.c("server/chunks/[root-of-the-server]__7270c757._.js")
R.m("[project]/spam-cloud-25-11-25/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/spam-cloud-25-11-25/pages/api/auth/check.js [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/spam-cloud-25-11-25/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/spam-cloud-25-11-25/pages/api/auth/check.js [api] (ecmascript)\" } [api] (ecmascript)").exports
