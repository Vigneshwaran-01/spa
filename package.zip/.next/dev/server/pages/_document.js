var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/bb85f_8ba6b763._.js")
R.c("server/chunks/ssr/[root-of-the-server]__992031e8._.js")
R.m("[project]/spam-cloud-25-11-25/pages/_document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/spam-cloud-25-11-25/pages/_document.js [ssr] (ecmascript)").exports
