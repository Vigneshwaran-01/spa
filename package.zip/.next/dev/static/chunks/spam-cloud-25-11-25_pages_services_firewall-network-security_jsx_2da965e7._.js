(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__da6a3110._.js",
  "static/chunks/bb85f_next_dist_compiled_478a8bd8._.js",
  "static/chunks/bb85f_next_dist_shared_lib_cbd6f651._.js",
  "static/chunks/bb85f_next_dist_client_261b0bf4._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_4c2fe7a4._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_73cbe722._.js"
],
    source: "entry"
});
