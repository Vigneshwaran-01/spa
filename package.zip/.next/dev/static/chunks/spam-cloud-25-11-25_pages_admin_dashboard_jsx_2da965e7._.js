(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bb85f_next_dist_compiled_615e306c._.js",
  "static/chunks/bb85f_next_dist_shared_lib_4dd88bf2._.js",
  "static/chunks/bb85f_next_dist_client_aa07e0da._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_a5634d5c._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_7a28e42f._.js",
  "static/chunks/[root-of-the-server]__eeb6ba19._.js"
],
    source: "entry"
});
