(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bb85f_prosemirror-view_dist_index_552c2d15.js",
  "static/chunks/bb85f_@tiptap_core_dist_fa0fd7d9._.js",
  "static/chunks/bb85f_d28c9b0f._.js",
  "static/chunks/spam-cloud-25-11-25_components_StableTiptapEditor_jsx_7fc6034d._.js"
],
    source: "dynamic"
});
