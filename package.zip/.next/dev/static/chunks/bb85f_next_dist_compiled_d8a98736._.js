(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/process/browser.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

(function() {
    var e = {
        229: function(e) {
            var t = e.exports = {};
            var r;
            var n;
            function defaultSetTimout() {
                throw new Error("setTimeout has not been defined");
            }
            function defaultClearTimeout() {
                throw new Error("clearTimeout has not been defined");
            }
            (function() {
                try {
                    if (typeof setTimeout === "function") {
                        r = setTimeout;
                    } else {
                        r = defaultSetTimout;
                    }
                } catch (e) {
                    r = defaultSetTimout;
                }
                try {
                    if (typeof clearTimeout === "function") {
                        n = clearTimeout;
                    } else {
                        n = defaultClearTimeout;
                    }
                } catch (e) {
                    n = defaultClearTimeout;
                }
            })();
            function runTimeout(e) {
                if (r === setTimeout) {
                    return setTimeout(e, 0);
                }
                if ((r === defaultSetTimout || !r) && setTimeout) {
                    r = setTimeout;
                    return setTimeout(e, 0);
                }
                try {
                    return r(e, 0);
                } catch (t) {
                    try {
                        return r.call(null, e, 0);
                    } catch (t) {
                        return r.call(this, e, 0);
                    }
                }
            }
            function runClearTimeout(e) {
                if (n === clearTimeout) {
                    return clearTimeout(e);
                }
                if ((n === defaultClearTimeout || !n) && clearTimeout) {
                    n = clearTimeout;
                    return clearTimeout(e);
                }
                try {
                    return n(e);
                } catch (t) {
                    try {
                        return n.call(null, e);
                    } catch (t) {
                        return n.call(this, e);
                    }
                }
            }
            var i = [];
            var o = false;
            var u;
            var a = -1;
            function cleanUpNextTick() {
                if (!o || !u) {
                    return;
                }
                o = false;
                if (u.length) {
                    i = u.concat(i);
                } else {
                    a = -1;
                }
                if (i.length) {
                    drainQueue();
                }
            }
            function drainQueue() {
                if (o) {
                    return;
                }
                var e = runTimeout(cleanUpNextTick);
                o = true;
                var t = i.length;
                while(t){
                    u = i;
                    i = [];
                    while(++a < t){
                        if (u) {
                            u[a].run();
                        }
                    }
                    a = -1;
                    t = i.length;
                }
                u = null;
                o = false;
                runClearTimeout(e);
            }
            t.nextTick = function(e) {
                var t = new Array(arguments.length - 1);
                if (arguments.length > 1) {
                    for(var r = 1; r < arguments.length; r++){
                        t[r - 1] = arguments[r];
                    }
                }
                i.push(new Item(e, t));
                if (i.length === 1 && !o) {
                    runTimeout(drainQueue);
                }
            };
            function Item(e, t) {
                this.fun = e;
                this.array = t;
            }
            Item.prototype.run = function() {
                this.fun.apply(null, this.array);
            };
            t.title = "browser";
            t.browser = true;
            t.env = {};
            t.argv = [];
            t.version = "";
            t.versions = {};
            function noop() {}
            t.on = noop;
            t.addListener = noop;
            t.once = noop;
            t.off = noop;
            t.removeListener = noop;
            t.removeAllListeners = noop;
            t.emit = noop;
            t.prependListener = noop;
            t.prependOnceListener = noop;
            t.listeners = function(e) {
                return [];
            };
            t.binding = function(e) {
                throw new Error("process.binding is not supported");
            };
            t.cwd = function() {
                return "/";
            };
            t.chdir = function(e) {
                throw new Error("process.chdir is not supported");
            };
            t.umask = function() {
                return 0;
            };
        }
    };
    var t = {};
    function __nccwpck_require__(r) {
        var n = t[r];
        if (n !== undefined) {
            return n.exports;
        }
        var i = t[r] = {
            exports: {}
        };
        var o = true;
        try {
            e[r](i, i.exports, __nccwpck_require__);
            o = false;
        } finally{
            if (o) delete t[r];
        }
        return i.exports;
    }
    if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = ("TURBOPACK compile-time value", "/ROOT/spam-cloud-25-11-25/node_modules/next/dist/compiled/process") + "/";
    var r = __nccwpck_require__(229);
    module.exports = r;
})();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-refresh/cjs/react-refresh-runtime.development.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-refresh-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time truthy", 1) {
    (function() {
        'use strict';
        // ATTENTION
        var REACT_FORWARD_REF_TYPE = Symbol.for('react.forward_ref');
        var REACT_MEMO_TYPE = Symbol.for('react.memo');
        var PossiblyWeakMap = typeof WeakMap === 'function' ? WeakMap : Map; // We never remove these associations.
        // It's OK to reference families, but use WeakMap/Set for types.
        var allFamiliesByID = new Map();
        var allFamiliesByType = new PossiblyWeakMap();
        var allSignaturesByType = new PossiblyWeakMap(); // This WeakMap is read by React, so we only put families
        // that have actually been edited here. This keeps checks fast.
        // $FlowIssue
        var updatedFamiliesByType = new PossiblyWeakMap(); // This is cleared on every performReactRefresh() call.
        // It is an array of [Family, NextType] tuples.
        var pendingUpdates = []; // This is injected by the renderer via DevTools global hook.
        var helpersByRendererID = new Map();
        var helpersByRoot = new Map(); // We keep track of mounted roots so we can schedule updates.
        var mountedRoots = new Set(); // If a root captures an error, we remember it so we can retry on edit.
        var failedRoots = new Set(); // In environments that support WeakMap, we also remember the last element for every root.
        // It needs to be weak because we do this even for roots that failed to mount.
        // If there is no WeakMap, we won't attempt to do retrying.
        // $FlowIssue
        var rootElements = typeof WeakMap === 'function' ? new WeakMap() : null;
        var isPerformingRefresh = false;
        function computeFullKey(signature) {
            if (signature.fullKey !== null) {
                return signature.fullKey;
            }
            var fullKey = signature.ownKey;
            var hooks;
            try {
                hooks = signature.getCustomHooks();
            } catch (err) {
                // This can happen in an edge case, e.g. if expression like Foo.useSomething
                // depends on Foo which is lazily initialized during rendering.
                // In that case just assume we'll have to remount.
                signature.forceReset = true;
                signature.fullKey = fullKey;
                return fullKey;
            }
            for(var i = 0; i < hooks.length; i++){
                var hook = hooks[i];
                if (typeof hook !== 'function') {
                    // Something's wrong. Assume we need to remount.
                    signature.forceReset = true;
                    signature.fullKey = fullKey;
                    return fullKey;
                }
                var nestedHookSignature = allSignaturesByType.get(hook);
                if (nestedHookSignature === undefined) {
                    continue;
                }
                var nestedHookKey = computeFullKey(nestedHookSignature);
                if (nestedHookSignature.forceReset) {
                    signature.forceReset = true;
                }
                fullKey += '\n---\n' + nestedHookKey;
            }
            signature.fullKey = fullKey;
            return fullKey;
        }
        function haveEqualSignatures(prevType, nextType) {
            var prevSignature = allSignaturesByType.get(prevType);
            var nextSignature = allSignaturesByType.get(nextType);
            if (prevSignature === undefined && nextSignature === undefined) {
                return true;
            }
            if (prevSignature === undefined || nextSignature === undefined) {
                return false;
            }
            if (computeFullKey(prevSignature) !== computeFullKey(nextSignature)) {
                return false;
            }
            if (nextSignature.forceReset) {
                return false;
            }
            return true;
        }
        function isReactClass(type) {
            return type.prototype && type.prototype.isReactComponent;
        }
        function canPreserveStateBetween(prevType, nextType) {
            if (isReactClass(prevType) || isReactClass(nextType)) {
                return false;
            }
            if (haveEqualSignatures(prevType, nextType)) {
                return true;
            }
            return false;
        }
        function resolveFamily(type) {
            // Only check updated types to keep lookups fast.
            return updatedFamiliesByType.get(type);
        } // If we didn't care about IE11, we could use new Map/Set(iterable).
        function cloneMap(map) {
            var clone = new Map();
            map.forEach(function(value, key) {
                clone.set(key, value);
            });
            return clone;
        }
        function cloneSet(set) {
            var clone = new Set();
            set.forEach(function(value) {
                clone.add(value);
            });
            return clone;
        } // This is a safety mechanism to protect against rogue getters and Proxies.
        function getProperty(object, property) {
            try {
                return object[property];
            } catch (err) {
                // Intentionally ignore.
                return undefined;
            }
        }
        function performReactRefresh() {
            if (pendingUpdates.length === 0) {
                return null;
            }
            if (isPerformingRefresh) {
                return null;
            }
            isPerformingRefresh = true;
            try {
                var staleFamilies = new Set();
                var updatedFamilies = new Set();
                var updates = pendingUpdates;
                pendingUpdates = [];
                updates.forEach(function(_ref) {
                    var family = _ref[0], nextType = _ref[1];
                    // Now that we got a real edit, we can create associations
                    // that will be read by the React reconciler.
                    var prevType = family.current;
                    updatedFamiliesByType.set(prevType, family);
                    updatedFamiliesByType.set(nextType, family);
                    family.current = nextType; // Determine whether this should be a re-render or a re-mount.
                    if (canPreserveStateBetween(prevType, nextType)) {
                        updatedFamilies.add(family);
                    } else {
                        staleFamilies.add(family);
                    }
                }); // TODO: rename these fields to something more meaningful.
                var update = {
                    updatedFamilies: updatedFamilies,
                    // Families that will re-render preserving state
                    staleFamilies: staleFamilies // Families that will be remounted
                };
                helpersByRendererID.forEach(function(helpers) {
                    // Even if there are no roots, set the handler on first update.
                    // This ensures that if *new* roots are mounted, they'll use the resolve handler.
                    helpers.setRefreshHandler(resolveFamily);
                });
                var didError = false;
                var firstError = null; // We snapshot maps and sets that are mutated during commits.
                // If we don't do this, there is a risk they will be mutated while
                // we iterate over them. For example, trying to recover a failed root
                // may cause another root to be added to the failed list -- an infinite loop.
                var failedRootsSnapshot = cloneSet(failedRoots);
                var mountedRootsSnapshot = cloneSet(mountedRoots);
                var helpersByRootSnapshot = cloneMap(helpersByRoot);
                failedRootsSnapshot.forEach(function(root) {
                    var helpers = helpersByRootSnapshot.get(root);
                    if (helpers === undefined) {
                        throw new Error('Could not find helpers for a root. This is a bug in React Refresh.');
                    }
                    if (!failedRoots.has(root)) {}
                    if (rootElements === null) {
                        return;
                    }
                    if (!rootElements.has(root)) {
                        return;
                    }
                    var element = rootElements.get(root);
                    try {
                        helpers.scheduleRoot(root, element);
                    } catch (err) {
                        if (!didError) {
                            didError = true;
                            firstError = err;
                        } // Keep trying other roots.
                    }
                });
                mountedRootsSnapshot.forEach(function(root) {
                    var helpers = helpersByRootSnapshot.get(root);
                    if (helpers === undefined) {
                        throw new Error('Could not find helpers for a root. This is a bug in React Refresh.');
                    }
                    if (!mountedRoots.has(root)) {}
                    try {
                        helpers.scheduleRefresh(root, update);
                    } catch (err) {
                        if (!didError) {
                            didError = true;
                            firstError = err;
                        } // Keep trying other roots.
                    }
                });
                if (didError) {
                    throw firstError;
                }
                return update;
            } finally{
                isPerformingRefresh = false;
            }
        }
        function register(type, id) {
            {
                if (type === null) {
                    return;
                }
                if (typeof type !== 'function' && typeof type !== 'object') {
                    return;
                } // This can happen in an edge case, e.g. if we register
                // return value of a HOC but it returns a cached component.
                // Ignore anything but the first registration for each type.
                if (allFamiliesByType.has(type)) {
                    return;
                } // Create family or remember to update it.
                // None of this bookkeeping affects reconciliation
                // until the first performReactRefresh() call above.
                var family = allFamiliesByID.get(id);
                if (family === undefined) {
                    family = {
                        current: type
                    };
                    allFamiliesByID.set(id, family);
                } else {
                    pendingUpdates.push([
                        family,
                        type
                    ]);
                }
                allFamiliesByType.set(type, family); // Visit inner types because we might not have registered them.
                if (typeof type === 'object' && type !== null) {
                    switch(getProperty(type, '$$typeof')){
                        case REACT_FORWARD_REF_TYPE:
                            register(type.render, id + '$render');
                            break;
                        case REACT_MEMO_TYPE:
                            register(type.type, id + '$type');
                            break;
                    }
                }
            }
        }
        function setSignature(type, key) {
            var forceReset = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
            var getCustomHooks = arguments.length > 3 ? arguments[3] : undefined;
            {
                if (!allSignaturesByType.has(type)) {
                    allSignaturesByType.set(type, {
                        forceReset: forceReset,
                        ownKey: key,
                        fullKey: null,
                        getCustomHooks: getCustomHooks || function() {
                            return [];
                        }
                    });
                } // Visit inner types because we might not have signed them.
                if (typeof type === 'object' && type !== null) {
                    switch(getProperty(type, '$$typeof')){
                        case REACT_FORWARD_REF_TYPE:
                            setSignature(type.render, key, forceReset, getCustomHooks);
                            break;
                        case REACT_MEMO_TYPE:
                            setSignature(type.type, key, forceReset, getCustomHooks);
                            break;
                    }
                }
            }
        } // This is lazily called during first render for a type.
        // It captures Hook list at that time so inline requires don't break comparisons.
        function collectCustomHooksForSignature(type) {
            {
                var signature = allSignaturesByType.get(type);
                if (signature !== undefined) {
                    computeFullKey(signature);
                }
            }
        }
        function getFamilyByID(id) {
            {
                return allFamiliesByID.get(id);
            }
        }
        function getFamilyByType(type) {
            {
                return allFamiliesByType.get(type);
            }
        }
        function findAffectedHostInstances(families) {
            {
                var affectedInstances = new Set();
                mountedRoots.forEach(function(root) {
                    var helpers = helpersByRoot.get(root);
                    if (helpers === undefined) {
                        throw new Error('Could not find helpers for a root. This is a bug in React Refresh.');
                    }
                    var instancesForRoot = helpers.findHostInstancesForRefresh(root, families);
                    instancesForRoot.forEach(function(inst) {
                        affectedInstances.add(inst);
                    });
                });
                return affectedInstances;
            }
        }
        function injectIntoGlobalHook(globalObject) {
            {
                // For React Native, the global hook will be set up by require('react-devtools-core').
                // That code will run before us. So we need to monkeypatch functions on existing hook.
                // For React Web, the global hook will be set up by the extension.
                // This will also run before us.
                var hook = globalObject.__REACT_DEVTOOLS_GLOBAL_HOOK__;
                if (hook === undefined) {
                    // However, if there is no DevTools extension, we'll need to set up the global hook ourselves.
                    // Note that in this case it's important that renderer code runs *after* this method call.
                    // Otherwise, the renderer will think that there is no global hook, and won't do the injection.
                    var nextID = 0;
                    globalObject.__REACT_DEVTOOLS_GLOBAL_HOOK__ = hook = {
                        renderers: new Map(),
                        supportsFiber: true,
                        inject: function(injected) {
                            return nextID++;
                        },
                        onScheduleFiberRoot: function(id, root, children) {},
                        onCommitFiberRoot: function(id, root, maybePriorityLevel, didError) {},
                        onCommitFiberUnmount: function() {}
                    };
                }
                if (hook.isDisabled) {
                    // This isn't a real property on the hook, but it can be set to opt out
                    // of DevTools integration and associated warnings and logs.
                    // Using console['warn'] to evade Babel and ESLint
                    console['warn']('Something has shimmed the React DevTools global hook (__REACT_DEVTOOLS_GLOBAL_HOOK__). ' + 'Fast Refresh is not compatible with this shim and will be disabled.');
                    return;
                } // Here, we just want to get a reference to scheduleRefresh.
                var oldInject = hook.inject;
                hook.inject = function(injected) {
                    var id = oldInject.apply(this, arguments);
                    if (typeof injected.scheduleRefresh === 'function' && typeof injected.setRefreshHandler === 'function') {
                        // This version supports React Refresh.
                        helpersByRendererID.set(id, injected);
                    }
                    return id;
                }; // Do the same for any already injected roots.
                // This is useful if ReactDOM has already been initialized.
                // https://github.com/facebook/react/issues/17626
                hook.renderers.forEach(function(injected, id) {
                    if (typeof injected.scheduleRefresh === 'function' && typeof injected.setRefreshHandler === 'function') {
                        // This version supports React Refresh.
                        helpersByRendererID.set(id, injected);
                    }
                }); // We also want to track currently mounted roots.
                var oldOnCommitFiberRoot = hook.onCommitFiberRoot;
                var oldOnScheduleFiberRoot = hook.onScheduleFiberRoot || function() {};
                hook.onScheduleFiberRoot = function(id, root, children) {
                    if (!isPerformingRefresh) {
                        // If it was intentionally scheduled, don't attempt to restore.
                        // This includes intentionally scheduled unmounts.
                        failedRoots.delete(root);
                        if (rootElements !== null) {
                            rootElements.set(root, children);
                        }
                    }
                    return oldOnScheduleFiberRoot.apply(this, arguments);
                };
                hook.onCommitFiberRoot = function(id, root, maybePriorityLevel, didError) {
                    var helpers = helpersByRendererID.get(id);
                    if (helpers !== undefined) {
                        helpersByRoot.set(root, helpers);
                        var current = root.current;
                        var alternate = current.alternate; // We need to determine whether this root has just (un)mounted.
                        // This logic is copy-pasted from similar logic in the DevTools backend.
                        // If this breaks with some refactoring, you'll want to update DevTools too.
                        if (alternate !== null) {
                            var wasMounted = alternate.memoizedState != null && alternate.memoizedState.element != null && mountedRoots.has(root);
                            var isMounted = current.memoizedState != null && current.memoizedState.element != null;
                            if (!wasMounted && isMounted) {
                                // Mount a new root.
                                mountedRoots.add(root);
                                failedRoots.delete(root);
                            } else if (wasMounted && isMounted) ;
                            else if (wasMounted && !isMounted) {
                                // Unmount an existing root.
                                mountedRoots.delete(root);
                                if (didError) {
                                    // We'll remount it on future edits.
                                    failedRoots.add(root);
                                } else {
                                    helpersByRoot.delete(root);
                                }
                            } else if (!wasMounted && !isMounted) {
                                if (didError) {
                                    // We'll remount it on future edits.
                                    failedRoots.add(root);
                                }
                            }
                        } else {
                            // Mount a new root.
                            mountedRoots.add(root);
                        }
                    } // Always call the decorated DevTools hook.
                    return oldOnCommitFiberRoot.apply(this, arguments);
                };
            }
        }
        function hasUnrecoverableErrors() {
            // TODO: delete this after removing dependency in RN.
            return false;
        } // Exposed for testing.
        function _getMountedRootCount() {
            {
                return mountedRoots.size;
            }
        } // This is a wrapper over more primitive functions for setting signature.
        // Signatures let us decide whether the Hook order has changed on refresh.
        //
        // This function is intended to be used as a transform target, e.g.:
        // var _s = createSignatureFunctionForTransform()
        //
        // function Hello() {
        //   const [foo, setFoo] = useState(0);
        //   const value = useCustomHook();
        //   _s(); /* Call without arguments triggers collecting the custom Hook list.
        //          * This doesn't happen during the module evaluation because we
        //          * don't want to change the module order with inline requires.
        //          * Next calls are noops. */
        //   return <h1>Hi</h1>;
        // }
        //
        // /* Call with arguments attaches the signature to the type: */
        // _s(
        //   Hello,
        //   'useState{[foo, setFoo]}(0)',
        //   () => [useCustomHook], /* Lazy to avoid triggering inline requires */
        // );
        function createSignatureFunctionForTransform() {
            {
                var savedType;
                var hasCustomHooks;
                var didCollectHooks = false;
                return function(type, key, forceReset, getCustomHooks) {
                    if (typeof key === 'string') {
                        // We're in the initial phase that associates signatures
                        // with the functions. Note this may be called multiple times
                        // in HOC chains like _s(hoc1(_s(hoc2(_s(actualFunction))))).
                        if (!savedType) {
                            // We're in the innermost call, so this is the actual type.
                            savedType = type;
                            hasCustomHooks = typeof getCustomHooks === 'function';
                        } // Set the signature for all types (even wrappers!) in case
                        // they have no signatures of their own. This is to prevent
                        // problems like https://github.com/facebook/react/issues/20417.
                        if (type != null && (typeof type === 'function' || typeof type === 'object')) {
                            setSignature(type, key, forceReset, getCustomHooks);
                        }
                        return type;
                    } else {
                        // We're in the _s() call without arguments, which means
                        // this is the time to collect custom Hook signatures.
                        // Only do this once. This path is hot and runs *inside* every render!
                        if (!didCollectHooks && hasCustomHooks) {
                            didCollectHooks = true;
                            collectCustomHooksForSignature(savedType);
                        }
                    }
                };
            }
        }
        function isLikelyComponentType(type) {
            {
                switch(typeof type){
                    case 'function':
                        {
                            // First, deal with classes.
                            if (type.prototype != null) {
                                if (type.prototype.isReactComponent) {
                                    // React class.
                                    return true;
                                }
                                var ownNames = Object.getOwnPropertyNames(type.prototype);
                                if (ownNames.length > 1 || ownNames[0] !== 'constructor') {
                                    // This looks like a class.
                                    return false;
                                } // eslint-disable-next-line no-proto
                                if (type.prototype.__proto__ !== Object.prototype) {
                                    // It has a superclass.
                                    return false;
                                } // Pass through.
                            // This looks like a regular function with empty prototype.
                            } // For plain functions and arrows, use name as a heuristic.
                            var name = type.name || type.displayName;
                            return typeof name === 'string' && /^[A-Z]/.test(name);
                        }
                    case 'object':
                        {
                            if (type != null) {
                                switch(getProperty(type, '$$typeof')){
                                    case REACT_FORWARD_REF_TYPE:
                                    case REACT_MEMO_TYPE:
                                        // Definitely React components.
                                        return true;
                                    default:
                                        return false;
                                }
                            }
                            return false;
                        }
                    default:
                        {
                            return false;
                        }
                }
            }
        }
        exports._getMountedRootCount = _getMountedRootCount;
        exports.collectCustomHooksForSignature = collectCustomHooksForSignature;
        exports.createSignatureFunctionForTransform = createSignatureFunctionForTransform;
        exports.findAffectedHostInstances = findAffectedHostInstances;
        exports.getFamilyByID = getFamilyByID;
        exports.getFamilyByType = getFamilyByType;
        exports.hasUnrecoverableErrors = hasUnrecoverableErrors;
        exports.injectIntoGlobalHook = injectIntoGlobalHook;
        exports.isLikelyComponentType = isLikelyComponentType;
        exports.performReactRefresh = performReactRefresh;
        exports.register = register;
        exports.setSignature = setSignature;
    })();
}
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-refresh/runtime.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-refresh/cjs/react-refresh-runtime.development.js [client] (ecmascript)");
}
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/@next/react-refresh-utils/dist/internal/helpers.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * MIT License
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */ var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
// This file is copied from the Metro JavaScript bundler, with minor tweaks for
// webpack 4 compatibility.
//
// https://github.com/facebook/metro/blob/d6b9685c730d0d63577db40f41369157f28dfa3a/packages/metro/src/lib/polyfills/require.js
const runtime_1 = __importDefault(__turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-refresh/runtime.js [client] (ecmascript)"));
function isSafeExport(key) {
    return key === '__esModule' || key === '__N_SSG' || key === '__N_SSP' || // TODO: remove this key from page config instead of allow listing it
    key === 'config';
}
function registerExportsForReactRefresh(moduleExports, moduleID) {
    runtime_1.default.register(moduleExports, moduleID + ' %exports%');
    if (moduleExports == null || typeof moduleExports !== 'object') {
        // Exit if we can't iterate over exports.
        // (This is important for legacy environments.)
        return;
    }
    for(var key in moduleExports){
        if (isSafeExport(key)) {
            continue;
        }
        try {
            var exportValue = moduleExports[key];
        } catch (_a) {
            continue;
        }
        var typeID = moduleID + ' %exports% ' + key;
        runtime_1.default.register(exportValue, typeID);
    }
}
function getRefreshBoundarySignature(moduleExports) {
    var signature = [];
    signature.push(runtime_1.default.getFamilyByType(moduleExports));
    if (moduleExports == null || typeof moduleExports !== 'object') {
        // Exit if we can't iterate over exports.
        // (This is important for legacy environments.)
        return signature;
    }
    for(var key in moduleExports){
        if (isSafeExport(key)) {
            continue;
        }
        try {
            var exportValue = moduleExports[key];
        } catch (_a) {
            continue;
        }
        signature.push(key);
        signature.push(runtime_1.default.getFamilyByType(exportValue));
    }
    return signature;
}
function isReactRefreshBoundary(moduleExports) {
    if (runtime_1.default.isLikelyComponentType(moduleExports)) {
        return true;
    }
    if (moduleExports == null || typeof moduleExports !== 'object') {
        // Exit if we can't iterate over exports.
        return false;
    }
    var hasExports = false;
    var areAllExportsComponents = true;
    for(var key in moduleExports){
        hasExports = true;
        if (isSafeExport(key)) {
            continue;
        }
        try {
            var exportValue = moduleExports[key];
        } catch (_a) {
            // This might fail due to circular dependencies
            return false;
        }
        if (!runtime_1.default.isLikelyComponentType(exportValue)) {
            areAllExportsComponents = false;
        }
    }
    return hasExports && areAllExportsComponents;
}
function shouldInvalidateReactRefreshBoundary(prevSignature, nextSignature) {
    if (prevSignature.length !== nextSignature.length) {
        return true;
    }
    for(var i = 0; i < nextSignature.length; i++){
        if (prevSignature[i] !== nextSignature[i]) {
            return true;
        }
    }
    return false;
}
var isUpdateScheduled = false;
// This function aggregates updates from multiple modules into a single React Refresh call.
function scheduleUpdate() {
    if (isUpdateScheduled) {
        return;
    }
    isUpdateScheduled = true;
    function canApplyUpdate(status) {
        return status === 'idle';
    }
    function applyUpdate() {
        isUpdateScheduled = false;
        try {
            runtime_1.default.performReactRefresh();
        } catch (err) {
            console.warn('Warning: Failed to re-render. We will retry on the next Fast Refresh event.\n' + err);
        }
    }
    if (canApplyUpdate(module.hot.status())) {
        // Apply update on the next tick.
        Promise.resolve().then(()=>{
            applyUpdate();
        });
        return;
    }
    const statusHandler = (status)=>{
        if (canApplyUpdate(status)) {
            module.hot.removeStatusHandler(statusHandler);
            applyUpdate();
        }
    };
    // Apply update once the HMR runtime's status is idle.
    module.hot.addStatusHandler(statusHandler);
}
// Needs to be compatible with IE11
exports.default = {
    registerExportsForReactRefresh: registerExportsForReactRefresh,
    isReactRefreshBoundary: isReactRefreshBoundary,
    shouldInvalidateReactRefreshBoundary: shouldInvalidateReactRefreshBoundary,
    getRefreshBoundarySignature: getRefreshBoundarySignature,
    scheduleUpdate: scheduleUpdate
}; //# sourceMappingURL=helpers.js.map
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/@next/react-refresh-utils/dist/runtime.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
const runtime_1 = __importDefault(__turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-refresh/runtime.js [client] (ecmascript)"));
const helpers_1 = __importDefault(__turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/@next/react-refresh-utils/dist/internal/helpers.js [client] (ecmascript)"));
// Hook into ReactDOM initialization
runtime_1.default.injectIntoGlobalHook(self);
// Register global helpers
self.$RefreshHelpers$ = helpers_1.default;
// Register a helper for module execution interception
self.$RefreshInterceptModuleExecution$ = function(webpackModuleId) {
    var prevRefreshReg = self.$RefreshReg$;
    var prevRefreshSig = self.$RefreshSig$;
    self.$RefreshReg$ = function(type, id) {
        runtime_1.default.register(type, webpackModuleId + ' ' + id);
    };
    self.$RefreshSig$ = runtime_1.default.createSignatureFunctionForTransform;
    // Modeled after `useEffect` cleanup pattern:
    // https://react.dev/learn/synchronizing-with-effects#step-3-add-cleanup-if-needed
    return function() {
        self.$RefreshReg$ = prevRefreshReg;
        self.$RefreshSig$ = prevRefreshSig;
    };
}; //# sourceMappingURL=runtime.js.map
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/path-to-regexp/index.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

(()=>{
    "use strict";
    if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = ("TURBOPACK compile-time value", "/ROOT/spam-cloud-25-11-25/node_modules/next/dist/compiled/path-to-regexp") + "/";
    var e = {};
    (()=>{
        var n = e;
        Object.defineProperty(n, "__esModule", {
            value: true
        });
        n.pathToRegexp = n.tokensToRegexp = n.regexpToFunction = n.match = n.tokensToFunction = n.compile = n.parse = void 0;
        function lexer(e) {
            var n = [];
            var r = 0;
            while(r < e.length){
                var t = e[r];
                if (t === "*" || t === "+" || t === "?") {
                    n.push({
                        type: "MODIFIER",
                        index: r,
                        value: e[r++]
                    });
                    continue;
                }
                if (t === "\\") {
                    n.push({
                        type: "ESCAPED_CHAR",
                        index: r++,
                        value: e[r++]
                    });
                    continue;
                }
                if (t === "{") {
                    n.push({
                        type: "OPEN",
                        index: r,
                        value: e[r++]
                    });
                    continue;
                }
                if (t === "}") {
                    n.push({
                        type: "CLOSE",
                        index: r,
                        value: e[r++]
                    });
                    continue;
                }
                if (t === ":") {
                    var a = "";
                    var i = r + 1;
                    while(i < e.length){
                        var o = e.charCodeAt(i);
                        if (o >= 48 && o <= 57 || o >= 65 && o <= 90 || o >= 97 && o <= 122 || o === 95) {
                            a += e[i++];
                            continue;
                        }
                        break;
                    }
                    if (!a) throw new TypeError("Missing parameter name at ".concat(r));
                    n.push({
                        type: "NAME",
                        index: r,
                        value: a
                    });
                    r = i;
                    continue;
                }
                if (t === "(") {
                    var c = 1;
                    var f = "";
                    var i = r + 1;
                    if (e[i] === "?") {
                        throw new TypeError('Pattern cannot start with "?" at '.concat(i));
                    }
                    while(i < e.length){
                        if (e[i] === "\\") {
                            f += e[i++] + e[i++];
                            continue;
                        }
                        if (e[i] === ")") {
                            c--;
                            if (c === 0) {
                                i++;
                                break;
                            }
                        } else if (e[i] === "(") {
                            c++;
                            if (e[i + 1] !== "?") {
                                throw new TypeError("Capturing groups are not allowed at ".concat(i));
                            }
                        }
                        f += e[i++];
                    }
                    if (c) throw new TypeError("Unbalanced pattern at ".concat(r));
                    if (!f) throw new TypeError("Missing pattern at ".concat(r));
                    n.push({
                        type: "PATTERN",
                        index: r,
                        value: f
                    });
                    r = i;
                    continue;
                }
                n.push({
                    type: "CHAR",
                    index: r,
                    value: e[r++]
                });
            }
            n.push({
                type: "END",
                index: r,
                value: ""
            });
            return n;
        }
        function parse(e, n) {
            if (n === void 0) {
                n = {};
            }
            var r = lexer(e);
            var t = n.prefixes, a = t === void 0 ? "./" : t, i = n.delimiter, o = i === void 0 ? "/#?" : i;
            var c = [];
            var f = 0;
            var u = 0;
            var p = "";
            var tryConsume = function(e) {
                if (u < r.length && r[u].type === e) return r[u++].value;
            };
            var mustConsume = function(e) {
                var n = tryConsume(e);
                if (n !== undefined) return n;
                var t = r[u], a = t.type, i = t.index;
                throw new TypeError("Unexpected ".concat(a, " at ").concat(i, ", expected ").concat(e));
            };
            var consumeText = function() {
                var e = "";
                var n;
                while(n = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")){
                    e += n;
                }
                return e;
            };
            var isSafe = function(e) {
                for(var n = 0, r = o; n < r.length; n++){
                    var t = r[n];
                    if (e.indexOf(t) > -1) return true;
                }
                return false;
            };
            var safePattern = function(e) {
                var n = c[c.length - 1];
                var r = e || (n && typeof n === "string" ? n : "");
                if (n && !r) {
                    throw new TypeError('Must have text between two parameters, missing text after "'.concat(n.name, '"'));
                }
                if (!r || isSafe(r)) return "[^".concat(escapeString(o), "]+?");
                return "(?:(?!".concat(escapeString(r), ")[^").concat(escapeString(o), "])+?");
            };
            while(u < r.length){
                var v = tryConsume("CHAR");
                var s = tryConsume("NAME");
                var d = tryConsume("PATTERN");
                if (s || d) {
                    var g = v || "";
                    if (a.indexOf(g) === -1) {
                        p += g;
                        g = "";
                    }
                    if (p) {
                        c.push(p);
                        p = "";
                    }
                    c.push({
                        name: s || f++,
                        prefix: g,
                        suffix: "",
                        pattern: d || safePattern(g),
                        modifier: tryConsume("MODIFIER") || ""
                    });
                    continue;
                }
                var x = v || tryConsume("ESCAPED_CHAR");
                if (x) {
                    p += x;
                    continue;
                }
                if (p) {
                    c.push(p);
                    p = "";
                }
                var h = tryConsume("OPEN");
                if (h) {
                    var g = consumeText();
                    var l = tryConsume("NAME") || "";
                    var m = tryConsume("PATTERN") || "";
                    var T = consumeText();
                    mustConsume("CLOSE");
                    c.push({
                        name: l || (m ? f++ : ""),
                        pattern: l && !m ? safePattern(g) : m,
                        prefix: g,
                        suffix: T,
                        modifier: tryConsume("MODIFIER") || ""
                    });
                    continue;
                }
                mustConsume("END");
            }
            return c;
        }
        n.parse = parse;
        function compile(e, n) {
            return tokensToFunction(parse(e, n), n);
        }
        n.compile = compile;
        function tokensToFunction(e, n) {
            if (n === void 0) {
                n = {};
            }
            var r = flags(n);
            var t = n.encode, a = t === void 0 ? function(e) {
                return e;
            } : t, i = n.validate, o = i === void 0 ? true : i;
            var c = e.map(function(e) {
                if (typeof e === "object") {
                    return new RegExp("^(?:".concat(e.pattern, ")$"), r);
                }
            });
            return function(n) {
                var r = "";
                for(var t = 0; t < e.length; t++){
                    var i = e[t];
                    if (typeof i === "string") {
                        r += i;
                        continue;
                    }
                    var f = n ? n[i.name] : undefined;
                    var u = i.modifier === "?" || i.modifier === "*";
                    var p = i.modifier === "*" || i.modifier === "+";
                    if (Array.isArray(f)) {
                        if (!p) {
                            throw new TypeError('Expected "'.concat(i.name, '" to not repeat, but got an array'));
                        }
                        if (f.length === 0) {
                            if (u) continue;
                            throw new TypeError('Expected "'.concat(i.name, '" to not be empty'));
                        }
                        for(var v = 0; v < f.length; v++){
                            var s = a(f[v], i);
                            if (o && !c[t].test(s)) {
                                throw new TypeError('Expected all "'.concat(i.name, '" to match "').concat(i.pattern, '", but got "').concat(s, '"'));
                            }
                            r += i.prefix + s + i.suffix;
                        }
                        continue;
                    }
                    if (typeof f === "string" || typeof f === "number") {
                        var s = a(String(f), i);
                        if (o && !c[t].test(s)) {
                            throw new TypeError('Expected "'.concat(i.name, '" to match "').concat(i.pattern, '", but got "').concat(s, '"'));
                        }
                        r += i.prefix + s + i.suffix;
                        continue;
                    }
                    if (u) continue;
                    var d = p ? "an array" : "a string";
                    throw new TypeError('Expected "'.concat(i.name, '" to be ').concat(d));
                }
                return r;
            };
        }
        n.tokensToFunction = tokensToFunction;
        function match(e, n) {
            var r = [];
            var t = pathToRegexp(e, r, n);
            return regexpToFunction(t, r, n);
        }
        n.match = match;
        function regexpToFunction(e, n, r) {
            if (r === void 0) {
                r = {};
            }
            var t = r.decode, a = t === void 0 ? function(e) {
                return e;
            } : t;
            return function(r) {
                var t = e.exec(r);
                if (!t) return false;
                var i = t[0], o = t.index;
                var c = Object.create(null);
                var _loop_1 = function(e) {
                    if (t[e] === undefined) return "continue";
                    var r = n[e - 1];
                    if (r.modifier === "*" || r.modifier === "+") {
                        c[r.name] = t[e].split(r.prefix + r.suffix).map(function(e) {
                            return a(e, r);
                        });
                    } else {
                        c[r.name] = a(t[e], r);
                    }
                };
                for(var f = 1; f < t.length; f++){
                    _loop_1(f);
                }
                return {
                    path: i,
                    index: o,
                    params: c
                };
            };
        }
        n.regexpToFunction = regexpToFunction;
        function escapeString(e) {
            return e.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
        }
        function flags(e) {
            return e && e.sensitive ? "" : "i";
        }
        function regexpToRegexp(e, n) {
            if (!n) return e;
            var r = /\((?:\?<(.*?)>)?(?!\?)/g;
            var t = 0;
            var a = r.exec(e.source);
            while(a){
                n.push({
                    name: a[1] || t++,
                    prefix: "",
                    suffix: "",
                    modifier: "",
                    pattern: ""
                });
                a = r.exec(e.source);
            }
            return e;
        }
        function arrayToRegexp(e, n, r) {
            var t = e.map(function(e) {
                return pathToRegexp(e, n, r).source;
            });
            return new RegExp("(?:".concat(t.join("|"), ")"), flags(r));
        }
        function stringToRegexp(e, n, r) {
            return tokensToRegexp(parse(e, r), n, r);
        }
        function tokensToRegexp(e, n, r) {
            if (r === void 0) {
                r = {};
            }
            var t = r.strict, a = t === void 0 ? false : t, i = r.start, o = i === void 0 ? true : i, c = r.end, f = c === void 0 ? true : c, u = r.encode, p = u === void 0 ? function(e) {
                return e;
            } : u, v = r.delimiter, s = v === void 0 ? "/#?" : v, d = r.endsWith, g = d === void 0 ? "" : d;
            var x = "[".concat(escapeString(g), "]|$");
            var h = "[".concat(escapeString(s), "]");
            var l = o ? "^" : "";
            for(var m = 0, T = e; m < T.length; m++){
                var E = T[m];
                if (typeof E === "string") {
                    l += escapeString(p(E));
                } else {
                    var w = escapeString(p(E.prefix));
                    var y = escapeString(p(E.suffix));
                    if (E.pattern) {
                        if (n) n.push(E);
                        if (w || y) {
                            if (E.modifier === "+" || E.modifier === "*") {
                                var R = E.modifier === "*" ? "?" : "";
                                l += "(?:".concat(w, "((?:").concat(E.pattern, ")(?:").concat(y).concat(w, "(?:").concat(E.pattern, "))*)").concat(y, ")").concat(R);
                            } else {
                                l += "(?:".concat(w, "(").concat(E.pattern, ")").concat(y, ")").concat(E.modifier);
                            }
                        } else {
                            if (E.modifier === "+" || E.modifier === "*") {
                                throw new TypeError('Can not repeat "'.concat(E.name, '" without a prefix and suffix'));
                            }
                            l += "(".concat(E.pattern, ")").concat(E.modifier);
                        }
                    } else {
                        l += "(?:".concat(w).concat(y, ")").concat(E.modifier);
                    }
                }
            }
            if (f) {
                if (!a) l += "".concat(h, "?");
                l += !r.endsWith ? "$" : "(?=".concat(x, ")");
            } else {
                var A = e[e.length - 1];
                var _ = typeof A === "string" ? h.indexOf(A[A.length - 1]) > -1 : A === undefined;
                if (!a) {
                    l += "(?:".concat(h, "(?=").concat(x, "))?");
                }
                if (!_) {
                    l += "(?=".concat(h, "|").concat(x, ")");
                }
            }
            return new RegExp(l, flags(r));
        }
        n.tokensToRegexp = tokensToRegexp;
        function pathToRegexp(e, n, r) {
            if (e instanceof RegExp) return regexpToRegexp(e, n);
            if (Array.isArray(e)) return arrayToRegexp(e, n, r);
            return stringToRegexp(e, n, r);
        }
        n.pathToRegexp = pathToRegexp;
    })();
    module.exports = e;
})();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-is/cjs/react-is.development.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-is.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function typeOf(object) {
        if ("object" === typeof object && null !== object) {
            var $$typeof = object.$$typeof;
            switch($$typeof){
                case REACT_ELEMENT_TYPE:
                    switch(object = object.type, object){
                        case REACT_FRAGMENT_TYPE:
                        case REACT_PROFILER_TYPE:
                        case REACT_STRICT_MODE_TYPE:
                        case REACT_SUSPENSE_TYPE:
                        case REACT_SUSPENSE_LIST_TYPE:
                        case REACT_VIEW_TRANSITION_TYPE:
                            return object;
                        default:
                            switch(object = object && object.$$typeof, object){
                                case REACT_CONTEXT_TYPE:
                                case REACT_FORWARD_REF_TYPE:
                                case REACT_LAZY_TYPE:
                                case REACT_MEMO_TYPE:
                                    return object;
                                case REACT_CONSUMER_TYPE:
                                    return object;
                                default:
                                    return $$typeof;
                            }
                    }
                case REACT_PORTAL_TYPE:
                    return $$typeof;
            }
        }
    }
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
    exports.ContextConsumer = REACT_CONSUMER_TYPE;
    exports.ContextProvider = REACT_CONTEXT_TYPE;
    exports.Element = REACT_ELEMENT_TYPE;
    exports.ForwardRef = REACT_FORWARD_REF_TYPE;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Lazy = REACT_LAZY_TYPE;
    exports.Memo = REACT_MEMO_TYPE;
    exports.Portal = REACT_PORTAL_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.SuspenseList = REACT_SUSPENSE_LIST_TYPE;
    exports.isContextConsumer = function(object) {
        return typeOf(object) === REACT_CONSUMER_TYPE;
    };
    exports.isContextProvider = function(object) {
        return typeOf(object) === REACT_CONTEXT_TYPE;
    };
    exports.isElement = function(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    };
    exports.isForwardRef = function(object) {
        return typeOf(object) === REACT_FORWARD_REF_TYPE;
    };
    exports.isFragment = function(object) {
        return typeOf(object) === REACT_FRAGMENT_TYPE;
    };
    exports.isLazy = function(object) {
        return typeOf(object) === REACT_LAZY_TYPE;
    };
    exports.isMemo = function(object) {
        return typeOf(object) === REACT_MEMO_TYPE;
    };
    exports.isPortal = function(object) {
        return typeOf(object) === REACT_PORTAL_TYPE;
    };
    exports.isProfiler = function(object) {
        return typeOf(object) === REACT_PROFILER_TYPE;
    };
    exports.isStrictMode = function(object) {
        return typeOf(object) === REACT_STRICT_MODE_TYPE;
    };
    exports.isSuspense = function(object) {
        return typeOf(object) === REACT_SUSPENSE_TYPE;
    };
    exports.isSuspenseList = function(object) {
        return typeOf(object) === REACT_SUSPENSE_LIST_TYPE;
    };
    exports.isValidElementType = function(type) {
        return "string" === typeof type || "function" === typeof type || type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || type === REACT_VIEW_TRANSITION_TYPE || "object" === typeof type && null !== type && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_CONSUMER_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_CLIENT_REFERENCE || void 0 !== type.getModuleId) ? !0 : !1;
    };
    exports.typeOf = typeOf;
}();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-is/index.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/react-is/cjs/react-is.development.js [client] (ecmascript)");
}
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/next-devtools/index.js (raw)", ((__turbopack_context__, module, exports) => {

var process = {env:
{"__NEXT_DEV_INDICATOR":true,"__NEXT_DEV_INDICATOR_POSITION":"bottom-left","__NEXT_ROUTER_BASEPATH":"","__NEXT_TELEMETRY_DISABLED":false,"__NEXT_BUNDLER":"Turbopack","__NEXT_BUNDLER_HAS_PERSISTENT_CACHE":false,"TURBOPACK":true,"__NEXT_CACHE_COMPONENTS":false,"__NEXT_DIST_DIR":"C:\\Users\\linux\\Downloads\\spam-cloud-25-11-25\\.next\\dev"}
};
(function(){
var __webpack_modules__={"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-indicator/devtools-indicator.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`[data-nextjs-toast] {
  &[data-hidden='true'] {
    display: none;
  }
}

.dev-tools-indicator-menu {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-alpha-400);
  background-clip: padding-box;
  box-shadow: var(--shadow-menu);
  border-radius: var(--rounded-xl);
  position: absolute;
  font-family: var(--font-stack-sans);
  z-index: 3;
  overflow: hidden;
  opacity: 0;
  outline: 0;
  min-width: 248px;
  transition: opacity var(--animate-out-duration-ms)
    var(--animate-out-timing-function);

  &[data-rendered='true'] {
    opacity: 1;
    scale: 1;
  }
}

.dev-tools-indicator-inner {
  padding: 6px;
  width: 100%;
}

.dev-tools-indicator-item {
  display: flex;
  align-items: center;
  padding: 8px 6px;
  height: var(--size-36);
  border-radius: 6px;
  text-decoration: none !important;
  user-select: none;
  white-space: nowrap;

  svg {
    width: var(--size-16);
    height: var(--size-16);
  }

  &:focus-visible {
    outline: 0;
  }
}

.dev-tools-indicator-footer {
  background: var(--color-background-200);
  padding: 6px;
  border-top: 1px solid var(--color-gray-400);
  width: 100%;
}

.dev-tools-indicator-item[data-selected='true'] {
  cursor: pointer;
  background-color: var(--color-gray-200);
}

.dev-tools-indicator-label {
  font-size: var(--size-14);
  line-height: var(--size-20);
  color: var(--color-gray-1000);
}

.dev-tools-indicator-value {
  font-size: var(--size-14);
  line-height: var(--size-20);
  color: var(--color-gray-900);
  margin-left: auto;
}

.dev-tools-indicator-issue-count {
  --color-primary: var(--color-gray-800);
  --color-secondary: var(--color-gray-100);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 8px;
  min-width: var(--size-40);
  height: var(--size-24);
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-alpha-400);
  background-clip: padding-box;
  box-shadow: var(--shadow-small);
  padding: 2px;
  color: var(--color-gray-1000);
  border-radius: 128px;
  font-weight: 500;
  font-size: var(--size-13);
  font-variant-numeric: tabular-nums;

  &[data-has-issues='true'] {
    --color-primary: var(--color-red-800);
    --color-secondary: var(--color-red-100);
  }

  .dev-tools-indicator-issue-count-indicator {
    width: var(--size-8);
    height: var(--size-8);
    background: var(--color-primary);
    box-shadow: 0 0 0 2px var(--color-secondary);
    border-radius: 50%;
  }
}

.dev-tools-indicator-shortcut {
  display: flex;
  gap: 4px;

  kbd {
    width: var(--size-20);
    height: var(--size-20);
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: var(--rounded-md);
    border: 1px solid var(--color-gray-400);
    font-family: var(--font-stack-sans);
    background: var(--color-background-100);
    color: var(--color-gray-1000);
    text-align: center;
    font-size: var(--size-12);
    line-height: var(--size-16);
  }
}

.dev-tools-grabbing {
  cursor: grabbing;

  > * {
    pointer-events: none;
  }
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-panel/resize/resize-handle.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`.resize-container {
  position: absolute;
  /* todo: better z index */
  z-index: 10;
  /* todo: is this needed */
  background: transparent;
}

.resize-line {
  position: absolute;
  /* todo smarter z index */
  z-index: -1;
  pointer-events: none;
  /* a normal exit animation curve- at this point the exit animation is */
  /* immediately responsive so we don't need a bespoke curve */
  transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  /* todo: better var? */
  border: 1px solid var(--color-gray-400);
}

/* start really fast because we start super hidden initially behind the panel, otherwise feels like an unintended animation delay */
.resize-container:hover ~ .resize-line {
  transition: transform 0.25s cubic-bezier(0.23, 1, 0.32, 0.9);
}

.resize-container.right,
.resize-container.left {
  top: 0;
  height: 100%;
  width: 22px;
  cursor: ew-resize;
}

/* todo: don't hard code all these values/use vars */

.resize-container.bottom,
.resize-container.top {
  left: 0;
  width: 100%;
  height: 22px;
  cursor: ns-resize;
}

.resize-container.top {
  top: -7px;
}
.resize-container.bottom {
  bottom: -7px;
}
.resize-container.left {
  left: -7px;
}
.resize-container.right {
  right: -7px;
}

.resize-container.top-left,
.resize-container.top-right,
.resize-container.bottom-left,
.resize-container.bottom-right {
  width: 26px;
  height: 26px;
  z-index: 15;
}

.resize-container.top-left {
  top: -5px;
  left: -5px;
  cursor: nwse-resize;
}
.resize-container.top-right {
  top: -5px;
  right: -5px;
  cursor: nesw-resize;
}
.resize-container.bottom-left {
  bottom: -5px;
  left: -5px;
  cursor: nesw-resize;
}
.resize-container.bottom-right {
  bottom: -5px;
  right: -5px;
  cursor: nwse-resize;
}

.resize-line.top,
.resize-line.bottom {
  height: 18px;
  width: 100%;
  background-color: var(--color-background-200);
}

.resize-line.left,
.resize-line.right {
  width: 18px;
  height: 100%;
  background-color: var(--color-background-200);
}

.resize-line.top {
  top: -7px;
  left: calc(-1 * var(--border-left, 2px));
  width: calc(100% + var(--border-horizontal, 4px));
  border-radius: var(--rounded-lg) var(--rounded-lg) 0 0;
  transform: translateY(18px);
}

.resize-line.bottom {
  bottom: -7px;
  left: calc(-1 * var(--border-left, 2px));
  width: calc(100% + var(--border-horizontal, 4px));
  border-radius: 0 0 var(--rounded-lg) var(--rounded-lg);
  transform: translateY(-18px);
}

.resize-line.left {
  top: calc(-1 * var(--border-top, 2px));
  left: -7px;
  height: calc(100% + var(--border-vertical, 4px));
  border-radius: var(--rounded-lg) 0 0 var(--rounded-lg);
  transform: translateX(18px);
}

.resize-line.right {
  top: calc(-1 * var(--border-top, 2px));
  right: -7px;
  height: calc(100% + var(--border-vertical, 4px));
  border-radius: 0 var(--rounded-lg) var(--rounded-lg) 0;
  transform: translateX(-18px);
}

.resize-container.right:hover ~ .resize-line.right,
.resize-container.left:hover ~ .resize-line.left,
.resize-line.right.dragging,
.resize-line.left.dragging {
  transform: translateX(0);
}

.resize-container.bottom:hover ~ .resize-line.bottom,
.resize-container.top:hover ~ .resize-line.top,
.resize-line.bottom.dragging,
.resize-line.top.dragging {
  transform: translateY(0);
}

/* make sure that we don't show multiple handles at once
 * we should only ever show the currently resizing handle
 * regardless of hover state 
 */
.resize-container.no-hover.right:hover ~ .resize-line.right {
  transform: translateX(-20px);
}
.resize-container.no-hover.left:hover ~ .resize-line.left {
  transform: translateX(20px);
}
.resize-container.no-hover.bottom:hover ~ .resize-line.bottom {
  transform: translateY(-20px);
}
.resize-container.no-hover.top:hover ~ .resize-line.top {
  transform: translateY(20px);
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-boundary-trigger.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`.segment-boundary-trigger {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 6px;
  line-height: 16px;
  font-weight: 500;
  color: var(--color-gray-1000);
  border-radius: 999px;
  border: none;
  font-size: var(--size-12);
  cursor: pointer;
  transition: background-color 0.15s ease;
}

.segment-boundary-trigger-text {
  font-size: var(--size-12);
  font-weight: 500;
  user-select: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.segment-boundary-trigger-text .plus-icon {
  transition: transform 0.25s ease;
}

.segment-boundary-trigger-text:hover .plus-icon {
  color: var(--color-gray-800);
}

.segment-boundary-trigger svg {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
  vertical-align: middle;
}

.segment-boundary-trigger:hover svg {
  color: var(--color-gray-700);
}

.segment-boundary-trigger[disabled] svg,
.segment-boundary-trigger[disabled]:hover svg {
  color: var(--color-gray-400);
  cursor: not-allowed;
}

.segment-boundary-dropdown {
  padding: 8px;
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-400);
  border-radius: 16px;
  min-width: 120px;
  user-select: none;
  cursor: default;
  box-shadow: 0px 4px 8px -4px
    color-mix(in srgb, var(--color-gray-900) 4%, transparent);
}

.segment-boundary-dropdown-positioner {
  z-index: var(--top-z-index);
}

.segment-boundary-dropdown-item {
  display: flex;
  align-items: center;
  padding: 8px;
  line-height: 20px;
  font-size: 14px;
  border-radius: 6px;
  color: var(--color-gray-1000);
  cursor: pointer;
  min-width: 220px;
  border: none;
  background: none;
  width: 100%;
}

.segment-boundary-dropdown-item[data-disabled] {
  color: var(--color-gray-400);
  cursor: not-allowed;
}

.segment-boundary-dropdown-item svg {
  margin-right: 12px;
  color: currentColor;
}

.segment-boundary-dropdown-item:hover {
  background: var(--color-gray-200);
}

.segment-boundary-dropdown-item:first-child {
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
}

.segment-boundary-dropdown-item:last-child {
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
}

.segment-boundary-group-label {
  padding: 8px;
  font-size: 13px;
  line-height: 16px;
  font-weight: 400;
  color: var(--color-gray-900);
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-explorer.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`.segment-explorer-content {
  font-size: var(--size-14);
  padding: 0 8px;
  width: 100%;
  height: 100%;
}

.segment-explorer-page-route-bar {
  display: flex;
  align-items: center;
  padding: 14px 16px;
  background-color: var(--color-background-200);
  gap: 12px;
}

.segment-explorer-page-route-bar-path {
  font-size: var(--size-14);
  font-weight: 500;
  color: var(--color-gray-1000);
  font-family: var(--font-mono);
  white-space: nowrap;
  line-height: 20px;
}

.segment-explorer-item {
  margin: 4px 0;
  border-radius: 6px;
}

.segment-explorer-item:nth-child(even) {
  background-color: var(--color-background-200);
}
.segment-explorer-item-row {
  display: flex;
  flex-direction: column;
  padding-top: 10px;
  padding-bottom: 10px;
  padding-right: 4px;
}
.segment-explorer-item-row-main {
  display: flex;
  align-items: center;
  white-space: pre;
  cursor: default;
  color: var(--color-gray-1000);
}

.segment-explorer-children--intended {
  padding-left: 16px;
}

.segment-explorer-filename {
  display: inline-flex;
  width: 100%;
  align-items: center;
}

.segment-explorer-filename select {
  margin-left: auto;
}
.segment-explorer-filename--path {
  margin-right: 8px;
}
.segment-explorer-filename--path small {
  display: inline-block;
  width: 0;
  opacity: 0;
}
.segment-explorer-filename--name {
  color: var(--color-gray-800);
}

.segment-explorer-files {
  display: inline-flex;
  gap: 8px;
  margin-left: auto;
}

.segment-explorer-files + .segment-boundary-trigger {
  margin-left: 8px;
}

.segment-explorer-file-label {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0 6px;
  height: 20px;
  border-radius: 16px;
  line-height: 16px;
  font-size: var(--size-12);
  font-weight: 500;
  user-select: none;
  cursor: pointer;
  background-color: var(--color-gray-300);
  color: var(--color-gray-1000);
}
.segment-explorer-file-label-text {
  display: inline-flex;
  align-items: center;
}

.segment-explorer-file-label--overridden {
  background-color: var(--color-amber-300);
  color: var(--color-amber-900);
}

.segment-explorer-file-label .code-icon {
  opacity: 0;
  margin-left: 0;
  width: 0;
  transition: all 0.15s ease-in-out;
}
.segment-explorer-file-label:hover .code-icon {
  opacity: 1;
  width: 12px;
  margin-left: 4px;
}

.segment-explorer-file-label:hover {
  filter: brightness(0.95);
}

.segment-explorer-file-label--builtin {
  background-color: transparent;
  color: var(--color-gray-900);
  border: 1px dashed var(--color-gray-500);
  height: 24px;
  cursor: default;
}
.segment-explorer-file-label--builtin svg {
  margin-left: 4px;
  margin-right: -4px;
}

/* Footer styles */
.segment-explorer-footer {
  padding: 8px;
  border-top: 1px solid var(--color-gray-400);
  user-select: none;
}

.segment-explorer-footer-button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  padding: 6px;
  background: var(--color-background-100);
  border: 1px solid var(--color-gray-400);
  border-radius: 6px;
  color: var(--color-gray-1000);
  font-size: var(--size-14);
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.15s ease;
}

.segment-explorer-footer-button:hover:not(:disabled) {
  background: var(--color-gray-200);
}

.segment-explorer-footer-button--disabled {
  cursor: not-allowed;
}

.segment-explorer-footer-text {
  text-align: center;
}

.segment-explorer-footer-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  background: var(--color-amber-300);
  color: var(--color-amber-900);
  border-radius: 10px;
  font-size: var(--size-12);
  font-weight: 600;
  line-height: 1;
}

.segment-explorer-file-label-tooltip--sm {
  white-space: nowrap;
}

.segment-explorer-file-label-tooltip--lg {
  min-width: 200px;
}

.segment-explorer-suggestions {
  display: inline-flex;
  gap: 8px;
}

.segment-explorer-suggestions-tooltip {
  width: 200px;
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/toast/style.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`.nextjs-toast {
  position: fixed;
  z-index: var(--top-z-index);
  max-width: 420px;
  box-shadow: 0px 16px 32px rgba(0, 0, 0, 0.25);
}

.nextjs-toast-errors-parent {
  padding: 16px;
  border-radius: var(--rounded-4xl);
  font-weight: 500;
  color: var(--color-ansi-bright-white);
  background-color: var(--color-ansi-red);
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/tooltip/tooltip.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`.tooltip-wrapper {
  position: relative;
  display: inline-block;
  line-height: 1;
}

.tooltip {
  position: relative;
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 14px;
  line-height: 1.4;
  pointer-events: none;
  color: var(--color-gray-100);
  background-color: var(--color-gray-1000);
}

.tooltip-arrow {
  position: absolute;
  width: 0;
  height: 0;
  border-style: solid;
  border-width: var(--arrow-size, 6px);
  border-color: transparent;
}

.tooltip-arrow--top {
  border-width: var(--arrow-size, 6px) var(--arrow-size, 6px) 0
    var(--arrow-size, 6px);
  border-top-color: var(--color-gray-1000);
  bottom: 0;
  transform: translateY(100%);
}

.tooltip-arrow--bottom {
  border-width: 0 var(--arrow-size, 6px) var(--arrow-size, 6px)
    var(--arrow-size, 6px);
  border-bottom-color: var(--color-gray-1000);
  top: 0;
  transform: translateY(-100%);
}

.tooltip-arrow--left {
  border-width: var(--arrow-size, 6px) 0 var(--arrow-size, 6px)
    var(--arrow-size, 6px);
  border-left-color: var(--color-gray-1000);
  right: 0;
  transform: translateX(100%);
}

.tooltip-arrow--right {
  border-width: var(--arrow-size, 6px) var(--arrow-size, 6px)
    var(--arrow-size, 6px) 0;
  border-right-color: var(--color-gray-1000);
  left: 0;
  transform: translateX(-100%);
}

.tooltip-positioner {
  z-index: var(--top-z-index);
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/global.css":function(e,t,n){"use strict";n.d(t,{A:()=>f});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a),l=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/normalize.css"),s=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/default-theme.css"),c=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/dark-theme.css"),u=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/colors.css"),d=i()(o());d.i(l.A),d.i(s.A),d.i(c.A),d.i(u.A),d.push([e.id,`/* devtool global css variables */
:host {
  /* variables */
  --top-z-index: 2147483647;
}

/* global styles */
* {
  -webkit-font-smoothing: antialiased;
}

/* global reset for draggable content scrollbar styles */
[data-nextjs-scrollable-content],
[data-nextjs-scrollable-content] * {
  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
    border-radius: 0 0 1rem 1rem;
    margin-bottom: 1rem;
  }

  &::-webkit-scrollbar-button {
    display: none;
  }

  &::-webkit-scrollbar-track {
    border-radius: 0 0 1rem 1rem;
    background-color: var(--color-background-100);
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 1rem;
    background-color: var(--color-gray-500);
  }
}

/* Place overflow: hidden on this so we can break out from [data-nextjs-dialog] */
[data-nextjs-scrollable-content] {
  overflow: hidden;
  border-radius: inherit;
}
`,""]);let f=d},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/menu/panel-router.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`/* Panel content padding styles */
.panel-content {
  padding: 16px;
  padding-top: 8px;
  overflow: hidden;
}

/* User preferences wrapper styles */
.user-preferences-wrapper {
  padding: 20px;
  padding-top: 8px;
  overflow: hidden;
}

/* Panel route base styles */
.panel-route {
  opacity: var(--panel-opacity);
  transition: var(--panel-transition);
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/normalize.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`:host {
  all: initial;

  /* the direction property is not reset by 'all' */
  direction: ltr;
}

/*!
 * Bootstrap Reboot v4.4.1 (https://getbootstrap.com/)
 * Copyright 2011-2019 The Bootstrap Authors
 * Copyright 2011-2019 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * Forked from Normalize.css, licensed MIT (https://github.com/necolas/normalize.css/blob/master/LICENSE.md)
 */
*,
*::before,
*::after {
  box-sizing: border-box;
}

:host {
  font-family: sans-serif;
  line-height: 1.15;
  -webkit-text-size-adjust: 100%;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}

article,
aside,
figcaption,
figure,
footer,
header,
hgroup,
main,
nav,
section {
  display: block;
}

:host {
  margin: 0;
  font-family:
    -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue',
    Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji',
    'Segoe UI Symbol', 'Noto Color Emoji';
  font-size: 16px;
  font-weight: 400;
  line-height: 1.5;
  color: var(--color-font);
  text-align: left;
}

:host:not(button) {
  background-color: #fff;
}

[tabindex='-1']:focus:not(:focus-visible) {
  outline: 0 !important;
}

hr {
  box-sizing: content-box;
  height: 0;
  overflow: visible;
}

h1,
h2,
h3,
h4,
h5,
h6 {
  margin-top: 0;
  margin-bottom: 8px;
}

p {
  margin-top: 0;
  margin-bottom: 16px;
}

abbr[title],
abbr[data-original-title] {
  text-decoration: underline;
  -webkit-text-decoration: underline dotted;
  text-decoration: underline dotted;
  cursor: help;
  border-bottom: 0;
  -webkit-text-decoration-skip-ink: none;
  text-decoration-skip-ink: none;
}

address {
  margin-bottom: 16px;
  font-style: normal;
  line-height: inherit;
}

ol,
ul,
dl {
  margin-top: 0;
  margin-bottom: 16px;
}

ol ol,
ul ul,
ol ul,
ul ol {
  margin-bottom: 0;
}

dt {
  font-weight: 700;
}

dd {
  margin-bottom: 8px;
  margin-left: 0;
}

blockquote {
  margin: 0 0 16px;
}

b,
strong {
  font-weight: bolder;
}

small {
  font-size: 80%;
}

sub,
sup {
  position: relative;
  font-size: 75%;
  line-height: 0;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

a {
  color: #007bff;
  text-decoration: none;
  background-color: transparent;
}

a:hover {
  color: #0056b3;
  text-decoration: underline;
}

a:not([href]) {
  color: inherit;
  text-decoration: none;
}

a:not([href]):hover {
  color: inherit;
  text-decoration: none;
}

pre,
code,
kbd,
samp {
  font-family:
    SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New',
    monospace;
  font-size: 1em;
}

pre {
  margin-top: 0;
  margin-bottom: 16px;
  overflow: auto;
}

figure {
  margin: 0 0 16px;
}

img {
  vertical-align: middle;
  border-style: none;
}

svg {
  overflow: hidden;
  vertical-align: middle;
}

table {
  border-collapse: collapse;
}

caption {
  padding-top: 12px;
  padding-bottom: 12px;
  color: #6c757d;
  text-align: left;
  caption-side: bottom;
}

th {
  text-align: inherit;
}

label {
  display: inline-block;
  margin-bottom: 8px;
}

button {
  border-radius: 0;
  border: 0;
  padding: 0;
  margin: 0;
  background: none;
  appearance: none;
  -webkit-appearance: none;
}

button:focus {
  outline: 1px dotted;
  outline: 5px auto -webkit-focus-ring-color;
}

button:focus:not(:focus-visible) {
  outline: none;
}

input,
button,
select,
optgroup,
textarea {
  margin: 0;
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}

button,
input {
  overflow: visible;
}

button,
select {
  text-transform: none;
}

select {
  word-wrap: normal;
}

button,
[type='button'],
[type='reset'],
[type='submit'] {
  -webkit-appearance: button;
}

button:not(:disabled),
[type='button']:not(:disabled),
[type='reset']:not(:disabled),
[type='submit']:not(:disabled) {
  cursor: pointer;
}

button::-moz-focus-inner,
[type='button']::-moz-focus-inner,
[type='reset']::-moz-focus-inner,
[type='submit']::-moz-focus-inner {
  padding: 0;
  border-style: none;
}

input[type='radio'],
input[type='checkbox'] {
  box-sizing: border-box;
  padding: 0;
}

input[type='date'],
input[type='time'],
input[type='datetime-local'],
input[type='month'] {
  -webkit-appearance: listbox;
}

textarea {
  overflow: auto;
  resize: vertical;
}

fieldset {
  min-width: 0;
  padding: 0;
  margin: 0;
  border: 0;
}

legend {
  display: block;
  width: 100%;
  max-width: 100%;
  padding: 0;
  margin-bottom: 8px;
  font-size: 24px;
  line-height: inherit;
  color: inherit;
  white-space: normal;
}

progress {
  vertical-align: baseline;
}

[type='number']::-webkit-inner-spin-button,
[type='number']::-webkit-outer-spin-button {
  height: auto;
}

[type='search'] {
  outline-offset: -2px;
  -webkit-appearance: none;
}

[type='search']::-webkit-search-decoration {
  -webkit-appearance: none;
}

::-webkit-file-upload-button {
  font: inherit;
  -webkit-appearance: button;
}

output {
  display: inline-block;
}

summary {
  display: list-item;
  cursor: pointer;
}

template {
  display: none;
}

[hidden] {
  display: none !important;
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/panel/dynamic-panel.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`/* Panel container base styles with dynamic positioning and sizing */
.dynamic-panel-container {
  position: fixed;
  z-index: 2147483646;
  outline: none;
  top: var(--panel-top, auto);
  bottom: var(--panel-bottom, auto);
  left: var(--panel-left, auto);
  right: var(--panel-right, auto);
  width: var(--panel-width);
  height: var(--panel-height);
  min-width: var(--panel-min-width);
  min-height: var(--panel-min-height);
  max-width: var(--panel-max-width);
  max-height: var(--panel-max-height);
}

/* Panel content container styles */
.panel-content-container {
  position: relative;
  width: 100%;
  height: 100%;
  border: 1px solid var(--color-gray-alpha-400);
  border-radius: var(--rounded-xl);
  background: var(--color-background-100);
  display: flex;
  flex-direction: column;
}

/* Draggable content area styles */
.draggable-content {
  flex: 1;
  overflow: auto;
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/colors.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`:host {
  /* 
   * CAUTION: THIS IS A WORKAROUND!
   * For now, we use @babel/code-frame to parse the code frame which does not support option to change the color.
   * x-ref: https://github.com/babel/babel/blob/efa52324ff835b794c48080f14877b6caf32cd15/packages/babel-code-frame/src/defs.ts#L40-L54
   * So, we do a workaround mapping to change the color matching the theme.
   *
   * For example, in @babel/code-frame, the "keyword" is mapped to ANSI "cyan".
   * We want the "keyword" to use the "syntax-keyword" color in the theme.
   * So, we map the "cyan" to the "syntax-keyword" in the theme.
   */
  /* cyan: keyword */
  --color-ansi-cyan: var(--color-syntax-keyword);
  /* yellow: capitalized, jsxIdentifier, punctuation */
  --color-ansi-yellow: var(--color-syntax-function);
  /* magenta: number, regex */
  --color-ansi-magenta: var(--color-syntax-keyword);
  /* green: string */
  --color-ansi-green: var(--color-syntax-string);
  /* gray (bright black): comment, gutter */
  --color-ansi-bright-black: var(--color-syntax-comment);

  /* Ansi - Temporary */
  --color-ansi-selection: var(--color-gray-alpha-300);
  --color-ansi-bg: var(--color-background-200);
  --color-ansi-fg: var(--color-gray-1000);

  --color-ansi-white: var(--color-gray-700);
  --color-ansi-black: var(--color-gray-200);
  --color-ansi-blue: var(--color-blue-700);
  --color-ansi-red: var(--color-red-700);
  --color-ansi-bright-white: var(--color-gray-1000);
  --color-ansi-bright-blue: var(--color-blue-800);
  --color-ansi-bright-cyan: var(--color-blue-800);
  --color-ansi-bright-green: var(--color-green-800);
  --color-ansi-bright-magenta: var(--color-blue-800);
  --color-ansi-bright-red: var(--color-red-800);
  --color-ansi-bright-yellow: var(--color-amber-900);

  /* Background Light */
  --color-background-100: #ffffff;
  --color-background-200: #fafafa;

  /* Syntax Light */
  --color-syntax-comment: #545454;
  --color-syntax-constant: #171717;
  --color-syntax-function: #0054ad;
  --color-syntax-keyword: #a51850;
  --color-syntax-link: #066056;
  --color-syntax-parameter: #8f3e00;
  --color-syntax-punctuation: #171717;
  --color-syntax-string: #036157;
  --color-syntax-string-expression: #066056;

  /* Gray Scale Light */
  --color-gray-100: #f2f2f2;
  --color-gray-200: #ebebeb;
  --color-gray-300: #e6e6e6;
  --color-gray-400: #eaeaea;
  --color-gray-500: #c9c9c9;
  --color-gray-600: #a8a8a8;
  --color-gray-700: #8f8f8f;
  --color-gray-800: #7d7d7d;
  --color-gray-900: #666666;
  --color-gray-1000: #171717;

  /* Gray Alpha Scale Light */
  --color-gray-alpha-100: rgba(0, 0, 0, 0.05);
  --color-gray-alpha-200: rgba(0, 0, 0, 0.081);
  --color-gray-alpha-300: rgba(0, 0, 0, 0.1);
  --color-gray-alpha-400: rgba(0, 0, 0, 0.08);
  --color-gray-alpha-500: rgba(0, 0, 0, 0.21);
  --color-gray-alpha-600: rgba(0, 0, 0, 0.34);
  --color-gray-alpha-700: rgba(0, 0, 0, 0.44);
  --color-gray-alpha-800: rgba(0, 0, 0, 0.51);
  --color-gray-alpha-900: rgba(0, 0, 0, 0.605);
  --color-gray-alpha-1000: rgba(0, 0, 0, 0.91);

  /* Blue Scale Light */
  --color-blue-100: #f0f7ff;
  --color-blue-200: #edf6ff;
  --color-blue-300: #e1f0ff;
  --color-blue-400: #cde7ff;
  --color-blue-500: #99ceff;
  --color-blue-600: #52aeff;
  --color-blue-700: #0070f3;
  --color-blue-800: #0060d1;
  --color-blue-900: #0067d6;
  --color-blue-1000: #0025ad;

  /* Red Scale Light */
  --color-red-100: #fff0f0;
  --color-red-200: #ffebeb;
  --color-red-300: #ffe5e5;
  --color-red-400: #fdd8d8;
  --color-red-500: #f8baba;
  --color-red-600: #f87274;
  --color-red-700: #e5484d;
  --color-red-800: #da3036;
  --color-red-900: #ca2a30;
  --color-red-1000: #381316;

  /* Amber Scale Light */
  --color-amber-100: #fff6e5;
  --color-amber-200: #fff4d5;
  --color-amber-300: #fef0cd;
  --color-amber-400: #ffddbf;
  --color-amber-500: #ffc96b;
  --color-amber-600: #f5b047;
  --color-amber-700: #ffb224;
  --color-amber-800: #ff990a;
  --color-amber-900: #a35200;
  --color-amber-1000: #4e2009;

  /* Green Scale Light */
  --color-green-100: #effbef;
  --color-green-200: #eafaea;
  --color-green-300: #dcf6dc;
  --color-green-400: #c8f1c9;
  --color-green-500: #99e59f;
  --color-green-600: #6cda76;
  --color-green-700: #46a758;
  --color-green-800: #388e4a;
  --color-green-900: #297c3b;
  --color-green-1000: #18311e;

  /* Turbopack Light - Temporary */
  --color-turbopack-text-red: #ff1e56;
  --color-turbopack-text-blue: #0096ff;
  --color-turbopack-border-red: #f0adbe;
  --color-turbopack-border-blue: #adccea;
  --color-turbopack-background-red: #fff7f9;
  --color-turbopack-background-blue: #f6fbff;
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/dark-theme.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`:host(.dark) {
  --color-font: white;
  --color-backdrop: rgba(0, 0, 0, 0.8);
  --color-border-shadow: rgba(255, 255, 255, 0.145);

  --color-title-color: #fafafa;
  --color-stack-notes: #a9a9a9;

  /* Background Dark */
  --color-background-100: #0a0a0a;
  --color-background-200: #000000;

  /* Syntax Dark */
  --color-syntax-comment: #a0a0a0;
  --color-syntax-constant: #ededed;
  --color-syntax-function: #52a9ff;
  --color-syntax-keyword: #f76e99;
  --color-syntax-link: #0ac5b2;
  --color-syntax-parameter: #f1a10d;
  --color-syntax-punctuation: #ededed;
  --color-syntax-string: #0ac5b2;
  --color-syntax-string-expression: #0ac5b2;

  /* Gray Scale Dark */
  --color-gray-100: #1a1a1a;
  --color-gray-200: #1f1f1f;
  --color-gray-300: #292929;
  --color-gray-400: #2e2e2e;
  --color-gray-500: #454545;
  --color-gray-600: #878787;
  --color-gray-700: #8f8f8f;
  --color-gray-800: #7d7d7d;
  --color-gray-900: #a0a0a0;
  --color-gray-1000: #ededed;

  /* Gray Alpha Scale Dark */
  --color-gray-alpha-100: rgba(255, 255, 255, 0.066);
  --color-gray-alpha-200: rgba(255, 255, 255, 0.087);
  --color-gray-alpha-300: rgba(255, 255, 255, 0.125);
  --color-gray-alpha-400: rgba(255, 255, 255, 0.145);
  --color-gray-alpha-500: rgba(255, 255, 255, 0.239);
  --color-gray-alpha-600: rgba(255, 255, 255, 0.506);
  --color-gray-alpha-700: rgba(255, 255, 255, 0.54);
  --color-gray-alpha-800: rgba(255, 255, 255, 0.47);
  --color-gray-alpha-900: rgba(255, 255, 255, 0.61);
  --color-gray-alpha-1000: rgba(255, 255, 255, 0.923);

  /* Blue Scale Dark */
  --color-blue-100: #0f1b2d;
  --color-blue-200: #10243e;
  --color-blue-300: #0f3058;
  --color-blue-400: #0d3868;
  --color-blue-500: #0a4481;
  --color-blue-600: #0091ff;
  --color-blue-700: #0070f3;
  --color-blue-800: #0060d1;
  --color-blue-900: #52a9ff;
  --color-blue-1000: #eaf6ff;

  /* Red Scale Dark */
  --color-red-100: #2a1314;
  --color-red-200: #3d1719;
  --color-red-300: #551a1e;
  --color-red-400: #671e22;
  --color-red-500: #822025;
  --color-red-600: #e5484d;
  --color-red-700: #e5484d;
  --color-red-800: #da3036;
  --color-red-900: #ff6369;
  --color-red-1000: #ffecee;

  /* Amber Scale Dark */
  --color-amber-100: #271700;
  --color-amber-200: #341c00;
  --color-amber-300: #4a2900;
  --color-amber-400: #573300;
  --color-amber-500: #693f05;
  --color-amber-600: #e79c13;
  --color-amber-700: #ffb224;
  --color-amber-800: #ff990a;
  --color-amber-900: #f1a10d;
  --color-amber-1000: #fef3dd;

  /* Green Scale Dark */
  --color-green-100: #0b2211;
  --color-green-200: #0f2c17;
  --color-green-300: #11351b;
  --color-green-400: #0c461b;
  --color-green-500: #126427;
  --color-green-600: #1a9338;
  --color-green-700: #46a758;
  --color-green-800: #388e4a;
  --color-green-900: #63c174;
  --color-green-1000: #e5fbeb;

  /* Turbopack Dark - Temporary */
  --color-turbopack-text-red: #ff6d92;
  --color-turbopack-text-blue: #45b2ff;
  --color-turbopack-border-red: #6e293b;
  --color-turbopack-border-blue: #284f80;
  --color-turbopack-background-red: #250d12;
  --color-turbopack-background-blue: #0a1723;
}

@media (prefers-color-scheme: dark) {
  :host(:not(.light)) {
    --color-font: white;
    --color-backdrop: rgba(0, 0, 0, 0.8);
    --color-border-shadow: rgba(255, 255, 255, 0.145);

    --color-title-color: #fafafa;
    --color-stack-notes: #a9a9a9;

    /* Background Dark */
    --color-background-100: #0a0a0a;
    --color-background-200: #000000;

    /* Syntax Dark */
    --color-syntax-comment: #a0a0a0;
    --color-syntax-constant: #ededed;
    --color-syntax-function: #52a9ff;
    --color-syntax-keyword: #f76e99;
    --color-syntax-link: #0ac5b2;
    --color-syntax-parameter: #f1a10d;
    --color-syntax-punctuation: #ededed;
    --color-syntax-string: #0ac5b2;
    --color-syntax-string-expression: #0ac5b2;

    /* Gray Scale Dark */
    --color-gray-100: #1a1a1a;
    --color-gray-200: #1f1f1f;
    --color-gray-300: #292929;
    --color-gray-400: #2e2e2e;
    --color-gray-500: #454545;
    --color-gray-600: #878787;
    --color-gray-700: #8f8f8f;
    --color-gray-800: #7d7d7d;
    --color-gray-900: #a0a0a0;
    --color-gray-1000: #ededed;

    /* Gray Alpha Scale Dark */
    --color-gray-alpha-100: rgba(255, 255, 255, 0.066);
    --color-gray-alpha-200: rgba(255, 255, 255, 0.087);
    --color-gray-alpha-300: rgba(255, 255, 255, 0.125);
    --color-gray-alpha-400: rgba(255, 255, 255, 0.145);
    --color-gray-alpha-500: rgba(255, 255, 255, 0.239);
    --color-gray-alpha-600: rgba(255, 255, 255, 0.506);
    --color-gray-alpha-700: rgba(255, 255, 255, 0.54);
    --color-gray-alpha-800: rgba(255, 255, 255, 0.47);
    --color-gray-alpha-900: rgba(255, 255, 255, 0.61);
    --color-gray-alpha-1000: rgba(255, 255, 255, 0.923);

    /* Blue Scale Dark */
    --color-blue-100: #0f1b2d;
    --color-blue-200: #10243e;
    --color-blue-300: #0f3058;
    --color-blue-400: #0d3868;
    --color-blue-500: #0a4481;
    --color-blue-600: #0091ff;
    --color-blue-700: #0070f3;
    --color-blue-800: #0060d1;
    --color-blue-900: #52a9ff;
    --color-blue-1000: #eaf6ff;

    /* Red Scale Dark */
    --color-red-100: #2a1314;
    --color-red-200: #3d1719;
    --color-red-300: #551a1e;
    --color-red-400: #671e22;
    --color-red-500: #822025;
    --color-red-600: #e5484d;
    --color-red-700: #e5484d;
    --color-red-800: #da3036;
    --color-red-900: #ff6369;
    --color-red-1000: #ffecee;

    /* Amber Scale Dark */
    --color-amber-100: #271700;
    --color-amber-200: #341c00;
    --color-amber-300: #4a2900;
    --color-amber-400: #573300;
    --color-amber-500: #693f05;
    --color-amber-600: #e79c13;
    --color-amber-700: #ffb224;
    --color-amber-800: #ff990a;
    --color-amber-900: #f1a10d;
    --color-amber-1000: #fef3dd;

    /* Green Scale Dark */
    --color-green-100: #0b2211;
    --color-green-200: #0f2c17;
    --color-green-300: #11351b;
    --color-green-400: #0c461b;
    --color-green-500: #126427;
    --color-green-600: #1a9338;
    --color-green-700: #46a758;
    --color-green-800: #388e4a;
    --color-green-900: #63c174;
    --color-green-1000: #e5fbeb;

    /* Turbopack Dark - Temporary */
    --color-turbopack-text-red: #ff6d92;
    --color-turbopack-text-blue: #45b2ff;
    --color-turbopack-border-red: #6e293b;
    --color-turbopack-border-blue: #284f80;
    --color-turbopack-background-red: #250d12;
    --color-turbopack-background-blue: #0a1723;
  }
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/styles/default-theme.css":function(e,t,n){"use strict";n.d(t,{A:()=>l});var r=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js"),o=n.n(r),a=n("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js"),i=n.n(a)()(o());i.push([e.id,`:host {
  /* 
   * Although the style applied to the shadow host is isolated,
   * the element that attached the shadow host (i.e. "nextjs-portal")
   * is still affected by the parent's style (e.g. "body"). This may
   * occur style conflicts like "display: flex", with other children
   * elements therefore give the shadow host an absolute position.
   */
  position: absolute;

  --color-font: #757575;
  --color-backdrop: rgba(250, 250, 250, 0.8);
  --color-border-shadow: rgba(0, 0, 0, 0.145);

  --color-title-color: #1f1f1f;
  --color-stack-notes: #777;

  --color-accents-1: #808080;
  --color-accents-2: #222222;
  --color-accents-3: #404040;

  --font-stack-monospace:
    '__nextjs-Geist Mono', 'Geist Mono', 'SFMono-Regular', Consolas,
    'Liberation Mono', Menlo, Courier, monospace;
  --font-stack-sans:
    '__nextjs-Geist', 'Geist', -apple-system, 'Source Sans Pro', sans-serif;

  font-family: var(--font-stack-sans);
  font-variant-ligatures: none;

  /* TODO: Remove replaced ones. */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  --shadow-lg:
    0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --shadow-xl:
    0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
  --shadow-2xl: 0 25px 50px -12px rgb(0 0 0 / 0.25);
  --shadow-inner: inset 0 2px 4px 0 rgb(0 0 0 / 0.05);
  --shadow-none: 0 0 #0000;

  --shadow-small: 0px 2px 2px rgba(0, 0, 0, 0.04);
  --shadow-menu:
    0px 1px 1px rgba(0, 0, 0, 0.02), 0px 4px 8px -4px rgba(0, 0, 0, 0.04),
    0px 16px 24px -8px rgba(0, 0, 0, 0.06);

  --focus-color: var(--color-blue-800);
  --focus-ring: 2px solid var(--focus-color);

  --timing-swift: cubic-bezier(0.23, 0.88, 0.26, 0.92);
  --timing-overlay: cubic-bezier(0.175, 0.885, 0.32, 1.1);
  /* prettier-ignore */
  --timing-bounce: linear(0 0%, 0.005871 1%, 0.022058 2%, 0.046612 3%, 0.077823 4%, 0.114199 5%, 0.154441 6%, 0.197431 7.000000000000001%, 0.242208 8%, 0.287959 9%, 0.333995 10%, 0.379743 11%, 0.424732 12%, 0.46858 13%, 0.510982 14.000000000000002%, 0.551702 15%, 0.590564 16%, 0.627445 17%, 0.662261 18%, 0.694971 19%, 0.725561 20%, 0.754047 21%, 0.780462 22%, 0.804861 23%, 0.82731 24%, 0.847888 25%, 0.866679 26%, 0.883775 27%, 0.899272 28.000000000000004%, 0.913267 28.999999999999996%, 0.925856 30%, 0.937137 31%, 0.947205 32%, 0.956153 33%, 0.96407 34%, 0.971043 35%, 0.977153 36%, 0.982479 37%, 0.987094 38%, 0.991066 39%, 0.994462 40%, 0.997339 41%, 0.999755 42%, 1.001761 43%, 1.003404 44%, 1.004727 45%, 1.00577 46%, 1.006569 47%, 1.007157 48%, 1.007563 49%, 1.007813 50%, 1.007931 51%, 1.007939 52%, 1.007855 53%, 1.007697 54%, 1.007477 55.00000000000001%, 1.00721 56.00000000000001%, 1.006907 56.99999999999999%, 1.006576 57.99999999999999%, 1.006228 59%, 1.005868 60%, 1.005503 61%, 1.005137 62%, 1.004776 63%, 1.004422 64%, 1.004078 65%, 1.003746 66%, 1.003429 67%, 1.003127 68%, 1.00284 69%, 1.002571 70%, 1.002318 71%, 1.002082 72%, 1.001863 73%, 1.00166 74%, 1.001473 75%, 1.001301 76%, 1.001143 77%, 1.001 78%, 1.000869 79%, 1.000752 80%, 1.000645 81%, 1.00055 82%, 1.000464 83%, 1.000388 84%, 1.000321 85%, 1.000261 86%, 1.000209 87%, 1.000163 88%, 1.000123 89%, 1.000088 90%);

  --rounded-none: 0px;
  --rounded-sm: 2px;
  --rounded-md: 4px;
  --rounded-md-2: 6px;
  --rounded-lg: 8px;
  --rounded-xl: 12px;
  --rounded-2xl: 16px;
  --rounded-3xl: 24px;
  --rounded-4xl: 32px;
  --rounded-full: 9999px;

  /* 
    This value gets set from the Dev Tools preferences,
    and we use the following --size-* variables to 
    scale the relevant elements.

    The reason why we don't rely on rem values is because
    if an app sets their root font size to something tiny, 
    it feels unexpected to have the app root size leak 
    into a Next.js surface.

    https://github.com/vercel/next.js/discussions/76812
  */
  --nextjs-dev-tools-scale: 1;
  --size-1: calc(1px / var(--nextjs-dev-tools-scale));
  --size-2: calc(2px / var(--nextjs-dev-tools-scale));
  --size-3: calc(3px / var(--nextjs-dev-tools-scale));
  --size-4: calc(4px / var(--nextjs-dev-tools-scale));
  --size-5: calc(5px / var(--nextjs-dev-tools-scale));
  --size-6: calc(6px / var(--nextjs-dev-tools-scale));
  --size-7: calc(7px / var(--nextjs-dev-tools-scale));
  --size-8: calc(8px / var(--nextjs-dev-tools-scale));
  --size-9: calc(9px / var(--nextjs-dev-tools-scale));
  --size-10: calc(10px / var(--nextjs-dev-tools-scale));
  --size-11: calc(11px / var(--nextjs-dev-tools-scale));
  --size-12: calc(12px / var(--nextjs-dev-tools-scale));
  --size-13: calc(13px / var(--nextjs-dev-tools-scale));
  --size-14: calc(14px / var(--nextjs-dev-tools-scale));
  --size-15: calc(15px / var(--nextjs-dev-tools-scale));
  --size-16: calc(16px / var(--nextjs-dev-tools-scale));
  --size-17: calc(17px / var(--nextjs-dev-tools-scale));
  --size-18: calc(18px / var(--nextjs-dev-tools-scale));
  --size-20: calc(20px / var(--nextjs-dev-tools-scale));
  --size-22: calc(22px / var(--nextjs-dev-tools-scale));
  --size-24: calc(24px / var(--nextjs-dev-tools-scale));
  --size-26: calc(26px / var(--nextjs-dev-tools-scale));
  --size-28: calc(28px / var(--nextjs-dev-tools-scale));
  --size-30: calc(30px / var(--nextjs-dev-tools-scale));
  --size-32: calc(32px / var(--nextjs-dev-tools-scale));
  --size-34: calc(34px / var(--nextjs-dev-tools-scale));
  --size-36: calc(36px / var(--nextjs-dev-tools-scale));
  --size-38: calc(38px / var(--nextjs-dev-tools-scale));
  --size-40: calc(40px / var(--nextjs-dev-tools-scale));
  --size-42: calc(42px / var(--nextjs-dev-tools-scale));
  --size-44: calc(44px / var(--nextjs-dev-tools-scale));
  --size-46: calc(46px / var(--nextjs-dev-tools-scale));
  --size-48: calc(48px / var(--nextjs-dev-tools-scale));

  @media print {
    display: none;
  }
}

h1,
h2,
h3,
h4,
h5,
h6 {
  margin-bottom: 8px;
  font-weight: 500;
  line-height: 1.5;
}

a {
  color: var(--color-blue-900);
  &:hover {
    color: var(--color-blue-900);
  }
  &:focus-visible {
    outline: var(--focus-ring);
  }
}
`,""]);let l=i},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/api.js":function(e){"use strict";e.exports=function(e){var t=[];return t.toString=function(){return this.map(function(t){var n="",r=void 0!==t[5];return t[4]&&(n+="@supports (".concat(t[4],") {")),t[2]&&(n+="@media ".concat(t[2]," {")),r&&(n+="@layer".concat(t[5].length>0?" ".concat(t[5]):""," {")),n+=e(t),r&&(n+="}"),t[2]&&(n+="}"),t[4]&&(n+="}"),n}).join("")},t.i=function(e,n,r,o,a){"string"==typeof e&&(e=[[null,e,void 0]]);var i={};if(r)for(var l=0;l<this.length;l++){var s=this[l][0];null!=s&&(i[s]=!0)}for(var c=0;c<e.length;c++){var u=[].concat(e[c]);r&&i[u[0]]||(void 0!==a&&(void 0===u[5]||(u[1]="@layer".concat(u[5].length>0?" ".concat(u[5]):""," {").concat(u[1],"}")),u[5]=a),n&&(u[2]&&(u[1]="@media ".concat(u[2]," {").concat(u[1],"}")),u[2]=n),o&&(u[4]?(u[1]="@supports (".concat(u[4],") {").concat(u[1],"}"),u[4]=o):u[4]="".concat(o)),t.push(u))}},t}},"../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/runtime/noSourceMaps.js":function(e){"use strict";e.exports=function(e){return e[1]}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":function(e){"use strict";var t=[];function n(e){for(var n=-1,r=0;r<t.length;r++)if(t[r].identifier===e){n=r;break}return n}function r(e,r){for(var o={},a=[],i=0;i<e.length;i++){var l=e[i],s=r.base?l[0]+r.base:l[0],c=o[s]||0,u="".concat(s," ").concat(c);o[s]=c+1;var d=n(u),f={css:l[1],media:l[2],sourceMap:l[3],supports:l[4],layer:l[5]};if(-1!==d)t[d].references++,t[d].updater(f);else{var p=function(e,t){var n=t.domAPI(t);return n.update(e),function(t){t?(t.css!==e.css||t.media!==e.media||t.sourceMap!==e.sourceMap||t.supports!==e.supports||t.layer!==e.layer)&&n.update(e=t):n.remove()}}(f,r);r.byIndex=i,t.splice(i,0,{identifier:u,updater:p,references:1})}a.push(u)}return a}e.exports=function(e,o){var a=r(e=e||[],o=o||{});return function(e){e=e||[];for(var i=0;i<a.length;i++){var l=n(a[i]);t[l].references--}for(var s=r(e,o),c=0;c<a.length;c++){var u=n(a[c]);0===t[u].references&&(t[u].updater(),t.splice(u,1))}a=s}}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/insertStyleElement.js":function(e){"use strict";e.exports=function(e){var t=document.createElement("style");return e.setAttributes(t,e.attributes),e.insert(t,e.options),t}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js":function(e,t,n){"use strict";e.exports=function(e){var t=n.nc;t&&e.setAttribute("nonce",t)}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleDomAPI.js":function(e){"use strict";e.exports=function(e){if("undefined"==typeof document)return{update:function(){},remove:function(){}};var t=e.insertStyleElement(e);return{update:function(n){var r,o,a;r="",n.supports&&(r+="@supports (".concat(n.supports,") {")),n.media&&(r+="@media ".concat(n.media," {")),(o=void 0!==n.layer)&&(r+="@layer".concat(n.layer.length>0?" ".concat(n.layer):""," {")),r+=n.css,o&&(r+="}"),n.media&&(r+="}"),n.supports&&(r+="}"),(a=n.sourceMap)&&"undefined"!=typeof btoa&&(r+="\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(a))))," */")),e.styleTagTransform(r,t,e.options)},remove:function(){var e;null===(e=t).parentNode||e.parentNode.removeChild(e)}}}},"../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleTagTransform.js":function(e){"use strict";e.exports=function(e,t){if(t.styleSheet)t.styleSheet.cssText=e;else{for(;t.firstChild;)t.removeChild(t.firstChild);t.appendChild(document.createTextNode(e))}}},"./dist/compiled/anser/index.js":function(e){(()=>{"use strict";var t={211:e=>{var t=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),n=[[{color:"0, 0, 0",class:"ansi-black"},{color:"187, 0, 0",class:"ansi-red"},{color:"0, 187, 0",class:"ansi-green"},{color:"187, 187, 0",class:"ansi-yellow"},{color:"0, 0, 187",class:"ansi-blue"},{color:"187, 0, 187",class:"ansi-magenta"},{color:"0, 187, 187",class:"ansi-cyan"},{color:"255,255,255",class:"ansi-white"}],[{color:"85, 85, 85",class:"ansi-bright-black"},{color:"255, 85, 85",class:"ansi-bright-red"},{color:"0, 255, 0",class:"ansi-bright-green"},{color:"255, 255, 85",class:"ansi-bright-yellow"},{color:"85, 85, 255",class:"ansi-bright-blue"},{color:"255, 85, 255",class:"ansi-bright-magenta"},{color:"85, 255, 255",class:"ansi-bright-cyan"},{color:"255, 255, 255",class:"ansi-bright-white"}]];e.exports=function(){function e(){if(!(this instanceof e))throw TypeError("Cannot call a class as a function");this.fg=this.bg=this.fg_truecolor=this.bg_truecolor=null,this.bright=0}return t(e,null,[{key:"escapeForHtml",value:function(t){return(new e).escapeForHtml(t)}},{key:"linkify",value:function(t){return(new e).linkify(t)}},{key:"ansiToHtml",value:function(t,n){return(new e).ansiToHtml(t,n)}},{key:"ansiToJson",value:function(t,n){return(new e).ansiToJson(t,n)}},{key:"ansiToText",value:function(t){return(new e).ansiToText(t)}}]),t(e,[{key:"setupPalette",value:function(){this.PALETTE_COLORS=[];for(var e=0;e<2;++e)for(var t=0;t<8;++t)this.PALETTE_COLORS.push(n[e][t].color);for(var r=[0,95,135,175,215,255],o=function(e,t,n){return r[e]+", "+r[t]+", "+r[n]},a=0;a<6;++a)for(var i=0;i<6;++i)for(var l=0;l<6;++l)this.PALETTE_COLORS.push(o(a,i,l));for(var s=8,c=0;c<24;++c,s+=10)this.PALETTE_COLORS.push(o(s,s,s))}},{key:"escapeForHtml",value:function(e){return e.replace(/[&<>]/gm,function(e){return"&"==e?"&amp;":"<"==e?"&lt;":">"==e?"&gt;":""})}},{key:"linkify",value:function(e){return e.replace(/(https?:\/\/[^\s]+)/gm,function(e){return'<a href="'+e+'">'+e+"</a>"})}},{key:"ansiToHtml",value:function(e,t){return this.process(e,t,!0)}},{key:"ansiToJson",value:function(e,t){return(t=t||{}).json=!0,t.clearLine=!1,this.process(e,t,!0)}},{key:"ansiToText",value:function(e){return this.process(e,{},!1)}},{key:"process",value:function(e,t,n){var r=this,o=e.split(/\033\[/),a=o.shift();null==t&&(t={}),t.clearLine=/\r/.test(e);var i=o.map(function(e){return r.processChunk(e,t,n)});if(t&&t.json){var l=this.processChunkJson("");return l.content=a,l.clearLine=t.clearLine,i.unshift(l),t.remove_empty&&(i=i.filter(function(e){return!e.isEmpty()})),i}return i.unshift(a),i.join("")}},{key:"processChunkJson",value:function(e,t,r){var o=(t=void 0===t?{}:t).use_classes=void 0!==t.use_classes&&t.use_classes,a=t.key=o?"class":"color",i={content:e,fg:null,bg:null,fg_truecolor:null,bg_truecolor:null,clearLine:t.clearLine,decoration:null,was_processed:!1,isEmpty:function(){return!i.content}},l=e.match(/^([!\x3c-\x3f]*)([\d;]*)([\x20-\x2c]*[\x40-\x7e])([\s\S]*)/m);if(!l)return i;i.content=l[4];var s=l[2].split(";");if(""!==l[1]||"m"!==l[3]||!r)return i;for(this.decoration=null;s.length>0;){var c=parseInt(s.shift());if(isNaN(c)||0===c)this.fg=this.bg=this.decoration=null;else if(1===c)this.decoration="bold";else if(2===c)this.decoration="dim";else if(3==c)this.decoration="italic";else if(4==c)this.decoration="underline";else if(5==c)this.decoration="blink";else if(7===c)this.decoration="reverse";else if(8===c)this.decoration="hidden";else if(9===c)this.decoration="strikethrough";else if(39==c)this.fg=null;else if(49==c)this.bg=null;else if(c>=30&&c<38)this.fg=n[0][c%10][a];else if(c>=90&&c<98)this.fg=n[1][c%10][a];else if(c>=40&&c<48)this.bg=n[0][c%10][a];else if(c>=100&&c<108)this.bg=n[1][c%10][a];else if(38===c||48===c){var u=38===c;if(s.length>=1){var d=s.shift();if("5"===d&&s.length>=1){var f=parseInt(s.shift());if(f>=0&&f<=255)if(o){var p=f>=16?"ansi-palette-"+f:n[+(f>7)][f%8].class;u?this.fg=p:this.bg=p}else this.PALETTE_COLORS||this.setupPalette(),u?this.fg=this.PALETTE_COLORS[f]:this.bg=this.PALETTE_COLORS[f]}else if("2"===d&&s.length>=3){var h=parseInt(s.shift()),m=parseInt(s.shift()),g=parseInt(s.shift());if(h>=0&&h<=255&&m>=0&&m<=255&&g>=0&&g<=255){var v=h+", "+m+", "+g;o?u?(this.fg="ansi-truecolor",this.fg_truecolor=v):(this.bg="ansi-truecolor",this.bg_truecolor=v):u?this.fg=v:this.bg=v}}}}}return null===this.fg&&null===this.bg&&null===this.decoration||(i.fg=this.fg,i.bg=this.bg,i.fg_truecolor=this.fg_truecolor,i.bg_truecolor=this.bg_truecolor,i.decoration=this.decoration,i.was_processed=!0),i}},{key:"processChunk",value:function(e,t,n){var r=this;t=t||{};var o=this.processChunkJson(e,t,n);if(t.json)return o;if(o.isEmpty())return"";if(!o.was_processed)return o.content;var a=t.use_classes,i=[],l=[],s={},c=function(e){var t=[],n=void 0;for(n in e)e.hasOwnProperty(n)&&t.push("data-"+n+'="'+r.escapeForHtml(e[n])+'"');return t.length>0?" "+t.join(" "):""};return(o.fg&&(a?(l.push(o.fg+"-fg"),null!==o.fg_truecolor&&(s["ansi-truecolor-fg"]=o.fg_truecolor,o.fg_truecolor=null)):i.push("color:rgb("+o.fg+")")),o.bg&&(a?(l.push(o.bg+"-bg"),null!==o.bg_truecolor&&(s["ansi-truecolor-bg"]=o.bg_truecolor,o.bg_truecolor=null)):i.push("background-color:rgb("+o.bg+")")),o.decoration&&(a?l.push("ansi-"+o.decoration):"bold"===o.decoration?i.push("font-weight:bold"):"dim"===o.decoration?i.push("opacity:0.5"):"italic"===o.decoration?i.push("font-style:italic"):"reverse"===o.decoration?i.push("filter:invert(100%)"):"hidden"===o.decoration?i.push("visibility:hidden"):"strikethrough"===o.decoration?i.push("text-decoration:line-through"):i.push("text-decoration:"+o.decoration)),a)?'<span class="'+l.join(" ")+'"'+c(s)+">"+o.content+"</span>":'<span style="'+i.join(";")+'"'+c(s)+">"+o.content+"</span>"}}]),e}()}},n={};function r(e){var o=n[e];if(void 0!==o)return o.exports;var a=n[e]={exports:{}},i=!0;try{t[e](a,a.exports,r),i=!1}finally{i&&delete n[e]}return a.exports}r.ab="//",e.exports=r(211)})()},"./dist/compiled/react-dom/cjs/react-dom-client.production.js":function(e,t,n){"use strict";var r,o=n("./dist/compiled/scheduler/index.js"),a=n("./dist/compiled/react/index.js"),i=n("./dist/compiled/react-dom/index.js");function l(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function s(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do 0!=(4098&(t=e).flags)&&(n=t.return),e=t.return;while(e)}return 3===t.tag?n:null}function c(e){if(13===e.tag){var t=e.memoizedState;if(null===t&&null!==(e=e.alternate)&&(t=e.memoizedState),null!==t)return t.dehydrated}return null}function u(e){if(31===e.tag){var t=e.memoizedState;if(null===t&&null!==(e=e.alternate)&&(t=e.memoizedState),null!==t)return t.dehydrated}return null}function d(e){if(s(e)!==e)throw Error(l(188))}function f(e,t,n,r,o,a){for(;null!==e;){if(5===e.tag&&n(e,r,o,a)||(22!==e.tag||null===e.memoizedState)&&(t||5!==e.tag)&&f(e.child,t,n,r,o,a))return!0;e=e.sibling}return!1}function p(e){for(e=e.return;null!==e;){if(3===e.tag||5===e.tag)return e;e=e.return}return null}function h(e){switch(e.tag){case 5:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(l(559))}}var m=null,g=null;function v(e){return m=e,!0}function y(e,t,n){return e===n||e===t&&(m=e,!0)}function b(e,t,n){return e===n?(g=e,!1):e===t&&(null!==g&&(m=e),!0)}function x(e){if(null===e)return null;do e=null===e?null:e.return;while(e&&5!==e.tag&&27!==e.tag&&3!==e.tag);return e||null}function w(e,t,n){for(var r=0,o=e;o;o=n(o))r++;o=0;for(var a=t;a;a=n(a))o++;for(;0<r-o;)e=n(e),r--;for(;0<o-r;)t=n(t),o--;for(;r--;){if(e===t||null!==t&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var _=Object.assign,k=Symbol.for("react.element"),j=Symbol.for("react.transitional.element"),S=Symbol.for("react.portal"),O=Symbol.for("react.fragment"),C=Symbol.for("react.strict_mode"),P=Symbol.for("react.profiler"),E=Symbol.for("react.consumer"),T=Symbol.for("react.context"),I=Symbol.for("react.forward_ref"),N=Symbol.for("react.suspense"),L=Symbol.for("react.suspense_list"),A=Symbol.for("react.memo"),z=Symbol.for("react.lazy");Symbol.for("react.scope");var R=Symbol.for("react.activity"),D=Symbol.for("react.legacy_hidden");Symbol.for("react.tracing_marker");var M=Symbol.for("react.memo_cache_sentinel"),Z=Symbol.for("react.view_transition"),F=Symbol.iterator;function U(e){return null===e||"object"!=typeof e?null:"function"==typeof(e=F&&e[F]||e["@@iterator"])?e:null}var H=Symbol.for("react.client.reference"),V=Array.isArray,B=a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,$=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,q={pending:!1,data:null,method:null,action:null},W=[],K=-1;function Y(e){return{current:e}}function G(e){0>K||(e.current=W[K],W[K]=null,K--)}function X(e,t){W[++K]=e.current,e.current=t}var Q=Y(null),J=Y(null),ee=Y(null),et=Y(null);function en(e,t){switch(X(ee,t),X(J,e),X(Q,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?uu(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)e=ud(t=uu(t),e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}G(Q),X(Q,e)}function er(){G(Q),G(J),G(ee)}function eo(e){null!==e.memoizedState&&X(et,e);var t=Q.current,n=ud(t,e.type);t!==n&&(X(J,e),X(Q,n))}function ea(e){J.current===e&&(G(Q),G(J)),et.current===e&&(G(et),db._currentValue=q)}function ei(e){if(void 0===tG)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);tG=t&&t[1]||"",tX=-1<e.stack.indexOf("\n    at")?" (<anonymous>)":-1<e.stack.indexOf("@")?"@unknown:0:0":""}return"\n"+tG+e+tX}var el=!1;function es(e,t){if(!e||el)return"";el=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),"object"==typeof Reflect&&Reflect.construct){try{Reflect.construct(n,[])}catch(e){var r=e}Reflect.construct(e,[],n)}else{try{n.call()}catch(e){r=e}e.call(n.prototype)}}else{try{throw Error()}catch(e){r=e}(n=e())&&"function"==typeof n.catch&&n.catch(function(){})}}catch(e){if(e&&r&&"string"==typeof e.stack)return[e.stack,r.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var o=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,"name");o&&o.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var a=r.DetermineComponentFrameRoot(),i=a[0],l=a[1];if(i&&l){var s=i.split("\n"),c=l.split("\n");for(o=r=0;r<s.length&&!s[r].includes("DetermineComponentFrameRoot");)r++;for(;o<c.length&&!c[o].includes("DetermineComponentFrameRoot");)o++;if(r===s.length||o===c.length)for(r=s.length-1,o=c.length-1;1<=r&&0<=o&&s[r]!==c[o];)o--;for(;1<=r&&0<=o;r--,o--)if(s[r]!==c[o]){if(1!==r||1!==o)do if(r--,o--,0>o||s[r]!==c[o]){var u="\n"+s[r].replace(" at new "," at ");return e.displayName&&u.includes("<anonymous>")&&(u=u.replace("<anonymous>",e.displayName)),u}while(1<=r&&0<=o);break}}}finally{el=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?ei(n):""}function ec(e){try{var t="",n=null;do t+=function(e,t){switch(e.tag){case 26:case 27:case 5:return ei(e.type);case 16:return ei("Lazy");case 13:return e.child!==t&&null!==t?ei("Suspense Fallback"):ei("Suspense");case 19:return ei("SuspenseList");case 0:case 15:return es(e.type,!1);case 11:return es(e.type.render,!1);case 1:return es(e.type,!0);case 31:return ei("Activity");case 30:return ei("ViewTransition");default:return""}}(e,n),n=e,e=e.return;while(e);return t}catch(e){return"\nError generating stack: "+e.message+"\n"+e.stack}}var eu=Object.prototype.hasOwnProperty,ed=o.unstable_scheduleCallback,ef=o.unstable_cancelCallback,ep=o.unstable_shouldYield,eh=o.unstable_requestPaint,em=o.unstable_now,eg=o.unstable_getCurrentPriorityLevel,ev=o.unstable_ImmediatePriority,ey=o.unstable_UserBlockingPriority,eb=o.unstable_NormalPriority,ex=o.unstable_LowPriority,ew=o.unstable_IdlePriority,e_=o.log,ek=o.unstable_setDisableYieldValue,ej=null,eS=null;function eO(e){if("function"==typeof e_&&ek(e),eS&&"function"==typeof eS.setStrictMode)try{eS.setStrictMode(ej,e)}catch(e){}}var eC=Math.clz32?Math.clz32:function(e){return 0==(e>>>=0)?32:31-(eP(e)/eE|0)|0},eP=Math.log,eE=Math.LN2,eT=256,eI=262144,eN=4194304;function eL(e){var t=42&e;if(0!==t)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return 261888&e;case 262144:case 524288:case 1048576:case 2097152:return 3932160&e;case 4194304:case 8388608:case 0x1000000:case 0x2000000:return 0x3c00000&e;case 0x4000000:return 0x4000000;case 0x8000000:return 0x8000000;case 0x10000000:return 0x10000000;case 0x20000000:return 0x20000000;case 0x40000000:return 0;default:return e}}function eA(e,t,n){var r=e.pendingLanes;if(0===r)return 0;var o=0,a=e.suspendedLanes,i=e.pingedLanes;e=e.warmLanes;var l=0x7ffffff&r;return 0!==l?0!=(r=l&~a)?o=eL(r):0!=(i&=l)?o=eL(i):n||0!=(n=l&~e)&&(o=eL(n)):0!=(l=r&~a)?o=eL(l):0!==i?o=eL(i):n||0!=(n=r&~e)&&(o=eL(n)),0===o?0:0!==t&&t!==o&&0==(t&a)&&((a=o&-o)>=(n=t&-t)||32===a&&0!=(4194048&n))?t:o}function ez(e,t){return 0==(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)}function eR(){var e=eN;return 0==(0x3c00000&(eN<<=1))&&(eN=4194304),e}function eD(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function eM(e,t){e.pendingLanes|=t,0x10000000!==t&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function eZ(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-eC(t);e.entangledLanes|=t,e.entanglements[r]=0x40000000|e.entanglements[r]|261930&n}function eF(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-eC(n),o=1<<r;o&t|e[r]&t&&(e[r]|=t),n&=~o}}function eU(e,t){var n=t&-t;return 0!=((n=0!=(42&n)?1:eH(n))&(e.suspendedLanes|t))?0:n}function eH(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 0x1000000:case 0x2000000:e=128;break;case 0x10000000:e=0x8000000;break;default:e=0}return e}function eV(e){return 2<(e&=-e)?8<e?0!=(0x7ffffff&e)?32:0x10000000:8:2}function eB(){var e=$.p;return 0!==e?e:void 0===(e=window.event)?32:dL(e.type)}function e$(e,t){var n=$.p;try{return $.p=e,t()}finally{$.p=n}}var eq=Math.random().toString(36).slice(2),eW="__reactFiber$"+eq,eK="__reactProps$"+eq,eY="__reactContainer$"+eq,eG="__reactEvents$"+eq,eX="__reactListeners$"+eq,eQ="__reactHandles$"+eq,eJ="__reactResources$"+eq,e0="__reactMarker$"+eq;function e1(e){delete e[eW],delete e[eK],delete e[eG],delete e[eX],delete e[eQ]}function e2(e){var t;if(t=e[eW])return t;for(var n=e.parentNode;n;){if(t=n[eY]||n[eW]){if(n=t.alternate,null!==t.child||null!==n&&null!==n.child)for(e=uY(e);null!==e;){if(n=e[eW])return n;e=uY(e)}return t}n=(e=n).parentNode}return null}function e3(e){if(e=e[eW]||e[eY]){var t=e.tag;if(5===t||6===t||13===t||31===t||26===t||27===t||3===t)return e}return null}function e4(e){var t=e.tag;if(5===t||26===t||27===t||6===t)return e.stateNode;throw Error(l(33))}function e5(e){var t=e[eJ];return t||(t=e[eJ]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function e6(e){e[e0]=!0}var e9=new Set,e8={};function e7(e,t){te(e,t),te(e+"Capture",t)}function te(e,t){for(e8[e]=t,e=0;e<t.length;e++)e9.add(t[e])}var tt=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),tn={},tr={},to=!1;function ta(){var e=to;return to=!1,e}function ti(e,t,n){if(eu.call(tr,t)||!eu.call(tn,t)&&(tt.test(t)?tr[t]=!0:(tn[t]=!0,!1)))if(null===n)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var r=t.toLowerCase().slice(0,5);if("data-"!==r&&"aria-"!==r)return void e.removeAttribute(t)}e.setAttribute(t,""+n)}}function tl(e,t,n){if(null===n)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+n)}}function ts(e,t,n,r){if(null===r)e.removeAttribute(n);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,""+r)}}function tc(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":case"object":return e;default:return""}}function tu(e){var t=e.type;return(e=e.nodeName)&&"input"===e.toLowerCase()&&("checkbox"===t||"radio"===t)}function td(e){if(!e._valueTracker){var t=tu(e)?"checked":"value";e._valueTracker=function(e,t,n){var r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&void 0!==r&&"function"==typeof r.get&&"function"==typeof r.set){var o=r.get,a=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return o.call(this)},set:function(e){n=""+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(e){n=""+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}(e,t,""+e[t])}}function tf(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=tu(e)?e.checked?"true":"false":e.value),(e=r)!==n&&(t.setValue(e),!0)}function tp(e){if(void 0===(e=e||("undefined"!=typeof document?document:void 0)))return null;try{return e.activeElement||e.body}catch(t){return e.body}}var th=/[\n"\\]/g;function tm(e){return e.replace(th,function(e){return"\\"+e.charCodeAt(0).toString(16)+" "})}function tg(e,t,n,r,o,a,i,l){e.name="",null!=i&&"function"!=typeof i&&"symbol"!=typeof i&&"boolean"!=typeof i?e.type=i:e.removeAttribute("type"),null!=t?"number"===i?(0===t&&""===e.value||e.value!=t)&&(e.value=""+tc(t)):e.value!==""+tc(t)&&(e.value=""+tc(t)):"submit"!==i&&"reset"!==i||e.removeAttribute("value"),null!=t?ty(e,i,tc(t)):null!=n?ty(e,i,tc(n)):null!=r&&e.removeAttribute("value"),null==o&&null!=a&&(e.defaultChecked=!!a),null!=o&&(e.checked=o&&"function"!=typeof o&&"symbol"!=typeof o),null!=l&&"function"!=typeof l&&"symbol"!=typeof l&&"boolean"!=typeof l?e.name=""+tc(l):e.removeAttribute("name")}function tv(e,t,n,r,o,a,i,l){if(null!=a&&"function"!=typeof a&&"symbol"!=typeof a&&"boolean"!=typeof a&&(e.type=a),null!=t||null!=n){if(("submit"===a||"reset"===a)&&null==t)return void td(e);n=null!=n?""+tc(n):"",t=null!=t?""+tc(t):n,l||t===e.value||(e.value=t),e.defaultValue=t}r="function"!=typeof(r=null!=r?r:o)&&"symbol"!=typeof r&&!!r,e.checked=l?e.checked:!!r,e.defaultChecked=!!r,null!=i&&"function"!=typeof i&&"symbol"!=typeof i&&"boolean"!=typeof i&&(e.name=i),td(e)}function ty(e,t,n){"number"===t&&tp(e.ownerDocument)===e||e.defaultValue===""+n||(e.defaultValue=""+n)}function tb(e,t,n,r){if(e=e.options,t){t={};for(var o=0;o<n.length;o++)t["$"+n[o]]=!0;for(n=0;n<e.length;n++)o=t.hasOwnProperty("$"+e[n].value),e[n].selected!==o&&(e[n].selected=o),o&&r&&(e[n].defaultSelected=!0)}else{for(o=0,n=""+tc(n),t=null;o<e.length;o++){if(e[o].value===n){e[o].selected=!0,r&&(e[o].defaultSelected=!0);return}null!==t||e[o].disabled||(t=e[o])}null!==t&&(t.selected=!0)}}function tx(e,t,n){if(null!=t&&((t=""+tc(t))!==e.value&&(e.value=t),null==n)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=null!=n?""+tc(n):""}function tw(e,t,n,r){if(null==t){if(null!=r){if(null!=n)throw Error(l(92));if(V(r)){if(1<r.length)throw Error(l(93));r=r[0]}n=r}null==n&&(n=""),t=n}e.defaultValue=n=tc(t),(r=e.textContent)===n&&""!==r&&null!==r&&(e.value=r),td(e)}function t_(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&3===n.nodeType){n.nodeValue=t;return}}e.textContent=t}var tk=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function tj(e,t,n){var r=0===t.indexOf("--");null==n||"boolean"==typeof n||""===n?r?e.setProperty(t,""):"float"===t?e.cssFloat="":e[t]="":r?e.setProperty(t,n):"number"!=typeof n||0===n||tk.has(t)?"float"===t?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function tS(e,t,n){if(null!=t&&"object"!=typeof t)throw Error(l(62));if(e=e.style,null!=n){for(var r in n)!n.hasOwnProperty(r)||null!=t&&t.hasOwnProperty(r)||(0===r.indexOf("--")?e.setProperty(r,""):"float"===r?e.cssFloat="":e[r]="",to=!0);for(var o in t)r=t[o],t.hasOwnProperty(o)&&n[o]!==r&&(tj(e,o,r),to=!0)}else for(var a in t)t.hasOwnProperty(a)&&tj(e,a,t[a])}function tO(e){if(-1===e.indexOf("-"))return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var tC=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),tP=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function tE(e){return tP.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function tT(){}var tI=null;function tN(e){return(e=e.target||e.srcElement||window).correspondingUseElement&&(e=e.correspondingUseElement),3===e.nodeType?e.parentNode:e}var tL=null,tA=null;function tz(e){var t=e3(e);if(t&&(e=t.stateNode)){var n=e[eK]||null;switch(e=t.stateNode,t.type){case"input":if(tg(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,"radio"===n.type&&null!=t){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+tm(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var o=r[eK]||null;if(!o)throw Error(l(90));tg(r,o.value,o.defaultValue,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name)}}for(t=0;t<n.length;t++)(r=n[t]).form===e.form&&tf(r)}break;case"textarea":tx(e,n.value,n.defaultValue);break;case"select":null!=(t=n.value)&&tb(e,!!n.multiple,t,!1)}}}var tR=!1;function tD(e,t,n){if(tR)return e(t,n);tR=!0;try{return e(t)}finally{if(tR=!1,(null!==tL||null!==tA)&&(cn(),tL&&(t=tL,e=tA,tA=tL=null,tz(t),e)))for(t=0;t<e.length;t++)tz(e[t])}}function tM(e,t){var n=e.stateNode;if(null===n)return null;var r=n[eK]||null;if(null===r)return null;switch(n=r[t],t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(r="button"!==(e=e.type)&&"input"!==e&&"select"!==e&&"textarea"!==e),e=!r;break;default:e=!1}if(e)return null;if(n&&"function"!=typeof n)throw Error(l(231,t,typeof n));return n}var tZ="undefined"!=typeof window&&void 0!==window.document&&void 0!==window.document.createElement,tF=!1;if(tZ)try{var tU={};Object.defineProperty(tU,"passive",{get:function(){tF=!0}}),window.addEventListener("test",tU,tU),window.removeEventListener("test",tU,tU)}catch(e){tF=!1}var tH=null,tV=null,tB=null;function t$(){if(tB)return tB;var e,t,n=tV,r=n.length,o="value"in tH?tH.value:tH.textContent,a=o.length;for(e=0;e<r&&n[e]===o[e];e++);var i=r-e;for(t=1;t<=i&&n[r-t]===o[a-t];t++);return tB=o.slice(e,1<t?1-t:void 0)}function tq(e){var t=e.keyCode;return"charCode"in e?0===(e=e.charCode)&&13===t&&(e=13):e=t,10===e&&(e=13),32<=e||13===e?e:0}function tW(){return!0}function tK(){return!1}function tY(e){function t(t,n,r,o,a){for(var i in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=o,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(i)&&(t=e[i],this[i]=t?t(o):o[i]);return this.isDefaultPrevented=(null!=o.defaultPrevented?o.defaultPrevented:!1===o.returnValue)?tW:tK,this.isPropagationStopped=tK,this}return _(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():"unknown"!=typeof e.returnValue&&(e.returnValue=!1),this.isDefaultPrevented=tW)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():"unknown"!=typeof e.cancelBubble&&(e.cancelBubble=!0),this.isPropagationStopped=tW)},persist:function(){},isPersistent:tW}),t}var tG,tX,tQ,tJ,t0,t1={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},t2=tY(t1),t3=_({},t1,{view:0,detail:0}),t4=tY(t3),t5=_({},t3,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ni,button:0,buttons:0,relatedTarget:function(e){return void 0===e.relatedTarget?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==t0&&(t0&&"mousemove"===e.type?(tQ=e.screenX-t0.screenX,tJ=e.screenY-t0.screenY):tJ=tQ=0,t0=e),tQ)},movementY:function(e){return"movementY"in e?e.movementY:tJ}}),t6=tY(t5),t9=tY(_({},t5,{dataTransfer:0})),t8=tY(_({},t3,{relatedTarget:0})),t7=tY(_({},t1,{animationName:0,elapsedTime:0,pseudoElement:0})),ne=tY(_({},t1,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}})),nt=tY(_({},t1,{data:0})),nn={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},nr={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},no={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function na(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):!!(e=no[e])&&!!t[e]}function ni(){return na}var nl=tY(_({},t3,{key:function(e){if(e.key){var t=nn[e.key]||e.key;if("Unidentified"!==t)return t}return"keypress"===e.type?13===(e=tq(e))?"Enter":String.fromCharCode(e):"keydown"===e.type||"keyup"===e.type?nr[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ni,charCode:function(e){return"keypress"===e.type?tq(e):0},keyCode:function(e){return"keydown"===e.type||"keyup"===e.type?e.keyCode:0},which:function(e){return"keypress"===e.type?tq(e):"keydown"===e.type||"keyup"===e.type?e.keyCode:0}})),ns=tY(_({},t5,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),nc=tY(_({},t3,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ni})),nu=tY(_({},t1,{propertyName:0,elapsedTime:0,pseudoElement:0})),nd=tY(_({},t5,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),nf=tY(_({},t1,{newState:0,oldState:0})),np=[9,13,27,32],nh=tZ&&"CompositionEvent"in window,nm=null;tZ&&"documentMode"in document&&(nm=document.documentMode);var ng=tZ&&"TextEvent"in window&&!nm,nv=tZ&&(!nh||nm&&8<nm&&11>=nm),ny=!1;function nb(e,t){switch(e){case"keyup":return -1!==np.indexOf(t.keyCode);case"keydown":return 229!==t.keyCode;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function nx(e){return"object"==typeof(e=e.detail)&&"data"in e?e.data:null}var nw=!1,n_={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function nk(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return"input"===t?!!n_[e.type]:"textarea"===t}function nj(e,t,n,r){tL?tA?tA.push(r):tA=[r]:tL=r,0<(t=c6(t,"onChange")).length&&(n=new t2("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var nS=null,nO=null;function nC(e){cQ(e,0)}function nP(e){if(tf(e4(e)))return e}function nE(e,t){if("change"===e)return t}var nT=!1;if(tZ){if(tZ){var nI="oninput"in document;if(!nI){var nN=document.createElement("div");nN.setAttribute("oninput","return;"),nI="function"==typeof nN.oninput}r=nI}else r=!1;nT=r&&(!document.documentMode||9<document.documentMode)}function nL(){nS&&(nS.detachEvent("onpropertychange",nA),nO=nS=null)}function nA(e){if("value"===e.propertyName&&nP(nO)){var t=[];nj(t,nO,e,tN(e)),tD(nC,t)}}function nz(e,t,n){"focusin"===e?(nL(),nS=t,nO=n,nS.attachEvent("onpropertychange",nA)):"focusout"===e&&nL()}function nR(e){if("selectionchange"===e||"keyup"===e||"keydown"===e)return nP(nO)}function nD(e,t){if("click"===e)return nP(t)}function nM(e,t){if("input"===e||"change"===e)return nP(t)}var nZ="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t};function nF(e,t){if(nZ(e,t))return!0;if("object"!=typeof e||null===e||"object"!=typeof t||null===t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var o=n[r];if(!eu.call(t,o)||!nZ(e[o],t[o]))return!1}return!0}function nU(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function nH(e,t){var n,r=nU(e);for(e=0;r;){if(3===r.nodeType){if(n=e+r.textContent.length,e<=t&&n>=t)return{node:r,offset:t-e};e=n}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=nU(r)}}function nV(e){e=null!=e&&null!=e.ownerDocument&&null!=e.ownerDocument.defaultView?e.ownerDocument.defaultView:window;for(var t=tp(e.document);t instanceof e.HTMLIFrameElement;){try{var n="string"==typeof t.contentWindow.location.href}catch(e){n=!1}if(n)e=t.contentWindow;else break;t=tp(e.document)}return t}function nB(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&("input"===t&&("text"===e.type||"search"===e.type||"tel"===e.type||"url"===e.type||"password"===e.type)||"textarea"===t||"true"===e.contentEditable)}var n$=tZ&&"documentMode"in document&&11>=document.documentMode,nq=null,nW=null,nK=null,nY=!1;function nG(e,t,n){var r=n.window===n?n.document:9===n.nodeType?n:n.ownerDocument;nY||null==nq||nq!==tp(r)||(r="selectionStart"in(r=nq)&&nB(r)?{start:r.selectionStart,end:r.selectionEnd}:{anchorNode:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection()).anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset},nK&&nF(nK,r)||(nK=r,0<(r=c6(nW,"onSelect")).length&&(t=new t2("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=nq)))}function nX(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var nQ={animationend:nX("Animation","AnimationEnd"),animationiteration:nX("Animation","AnimationIteration"),animationstart:nX("Animation","AnimationStart"),transitionrun:nX("Transition","TransitionRun"),transitionstart:nX("Transition","TransitionStart"),transitioncancel:nX("Transition","TransitionCancel"),transitionend:nX("Transition","TransitionEnd")},nJ={},n0={};function n1(e){if(nJ[e])return nJ[e];if(!nQ[e])return e;var t,n=nQ[e];for(t in n)if(n.hasOwnProperty(t)&&t in n0)return nJ[e]=n[t];return e}tZ&&(n0=document.createElement("div").style,"AnimationEvent"in window||(delete nQ.animationend.animation,delete nQ.animationiteration.animation,delete nQ.animationstart.animation),"TransitionEvent"in window||delete nQ.transitionend.transition);var n2=n1("animationend"),n3=n1("animationiteration"),n4=n1("animationstart"),n5=n1("transitionrun"),n6=n1("transitionstart"),n9=n1("transitioncancel"),n8=n1("transitionend"),n7=new Map,re="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function rt(e,t){n7.set(e,t),e7(t,[e])}re.push("scrollEnd");var rn=0;function rr(e,t){return null!=e.name&&"auto"!==e.name?e.name:null!==t.autoName?t.autoName:t.autoName=e="_"+(e=sK.identifierPrefix)+"t_"+(rn++).toString(32)+"_"}function ro(e){if(null==e||"string"==typeof e)return e;var t=null,n=s2;if(null!==n)for(var r=0;r<n.length;r++){var o=e[n[r]];if(null!=o){if("none"===o)return"none";t=null==t?o:t+" "+o}}return null==t?e.default:t}function ra(e,t){return e=ro(e),null==(t=ro(t))?"auto"===e?null:e:"auto"===t?null:t}var ri="function"==typeof reportError?reportError:function(e){if("object"==typeof window&&"function"==typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"==typeof e&&null!==e&&"string"==typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"==typeof process&&"function"==typeof process.emit)return void process.emit("uncaughtException",e);console.error(e)},rl=[],rs=0,rc=0;function ru(){for(var e=rs,t=rc=rs=0;t<e;){var n=rl[t];rl[t++]=null;var r=rl[t];rl[t++]=null;var o=rl[t];rl[t++]=null;var a=rl[t];if(rl[t++]=null,null!==r&&null!==o){var i=r.pending;null===i?o.next=o:(o.next=i.next,i.next=o),r.pending=o}0!==a&&rh(n,o,a)}}function rd(e,t,n,r){rl[rs++]=e,rl[rs++]=t,rl[rs++]=n,rl[rs++]=r,rc|=r,e.lanes|=r,null!==(e=e.alternate)&&(e.lanes|=r)}function rf(e,t,n,r){return rd(e,t,n,r),rm(e)}function rp(e,t){return rd(e,null,null,t),rm(e)}function rh(e,t,n){e.lanes|=n;var r=e.alternate;null!==r&&(r.lanes|=n);for(var o=!1,a=e.return;null!==a;)a.childLanes|=n,null!==(r=a.alternate)&&(r.childLanes|=n),22===a.tag&&(null===(e=a.stateNode)||1&e._visibility||(o=!0)),e=a,a=a.return;return 3===e.tag?(a=e.stateNode,o&&null!==t&&(o=31-eC(n),null===(r=(e=a.hiddenUpdates)[o])?e[o]=[t]:r.push(t),t.lane=0x20000000|n),a):null}function rm(e){if(50<s3)throw s3=0,s4=null,Error(l(185));for(var t=e.return;null!==t;)t=(e=t).return;return 3===e.tag?e.stateNode:null}var rg={};function rv(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function ry(e,t,n,r){return new rv(e,t,n,r)}function rb(e){return!(!(e=e.prototype)||!e.isReactComponent)}function rx(e,t){var n=e.alternate;return null===n?((n=ry(e.tag,t,e.key,e.mode)).elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=0x7e00000&e.flags,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=null===t?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function rw(e,t){e.flags&=0x7e00002;var n=e.alternate;return null===n?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,e.dependencies=null===(t=n.dependencies)?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function r_(e,t,n,r,o,a){var i=0;if(r=e,"function"==typeof e)rb(e)&&(i=1);else if("string"==typeof e)i=!function(e,t,n){if(1===n||null!=t.itemProp)return!1;switch(e){case"meta":case"title":return!0;case"style":if("string"!=typeof t.precedence||"string"!=typeof t.href||""===t.href)break;return!0;case"link":if("string"!=typeof t.rel||"string"!=typeof t.href||""===t.href||t.onLoad||t.onError)break;if("stylesheet"===t.rel)return e=t.disabled,"string"==typeof t.precedence&&null==e;return!0;case"script":if(t.async&&"function"!=typeof t.async&&"symbol"!=typeof t.async&&!t.onLoad&&!t.onError&&t.src&&"string"==typeof t.src)return!0}return!1}(e,n,Q.current)?"html"===e||"head"===e||"body"===e?27:5:26;else e:switch(e){case R:return(e=ry(31,n,t,o)).elementType=R,e.lanes=a,e;case O:return rk(n.children,o,a,t);case C:i=8,o|=24;break;case P:return(e=ry(12,n,t,2|o)).elementType=P,e.lanes=a,e;case N:return(e=ry(13,n,t,o)).elementType=N,e.lanes=a,e;case L:return(e=ry(19,n,t,o)).elementType=L,e.lanes=a,e;case D:case Z:return(e=ry(30,n,t,e=32|o)).elementType=Z,e.lanes=a,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if("object"==typeof e&&null!==e)switch(e.$$typeof){case T:i=10;break e;case E:i=9;break e;case I:i=11;break e;case A:i=14;break e;case z:i=16,r=null;break e}i=29,n=Error(l(130,null===e?"null":typeof e,"")),r=null}return(t=ry(i,n,t,o)).elementType=e,t.type=r,t.lanes=a,t}function rk(e,t,n,r){return(e=ry(7,e,r,t)).lanes=n,e}function rj(e,t,n){return(e=ry(6,e,null,t)).lanes=n,e}function rS(e){var t=ry(18,null,null,0);return t.stateNode=e,t}function rO(e,t,n){return(t=ry(4,null!==e.children?e.children:[],e.key,t)).lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var rC=new WeakMap;function rP(e,t){if("object"==typeof e&&null!==e){var n=rC.get(e);return void 0!==n?n:(t={value:e,source:t,stack:ec(t)},rC.set(e,t),t)}return{value:e,source:t,stack:ec(t)}}var rE=[],rT=0,rI=null,rN=0,rL=[],rA=0,rz=null,rR=1,rD="";function rM(e,t){rE[rT++]=rN,rE[rT++]=rI,rI=e,rN=t}function rZ(e,t,n){rL[rA++]=rR,rL[rA++]=rD,rL[rA++]=rz,rz=e;var r=rR;e=rD;var o=32-eC(r)-1;r&=~(1<<o),n+=1;var a=32-eC(t)+o;if(30<a){var i=o-o%5;a=(r&(1<<i)-1).toString(32),r>>=i,o-=i,rR=1<<32-eC(t)+o|n<<o|r,rD=a+e}else rR=1<<a|n<<o|r,rD=e}function rF(e){null!==e.return&&(rM(e,1),rZ(e,1,0))}function rU(e){for(;e===rI;)rI=rE[--rT],rE[rT]=null,rN=rE[--rT],rE[rT]=null;for(;e===rz;)rz=rL[--rA],rL[rA]=null,rD=rL[--rA],rL[rA]=null,rR=rL[--rA],rL[rA]=null}function rH(e,t){rL[rA++]=rR,rL[rA++]=rD,rL[rA++]=rz,rR=t.id,rD=t.overflow,rz=e}var rV=null,rB=null,r$=!1,rq=null,rW=!1,rK=Error(l(519));function rY(e){var t=Error(l(418,1<arguments.length&&void 0!==arguments[1]&&arguments[1]?"text":"HTML",""));throw r1(rP(t,e)),rK}function rG(e){var t=e.stateNode,n=e.type,r=e.memoizedProps;switch(t[eW]=e,t[eK]=r,n){case"dialog":cJ("cancel",t),cJ("close",t);break;case"iframe":case"object":case"embed":cJ("load",t);break;case"video":case"audio":for(n=0;n<cG.length;n++)cJ(cG[n],t);break;case"source":cJ("error",t);break;case"img":case"image":case"link":cJ("error",t),cJ("load",t);break;case"details":cJ("toggle",t);break;case"input":cJ("invalid",t),tv(t,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0);break;case"select":cJ("invalid",t);break;case"textarea":cJ("invalid",t),tw(t,r.value,r.defaultValue,r.children)}"string"!=typeof(n=r.children)&&"number"!=typeof n&&"bigint"!=typeof n||t.textContent===""+n||!0===r.suppressHydrationWarning||un(t.textContent,n)?(null!=r.popover&&(cJ("beforetoggle",t),cJ("toggle",t)),null!=r.onScroll&&cJ("scroll",t),null!=r.onScrollEnd&&cJ("scrollend",t),null!=r.onClick&&(t.onclick=tT),t=!0):t=!1,t||rY(e,!0)}function rX(e){for(rV=e.return;rV;)switch(rV.tag){case 5:case 31:case 13:rW=!1;return;case 27:case 3:rW=!0;return;default:rV=rV.return}}function rQ(e){if(e!==rV)return!1;if(!r$)return rX(e),r$=!0,!1;var t,n=e.tag;if((t=3!==n&&27!==n)&&((t=5===n)&&(t="form"===(t=e.type)||"button"===t||uf(e.type,e.memoizedProps)),t=!t),t&&rB&&rY(e),rX(e),13===n){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(l(317));rB=uK(e)}else if(31===n){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(l(317));rB=uK(e)}else 27===n?(n=rB,ub(e.type)?(e=uW,uW=null,rB=e):rB=n):rB=rV?uq(e.stateNode.nextSibling):null;return!0}function rJ(){rB=rV=null,r$=!1}function r0(){var e=rq;return null!==e&&(null===sF?sF=e:sF.push.apply(sF,e),rq=null),e}function r1(e){null===rq?rq=[e]:rq.push(e)}var r2=Y(null),r3=null,r4=null;function r5(e,t,n){X(r2,t._currentValue),t._currentValue=n}function r6(e){e._currentValue=r2.current,G(r2)}function r9(e,t,n){for(;null!==e;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,null!==r&&(r.childLanes|=t)):null!==r&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function r8(e,t,n,r){var o=e.child;for(null!==o&&(o.return=e);null!==o;){var a=o.dependencies;if(null!==a){var i=o.child;a=a.firstContext;e:for(;null!==a;){var s=a;a=o;for(var c=0;c<t.length;c++)if(s.context===t[c]){a.lanes|=n,null!==(s=a.alternate)&&(s.lanes|=n),r9(a.return,n,e),r||(i=null);break e}a=s.next}}else if(18===o.tag){if(null===(i=o.return))throw Error(l(341));i.lanes|=n,null!==(a=i.alternate)&&(a.lanes|=n),r9(i,n,e),i=null}else i=o.child;if(null!==i)i.return=o;else for(i=o;null!==i;){if(i===e){i=null;break}if(null!==(o=i.sibling)){o.return=i.return,i=o;break}i=i.return}o=i}}function r7(e,t,n,r){e=null;for(var o=t,a=!1;null!==o;){if(!a){if(0!=(524288&o.flags))a=!0;else if(0!=(262144&o.flags))break}if(10===o.tag){var i=o.alternate;if(null===i)throw Error(l(387));if(null!==(i=i.memoizedProps)){var s=o.type;nZ(o.pendingProps.value,i.value)||(null!==e?e.push(s):e=[s])}}else if(o===et.current){if(null===(i=o.alternate))throw Error(l(387));i.memoizedState.memoizedState!==o.memoizedState.memoizedState&&(null!==e?e.push(db):e=[db])}o=o.return}null!==e&&r8(t,e,n,r),t.flags|=262144}function oe(e){for(e=e.firstContext;null!==e;){if(!nZ(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function ot(e){r3=e,r4=null,null!==(e=e.dependencies)&&(e.firstContext=null)}function on(e){return oo(r3,e)}function or(e,t){return null===r3&&ot(e),oo(e,t)}function oo(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},null===r4){if(null===e)throw Error(l(308));r4=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else r4=r4.next=t;return n}var oa="undefined"!=typeof AbortController?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},oi=o.unstable_scheduleCallback,ol=o.unstable_NormalPriority,os={$$typeof:T,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function oc(){return{controller:new oa,data:new Map,refCount:0}}function ou(e){e.refCount--,0===e.refCount&&oi(ol,function(){e.controller.abort()})}function od(e,t){if(0!=(4194048&e.pendingLanes)){var n=e.transitionTypes;for(null===n&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var r=t[e];-1===n.indexOf(r)&&n.push(r)}}}var of=null,op=null,oh=0,om=0,og=null;function ov(){if(0==--oh&&(of=null,null!==op)){null!==og&&(og.status="fulfilled");var e=op;op=null,om=0,og=null;for(var t=0;t<e.length;t++)(0,e[t])()}}var oy=B.S;B.S=function(e,t){if(sV=em(),"object"==typeof t&&null!==t&&"function"==typeof t.then&&function(e,t){if(null===op){var n=op=[];oh=0,om=c$(),og={status:"pending",value:void 0,then:function(e){n.push(e)}}}oh++,t.then(ov,ov)}(0,t),null!==of)for(var n=cN;null!==n;)od(n,of),n=n.next;if(null!==(n=e.types)){for(var r=cN;null!==r;)od(r,n),r=r.next;if(0!==om){null===(r=of)&&(r=of=[]);for(var o=0;o<n.length;o++){var a=n[o];-1===r.indexOf(a)&&r.push(a)}}}null!==oy&&oy(e,t)};var ob=Y(null);function ox(){var e=ob.current;return null!==e?e:sj.pooledCache}function ow(e,t){null===t?X(ob,ob.current):X(ob,t.pool)}function o_(){var e=ox();return null===e?null:{parent:os._currentValue,pool:e}}var ok=Error(l(460)),oj=Error(l(474)),oS=Error(l(542)),oO={then:function(){}};function oC(e){return"fulfilled"===(e=e.status)||"rejected"===e}function oP(e,t,n){switch(void 0===(n=e[n])?e.push(t):n!==t&&(t.then(tT,tT),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw oN(e=t.reason),e;default:if("string"==typeof t.status)t.then(tT,tT);else{if(null!==(e=sj)&&100<e.shellSuspendCounter)throw Error(l(482));(e=t).status="pending",e.then(function(e){if("pending"===t.status){var n=t;n.status="fulfilled",n.value=e}},function(e){if("pending"===t.status){var n=t;n.status="rejected",n.reason=e}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw oN(e=t.reason),e}throw oT=t,ok}}function oE(e){try{return(0,e._init)(e._payload)}catch(e){if(null!==e&&"object"==typeof e&&"function"==typeof e.then)throw oT=e,ok;throw e}}var oT=null;function oI(){if(null===oT)throw Error(l(459));var e=oT;return oT=null,e}function oN(e){if(e===ok||e===oS)throw Error(l(483))}var oL=null,oA=0;function oz(e){var t=oA;return oA+=1,null===oL&&(oL=[]),oP(oL,e,t)}function oR(e,t){e.ref=void 0!==(t=t.props.ref)?t:null}function oD(e,t){if(t.$$typeof===k)throw Error(l(525));throw Error(l(31,"[object Object]"===(e=Object.prototype.toString.call(t))?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function oM(e){function t(t,n){if(e){var r=t.deletions;null===r?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;null!==r;)t(n,r),r=r.sibling;return null}function r(e){for(var t=new Map;null!==e;)null!==e.key?t.set(e.key,e):t.set(e.index,e),e=e.sibling;return t}function o(e,t){return(e=rx(e,t)).index=0,e.sibling=null,e}function a(t,n,r){return(t.index=r,e)?null!==(r=t.alternate)?(r=r.index)<n?(t.flags|=0x8000002,n):r:(t.flags|=0x8000002,n):(t.flags|=1048576,n)}function i(t){return e&&null===t.alternate&&(t.flags|=0x8000002),t}function s(e,t,n,r){return null===t||6!==t.tag?(t=rj(n,e.mode,r)).return=e:(t=o(t,n)).return=e,t}function c(e,t,n,r){var a=n.type;return a===O?(oR(e=d(e,t,n.props.children,r,n.key),n),e):(null!==t&&(t.elementType===a||"object"==typeof a&&null!==a&&a.$$typeof===z&&oE(a)===t.type)?oR(t=o(t,n.props),n):oR(t=r_(n.type,n.key,n.props,null,e.mode,r),n),t.return=e,t)}function u(e,t,n,r){return null===t||4!==t.tag||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=rO(n,e.mode,r)).return=e:(t=o(t,n.children||[])).return=e,t}function d(e,t,n,r,a){return null===t||7!==t.tag?(t=rk(n,e.mode,r,a)).return=e:(t=o(t,n)).return=e,t}function f(e,t,n){if("string"==typeof t&&""!==t||"number"==typeof t||"bigint"==typeof t)return(t=rj(""+t,e.mode,n)).return=e,t;if("object"==typeof t&&null!==t){switch(t.$$typeof){case j:return oR(n=r_(t.type,t.key,t.props,null,e.mode,n),t),n.return=e,n;case S:return(t=rO(t,e.mode,n)).return=e,t;case z:return f(e,t=oE(t),n)}if(V(t)||U(t))return(t=rk(t,e.mode,n,null)).return=e,t;if("function"==typeof t.then)return f(e,oz(t),n);if(t.$$typeof===T)return f(e,or(e,t),n);oD(e,t)}return null}function p(e,t,n,r){var o=null!==t?t.key:null;if("string"==typeof n&&""!==n||"number"==typeof n||"bigint"==typeof n)return null!==o?null:s(e,t,""+n,r);if("object"==typeof n&&null!==n){switch(n.$$typeof){case j:return n.key===o?c(e,t,n,r):null;case S:return n.key===o?u(e,t,n,r):null;case z:return p(e,t,n=oE(n),r)}if(V(n)||U(n))return null!==o?null:d(e,t,n,r,null);if("function"==typeof n.then)return p(e,t,oz(n),r);if(n.$$typeof===T)return p(e,t,or(e,n),r);oD(e,n)}return null}function h(e,t,n,r,o){if("string"==typeof r&&""!==r||"number"==typeof r||"bigint"==typeof r)return s(t,e=e.get(n)||null,""+r,o);if("object"==typeof r&&null!==r){switch(r.$$typeof){case j:return c(t,e=e.get(null===r.key?n:r.key)||null,r,o);case S:return u(t,e=e.get(null===r.key?n:r.key)||null,r,o);case z:return h(e,t,n,r=oE(r),o)}if(V(r)||U(r))return d(t,e=e.get(n)||null,r,o,null);if("function"==typeof r.then)return h(e,t,n,oz(r),o);if(r.$$typeof===T)return h(e,t,n,or(t,r),o);oD(t,r)}return null}return function(s,c,u,d){try{oA=0;var m=function s(c,u,d,m){if("object"==typeof d&&null!==d&&d.type===O&&null===d.key&&void 0===d.props.ref&&(d=d.props.children),"object"==typeof d&&null!==d){switch(d.$$typeof){case j:e:{for(var g=d.key;null!==u;){if(u.key===g){if((g=d.type)===O){if(7===u.tag){n(c,u.sibling),oR(m=o(u,d.props.children),d),m.return=c,c=m;break e}}else if(u.elementType===g||"object"==typeof g&&null!==g&&g.$$typeof===z&&oE(g)===u.type){n(c,u.sibling),oR(m=o(u,d.props),d),m.return=c,c=m;break e}n(c,u);break}t(c,u),u=u.sibling}d.type===O?oR(m=rk(d.props.children,c.mode,m,d.key),d):oR(m=r_(d.type,d.key,d.props,null,c.mode,m),d),m.return=c,c=m}return i(c);case S:e:{for(g=d.key;null!==u;){if(u.key===g)if(4===u.tag&&u.stateNode.containerInfo===d.containerInfo&&u.stateNode.implementation===d.implementation){n(c,u.sibling),(m=o(u,d.children||[])).return=c,c=m;break e}else{n(c,u);break}t(c,u),u=u.sibling}(m=rO(d,c.mode,m)).return=c,c=m}return i(c);case z:return s(c,u,d=oE(d),m)}if(V(d))return function(o,i,l,s){for(var c=null,u=null,d=i,m=i=0,g=null;null!==d&&m<l.length;m++){d.index>m?(g=d,d=null):g=d.sibling;var v=p(o,d,l[m],s);if(null===v){null===d&&(d=g);break}e&&d&&null===v.alternate&&t(o,d),i=a(v,i,m),null===u?c=v:u.sibling=v,u=v,d=g}if(m===l.length)return n(o,d),r$&&rM(o,m),c;if(null===d){for(;m<l.length;m++)null!==(d=f(o,l[m],s))&&(i=a(d,i,m),null===u?c=d:u.sibling=d,u=d);return r$&&rM(o,m),c}for(d=r(d);m<l.length;m++)null!==(g=h(d,o,m,l[m],s))&&(e&&null!==g.alternate&&d.delete(null===g.key?m:g.key),i=a(g,i,m),null===u?c=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(o,e)}),r$&&rM(o,m),c}(c,u,d,m);if(U(d)){if("function"!=typeof(g=U(d)))throw Error(l(150));return function(o,i,s,c){if(null==s)throw Error(l(151));for(var u=null,d=null,m=i,g=i=0,v=null,y=s.next();null!==m&&!y.done;g++,y=s.next()){m.index>g?(v=m,m=null):v=m.sibling;var b=p(o,m,y.value,c);if(null===b){null===m&&(m=v);break}e&&m&&null===b.alternate&&t(o,m),i=a(b,i,g),null===d?u=b:d.sibling=b,d=b,m=v}if(y.done)return n(o,m),r$&&rM(o,g),u;if(null===m){for(;!y.done;g++,y=s.next())null!==(y=f(o,y.value,c))&&(i=a(y,i,g),null===d?u=y:d.sibling=y,d=y);return r$&&rM(o,g),u}for(m=r(m);!y.done;g++,y=s.next())null!==(y=h(m,o,g,y.value,c))&&(e&&null!==y.alternate&&m.delete(null===y.key?g:y.key),i=a(y,i,g),null===d?u=y:d.sibling=y,d=y);return e&&m.forEach(function(e){return t(o,e)}),r$&&rM(o,g),u}(c,u,d=g.call(d),m)}if("function"==typeof d.then)return s(c,u,oz(d),m);if(d.$$typeof===T)return s(c,u,or(c,d),m);oD(c,d)}return"string"==typeof d&&""!==d||"number"==typeof d||"bigint"==typeof d?(d=""+d,null!==u&&6===u.tag?(n(c,u.sibling),(m=o(u,d)).return=c):(n(c,u),(m=rj(d,c.mode,m)).return=c),i(c=m)):n(c,u)}(s,c,u,d);return oL=null,m}catch(e){if(e===ok||e===oS)throw e;var g=ry(29,e,null,s.mode);return g.lanes=d,g.return=s,g}finally{}}}var oZ=oM(!0),oF=oM(!1),oU=!1;function oH(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function oV(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function oB(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function o$(e,t,n){var r=e.updateQueue;if(null===r)return null;if(r=r.shared,0!=(2&sk)){var o=r.pending;return null===o?t.next=t:(t.next=o.next,o.next=t),r.pending=t,t=rm(e),rh(e,null,n),t}return rd(e,r,t,n),rm(e)}function oq(e,t,n){if(null!==(t=t.updateQueue)&&(t=t.shared,0!=(4194048&n))){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,eF(e,n)}}function oW(e,t){var n=e.updateQueue,r=e.alternate;if(null!==r&&n===(r=r.updateQueue)){var o=null,a=null;if(null!==(n=n.firstBaseUpdate)){do{var i={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};null===a?o=a=i:a=a.next=i,n=n.next}while(null!==n);null===a?o=a=t:a=a.next=t}else o=a=t;n={baseState:r.baseState,firstBaseUpdate:o,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n;return}null===(e=n.lastBaseUpdate)?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var oK=!1;function oY(){if(oK){var e=og;if(null!==e)throw e}}function oG(e,t,n,r){oK=!1;var o=e.updateQueue;oU=!1;var a=o.firstBaseUpdate,i=o.lastBaseUpdate,l=o.shared.pending;if(null!==l){o.shared.pending=null;var s=l,c=s.next;s.next=null,null===i?a=c:i.next=c,i=s;var u=e.alternate;null!==u&&(l=(u=u.updateQueue).lastBaseUpdate)!==i&&(null===l?u.firstBaseUpdate=c:l.next=c,u.lastBaseUpdate=s)}if(null!==a){var d=o.baseState;for(i=0,u=c=s=null,l=a;;){var f=-0x20000001&l.lane,p=f!==l.lane;if(p?(sO&f)===f:(r&f)===f){0!==f&&f===om&&(oK=!0),null!==u&&(u=u.next={lane:0,tag:l.tag,payload:l.payload,callback:null,next:null});e:{var h=e,m=l;switch(f=t,m.tag){case 1:if("function"==typeof(h=m.payload)){d=h.call(n,d,f);break e}d=h;break e;case 3:h.flags=-65537&h.flags|128;case 0:if(null==(f="function"==typeof(h=m.payload)?h.call(n,d,f):h))break e;d=_({},d,f);break e;case 2:oU=!0}}null!==(f=l.callback)&&(e.flags|=64,p&&(e.flags|=8192),null===(p=o.callbacks)?o.callbacks=[f]:p.push(f))}else p={lane:f,tag:l.tag,payload:l.payload,callback:l.callback,next:null},null===u?(c=u=p,s=d):u=u.next=p,i|=f;if(null===(l=l.next))if(null===(l=o.shared.pending))break;else l=(p=l).next,p.next=null,o.lastBaseUpdate=p,o.shared.pending=null}null===u&&(s=d),o.baseState=s,o.firstBaseUpdate=c,o.lastBaseUpdate=u,null===a&&(o.shared.lanes=0),sA|=i,e.lanes=i,e.memoizedState=d}}function oX(e,t){if("function"!=typeof e)throw Error(l(191,e));e.call(t)}function oQ(e,t){var n=e.callbacks;if(null!==n)for(e.callbacks=null,e=0;e<n.length;e++)oX(n[e],t)}var oJ=Y(null),o0=Y(0);function o1(e,t){X(o0,e=sN),X(oJ,t),sN=e|t.baseLanes}function o2(){X(o0,sN),X(oJ,oJ.current)}function o3(){sN=o0.current,G(oJ),G(o0)}var o4=Y(null),o5=null;function o6(e){var t=e.alternate;X(at,1&at.current),X(o4,e),null===o5&&(null===t||null!==oJ.current?o5=e:null!==t.memoizedState&&(o5=e))}function o9(e){X(at,at.current),X(o4,e),null===o5&&(o5=e)}function o8(e){22===e.tag?(X(at,at.current),X(o4,e),null===o5&&(o5=e)):o7()}function o7(){X(at,at.current),X(o4,o4.current)}function ae(e){G(o4),o5===e&&(o5=null),G(at)}var at=Y(0);function an(e,t){X(o4,o4.current),X(at,t)}function ar(e){G(at),G(o4),o5===e&&(o5=null)}function ao(e){for(var t=e;null!==t;){if(13===t.tag){var n=t.memoizedState;if(null!==n&&(null===(n=n.dehydrated)||uB(n)||u$(n)))return t}else if(19===t.tag&&"independent"!==t.memoizedProps.revealOrder){if(0!=(128&t.flags))return t}else if(null!==t.child){t.child.return=t,t=t.child;continue}if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var aa=0,ai=null,al=null,as=null,ac=!1,au=!1,ad=!1,af=0,ap=0,ah=null,am=0;function ag(){throw Error(l(321))}function av(e,t){if(null===t)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!nZ(e[n],t[n]))return!1;return!0}function ay(e,t,n,r,o,a){return aa=a,ai=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,B.H=null===e||null===e.memoizedState?iO:iC,ad=!1,a=n(r,o),ad=!1,au&&(a=ax(t,n,r,o)),ab(e),a}function ab(e){B.H=iS;var t=null!==al&&null!==al.next;if(aa=0,as=al=ai=null,ac=!1,ap=0,ah=null,t)throw Error(l(300));null===e||iV||null!==(e=e.dependencies)&&oe(e)&&(iV=!0)}function ax(e,t,n,r){ai=e;var o=0;do{if(au&&(ah=null),ap=0,au=!1,25<=o)throw Error(l(301));if(o+=1,as=al=null,null!=e.updateQueue){var a=e.updateQueue;a.lastEffect=null,a.events=null,a.stores=null,null!=a.memoCache&&(a.memoCache.index=0)}B.H=iP,a=t(n,r)}while(au);return a}function aw(){var e=B.H,t=e.useState()[0];return t="function"==typeof t.then?aP(t):t,e=e.useState()[0],(null!==al?al.memoizedState:null)!==e&&(ai.flags|=1024),t}function a_(){var e=0!==af;return af=0,e}function ak(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function aj(e){if(ac){for(e=e.memoizedState;null!==e;){var t=e.queue;null!==t&&(t.pending=null),e=e.next}ac=!1}aa=0,as=al=ai=null,au=!1,ap=af=0,ah=null}function aS(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return null===as?ai.memoizedState=as=e:as=as.next=e,as}function aO(){if(null===al){var e=ai.alternate;e=null!==e?e.memoizedState:null}else e=al.next;var t=null===as?ai.memoizedState:as.next;if(null!==t)as=t,al=e;else{if(null===e){if(null===ai.alternate)throw Error(l(467));throw Error(l(310))}e={memoizedState:(al=e).memoizedState,baseState:al.baseState,baseQueue:al.baseQueue,queue:al.queue,next:null},null===as?ai.memoizedState=as=e:as=as.next=e}return as}function aC(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function aP(e){var t=ap;return ap+=1,null===ah&&(ah=[]),e=oP(ah,e,t),t=ai,null===(null===as?t.memoizedState:as.next)&&(B.H=null===(t=t.alternate)||null===t.memoizedState?iO:iC),e}function aE(e){if(null!==e&&"object"==typeof e){if("function"==typeof e.then)return aP(e);if(e.$$typeof===T)return on(e)}throw Error(l(438,String(e)))}function aT(e){var t=null,n=ai.updateQueue;if(null!==n&&(t=n.memoCache),null==t){var r=ai.alternate;null!==r&&null!==(r=r.updateQueue)&&null!=(r=r.memoCache)&&(t={data:r.data.map(function(e){return e.slice()}),index:0})}if(null==t&&(t={data:[],index:0}),null===n&&(n=aC(),ai.updateQueue=n),n.memoCache=t,void 0===(n=t.data[t.index]))for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=M;return t.index++,n}function aI(e,t){return"function"==typeof t?t(e):t}function aN(e){return aL(aO(),al,e)}function aL(e,t,n){var r=e.queue;if(null===r)throw Error(l(311));r.lastRenderedReducer=n;var o=e.baseQueue,a=r.pending;if(null!==a){if(null!==o){var i=o.next;o.next=a.next,a.next=i}t.baseQueue=o=a,r.pending=null}if(a=e.baseState,null===o)e.memoizedState=a;else{t=o.next;var s=i=null,c=null,u=t,d=!1;do{var f=-0x20000001&u.lane;if(f!==u.lane?(sO&f)===f:(aa&f)===f){var p=u.revertLane;if(0===p)null!==c&&(c=c.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),f===om&&(d=!0);else if((aa&p)===p){u=u.next,p===om&&(d=!0);continue}else f={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},null===c?(s=c=f,i=a):c=c.next=f,ai.lanes|=p,sA|=p;f=u.action,ad&&n(a,f),a=u.hasEagerState?u.eagerState:n(a,f)}else p={lane:f,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},null===c?(s=c=p,i=a):c=c.next=p,ai.lanes|=f,sA|=f;u=u.next}while(null!==u&&u!==t);if(null===c?i=a:c.next=s,!nZ(a,e.memoizedState)&&(iV=!0,d&&null!==(n=og)))throw n;e.memoizedState=a,e.baseState=i,e.baseQueue=c,r.lastRenderedState=a}return null===o&&(r.lanes=0),[e.memoizedState,r.dispatch]}function aA(e){var t=aO(),n=t.queue;if(null===n)throw Error(l(311));n.lastRenderedReducer=e;var r=n.dispatch,o=n.pending,a=t.memoizedState;if(null!==o){n.pending=null;var i=o=o.next;do a=e(a,i.action),i=i.next;while(i!==o);nZ(a,t.memoizedState)||(iV=!0),t.memoizedState=a,null===t.baseQueue&&(t.baseState=a),n.lastRenderedState=a}return[a,r]}function az(e,t,n){var r=ai,o=aO(),a=r$;if(a){if(void 0===n)throw Error(l(407));n=n()}else n=t();var i=!nZ((al||o).memoizedState,n);if(i&&(o.memoizedState=n,iV=!0),o=o.queue,a6(aM.bind(null,r,o,e),[e]),o.getSnapshot!==t||i||null!==as&&1&as.memoizedState.tag){if(r.flags|=2048,a1(9,{destroy:void 0},aD.bind(null,r,o,n,t),null),null===sj)throw Error(l(349));a||0!=(127&aa)||aR(r,t,n)}return n}function aR(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},null===(t=ai.updateQueue)?(t=aC(),ai.updateQueue=t,t.stores=[e]):null===(n=t.stores)?t.stores=[e]:n.push(e)}function aD(e,t,n,r){t.value=n,t.getSnapshot=r,aZ(t)&&aF(e)}function aM(e,t,n){return n(function(){aZ(t)&&aF(e)})}function aZ(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!nZ(e,n)}catch(e){return!0}}function aF(e){var t=rp(e,2);null!==t&&s8(t,e,2)}function aU(e){var t=aS();if("function"==typeof e){var n=e;if(e=n(),ad){eO(!0);try{n()}finally{eO(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:aI,lastRenderedState:e},t}function aH(e,t,n,r){return e.baseState=n,aL(e,al,"function"==typeof r?r:aI)}function aV(e,t,n,r,o){if(i_(e))throw Error(l(485));if(null!==(e=t.action)){var a={payload:o,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(e){a.listeners.push(e)}};null!==B.T?n(!0):a.isTransition=!1,r(a),null===(n=t.pending)?(a.next=t.pending=a,aB(t,a)):(a.next=n.next,t.pending=n.next=a)}}function aB(e,t){var n=t.action,r=t.payload,o=e.state;if(t.isTransition){var a=B.T,i={};i.types=null!==a?a.types:null,B.T=i;try{var l=n(o,r),s=B.S;null!==s&&s(i,l),a$(e,t,l)}catch(n){aW(e,t,n)}finally{null!==a&&null!==i.types&&(a.types=i.types),B.T=a}}else try{a=n(o,r),a$(e,t,a)}catch(n){aW(e,t,n)}}function a$(e,t,n){null!==n&&"object"==typeof n&&"function"==typeof n.then?n.then(function(n){aq(e,t,n)},function(n){return aW(e,t,n)}):aq(e,t,n)}function aq(e,t,n){t.status="fulfilled",t.value=n,aK(t),e.state=n,null!==(t=e.pending)&&((n=t.next)===t?e.pending=null:(n=n.next,t.next=n,aB(e,n)))}function aW(e,t,n){var r=e.pending;if(e.pending=null,null!==r){r=r.next;do t.status="rejected",t.reason=n,aK(t),t=t.next;while(t!==r)}e.action=null}function aK(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function aY(e,t){return t}function aG(e,t){if(r$){var n=sj.formState;if(null!==n){e:{var r=ai;if(r$){if(rB){t:{for(var o=rB,a=rW;8!==o.nodeType;)if(!a||null===(o=uq(o.nextSibling))){o=null;break t}o="F!"===(a=o.data)||"F"===a?o:null}if(o){rB=uq(o.nextSibling),r="F!"===o.data;break e}}rY(r)}r=!1}r&&(t=n[0])}}return(n=aS()).memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:aY,lastRenderedState:t},n.queue=r,n=ib.bind(null,ai,r),r.dispatch=n,r=aU(!1),a=iw.bind(null,ai,!1,r.queue),r=aS(),o={state:t,dispatch:null,action:e,pending:null},r.queue=o,n=aV.bind(null,ai,o,a,n),o.dispatch=n,r.memoizedState=e,[t,n,!1]}function aX(e){return aQ(aO(),al,e)}function aQ(e,t,n){if(t=aL(e,t,aY)[0],e=aN(aI)[0],"object"==typeof t&&null!==t&&"function"==typeof t.then)try{var r=aP(t)}catch(e){if(e===ok)throw oS;throw e}else r=t;var o=(t=aO()).queue,a=o.dispatch;return n!==t.memoizedState&&(ai.flags|=2048,a1(9,{destroy:void 0},aJ.bind(null,o,n),null)),[r,a,e]}function aJ(e,t){e.action=t}function a0(e){var t=aO(),n=al;if(null!==n)return aQ(t,n,e);aO(),t=t.memoizedState;var r=(n=aO()).queue.dispatch;return n.memoizedState=e,[t,r,!1]}function a1(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},null===(t=ai.updateQueue)&&(t=aC(),ai.updateQueue=t),null===(n=t.lastEffect)?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function a2(){return aO().memoizedState}function a3(e,t,n,r){var o=aS();ai.flags|=e,o.memoizedState=a1(1|t,{destroy:void 0},n,void 0===r?null:r)}function a4(e,t,n,r){var o=aO();r=void 0===r?null:r;var a=o.memoizedState.inst;null!==al&&null!==r&&av(r,al.memoizedState.deps)?o.memoizedState=a1(t,a,n,r):(ai.flags|=e,o.memoizedState=a1(1|t,a,n,r))}function a5(e,t){a3(8390656,8,e,t)}function a6(e,t){a4(2048,8,e,t)}function a9(e){var t=aO().memoizedState,n={ref:t,nextImpl:e};ai.flags|=4;var r=ai.updateQueue;if(null===r)r=aC(),ai.updateQueue=r,r.events=[n];else{var o=r.events;null===o?r.events=[n]:o.push(n)}return function(){if(0!=(2&sk))throw Error(l(440));return t.impl.apply(void 0,arguments)}}function a8(e,t){return a4(4,2,e,t)}function a7(e,t){return a4(4,4,e,t)}function ie(e,t){if("function"==typeof t){var n=t(e=e());return function(){"function"==typeof n?n():t(null)}}if(null!=t)return t.current=e=e(),function(){t.current=null}}function it(e,t,n){n=null!=n?n.concat([e]):null,a4(4,4,ie.bind(null,t,e),n)}function ir(){}function io(e,t){var n=aO();t=void 0===t?null:t;var r=n.memoizedState;return null!==t&&av(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function ia(e,t){var n=aO();t=void 0===t?null:t;var r=n.memoizedState;if(null!==t&&av(t,r[1]))return r[0];if(r=e(),ad){eO(!0);try{e()}finally{eO(!1)}}return n.memoizedState=[r,t],r}function ii(e,t,n){return void 0===n||0!=(0x40000000&aa)&&0==(261930&sO)?e.memoizedState=t:(e.memoizedState=n,e=s6(),ai.lanes|=e,sA|=e,n)}function il(e,t,n,r){return nZ(n,t)?n:null!==oJ.current?(nZ(e=ii(e,n,r),t)||(iV=!0),e):0==(42&aa)||0!=(0x40000000&aa)&&0==(261930&sO)?(iV=!0,e.memoizedState=n):(e=s6(),ai.lanes|=e,sA|=e,t)}function is(e,t,n,r,o){var a=$.p;$.p=0!==a&&8>a?a:8;var i=B.T,l={};l.types=null!==i?i.types:null,B.T=l,iw(e,!1,t,n);try{var s=o(),c=B.S;if(null!==c&&c(l,s),null!==s&&"object"==typeof s&&"function"==typeof s.then){var u,d,f=(u=[],d={status:"pending",value:null,reason:null,then:function(e){u.push(e)}},s.then(function(){d.status="fulfilled",d.value=r;for(var e=0;e<u.length;e++)(0,u[e])(r)},function(e){for(d.status="rejected",d.reason=e,e=0;e<u.length;e++)(0,u[e])(void 0)}),d);ix(e,t,f,s5(e))}else ix(e,t,r,s5(e))}catch(n){ix(e,t,{then:function(){},status:"rejected",reason:n},s5())}finally{$.p=a,null!==i&&null!==l.types&&(i.types=l.types),B.T=i}}function ic(){}function iu(e,t,n,r){if(5!==e.tag)throw Error(l(476));var o=id(e).queue;is(e,o,t,q,null===n?ic:function(){return ip(e),n(r)})}function id(e){var t=e.memoizedState;if(null!==t)return t;var n={};return(t={memoizedState:q,baseState:q,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:aI,lastRenderedState:q},next:null}).next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:aI,lastRenderedState:n},next:null},e.memoizedState=t,null!==(e=e.alternate)&&(e.memoizedState=t),t}function ip(e){var t=id(e);null===t.next&&(t=e.alternate.memoizedState),ix(e,t.next.queue,{},s5())}function ih(){return on(db)}function im(){return aO().memoizedState}function ig(){return aO().memoizedState}function iv(e){for(var t=e.return;null!==t;){switch(t.tag){case 24:case 3:var n=s5(),r=o$(t,e=oB(n),n);null!==r&&(s8(r,t,n),oq(r,t,n)),t={cache:oc()},e.payload=t;return}t=t.return}}function iy(e,t,n){var r=s5();n={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},i_(e)?ik(t,n):null!==(n=rf(e,t,n,r))&&(s8(n,e,r),ij(n,t,r))}function ib(e,t,n){ix(e,t,n,s5())}function ix(e,t,n,r){var o={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(i_(e))ik(t,o);else{var a=e.alternate;if(0===e.lanes&&(null===a||0===a.lanes)&&null!==(a=t.lastRenderedReducer))try{var i=t.lastRenderedState,l=a(i,n);if(o.hasEagerState=!0,o.eagerState=l,nZ(l,i))return rd(e,t,o,0),null===sj&&ru(),!1}catch(e){}finally{}if(null!==(n=rf(e,t,o,r)))return s8(n,e,r),ij(n,t,r),!0}return!1}function iw(e,t,n,r){if(r={lane:2,revertLane:c$(),gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},i_(e)){if(t)throw Error(l(479))}else null!==(t=rf(e,n,r,2))&&s8(t,e,2)}function i_(e){var t=e.alternate;return e===ai||null!==t&&t===ai}function ik(e,t){au=ac=!0;var n=e.pending;null===n?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function ij(e,t,n){if(0!=(4194048&n)){var r=t.lanes;r&=e.pendingLanes,t.lanes=n|=r,eF(e,n)}}var iS={readContext:on,use:aE,useCallback:ag,useContext:ag,useEffect:ag,useImperativeHandle:ag,useLayoutEffect:ag,useInsertionEffect:ag,useMemo:ag,useReducer:ag,useRef:ag,useState:ag,useDebugValue:ag,useDeferredValue:ag,useTransition:ag,useSyncExternalStore:ag,useId:ag,useHostTransitionStatus:ag,useFormState:ag,useActionState:ag,useOptimistic:ag,useMemoCache:ag,useCacheRefresh:ag};iS.useEffectEvent=ag;var iO={readContext:on,use:aE,useCallback:function(e,t){return aS().memoizedState=[e,void 0===t?null:t],e},useContext:on,useEffect:a5,useImperativeHandle:function(e,t,n){n=null!=n?n.concat([e]):null,a3(4194308,4,ie.bind(null,t,e),n)},useLayoutEffect:function(e,t){return a3(4194308,4,e,t)},useInsertionEffect:function(e,t){a3(4,2,e,t)},useMemo:function(e,t){var n=aS();t=void 0===t?null:t;var r=e();if(ad){eO(!0);try{e()}finally{eO(!1)}}return n.memoizedState=[r,t],r},useReducer:function(e,t,n){var r=aS();if(void 0!==n){var o=n(t);if(ad){eO(!0);try{n(t)}finally{eO(!1)}}}else o=t;return r.memoizedState=r.baseState=o,r.queue=e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:o},e=e.dispatch=iy.bind(null,ai,e),[r.memoizedState,e]},useRef:function(e){return aS().memoizedState={current:e}},useState:function(e){var t=(e=aU(e)).queue,n=ib.bind(null,ai,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:ir,useDeferredValue:function(e,t){return ii(aS(),e,t)},useTransition:function(){var e=aU(!1);return e=is.bind(null,ai,e.queue,!0,!1),aS().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var r=ai,o=aS();if(r$){if(void 0===n)throw Error(l(407));n=n()}else{if(n=t(),null===sj)throw Error(l(349));0!=(127&sO)||aR(r,t,n)}o.memoizedState=n;var a={value:n,getSnapshot:t};return o.queue=a,a5(aM.bind(null,r,a,e),[e]),r.flags|=2048,a1(9,{destroy:void 0},aD.bind(null,r,a,n,t),null),n},useId:function(){var e=aS(),t=sj.identifierPrefix;if(r$){var n=rD,r=rR;t="_"+t+"R_"+(n=(r&~(1<<32-eC(r)-1)).toString(32)+n),0<(n=af++)&&(t+="H"+n.toString(32)),t+="_"}else t="_"+t+"r_"+(n=am++).toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:ih,useFormState:aG,useActionState:aG,useOptimistic:function(e){var t=aS();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=iw.bind(null,ai,!0,n),n.dispatch=t,[e,t]},useMemoCache:aT,useCacheRefresh:function(){return aS().memoizedState=iv.bind(null,ai)},useEffectEvent:function(e){var t=aS(),n={impl:e};return t.memoizedState=n,function(){if(0!=(2&sk))throw Error(l(440));return n.impl.apply(void 0,arguments)}}},iC={readContext:on,use:aE,useCallback:io,useContext:on,useEffect:a6,useImperativeHandle:it,useInsertionEffect:a8,useLayoutEffect:a7,useMemo:ia,useReducer:aN,useRef:a2,useState:function(){return aN(aI)},useDebugValue:ir,useDeferredValue:function(e,t){return il(aO(),al.memoizedState,e,t)},useTransition:function(){var e=aN(aI)[0],t=aO().memoizedState;return["boolean"==typeof e?e:aP(e),t]},useSyncExternalStore:az,useId:im,useHostTransitionStatus:ih,useFormState:aX,useActionState:aX,useOptimistic:function(e,t){return aH(aO(),al,e,t)},useMemoCache:aT,useCacheRefresh:ig};iC.useEffectEvent=a9;var iP={readContext:on,use:aE,useCallback:io,useContext:on,useEffect:a6,useImperativeHandle:it,useInsertionEffect:a8,useLayoutEffect:a7,useMemo:ia,useReducer:aA,useRef:a2,useState:function(){return aA(aI)},useDebugValue:ir,useDeferredValue:function(e,t){var n=aO();return null===al?ii(n,e,t):il(n,al.memoizedState,e,t)},useTransition:function(){var e=aA(aI)[0],t=aO().memoizedState;return["boolean"==typeof e?e:aP(e),t]},useSyncExternalStore:az,useId:im,useHostTransitionStatus:ih,useFormState:a0,useActionState:a0,useOptimistic:function(e,t){var n=aO();return null!==al?aH(n,al,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:aT,useCacheRefresh:ig};function iE(e,t,n,r){n=null==(n=n(r,t=e.memoizedState))?t:_({},t,n),e.memoizedState=n,0===e.lanes&&(e.updateQueue.baseState=n)}iP.useEffectEvent=a9;var iT={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=s5(),o=oB(r);o.payload=t,null!=n&&(o.callback=n),null!==(t=o$(e,o,r))&&(s8(t,e,r),oq(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=s5(),o=oB(r);o.tag=1,o.payload=t,null!=n&&(o.callback=n),null!==(t=o$(e,o,r))&&(s8(t,e,r),oq(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=s5(),r=oB(n);r.tag=2,null!=t&&(r.callback=t),null!==(t=o$(e,r,n))&&(s8(t,e,n),oq(t,e,n))}};function iI(e,t,n,r,o,a,i){return"function"==typeof(e=e.stateNode).shouldComponentUpdate?e.shouldComponentUpdate(r,a,i):!t.prototype||!t.prototype.isPureReactComponent||!nF(n,r)||!nF(o,a)}function iN(e,t,n,r){e=t.state,"function"==typeof t.componentWillReceiveProps&&t.componentWillReceiveProps(n,r),"function"==typeof t.UNSAFE_componentWillReceiveProps&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&iT.enqueueReplaceState(t,t.state,null)}function iL(e,t){var n=t;if("ref"in t)for(var r in n={},t)"ref"!==r&&(n[r]=t[r]);if(e=e.defaultProps)for(var o in n===t&&(n=_({},n)),e)void 0===n[o]&&(n[o]=e[o]);return n}function iA(e){ri(e)}function iz(e){console.error(e)}function iR(e){ri(e)}function iD(e,t){try{(0,e.onUncaughtError)(t.value,{componentStack:t.stack})}catch(e){setTimeout(function(){throw e})}}function iM(e,t,n){try{(0,e.onCaughtError)(n.value,{componentStack:n.stack,errorBoundary:1===t.tag?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function iZ(e,t,n){return(n=oB(n)).tag=3,n.payload={element:null},n.callback=function(){iD(e,t)},n}function iF(e){return(e=oB(e)).tag=3,e}function iU(e,t,n,r){var o=n.type.getDerivedStateFromError;if("function"==typeof o){var a=r.value;e.payload=function(){return o(a)},e.callback=function(){iM(t,n,r)}}var i=n.stateNode;null!==i&&"function"==typeof i.componentDidCatch&&(e.callback=function(){iM(t,n,r),"function"!=typeof o&&(null===sq?sq=new Set([this]):sq.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:null!==e?e:""})})}var iH=Error(l(461)),iV=!1;function iB(e,t,n,r){t.child=null===e?oF(t,null,n,r):oZ(t,e.child,n,r)}function i$(e,t,n,r,o){n=n.render;var a=t.ref;if("ref"in r){var i={};for(var l in r)"ref"!==l&&(i[l]=r[l])}else i=r;return(ot(t),r=ay(e,t,n,i,a,o),l=a_(),null===e||iV)?(r$&&l&&rF(t),t.flags|=1,iB(e,t,r,o),t.child):(ak(e,t,o),li(e,t,o))}function iq(e,t,n,r,o){if(null===e){var a=n.type;return"function"!=typeof a||rb(a)||void 0!==a.defaultProps||null!==n.compare?((e=r_(n.type,null,r,t,t.mode,o)).ref=t.ref,e.return=t,t.child=e):(t.tag=15,t.type=a,iW(e,t,a,r,o))}if(a=e.child,!ll(e,o)){var i=a.memoizedProps;if((n=null!==(n=n.compare)?n:nF)(i,r)&&e.ref===t.ref)return li(e,t,o)}return t.flags|=1,(e=rx(a,r)).ref=t.ref,e.return=t,t.child=e}function iW(e,t,n,r,o){if(null!==e){var a=e.memoizedProps;if(nF(a,r)&&e.ref===t.ref)if(iV=!1,t.pendingProps=r=a,!ll(e,o))return t.lanes=e.lanes,li(e,t,o);else 0!=(131072&e.flags)&&(iV=!0)}return i0(e,t,n,r,o)}function iK(e,t,n,r){var o=r.children,a=null!==e?e.memoizedState:null;if(null===e&&null===t.stateNode&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),"hidden"===r.mode){if(0!=(128&t.flags)){if(a=null!==a?a.baseLanes|n:n,null!==e){for(o=0,r=t.child=e.child;null!==r;)o=o|r.lanes|r.childLanes,r=r.sibling;r=o&~a}else r=0,t.child=null;return iG(e,t,a,n,r)}if(0==(0x20000000&n))return r=t.lanes=0x20000000,iG(e,t,null!==a?a.baseLanes|n:n,n,r);t.memoizedState={baseLanes:0,cachePool:null},null!==e&&ow(t,null!==a?a.cachePool:null),null!==a?o1(t,a):o2(),o8(t)}else null!==a?(ow(t,a.cachePool),o1(t,a),o7(),t.memoizedState=null):(null!==e&&ow(t,null),o2(),o7());return iB(e,t,o,n),t.child}function iY(e,t){return null!==e&&22===e.tag||null!==t.stateNode||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function iG(e,t,n,r,o){var a=ox();return t.memoizedState={baseLanes:n,cachePool:a=null===a?null:{parent:os._currentValue,pool:a}},null!==e&&ow(t,null),o2(),o8(t),null!==e&&r7(e,t,r,!0),t.childLanes=o,null}function iX(e,t){return(t=i7({mode:t.mode,children:t.children},e.mode)).ref=e.ref,e.child=t,t.return=e,t}function iQ(e,t,n){return oZ(t,e.child,null,n),e=iX(t,t.pendingProps),e.flags|=2,ae(t),t.memoizedState=null,e}function iJ(e,t){var n=t.ref;if(null===n)null!==e&&null!==e.ref&&(t.flags|=4194816);else{if("function"!=typeof n&&"object"!=typeof n)throw Error(l(284));(null===e||e.ref!==n)&&(t.flags|=4194816)}}function i0(e,t,n,r,o){return(ot(t),n=ay(e,t,n,r,void 0,o),r=a_(),null===e||iV)?(r$&&r&&rF(t),t.flags|=1,iB(e,t,n,o),t.child):(ak(e,t,o),li(e,t,o))}function i1(e,t,n,r,o,a){return(ot(t),t.updateQueue=null,n=ax(t,r,n,o),ab(e),r=a_(),null===e||iV)?(r$&&r&&rF(t),t.flags|=1,iB(e,t,n,a),t.child):(ak(e,t,a),li(e,t,a))}function i2(e,t,n,r,o){if(ot(t),null===t.stateNode){var a=rg,i=n.contextType;"object"==typeof i&&null!==i&&(a=on(i)),t.memoizedState=null!==(a=new n(r,a)).state&&void 0!==a.state?a.state:null,a.updater=iT,t.stateNode=a,a._reactInternals=t,(a=t.stateNode).props=r,a.state=t.memoizedState,a.refs={},oH(t),i=n.contextType,a.context="object"==typeof i&&null!==i?on(i):rg,a.state=t.memoizedState,"function"==typeof(i=n.getDerivedStateFromProps)&&(iE(t,n,i,r),a.state=t.memoizedState),"function"==typeof n.getDerivedStateFromProps||"function"==typeof a.getSnapshotBeforeUpdate||"function"!=typeof a.UNSAFE_componentWillMount&&"function"!=typeof a.componentWillMount||(i=a.state,"function"==typeof a.componentWillMount&&a.componentWillMount(),"function"==typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount(),i!==a.state&&iT.enqueueReplaceState(a,a.state,null),oG(t,r,a,o),oY(),a.state=t.memoizedState),"function"==typeof a.componentDidMount&&(t.flags|=4194308),r=!0}else if(null===e){a=t.stateNode;var l=t.memoizedProps,s=iL(n,l);a.props=s;var c=a.context,u=n.contextType;i=rg,"object"==typeof u&&null!==u&&(i=on(u));var d=n.getDerivedStateFromProps;u="function"==typeof d||"function"==typeof a.getSnapshotBeforeUpdate,l=t.pendingProps!==l,u||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(l||c!==i)&&iN(t,a,r,i),oU=!1;var f=t.memoizedState;a.state=f,oG(t,r,a,o),oY(),c=t.memoizedState,l||f!==c||oU?("function"==typeof d&&(iE(t,n,d,r),c=t.memoizedState),(s=oU||iI(t,n,s,r,f,c,i))?(u||"function"!=typeof a.UNSAFE_componentWillMount&&"function"!=typeof a.componentWillMount||("function"==typeof a.componentWillMount&&a.componentWillMount(),"function"==typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount()),"function"==typeof a.componentDidMount&&(t.flags|=4194308)):("function"==typeof a.componentDidMount&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=c),a.props=r,a.state=c,a.context=i,r=s):("function"==typeof a.componentDidMount&&(t.flags|=4194308),r=!1)}else{a=t.stateNode,oV(e,t),u=iL(n,i=t.memoizedProps),a.props=u,d=t.pendingProps,f=a.context,c=n.contextType,s=rg,"object"==typeof c&&null!==c&&(s=on(c)),(c="function"==typeof(l=n.getDerivedStateFromProps)||"function"==typeof a.getSnapshotBeforeUpdate)||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(i!==d||f!==s)&&iN(t,a,r,s),oU=!1,f=t.memoizedState,a.state=f,oG(t,r,a,o),oY();var p=t.memoizedState;i!==d||f!==p||oU||null!==e&&null!==e.dependencies&&oe(e.dependencies)?("function"==typeof l&&(iE(t,n,l,r),p=t.memoizedState),(u=oU||iI(t,n,u,r,f,p,s)||null!==e&&null!==e.dependencies&&oe(e.dependencies))?(c||"function"!=typeof a.UNSAFE_componentWillUpdate&&"function"!=typeof a.componentWillUpdate||("function"==typeof a.componentWillUpdate&&a.componentWillUpdate(r,p,s),"function"==typeof a.UNSAFE_componentWillUpdate&&a.UNSAFE_componentWillUpdate(r,p,s)),"function"==typeof a.componentDidUpdate&&(t.flags|=4),"function"==typeof a.getSnapshotBeforeUpdate&&(t.flags|=1024)):("function"!=typeof a.componentDidUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),a.props=r,a.state=p,a.context=s,r=u):("function"!=typeof a.componentDidUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||i===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return a=r,iJ(e,t),r=0!=(128&t.flags),a||r?(a=t.stateNode,n=r&&"function"!=typeof n.getDerivedStateFromError?null:a.render(),t.flags|=1,null!==e&&r?(t.child=oZ(t,e.child,null,o),t.child=oZ(t,null,n,o)):iB(e,t,n,o),t.memoizedState=a.state,e=t.child):e=li(e,t,o),e}function i3(e,t,n,r){return rJ(),t.flags|=256,iB(e,t,n,r),t.child}var i4={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function i5(e){return{baseLanes:e,cachePool:o_()}}function i6(e,t,n){return e=null!==e?e.childLanes&~n:0,t&&(e|=sD),e}function i9(e,t,n){var r,o=t.pendingProps,a=!1,i=0!=(128&t.flags);if((r=i)||(r=(null===e||null!==e.memoizedState)&&0!=(2&at.current)),r&&(a=!0,t.flags&=-129),r=0!=(32&t.flags),t.flags&=-33,null===e){if(r$){if(a?o6(t):o7(),(e=rB)?null!==(e=null!==(e=uV(e,rW))&&"&"!==e.data?e:null)&&(t.memoizedState={dehydrated:e,treeContext:null!==rz?{id:rR,overflow:rD}:null,retryLane:0x20000000,hydrationErrors:null},(n=rS(e)).return=t,t.child=n,rV=t,rB=null):e=null,null===e)throw rY(t);return u$(e)?t.lanes=32:t.lanes=0x20000000,null}var s=o.children;return(o=o.fallback,a)?(o7(),s=i7({mode:"hidden",children:s},a=t.mode),o=rk(o,a,n,null),s.return=t,o.return=t,s.sibling=o,t.child=s,(o=t.child).memoizedState=i5(n),o.childLanes=i6(e,r,n),t.memoizedState=i4,iY(null,o)):(o6(t),i8(t,s))}var c=e.memoizedState;if(null!==c&&null!==(s=c.dehydrated)){if(i)256&t.flags?(o6(t),t.flags&=-257,t=le(e,t,n)):null!==t.memoizedState?(o7(),t.child=e.child,t.flags|=128,t=null):(o7(),s=o.fallback,a=t.mode,o=i7({mode:"visible",children:o.children},a),s=rk(s,a,n,null),s.flags|=2,o.return=t,s.return=t,o.sibling=s,t.child=o,oZ(t,e.child,null,n),(o=t.child).memoizedState=i5(n),o.childLanes=i6(e,r,n),t.memoizedState=i4,t=iY(null,o));else if(o6(t),u$(s)){if(r=s.nextSibling&&s.nextSibling.dataset)var u=r.dgst;r=u,(o=Error(l(419))).stack="",o.digest=r,r1({value:o,source:null,stack:null}),t=le(e,t,n)}else if(iV||r7(e,t,n,!1),r=0!=(n&e.childLanes),iV||r){if(null!==(r=sj)&&0!==(o=eU(r,n))&&o!==c.retryLane)throw c.retryLane=o,rp(e,o),s8(r,e,o),iH;uB(s)||cc(),t=le(e,t,n)}else uB(s)?(t.flags|=192,t.child=e.child,t=null):(e=c.treeContext,rB=uq(s.nextSibling),rV=t,r$=!0,rq=null,rW=!1,null!==e&&rH(t,e),t=i8(t,o.children),t.flags|=4096);return t}return a?(o7(),s=o.fallback,a=t.mode,u=(c=e.child).sibling,(o=rx(c,{mode:"hidden",children:o.children})).subtreeFlags=0x7e00000&c.subtreeFlags,null!==u?s=rx(u,s):(s=rk(s,a,n,null),s.flags|=2),s.return=t,o.return=t,o.sibling=s,t.child=o,iY(null,o),o=t.child,null===(s=e.child.memoizedState)?s=i5(n):(null!==(a=s.cachePool)?(c=os._currentValue,a=a.parent!==c?{parent:c,pool:c}:a):a=o_(),s={baseLanes:s.baseLanes|n,cachePool:a}),o.memoizedState=s,o.childLanes=i6(e,r,n),t.memoizedState=i4,iY(e.child,o)):(o6(t),e=(n=e.child).sibling,(n=rx(n,{mode:"visible",children:o.children})).return=t,n.sibling=null,null!==e&&(null===(r=t.deletions)?(t.deletions=[e],t.flags|=16):r.push(e)),t.child=n,t.memoizedState=null,n)}function i8(e,t){return(t=i7({mode:"visible",children:t},e.mode)).return=e,e.child=t}function i7(e,t){return(e=ry(22,e,null,t)).lanes=0,e}function le(e,t,n){return oZ(t,e.child,null,n),e=i8(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function lt(e,t,n){e.lanes|=t;var r=e.alternate;null!==r&&(r.lanes|=t),r9(e.return,t,n)}function ln(e){for(var t=null;null!==e;){var n=e.alternate;null!==n&&null===ao(n)&&(t=e),e=e.sibling}return t}function lr(e,t,n,r,o,a){var i=e.memoizedState;null===i?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:o,treeForkCount:a}:(i.isBackwards=t,i.rendering=null,i.renderingStartTime=0,i.last=r,i.tail=n,i.tailMode=o,i.treeForkCount=a)}function lo(e){var t=e.child;for(e.child=null;null!==t;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function la(e,t,n){var r=t.pendingProps,o=r.revealOrder,a=r.tail;r=r.children;var i=at.current;if(128&t.flags)return an(t,i),null;var l=0!=(2&i);if(l?(i=1&i|2,t.flags|=128):i&=1,an(t,i),"backwards"===o&&null!==e?(lo(e),iB(e,t,r,n),lo(e)):iB(e,t,r,n),r=r$?rN:0,!l&&null!==e&&0!=(128&e.flags))e:for(e=t.child;null!==e;){if(13===e.tag)null!==e.memoizedState&&lt(e,n,t);else if(19===e.tag)lt(e,n,t);else if(null!==e.child){e.child.return=e,e=e.child;continue}if(e===t)break;for(;null===e.sibling;){if(null===e.return||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(o){case"backwards":null===(n=ln(t.child))?(o=t.child,t.child=null):(o=n.sibling,n.sibling=null,lo(t)),lr(t,!0,o,null,a,r);break;case"unstable_legacy-backwards":for(n=null,o=t.child,t.child=null;null!==o;){if(null!==(e=o.alternate)&&null===ao(e)){t.child=o;break}e=o.sibling,o.sibling=n,n=o,o=e}lr(t,!0,n,null,a,r);break;case"together":lr(t,!1,null,null,void 0,r);break;case"independent":t.memoizedState=null;break;default:null===(n=ln(t.child))?(o=t.child,t.child=null):(o=n.sibling,n.sibling=null),lr(t,!1,o,n,a,r)}return t.child}function li(e,t,n){if(null!==e&&(t.dependencies=e.dependencies),sA|=t.lanes,0==(n&t.childLanes)){if(null===e)return null;else if(r7(e,t,n,!1),0==(n&t.childLanes))return null}if(null!==e&&t.child!==e.child)throw Error(l(153));if(null!==t.child){for(n=rx(e=t.child,e.pendingProps),t.child=n,n.return=t;null!==e.sibling;)e=e.sibling,(n=n.sibling=rx(e,e.pendingProps)).return=t;n.sibling=null}return t.child}function ll(e,t){return 0!=(e.lanes&t)||!!(null!==(e=e.dependencies)&&oe(e))}function ls(e,t,n){if(null!==e)if(e.memoizedProps!==t.pendingProps)iV=!0;else{if(!ll(e,n)&&0==(128&t.flags))return iV=!1,function(e,t,n){switch(t.tag){case 3:en(t,t.stateNode.containerInfo),r5(t,os,e.memoizedState.cache),rJ();break;case 27:case 5:eo(t);break;case 4:en(t,t.stateNode.containerInfo);break;case 10:r5(t,t.type,t.memoizedProps.value);break;case 31:if(null!==t.memoizedState)return t.flags|=128,o9(t),null;break;case 13:var r=t.memoizedState;if(null!==r){if(null!==r.dehydrated)return o6(t),t.flags|=128,null;if(0!=(n&t.child.childLanes))return i9(e,t,n);return o6(t),null!==(e=li(e,t,n))?e.sibling:null}o6(t);break;case 19:if(128&t.flags)return la(e,t,n);var o=0!=(128&e.flags);if((r=0!=(n&t.childLanes))||(r7(e,t,n,!1),r=0!=(n&t.childLanes)),o){if(r)return la(e,t,n);t.flags|=128}if(null!==(o=t.memoizedState)&&(o.rendering=null,o.tail=null,o.lastEffect=null),an(t,at.current),!r)return null;break;case 22:return t.lanes=0,iK(e,t,n,t.pendingProps);case 24:r5(t,os,e.memoizedState.cache)}return li(e,t,n)}(e,t,n);iV=0!=(131072&e.flags)}else iV=!1,r$&&0!=(1048576&t.flags)&&rZ(t,rN,t.index);switch(t.lanes=0,t.tag){case 16:e:{var r=t.pendingProps;if(e=oE(t.elementType),t.type=e,"function"==typeof e)rb(e)?(r=iL(e,r),t.tag=1,t=i2(null,t,e,r,n)):(t.tag=0,t=i0(null,t,e,r,n));else{if(null!=e){var o=e.$$typeof;if(o===I){t.tag=11,t=i$(null,t,e,r,n);break e}if(o===A){t.tag=14,t=iq(null,t,e,r,n);break e}}throw Error(l(306,t=function e(t){if(null==t)return null;if("function"==typeof t)return t.$$typeof===H?null:t.displayName||t.name||null;if("string"==typeof t)return t;switch(t){case O:return"Fragment";case P:return"Profiler";case C:return"StrictMode";case N:return"Suspense";case L:return"SuspenseList";case R:return"Activity";case Z:return"ViewTransition"}if("object"==typeof t)switch(t.$$typeof){case S:return"Portal";case T:return t.displayName||"Context";case E:return(t._context.displayName||"Context")+".Consumer";case I:var n=t.render;return(t=t.displayName)||(t=""!==(t=n.displayName||n.name||"")?"ForwardRef("+t+")":"ForwardRef"),t;case A:return null!==(n=t.displayName||null)?n:e(t.type)||"Memo";case z:n=t._payload,t=t._init;try{return e(t(n))}catch(e){}}return null}(e)||e,""))}}return t;case 0:return i0(e,t,t.type,t.pendingProps,n);case 1:return o=iL(r=t.type,t.pendingProps),i2(e,t,r,o,n);case 3:e:{if(en(t,t.stateNode.containerInfo),null===e)throw Error(l(387));r=t.pendingProps;var a=t.memoizedState;o=a.element,oV(e,t),oG(t,r,null,n);var i=t.memoizedState;if(r5(t,os,r=i.cache),r!==a.cache&&r8(t,[os],n,!0),oY(),r=i.element,a.isDehydrated)if(a={element:r,isDehydrated:!1,cache:i.cache},t.updateQueue.baseState=a,t.memoizedState=a,256&t.flags){t=i3(e,t,r,n);break e}else if(r!==o){r1(o=rP(Error(l(424)),t)),t=i3(e,t,r,n);break e}else for(rB=uq((e=9===(e=t.stateNode.containerInfo).nodeType?e.body:"HTML"===e.nodeName?e.ownerDocument.body:e).firstChild),rV=t,r$=!0,rq=null,rW=!0,n=oF(t,null,r,n),t.child=n;n;)n.flags=-3&n.flags|4096,n=n.sibling;else{if(rJ(),r===o){t=li(e,t,n);break e}iB(e,t,r,n)}t=t.child}return t;case 26:return iJ(e,t),null===e?(n=u4(t.type,null,t.pendingProps,null))?t.memoizedState=n:r$||(n=t.type,e=t.pendingProps,(r=uc(ee.current).createElement(n))[eW]=t,r[eK]=e,ua(r,n,e),e6(r),t.stateNode=r):t.memoizedState=u4(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return eo(t),null===e&&r$&&(r=t.stateNode=uG(t.type,t.pendingProps,ee.current),rV=t,rW=!0,o=rB,ub(t.type)?(uW=o,rB=uq(r.firstChild)):rB=o),iB(e,t,t.pendingProps.children,n),iJ(e,t),null===e&&(t.flags|=4194304),t.child;case 5:return null===e&&r$&&((o=r=rB)&&(null!==(r=function(e,t,n,r){for(;1===e.nodeType;){if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!r&&("INPUT"!==e.nodeName||"hidden"!==e.type))break}else if(r){if(!e[e0])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if("stylesheet"===(o=e.getAttribute("rel"))&&e.hasAttribute("data-precedence")||o!==n.rel||e.getAttribute("href")!==(null==n.href||""===n.href?null:n.href)||e.getAttribute("crossorigin")!==(null==n.crossOrigin?null:n.crossOrigin)||e.getAttribute("title")!==(null==n.title?null:n.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(((o=e.getAttribute("src"))!==(null==n.src?null:n.src)||e.getAttribute("type")!==(null==n.type?null:n.type)||e.getAttribute("crossorigin")!==(null==n.crossOrigin?null:n.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else{if("input"!==t||"hidden"!==e.type)return e;var o=null==n.name?null:""+n.name;if("hidden"===n.type&&e.getAttribute("name")===o)return e}if(null===(e=uq(e.nextSibling)))break}return null}(r,t.type,t.pendingProps,rW))?(t.stateNode=r,rV=t,rB=uq(r.firstChild),rW=!1,o=!0):o=!1),o||rY(t)),eo(t),o=t.type,a=t.pendingProps,i=null!==e?e.memoizedProps:null,r=a.children,uf(o,a)?r=null:null!==i&&uf(o,i)&&(t.flags|=32),null!==t.memoizedState&&(db._currentValue=o=ay(e,t,aw,null,null,n)),iJ(e,t),iB(e,t,r,n),t.child;case 6:return null===e&&r$&&((e=n=rB)&&(null!==(n=function(e,t,n){if(""===t)return null;for(;3!==e.nodeType;)if((1!==e.nodeType||"INPUT"!==e.nodeName||"hidden"!==e.type)&&!n||null===(e=uq(e.nextSibling)))return null;return e}(n,t.pendingProps,rW))?(t.stateNode=n,rV=t,rB=null,e=!0):e=!1),e||rY(t)),null;case 13:return i9(e,t,n);case 4:return en(t,t.stateNode.containerInfo),r=t.pendingProps,null===e?t.child=oZ(t,null,r,n):iB(e,t,r,n),t.child;case 11:return i$(e,t,t.type,t.pendingProps,n);case 7:return r=t.pendingProps,iJ(e,t),iB(e,t,r,n),t.child;case 8:case 12:return iB(e,t,t.pendingProps.children,n),t.child;case 10:return r=t.pendingProps,r5(t,t.type,r.value),iB(e,t,r.children,n),t.child;case 9:return o=t.type._context,r=t.pendingProps.children,ot(t),r=r(o=on(o)),t.flags|=1,iB(e,t,r,n),t.child;case 14:return iq(e,t,t.type,t.pendingProps,n);case 15:return iW(e,t,t.type,t.pendingProps,n);case 19:return la(e,t,n);case 31:var s=e,c=t,u=n,d=c.pendingProps,f=0!=(128&c.flags);if(c.flags&=-129,null===s){if(r$){if("hidden"===d.mode)return s=iX(c,d),c.lanes=0x20000000,iY(null,s);if(o9(c),(s=rB)?null!==(s=null!==(s=uV(s,rW))&&"&"===s.data?s:null)&&(c.memoizedState={dehydrated:s,treeContext:null!==rz?{id:rR,overflow:rD}:null,retryLane:0x20000000,hydrationErrors:null},(u=rS(s)).return=c,c.child=u,rV=c,rB=null):s=null,null===s)throw rY(c);return c.lanes=0x20000000,null}return iX(c,d)}var p=s.memoizedState;if(null!==p){var h=p.dehydrated;if(o9(c),f)if(256&c.flags)c.flags&=-257,c=iQ(s,c,u);else if(null!==c.memoizedState)c.child=s.child,c.flags|=128,c=null;else throw Error(l(558));else if(iV||r7(s,c,u,!1),f=0!=(u&s.childLanes),iV||f){if(null!==(d=sj)&&0!==(h=eU(d,u))&&h!==p.retryLane)throw p.retryLane=h,rp(s,h),s8(d,s,h),iH;cc(),c=iQ(s,c,u)}else s=p.treeContext,rB=uq(h.nextSibling),rV=c,r$=!0,rq=null,rW=!1,null!==s&&rH(c,s),c=iX(c,d),c.flags|=4096;return c}return(s=rx(s.child,{mode:d.mode,children:d.children})).ref=c.ref,c.child=s,s.return=c,s;case 22:return iK(e,t,n,t.pendingProps);case 24:return ot(t),r=on(os),null===e?(null===(o=ox())&&(o=sj,a=oc(),o.pooledCache=a,a.refCount++,null!==a&&(o.pooledCacheLanes|=n),o=a),t.memoizedState={parent:r,cache:o},oH(t),r5(t,os,o)):(0!=(e.lanes&n)&&(oV(e,t),oG(t,null,null,n),oY()),o=e.memoizedState,a=t.memoizedState,o.parent!==r?(o={parent:r,cache:r},t.memoizedState=o,0===t.lanes&&(t.memoizedState=t.updateQueue.baseState=o),r5(t,os,r)):(r5(t,os,r=a.cache),r!==o.cache&&r8(t,[os],n,!0))),iB(e,t,t.pendingProps.children,n),t.child;case 30:return null!=(r=t.pendingProps).name&&"auto"!==r.name?t.flags|=null===e?0x1202000:0x1200000:r$&&rF(t),null!==e&&e.memoizedProps.name!==r.name?t.flags|=4194816:iJ(e,t),iB(e,t,r.children,n),t.child;case 29:throw t.pendingProps}throw Error(l(156,t.tag))}function lc(e){e.flags|=4}function lu(e,t,n,r,o){var a;if((a=0!=(32&e.mode))&&(a=null===n?ds(t,r):ds(t,r)&&(r.src!==n.src||r.srcSet!==n.srcSet)),a){if(e.flags|=0x1000000,(0x13ffff40&o)===o)if(e.stateNode.complete)e.flags|=8192;else if(ci())e.flags|=8192;else throw oT=oO,oj}else e.flags&=-0x1000001}function ld(e,t){if("stylesheet"!==t.type||0!=(4&t.state.loading))e.flags&=-0x1000001;else if(e.flags|=0x1000000,!dc(t))if(ci())e.flags|=8192;else throw oT=oO,oj}function lf(e,t){null!==t&&(e.flags|=4),16384&e.flags&&(t=22!==e.tag?eR():0x20000000,e.lanes|=t,sM|=t)}function lp(e,t){if(!r$)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,r=null;null!==n;)null!==n.alternate&&(r=n),n=n.sibling;null===r?t||null===e.tail?e.tail=null:e.tail.sibling=null:r.sibling=null;break;default:for(n=null,t=e.tail;null!==t;)null!==t.alternate&&(n=t),t=t.sibling;null===n?e.tail=null:n.sibling=null}}function lh(e){var t=null!==e.alternate&&e.alternate.child===e.child,n=0,r=0;if(t)for(var o=e.child;null!==o;)n|=o.lanes|o.childLanes,r|=0x7e00000&o.subtreeFlags,r|=0x7e00000&o.flags,o.return=e,o=o.sibling;else for(o=e.child;null!==o;)n|=o.lanes|o.childLanes,r|=o.subtreeFlags,r|=o.flags,o.return=e,o=o.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function lm(e,t){switch(rU(t),t.tag){case 3:r6(os),er();break;case 26:case 27:case 5:ea(t);break;case 4:er();break;case 31:null!==t.memoizedState&&ae(t);break;case 13:ae(t);break;case 19:ar(t);break;case 10:r6(t.type);break;case 22:case 23:ae(t),o3(),null!==e&&G(ob);break;case 24:r6(os)}}function lg(e,t){try{var n=t.updateQueue,r=null!==n?n.lastEffect:null;if(null!==r){var o=r.next;n=o;do{if((n.tag&e)===e){r=void 0;var a=n.create;n.inst.destroy=r=a()}n=n.next}while(n!==o)}}catch(e){cO(t,t.return,e)}}function lv(e,t,n){try{var r=t.updateQueue,o=null!==r?r.lastEffect:null;if(null!==o){var a=o.next;r=a;do{if((r.tag&e)===e){var i=r.inst,l=i.destroy;if(void 0!==l){i.destroy=void 0,o=t;try{l()}catch(e){cO(o,n,e)}}}r=r.next}while(r!==a)}}catch(e){cO(t,t.return,e)}}function ly(e){var t=e.updateQueue;if(null!==t){var n=e.stateNode;try{oQ(t,n)}catch(t){cO(e,e.return,t)}}}function lb(e,t,n){n.props=iL(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(n){cO(e,t,n)}}function lx(e,t){try{var n=e.ref;if(null!==n){switch(e.tag){case 26:case 27:case 5:var r=e.stateNode;break;case 30:var o=e.stateNode,a=rr(e.memoizedProps,o);(null===o.ref||o.ref.name!==a)&&(o.ref=uE(a)),r=o.ref;break;case 7:null===e.stateNode&&(e.stateNode=new uT(e)),r=e.stateNode;break;default:r=e.stateNode}"function"==typeof n?e.refCleanup=n(r):n.current=r}}catch(n){cO(e,t,n)}}function lw(e,t){var n=e.ref,r=e.refCleanup;if(null!==n)if("function"==typeof r)try{r()}catch(n){cO(e,t,n)}finally{e.refCleanup=null,null!=(e=e.alternate)&&(e.refCleanup=null)}else if("function"==typeof n)try{n(null)}catch(n){cO(e,t,n)}else n.current=null}function l_(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&r.focus();break;case"img":n.src?r.src=n.src:n.srcSet&&(r.srcset=n.srcSet)}}catch(t){cO(e,e.return,t)}}function lk(e,t,n){try{var r=e.stateNode;(function(e,t,n,r){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var o=null,a=null,i=null,s=null,c=null,u=null,d=null;for(h in n){var f=n[h];if(n.hasOwnProperty(h)&&null!=f)switch(h){case"checked":case"value":break;case"defaultValue":c=f;default:r.hasOwnProperty(h)||ur(e,t,h,null,r,f)}}for(var p in r){var h=r[p];if(f=n[p],r.hasOwnProperty(p)&&(null!=h||null!=f))switch(p){case"type":h!==f&&(to=!0),a=h;break;case"name":h!==f&&(to=!0),o=h;break;case"checked":h!==f&&(to=!0),u=h;break;case"defaultChecked":h!==f&&(to=!0),d=h;break;case"value":h!==f&&(to=!0),i=h;break;case"defaultValue":h!==f&&(to=!0),s=h;break;case"children":case"dangerouslySetInnerHTML":if(null!=h)throw Error(l(137,t));break;default:h!==f&&ur(e,t,p,h,r,f)}}tg(e,i,s,c,u,d,a,o);return;case"select":for(a in h=i=s=p=null,n)if(c=n[a],n.hasOwnProperty(a)&&null!=c)switch(a){case"value":break;case"multiple":h=c;default:r.hasOwnProperty(a)||ur(e,t,a,null,r,c)}for(o in r)if(a=r[o],c=n[o],r.hasOwnProperty(o)&&(null!=a||null!=c))switch(o){case"value":a!==c&&(to=!0),p=a;break;case"defaultValue":a!==c&&(to=!0),s=a;break;case"multiple":a!==c&&(to=!0),i=a;default:a!==c&&ur(e,t,o,a,r,c)}t=s,n=i,r=h,null!=p?tb(e,!!n,p,!1):!!r!=!!n&&(null!=t?tb(e,!!n,t,!0):tb(e,!!n,n?[]:"",!1));return;case"textarea":for(s in h=p=null,n)if(o=n[s],n.hasOwnProperty(s)&&null!=o&&!r.hasOwnProperty(s))switch(s){case"value":case"children":break;default:ur(e,t,s,null,r,o)}for(i in r)if(o=r[i],a=n[i],r.hasOwnProperty(i)&&(null!=o||null!=a))switch(i){case"value":o!==a&&(to=!0),p=o;break;case"defaultValue":o!==a&&(to=!0),h=o;break;case"children":break;case"dangerouslySetInnerHTML":if(null!=o)throw Error(l(91));break;default:o!==a&&ur(e,t,i,o,r,a)}tx(e,p,h);return;case"option":for(var m in n)p=n[m],n.hasOwnProperty(m)&&null!=p&&!r.hasOwnProperty(m)&&("selected"===m?e.selected=!1:ur(e,t,m,null,r,p));for(c in r)p=r[c],h=n[c],r.hasOwnProperty(c)&&p!==h&&(null!=p||null!=h)&&("selected"===c?(p!==h&&(to=!0),e.selected=p&&"function"!=typeof p&&"symbol"!=typeof p):ur(e,t,c,p,r,h));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var g in n)p=n[g],n.hasOwnProperty(g)&&null!=p&&!r.hasOwnProperty(g)&&ur(e,t,g,null,r,p);for(u in r)if(p=r[u],h=n[u],r.hasOwnProperty(u)&&p!==h&&(null!=p||null!=h))switch(u){case"children":case"dangerouslySetInnerHTML":if(null!=p)throw Error(l(137,t));break;default:ur(e,t,u,p,r,h)}return;default:if(tO(t)){for(var v in n)p=n[v],n.hasOwnProperty(v)&&void 0!==p&&!r.hasOwnProperty(v)&&uo(e,t,v,void 0,r,p);for(d in r)p=r[d],h=n[d],r.hasOwnProperty(d)&&p!==h&&(void 0!==p||void 0!==h)&&uo(e,t,d,p,r,h);return}}for(var y in n)p=n[y],n.hasOwnProperty(y)&&null!=p&&!r.hasOwnProperty(y)&&ur(e,t,y,null,r,p);for(f in r)p=r[f],h=n[f],r.hasOwnProperty(f)&&p!==h&&(null!=p||null!=h)&&ur(e,t,f,p,r,h)})(r,e.type,n,t),r[eK]=t}catch(t){cO(e,e.return,t)}}function lj(e,t){if(5===e.tag&&null===e.alternate&&null!==t)for(var n=0;n<t.length;n++)uU(e.stateNode,t[n])}function lS(e){for(var t=e.return;null!==t;){if(lC(t)){var n=e.stateNode,r=t.stateNode._eventListeners;if(null!==r)for(var o=0;o<r.length;o++){var a=r[o];n.removeEventListener(a.type,a.listener,a.optionsOrUseCapture)}}if(lO(t))break;t=t.return}}function lO(e){return 5===e.tag||3===e.tag||26===e.tag||27===e.tag&&ub(e.type)||4===e.tag}function lC(e){return e&&7===e.tag&&null!==e.stateNode}function lP(e){e:for(;;){for(;null===e.sibling;){if(null===e.return||lO(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;5!==e.tag&&6!==e.tag&&18!==e.tag;){if(27===e.tag&&ub(e.type)||2&e.flags||null===e.child||4===e.tag)continue e;e.child.return=e,e=e.child}if(!(2&e.flags))return e.stateNode}}function lE(e,t,n,r){var o=e.tag;if(5===o||6===o)o=e.stateNode,t?n.insertBefore(o,t):n.appendChild(o),lj(e,r),to=!0;else if(4!==o&&(27===o&&ub(e.type)&&(n=e.stateNode),null!==(e=e.child)))for(lE(e,t,n,r),e=e.sibling;null!==e;)lE(e,t,n,r),e=e.sibling}function lT(e){var t=e.stateNode,n=e.memoizedProps;try{for(var r=e.type,o=t.attributes;o.length;)t.removeAttributeNode(o[0]);ua(t,r,n),t[eW]=e,t[eK]=n}catch(t){cO(e,e.return,t)}}var lI=!1,lN=null;function lL(e){(30===e.tag||0!=(0x2000000&e.subtreeFlags))&&(lI=!0)}var lA=null;function lz(){var e=lA;return lA=null,e}var lR=0;function lD(e,t,n,r,o){return lR=0,function e(t,n,r,o,a){for(var i=!1;null!==t;){if(5===t.tag){var l=t.stateNode;if(null!==o){var s=uS(l);o.push(s),s.view&&(i=!0)}else i||uS(l).view&&(i=!0);lI=!0,u_(l,0===lR?n:n+"_"+lR,r),lR++}else(22!==t.tag||null===t.memoizedState)&&(30===t.tag&&a||e(t.child,n,r,o,a)&&(i=!0));t=t.sibling}return i}(e.child,t,n,r,o)}function lM(e,t){for(;null!==e;)5===e.tag?uk(e.stateNode,e.memoizedProps):(22!==e.tag||null===e.memoizedState)&&(30===e.tag&&t||lM(e.child,t)),e=e.sibling}function lZ(e){if(0!=(0x1200000&e.subtreeFlags))for(e=e.child;null!==e;){if((22!==e.tag||null===e.memoizedState)&&(lZ(e),30===e.tag&&0!=(0x1200000&e.flags)&&e.stateNode.paired)){var t=e.memoizedProps;if(null==t.name||"auto"===t.name)throw Error(l(544));var n=t.name;"none"!==(t=ra(t.default,t.share))&&(lD(e,n,t,null,!1)||lM(e.child,!1))}e=e.sibling}}function lF(e,t){if(30===e.tag){var n=e.stateNode,r=e.memoizedProps,o=rr(r,n),a=ra(r.default,n.paired?r.share:r.enter);"none"!==a?lD(e,o,a,null,!1)?(lZ(e),n.paired||t||s9(e,r.onEnter)):lM(e.child,!1):lZ(e)}else if(0!=(0x2000000&e.subtreeFlags))for(e=e.child;null!==e;)lF(e,t),e=e.sibling;else lZ(e)}function lU(e){if(null!==lN&&0!==lN.size){var t=lN;if(0!=(0x1200000&e.subtreeFlags))for(e=e.child;null!==e;){if(22!==e.tag||null===e.memoizedState){if(30===e.tag&&0!=(0x1200000&e.flags)){var n=e.memoizedProps,r=n.name;if(null!=r&&"auto"!==r){var o=t.get(r);if(void 0!==o){var a=ra(n.default,n.share);if("none"!==a&&(lD(e,r,a,null,!1)?(o.paired=a=e.stateNode,a.paired=o,s9(e,n.onShare)):lM(e.child,!1)),t.delete(r),0===t.size)break}}}lU(e)}e=e.sibling}}}function lH(e){if(30===e.tag){var t=e.memoizedProps,n=rr(t,e.stateNode),r=null!==lN?lN.get(n):void 0,o=ra(t.default,void 0!==r?t.share:t.exit);"none"!==o&&(lD(e,n,o,null,!1)?void 0!==r?(r.paired=o=e.stateNode,o.paired=r,lN.delete(n),s9(e,t.onShare)):s9(e,t.onExit):lM(e.child,!1)),null!==lN&&lU(e)}else if(0!=(0x2000000&e.subtreeFlags))for(e=e.child;null!==e;)lH(e),e=e.sibling;else null!==lN&&lU(e)}function lV(e){if(0!=(0x1200000&e.subtreeFlags))for(e=e.child;null!==e;){if(22!==e.tag||null===e.memoizedState){if(30===e.tag&&0!=(0x1200000&e.flags)){var t=e.stateNode;null!==t.paired&&(t.paired=null,lM(e.child,!1))}lV(e)}e=e.sibling}}function lB(e){if(30===e.tag)e.stateNode.paired=null,lM(e.child,!1),lV(e);else if(0!=(0x2000000&e.subtreeFlags))for(e=e.child;null!==e;)lB(e),e=e.sibling;else lV(e)}function l$(e,t,n,r,o,a,i){for(var l=!1;null!==t;){if(5===t.tag){var s=t.stateNode;if(null!==a&&lR<a.length){var c,u=a[lR],d=uS(s);if((u.view||d.view)&&(l=!0),c=0==(4&e.flags))if(d.clip)c=!0;else{c=u.rect;var f=d.rect;c=c.y!==f.y||c.x!==f.x||c.height!==f.height||c.width!==f.width}c&&(e.flags|=4),d.abs?d=!u.abs:(u=u.rect,d=d.rect,d=u.height!==d.height||u.width!==d.width),d&&(e.flags|=32)}else e.flags|=32;0!=(4&e.flags)&&u_(s,0===lR?n:n+"_"+lR,o),l&&0!=(4&e.flags)||(null===lA&&(lA=[]),lA.push(s,r,t.memoizedProps)),lR++}else(22!==t.tag||null===t.memoizedState)&&(30===t.tag&&i?e.flags|=32&t.flags:l$(e,t.child,n,r,o,a,i)&&(l=!0));t=t.sibling}return l}var lq=!1,lW=!1,lK=!1,lY=!1,lG="function"==typeof WeakSet?WeakSet:Set,lX=null,lQ=!1,lJ=!1,l0=!1,l1=!1;function l2(e){for(;null!==lX;){var t=lX,n=e,r=t.alternate,o=t.flags;switch(t.tag){case 0:case 11:case 15:if(0!=(4&o)&&null!==(r=null!==(r=t.updateQueue)?r.events:null))for(n=0;n<r.length;n++)(o=r[n]).ref.impl=o.nextImpl;break;case 1:if(0!=(1024&o)&&null!==r){n=void 0,o=r.memoizedProps,r=r.memoizedState;var a=t.stateNode;try{var i=iL(t.type,o);n=a.getSnapshotBeforeUpdate(i,r),a.__reactInternalSnapshotBeforeUpdate=n}catch(e){cO(t,t.return,e)}}break;case 3:if(0!=(1024&o)){if(9===(n=(r=t.stateNode.containerInfo).nodeType))uH(r);else if(1===n)switch(r.nodeName){case"HEAD":case"HTML":case"BODY":uH(r);break;default:r.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&null!==r&&(n=rr(r.memoizedProps,r.stateNode),"none"!==(o=ra((o=t.memoizedProps).default,o.update))&&lD(r,n,o,r.memoizedState=[],!0));break;default:if(0!=(1024&o))throw Error(l(163))}if(null!==(r=t.sibling)){r.return=t.return,lX=r;break}lX=t.return}}function l3(e,t,n){var r=n.flags;switch(n.tag){case 0:case 11:case 15:ss(e,n),4&r&&lg(5,n);break;case 1:if(ss(e,n),4&r)if(e=n.stateNode,null===t)try{e.componentDidMount()}catch(e){cO(n,n.return,e)}else{var o=iL(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(o,t,e.__reactInternalSnapshotBeforeUpdate)}catch(e){cO(n,n.return,e)}}64&r&&ly(n),512&r&&lx(n,n.return);break;case 3:if(ss(e,n),64&r&&null!==(e=n.updateQueue)){if(t=null,null!==n.child)switch(n.child.tag){case 27:case 5:case 1:t=n.child.stateNode}try{oQ(e,t)}catch(e){cO(n,n.return,e)}}break;case 27:null===t&&4&r&&lT(n);case 26:case 5:ss(e,n),null===t&&4&r&&l_(n),512&r&&lx(n,n.return);break;case 12:ss(e,n);break;case 31:ss(e,n),4&r&&l7(e,n);break;case 13:ss(e,n),4&r&&se(e,n),64&r&&null!==(e=n.memoizedState)&&null!==(e=e.dehydrated)&&function(e,t){var n=e.ownerDocument;if("$~"===e.data)e._reactRetry=t;else if("$?"!==e.data||"loading"!==n.readyState)t();else{var r=function(){t(),n.removeEventListener("DOMContentLoaded",r)};n.addEventListener("DOMContentLoaded",r),e._reactRetry=r}}(e,n=cT.bind(null,n));break;case 22:if(!(r=null!==n.memoizedState||lq)){t=null!==t&&null!==t.memoizedState||lW,o=lq;var a=lW;lq=r,(lW=t)&&!a?function e(t,n,r){for(r=r&&0!=(8772&n.subtreeFlags),n=n.child;null!==n;){var o=n.alternate,a=t,i=n,l=i.flags;switch(i.tag){case 0:case 11:case 15:e(a,i,r),lg(4,i);break;case 1:if(e(a,i,r),"function"==typeof(a=(o=i).stateNode).componentDidMount)try{a.componentDidMount()}catch(e){cO(o,o.return,e)}if(null!==(a=(o=i).updateQueue)){var s=o.stateNode;try{var c=a.shared.hiddenCallbacks;if(null!==c)for(a.shared.hiddenCallbacks=null,a=0;a<c.length;a++)oX(c[a],s)}catch(e){cO(o,o.return,e)}}r&&64&l&&ly(i),lx(i,i.return);break;case 27:lT(i);case 26:case 5:if(5===i.tag){s=i;for(var u=s.return;null!==u&&(lC(u)&&uU(s.stateNode,u.stateNode),!lO(u));)u=u.return}e(a,i,r),r&&null===o&&4&l&&l_(i),lx(i,i.return);break;case 12:e(a,i,r);break;case 31:e(a,i,r),r&&4&l&&l7(a,i);break;case 13:e(a,i,r),r&&4&l&&se(a,i);break;case 22:null===i.memoizedState&&e(a,i,r),lx(i,i.return);break;case 30:e(a,i,r),lx(i,i.return);break;case 7:lx(i,i.return);default:e(a,i,r)}n=n.sibling}}(e,n,0!=(8772&n.subtreeFlags)):ss(e,n),lq=o,lW=a}break;case 30:ss(e,n),512&r&&lx(n,n.return);break;case 7:512&r&&lx(n,n.return);default:ss(e,n)}}function l4(e,t){for(e=e.child;null!==e;)(function e(t,n){switch(t.tag){case 5:case 26:try{var r=t.stateNode;if(n){var o=r.style;"function"==typeof o.setProperty?o.setProperty("display","none","important"):o.display="none"}else{var a=t.stateNode,i=t.memoizedProps.style,l=null!=i&&i.hasOwnProperty("display")?i.display:null;a.style.display=null==l||"boolean"==typeof l?"":(""+l).trim()}}catch(e){cO(t,t.return,e)}!function t(n,r){if(0x4000000&n.subtreeFlags)for(n=n.child;null!==n;){e:{var o=n;switch(o.tag){case 4:e(o,r);break e;case 22:null===o.memoizedState&&t(o,r);break e;default:t(o,r)}}n=n.sibling}}(t,n);break;case 6:try{t.stateNode.nodeValue=n?"":t.memoizedProps,to=!0}catch(e){cO(t,t.return,e)}break;case 18:try{var s=t.stateNode;n?uw(s,!0):uw(t.stateNode,!1)}catch(e){cO(t,t.return,e)}break;case 22:case 23:null===t.memoizedState&&l4(t,n);break;default:l4(t,n)}})(e,t),e=e.sibling}var l5=null,l6=!1;function l9(e,t,n){for(n=n.child;null!==n;)l8(e,t,n),n=n.sibling}function l8(e,t,n){if(eS&&"function"==typeof eS.onCommitFiberUnmount)try{eS.onCommitFiberUnmount(ej,n)}catch(e){}switch(n.tag){case 26:lW||lw(n,t),l9(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&(n=n.stateNode).parentNode.removeChild(n);break;case 27:lW||lw(n,t);var r=l5,o=l6;ub(n.type)&&(l5=n.stateNode,l6=!1),l9(e,t,n),uX(n.stateNode),l5=r,l6=o;break;case 5:lW||lw(n,t),5===n.tag&&lS(n);case 6:if(r=l5,o=l6,l5=null,l9(e,t,n),l5=r,l6=o,null!==l5)if(l6)try{(9===l5.nodeType?l5.body:"HTML"===l5.nodeName?l5.ownerDocument.body:l5).removeChild(n.stateNode),to=!0}catch(e){cO(n,t,e)}else try{l5.removeChild(n.stateNode),to=!0}catch(e){cO(n,t,e)}break;case 18:null!==l5&&(l6?(ux(9===(e=l5).nodeType?e.body:"HTML"===e.nodeName?e.ownerDocument.body:e,n.stateNode),dX(e)):ux(l5,n.stateNode));break;case 4:r=l5,o=l6,l5=n.stateNode.containerInfo,l6=!0,l9(e,t,n),l5=r,l6=o;break;case 0:case 11:case 14:case 15:lv(2,n,t),lW||lv(4,n,t),l9(e,t,n);break;case 1:lW||(lw(n,t),"function"==typeof(r=n.stateNode).componentWillUnmount&&lb(n,t,r)),l9(e,t,n);break;case 21:default:l9(e,t,n);break;case 22:lW=(r=lW)||null!==n.memoizedState,l9(e,t,n),lW=r;break;case 30:lw(n,t),l9(e,t,n);break;case 7:lW||lw(n,t),l9(e,t,n)}}function l7(e,t){if(null===t.memoizedState&&null!==(e=t.alternate)&&null!==(e=e.memoizedState)){e=e.dehydrated;try{dX(e)}catch(e){cO(t,t.return,e)}}}function se(e,t){if(null===t.memoizedState&&null!==(e=t.alternate)&&null!==(e=e.memoizedState)&&null!==(e=e.dehydrated))try{dX(e)}catch(e){cO(t,t.return,e)}}function st(e,t){var n=function(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return null===t&&(t=e.stateNode=new lG),t;case 22:return null===(t=(e=e.stateNode)._retryCache)&&(t=e._retryCache=new lG),t;default:throw Error(l(435,e.tag))}}(e);t.forEach(function(t){if(!n.has(t)){n.add(t);var r=cI.bind(null,e,t);t.then(r,r)}})}function sn(e,t,n){var r=t.deletions;if(null!==r)for(var o=0;o<r.length;o++){var a=r[o],i=e,s=t,c=s;e:for(;null!==c;){switch(c.tag){case 27:if(ub(c.type)){l5=c.stateNode,l6=!1;break e}break;case 5:l5=c.stateNode,l6=!1;break e;case 3:case 4:l5=c.stateNode.containerInfo,l6=!0;break e}c=c.return}if(null===l5)throw Error(l(160));l8(i,s,a),l5=null,l6=!1,null!==(i=a.alternate)&&(i.return=null),a.return=null}if(13886&t.subtreeFlags)for(t=t.child;null!==t;)so(t,e,n),t=t.sibling}var sr=null;function so(e,t,n){var r=e.alternate,o=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:sn(t,e,n),sa(e),4&o&&(lv(3,e,e.return),lg(3,e),lv(5,e,e.return));break;case 1:sn(t,e,n),sa(e),512&o&&(lW||null===r||lw(r,r.return)),64&o&&lq&&null!==(e=e.updateQueue)&&null!==(r=e.callbacks)&&(t=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=null===t?r:t.concat(r));break;case 26:var a=sr;if(sn(t,e,n),sa(e),512&o&&(lW||null===r||lw(r,r.return)),4&o)if(n=null!==r?r.memoizedState:null,t=e.memoizedState,null===r)if(null===t)if(null===e.stateNode){e:{r=e.type,t=e.memoizedProps,n=a.ownerDocument||a;t:switch(r){case"title":(!(o=n.getElementsByTagName("title")[0])||o[e0]||o[eW]||"http://www.w3.org/2000/svg"===o.namespaceURI||o.hasAttribute("itemprop"))&&(o=n.createElement(r),n.head.insertBefore(o,n.querySelector("head > title"))),ua(o,r,t),o[eW]=e,e6(o),r=o;break e;case"link":if(a=di("link","href",n).get(r+(t.href||""))){for(var i=0;i<a.length;i++)if((o=a[i]).getAttribute("href")===(null==t.href||""===t.href?null:t.href)&&o.getAttribute("rel")===(null==t.rel?null:t.rel)&&o.getAttribute("title")===(null==t.title?null:t.title)&&o.getAttribute("crossorigin")===(null==t.crossOrigin?null:t.crossOrigin)){a.splice(i,1);break t}}ua(o=n.createElement(r),r,t),n.head.appendChild(o);break;case"meta":if(a=di("meta","content",n).get(r+(t.content||""))){for(i=0;i<a.length;i++)if((o=a[i]).getAttribute("content")===(null==t.content?null:""+t.content)&&o.getAttribute("name")===(null==t.name?null:t.name)&&o.getAttribute("property")===(null==t.property?null:t.property)&&o.getAttribute("http-equiv")===(null==t.httpEquiv?null:t.httpEquiv)&&o.getAttribute("charset")===(null==t.charSet?null:t.charSet)){a.splice(i,1);break t}}ua(o=n.createElement(r),r,t),n.head.appendChild(o);break;default:throw Error(l(468,r))}o[eW]=e,e6(o),r=o}e.stateNode=r}else dl(a,e.type,e.stateNode);else e.stateNode=de(a,t,e.memoizedProps);else n!==t?(null===n?null!==r.stateNode&&(r=r.stateNode).parentNode.removeChild(r):n.count--,null===t?dl(a,e.type,e.stateNode):de(a,t,e.memoizedProps)):null===t&&null!==e.stateNode&&lk(e,e.memoizedProps,r.memoizedProps);break;case 27:sn(t,e,n),sa(e),512&o&&(lW||null===r||lw(r,r.return)),null!==r&&4&o&&lk(e,e.memoizedProps,r.memoizedProps);break;case 5:if(a=lK,lK=!1,sn(t,e,n),lK=a,sa(e),512&o&&(lW||null===r||lw(r,r.return)),32&e.flags){t=e.stateNode;try{t_(t,""),to=!0}catch(t){cO(e,e.return,t)}}4&o&&null!=e.stateNode&&(t=e.memoizedProps,lk(e,t,null!==r?r.memoizedProps:t)),1024&o&&(lY=!0);break;case 6:if(sn(t,e,n),sa(e),4&o){if(null===e.stateNode)throw Error(l(162));r=e.memoizedProps,t=e.stateNode;try{t.nodeValue=r,to=!0}catch(t){cO(e,e.return,t)}}break;case 3:if(to=!1,da=null,a=sr,sr=u0(t.containerInfo),sn(t,e,n),sr=a,sa(e),4&o&&null!==r&&r.memoizedState.isDehydrated)try{dX(t.containerInfo)}catch(t){cO(e,e.return,t)}lY&&(lY=!1,function e(t){if(1024&t.subtreeFlags)for(t=t.child;null!==t;){var n=t;e(n),5===n.tag&&1024&n.flags&&n.stateNode.reset(),t=t.sibling}}(e)),to=!1;break;case 4:r=lK,lK=lq,o=ta(),a=sr,sr=u0(e.stateNode.containerInfo),sn(t,e,n),sa(e),sr=a,to&&lJ&&(l0=!0),to=o,lK=r;break;case 12:sn(t,e,n),sa(e);break;case 31:case 19:sn(t,e,n),sa(e),4&o&&null!==(r=e.updateQueue)&&(e.updateQueue=null,st(e,r));break;case 13:sn(t,e,n),sa(e),8192&e.child.flags&&null!==e.memoizedState!=(null!==r&&null!==r.memoizedState)&&(sH=em()),4&o&&null!==(r=e.updateQueue)&&(e.updateQueue=null,st(e,r));break;case 22:a=null!==e.memoizedState,i=null!==r&&null!==r.memoizedState;var s=lq,c=lW,u=lK;lq=s||a,lK=u||a,lW=c||i,sn(t,e,n),lW=c,lK=u,lq=s,sa(e),8192&o&&((t=e.stateNode)._visibility=a?-2&t._visibility:1|t._visibility,a&&(null===r||i||lq||lW||function e(t){for(t=t.child;null!==t;){var n=t;switch(n.tag){case 0:case 11:case 14:case 15:lv(4,n,n.return),e(n);break;case 1:lw(n,n.return);var r=n.stateNode;"function"==typeof r.componentWillUnmount&&lb(n,n.return,r),e(n);break;case 27:uX(n.stateNode);case 26:case 5:lw(n,n.return),5===n.tag&&lS(n),e(n);break;case 22:null===n.memoizedState&&e(n);break;case 30:lw(n,n.return),e(n);break;case 7:lw(n,n.return);default:e(n)}t=t.sibling}}(e)),!a&&lK||l4(e,a)),4&o&&null!==(r=e.updateQueue)&&null!==(t=r.retryQueue)&&(r.retryQueue=null,st(e,t));break;case 30:512&o&&(lW||null===r||lw(r,r.return)),o=ta(),a=lJ,i=(0x13ffff00&n)===n,s=e.memoizedProps,lJ=i&&"none"!==ra(s.default,s.update),sn(t,e,n),sa(e),i&&null!==r&&to&&(e.flags|=4),lJ=a,to=o;break;case 21:break;case 7:r&&null!==r.stateNode&&(r.stateNode._fragmentFiber=e);default:sn(t,e,n),sa(e)}}function sa(e){var t=e.flags;if(2&t){try{for(var n,r=null,o=e.return;null!==o;){if(lC(o)){var a=o.stateNode;null===r?r=[a]:r.push(a)}if(lO(o)){n=o;break}o=o.return}if(null==n)throw Error(l(160));switch(n.tag){case 27:var i=n.stateNode,s=lP(e);lE(e,s,i,r);break;case 5:var c=n.stateNode;32&n.flags&&(t_(c,""),n.flags&=-33);var u=lP(e);lE(e,u,c,r);break;case 3:case 4:var d=n.stateNode.containerInfo,f=lP(e);!function e(t,n,r,o){var a=t.tag;if(5===a||6===a)a=t.stateNode,n?(9===r.nodeType?r.body:"HTML"===r.nodeName?r.ownerDocument.body:r).insertBefore(a,n):((n=9===r.nodeType?r.body:"HTML"===r.nodeName?r.ownerDocument.body:r).appendChild(a),null!=(r=r._reactRootContainer)||null!==n.onclick||(n.onclick=tT)),lj(t,o),to=!0;else if(4!==a&&(27===a&&ub(t.type)&&(r=t.stateNode,n=null),null!==(t=t.child)))for(e(t,n,r,o),t=t.sibling;null!==t;)e(t,n,r,o),t=t.sibling}(e,f,d,r);break;default:throw Error(l(161))}}catch(t){cO(e,e.return,t)}e.flags&=-3}4096&t&&(e.flags&=-4097)}function si(e,t){if(9270&t.subtreeFlags)for(t=t.child;null!==t;)sl(t,e),t=t.sibling;else!function e(t,n){for(t=t.child;null!==t;){if(30===t.tag){var r=t.memoizedProps,o=t.stateNode,a=rr(r,o),i=ra(r.default,r.update);if(n)var l=null===(o=o.clones)?null:o.map(uO);else l=t.memoizedState,t.memoizedState=null;o=t;var s=t.child;lR=0,a=l$(o,s,a,a,i,l,!1),0!=(4&t.flags)&&a&&(n||s9(t,r.onUpdate))}else 0!=(0x2000000&t.subtreeFlags)&&e(t,n);t=t.sibling}}(t,!1)}function sl(e,t){var n=e.alternate;if(null===n)lF(e,!1);else switch(e.tag){case 3:if(l1=lQ=!1,lz(),si(t,e),!lQ&&!l0){if(null!==(e=lA))for(var r=0;r<e.length;r+=3){n=e[r];var o=e[r+1];uk(n,e[r+2]),null!==(n=n.ownerDocument.documentElement)&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+o+")"})}null!==(e=9===(e=t.containerInfo).nodeType?e.documentElement:e.ownerDocument.documentElement)&&""===e.style.viewTransitionName&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),l1=!0}lA=null;break;case 5:default:si(t,e);break;case 4:r=lQ,lQ=!1,si(t,e),lQ&&(l0=!0),lQ=r;break;case 22:null===e.memoizedState&&(null!==n.memoizedState?lF(e,!1):si(t,e));break;case 30:r=lQ,o=lz(),lQ=!1,si(t,e),lQ&&(e.flags|=4);var a=e.memoizedProps,i=e.stateNode;t=rr(a,i),i=rr(n.memoizedProps,i);var l=ra(a.default,a.update);"none"===l?t=!1:(a=n.memoizedState,n.memoizedState=null,n=e.child,lR=0,t=l$(e,n,t,i,l,a,!0),lR!==(null===a?0:a.length)&&(e.flags|=32)),0!=(4&e.flags)&&t?(s9(e,e.memoizedProps.onUpdate),lA=o):null!==o&&(o.push.apply(o,lA),lA=o),lQ=0!=(32&e.flags)||r}}function ss(e,t){if(8772&t.subtreeFlags)for(t=t.child;null!==t;)l3(e,t.alternate,t),t=t.sibling}function sc(e,t){var n=null;null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(n=e.memoizedState.cachePool.pool),e=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(e=t.memoizedState.cachePool.pool),e!==n&&(null!=e&&e.refCount++,null!=n&&ou(n))}function su(e,t){e=null,null!==t.alternate&&(e=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==e&&(t.refCount++,null!=e&&ou(e))}function sd(e,t,n,r){var o=(0x13ffff00&n)===n;if(t.subtreeFlags&(o?10262:10256))for(t=t.child;null!==t;)sf(e,t,n,r),t=t.sibling;else o&&function e(t){for(t=t.child;null!==t;)30===t.tag?lM(t.child,!1):0!=(0x2000000&t.subtreeFlags)&&e(t),t=t.sibling}(t)}function sf(e,t,n,r){var o=(0x13ffff00&n)===n;o&&null===t.alternate&&null!==t.return&&null!==t.return.alternate&&lB(t);var a=t.flags;switch(t.tag){case 0:case 11:case 15:sd(e,t,n,r),2048&a&&lg(9,t);break;case 1:case 31:case 13:default:sd(e,t,n,r);break;case 3:sd(e,t,n,r),o&&l1&&("root"===(e=9===(e=e.containerInfo).nodeType?e.body:"HTML"===e.nodeName?e.ownerDocument.body:e).style.viewTransitionName&&(e.style.viewTransitionName=""),null!==(e=e.ownerDocument.documentElement)&&"none"===e.style.viewTransitionName&&(e.style.viewTransitionName="")),2048&a&&(a=null,null!==t.alternate&&(a=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==a&&(t.refCount++,null!=a&&ou(a)));break;case 12:if(2048&a){sd(e,t,n,r),a=t.stateNode;try{var i=t.memoizedProps,l=i.id,s=i.onPostCommit;"function"==typeof s&&s(l,null===t.alternate?"mount":"update",a.passiveEffectDuration,-0)}catch(e){cO(t,t.return,e)}}else sd(e,t,n,r);break;case 23:break;case 22:i=t.stateNode,l=t.alternate,null!==t.memoizedState?(o&&null!==l&&null===l.memoizedState&&lB(l),2&i._visibility?sd(e,t,n,r):sp(e,t)):(o&&null!==l&&null!==l.memoizedState&&lB(t),2&i._visibility?sd(e,t,n,r):(i._visibility|=2,function e(t,n,r,o,a){for(a=a&&0!=(10256&n.subtreeFlags),n=n.child;null!==n;){var i=n,l=i.flags;switch(i.tag){case 0:case 11:case 15:e(t,i,r,o,a),lg(8,i);break;case 23:break;case 22:var s=i.stateNode;null!==i.memoizedState?2&s._visibility?e(t,i,r,o,a):sp(t,i):(s._visibility|=2,e(t,i,r,o,a)),a&&2048&l&&sc(i.alternate,i);break;case 24:e(t,i,r,o,a),a&&2048&l&&su(i.alternate,i);break;default:e(t,i,r,o,a)}n=n.sibling}}(e,t,n,r,0!=(10256&t.subtreeFlags)))),2048&a&&sc(l,t);break;case 24:sd(e,t,n,r),2048&a&&su(t.alternate,t);break;case 30:o&&null!==(a=t.alternate)&&(lM(a.child,!0),lM(t.child,!0)),sd(e,t,n,r)}}function sp(e,t){if(10256&t.subtreeFlags)for(t=t.child;null!==t;){var n=t,r=n.flags;switch(n.tag){case 22:sp(e,n),2048&r&&sc(n.alternate,n);break;case 24:sp(e,n),2048&r&&su(n.alternate,n);break;default:sp(e,n)}t=t.sibling}}var sh=8192;function sm(e,t,n){if(e.subtreeFlags&sh)for(e=e.child;null!==e;)sg(e,t,n),e=e.sibling}function sg(e,t,n){switch(e.tag){case 26:sm(e,t,n),e.flags&sh&&(null!==e.memoizedState?function(e,t,n,r){if("stylesheet"===n.type&&("string"!=typeof r.media||!1!==matchMedia(r.media).matches)&&0==(4&n.state.loading)){if(null===n.instance){var o=u5(r.href),a=t.querySelector(u6(o));if(a){null!==(t=a._p)&&"object"==typeof t&&"function"==typeof t.then&&(e.count++,e=dh.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=a,e6(a);return}a=t.ownerDocument||t,r=u9(r),(o=uQ.get(o))&&dn(r,o),e6(a=a.createElement("link"));var i=a;i._p=new Promise(function(e,t){i.onload=e,i.onerror=t}),ua(a,"link",r),n.instance=a}null===e.stylesheets&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&0==(3&n.state.loading)&&(e.count++,n=dh.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}(n,sr,e.memoizedState,e.memoizedProps):(e=e.stateNode,(0x13ffff40&t)===t&&dd(n,e)));break;case 5:sm(e,t,n),e.flags&sh&&(e=e.stateNode,(0x13ffff40&t)===t&&dd(n,e));break;case 3:case 4:var r=sr;sr=u0(e.stateNode.containerInfo),sm(e,t,n),sr=r;break;case 22:null===e.memoizedState&&(null!==(r=e.alternate)&&null!==r.memoizedState?(r=sh,sh=0x1000000,sm(e,t,n),sh=r):sm(e,t,n));break;case 30:if(0!=(e.flags&sh)&&null!=(r=e.memoizedProps.name)&&"auto"!==r){var o=e.stateNode;o.paired=null,null===lN&&(lN=new Map),lN.set(r,o)}sm(e,t,n);break;default:sm(e,t,n)}}function sv(e){var t=e.alternate;if(null!==t&&null!==(e=t.child)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(null!==e)}}function sy(e){var t=e.deletions;if(0!=(16&e.flags)){if(null!==t)for(var n=0;n<t.length;n++){var r=t[n];lX=r,sx(r,e)}sv(e)}if(10256&e.subtreeFlags)for(e=e.child;null!==e;)sb(e),e=e.sibling}function sb(e){switch(e.tag){case 0:case 11:case 15:sy(e),2048&e.flags&&lv(9,e,e.return);break;case 3:case 12:default:sy(e);break;case 22:var t=e.stateNode;null!==e.memoizedState&&2&t._visibility&&(null===e.return||13!==e.return.tag)?(t._visibility&=-3,function e(t){var n=t.deletions;if(0!=(16&t.flags)){if(null!==n)for(var r=0;r<n.length;r++){var o=n[r];lX=o,sx(o,t)}sv(t)}for(t=t.child;null!==t;){switch((n=t).tag){case 0:case 11:case 15:lv(8,n,n.return),e(n);break;case 22:2&(r=n.stateNode)._visibility&&(r._visibility&=-3,e(n));break;default:e(n)}t=t.sibling}}(e)):sy(e)}}function sx(e,t){for(;null!==lX;){var n=lX;switch(n.tag){case 0:case 11:case 15:lv(8,n,t);break;case 23:case 22:if(null!==n.memoizedState&&null!==n.memoizedState.cachePool){var r=n.memoizedState.cachePool.pool;null!=r&&r.refCount++}break;case 24:ou(n.memoizedState.cache)}if(null!==(r=n.child))r.return=n,lX=r;else for(n=e;null!==lX;){var o=(r=lX).sibling,a=r.return;if(!function e(t){var n=t.alternate;null!==n&&(t.alternate=null,e(n)),t.child=null,t.deletions=null,t.sibling=null,5===t.tag&&null!==(n=t.stateNode)&&e1(n),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}(r),r===n){lX=null;break}if(null!==o){o.return=a,lX=o;break}lX=a}}}var sw={getCacheForType:function(e){var t=on(os),n=t.data.get(e);return void 0===n&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return on(os).controller.signal}},s_="function"==typeof WeakMap?WeakMap:Map,sk=0,sj=null,sS=null,sO=0,sC=0,sP=null,sE=!1,sT=!1,sI=!1,sN=0,sL=0,sA=0,sz=0,sR=0,sD=0,sM=0,sZ=null,sF=null,sU=!1,sH=0,sV=0,sB=1/0,s$=null,sq=null,sW=0,sK=null,sY=null,sG=0,sX=0,sQ=null,sJ=null,s0=null,s1=null,s2=null,s3=0,s4=null;function s5(){return 0!=(2&sk)&&0!==sO?sO&-sO:null!==B.T?c$():eB()}function s6(){if(0===sD)if(0==(0x20000000&sO)||r$){var e=eI;0==(3932160&(eI<<=1))&&(eI=262144),sD=e}else sD=0x20000000;return null!==(e=o4.current)&&(e.flags|=32),sD}function s9(e,t){if(null!=t){var n=e.stateNode,r=n.ref;null===r&&(r=n.ref=uE(rr(e.memoizedProps,n))),null===s1&&(s1=[]),s1.push(t.bind(null,r))}}function s8(e,t,n){(e===sj&&(2===sC||9===sC)||null!==e.cancelPendingCommit)&&(co(e,0),ct(e,sO,sD,!1)),eM(e,n),(0==(2&sk)||e!==sj)&&(e===sj&&(0==(2&sk)&&(sz|=n),4===sL&&ct(e,sO,sD,!1)),cM(e))}function s7(e,t,n){if(0!=(6&sk))throw Error(l(327));for(var r=!n&&0==(127&t)&&0==(t&e.expiredLanes)||ez(e,t),o=r?function(e,t){var n=sk;sk|=2;var r=cl(),o=cs();sj!==e||sO!==t?(s$=null,sB=em()+500,co(e,t)):sT=ez(e,t);e:for(;;)try{if(0!==sC&&null!==sS){t=sS;var a=sP;t:switch(sC){case 1:sC=0,sP=null,cp(e,t,a,1);break;case 2:case 9:if(oC(a)){sC=0,sP=null,cf(t);break}t=function(){2!==sC&&9!==sC||sj!==e||(sC=7),cM(e)},a.then(t,t);break e;case 3:sC=7;break e;case 4:sC=5;break e;case 7:oC(a)?(sC=0,sP=null,cf(t)):(sC=0,sP=null,cp(e,t,a,7));break;case 5:var i=null;switch(sS.tag){case 26:i=sS.memoizedState;case 5:case 27:var s=sS;if(i?dc(i):s.stateNode.complete){sC=0,sP=null;var c=s.sibling;if(null!==c)sS=c;else{var u=s.return;null!==u?(sS=u,ch(u)):sS=null}break t}}sC=0,sP=null,cp(e,t,a,5);break;case 6:sC=0,sP=null,cp(e,t,a,6);break;case 8:cr(),sL=6;break e;default:throw Error(l(462))}}for(;null!==sS&&!ep();)cd(sS);break}catch(t){ca(e,t)}return(r4=r3=null,B.H=r,B.A=o,sk=n,null!==sS)?0:(sj=null,sO=0,ru(),sL)}(e,t):cu(e,t,!0),a=r;;){if(0===o)sT&&!r&&ct(e,t,0,!1);else{if(n=e.current.alternate,a&&!function(e){for(var t=e;;){var n=t.tag;if((0===n||11===n||15===n)&&16384&t.flags&&null!==(n=t.updateQueue)&&null!==(n=n.stores))for(var r=0;r<n.length;r++){var o=n[r],a=o.getSnapshot;o=o.value;try{if(!nZ(a(),o))return!1}catch(e){return!1}}if(n=t.child,16384&t.subtreeFlags&&null!==n)n.return=t,t=n;else{if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}(n)){o=cu(e,t,!1),a=!1;continue}if(2===o){if(a=t,e.errorRecoveryDisabledLanes&a)var i=0;else i=0!=(i=-0x20000001&e.pendingLanes)?i:0x20000000&i?0x20000000:0;if(0!==i){t=i;e:{o=sZ;var s=e.current.memoizedState.isDehydrated;if(s&&(co(e,i).flags|=256),2!==(i=cu(e,i,!1))){if(sI&&!s){e.errorRecoveryDisabledLanes|=a,sz|=a,o=4;break e}a=sF,sF=o,null!==a&&(null===sF?sF=a:sF.push.apply(sF,a))}o=i}if(a=!1,2!==o)continue}}if(1===o){co(e,0),ct(e,t,0,!0);break}e:{switch(r=e,a=o){case 0:case 1:throw Error(l(345));case 4:if((4194048&t)!==t&&(0x3c00000&t)!==t)break;case 6:ct(r,t,sD,!sE);break e;case 2:sF=null;break;case 3:case 5:break;default:throw Error(l(329))}if((0x3c00000&t)===t&&10<(o=sH+300-em())){if(ct(r,t,sD,!sE),0!==eA(r,0,!0))break e;sG=t,r.timeoutHandle=uh(ce.bind(null,r,n,sF,s$,sU,t,sD,sz,sM,sE,a,"Throttled",-0,0),o);break e}ce(r,n,sF,s$,sU,t,sD,sz,sM,sE,a,null,-0,0)}}break}cM(e)}function ce(e,t,n,r,o,a,i,l,s,c,u,d,f,p){e.timeoutHandle=-1;var h,m,g=t.subtreeFlags,v=(0x13ffff00&a)===a;if(d=null,(v||8192&g||0x1002000==(0x1002000&g))&&(lN=null,sg(t,a,d={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:tT}),v&&(g=d,null!=(v=(9===(v=e.containerInfo).nodeType?v:v.ownerDocument).__reactViewTransition)&&(g.count++,g.waitingForViewTransition=!0,g=dh.bind(g),v.finished.then(g,g))),null!==(h=d,m=g=(0x3c00000&a)===a?sH-em():(4194048&a)===a?sV-em():0,h.stylesheets&&0===h.count&&dv(h,h.stylesheets),g=0<h.count||0<h.imgCount?function(e){var t=setTimeout(function(){if(h.stylesheets&&dv(h,h.stylesheets),h.unsuspend){var e=h.unsuspend;h.unsuspend=null,e()}},6e4+m);0<h.imgBytes&&0===df&&(df=62500*function(){if("function"==typeof performance.getEntriesByType){for(var e=0,t=0,n=performance.getEntriesByType("resource"),r=0;r<n.length;r++){var o=n[r],a=o.transferSize,i=o.initiatorType,l=o.duration;if(a&&l&&ui(i)){for(i=0,l=o.responseEnd,r+=1;r<n.length;r++){var s=n[r],c=s.startTime;if(c>l)break;var u=s.transferSize,d=s.initiatorType;u&&ui(d)&&(i+=u*((s=s.responseEnd)<l?1:(l-c)/(s-c)))}if(--r,t+=8*(a+i)/(o.duration/1e3),10<++e)break}}if(0<e)return t/e/1e6}return navigator.connection&&"number"==typeof(e=navigator.connection.downlink)?e:5}());var n=setTimeout(function(){if(h.waitingForImages=!1,0===h.count&&(h.stylesheets&&dv(h,h.stylesheets),h.unsuspend)){var e=h.unsuspend;h.unsuspend=null,e()}},(h.imgBytes>df?50:800)+m);return h.unsuspend=e,function(){h.unsuspend=null,clearTimeout(t),clearTimeout(n)}}:null))){sG=a,e.cancelPendingCommit=g(cg.bind(null,e,t,a,n,r,o,i,l,s,u,d,null,f,p)),ct(e,a,i,!c);return}cg(e,t,a,n,r,o,i,l,s,u,d)}function ct(e,t,n,r){t&=~sR,t&=~sz,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var o=t;0<o;){var a=31-eC(o),i=1<<a;r[a]=-1,o&=~i}0!==n&&eZ(e,n,t)}function cn(){return 0!=(6&sk)||(cZ(0,!1),!1)}function cr(){if(null!==sS){if(0===sC)var e=sS.return;else e=sS,r4=r3=null,aj(e),oL=null,oA=0,e=sS;for(;null!==e;)lm(e.alternate,e),e=e.return;sS=null}}function co(e,t){var n=e.timeoutHandle;-1!==n&&(e.timeoutHandle=-1,um(n)),null!==(n=e.cancelPendingCommit)&&(e.cancelPendingCommit=null,n()),sG=0,cr(),sj=e,sS=n=rx(e.current,null),sO=t,sC=0,sP=null,sE=!1,sT=ez(e,t),sI=!1,sM=sD=sR=sz=sA=sL=0,sF=sZ=null,sU=!1,0!=(8&t)&&(t|=32&t);var r=e.entangledLanes;if(0!==r)for(e=e.entanglements,r&=t;0<r;){var o=31-eC(r),a=1<<o;t|=e[o],r&=~a}return sN=t,ru(),n}function ca(e,t){ai=null,B.H=iS,t===ok||t===oS?(t=oI(),sC=3):t===oj?(t=oI(),sC=4):sC=t===iH?8:null!==t&&"object"==typeof t&&"function"==typeof t.then?6:1,sP=t,null===sS&&(sL=1,iD(e,rP(t,e.current)))}function ci(){var e=o4.current;return null===e||((4194048&sO)===sO?null===o5:((0x3c00000&sO)===sO||0!=(0x20000000&sO))&&e===o5)}function cl(){var e=B.H;return B.H=iS,null===e?iS:e}function cs(){var e=B.A;return B.A=sw,e}function cc(){sL=4,sE||(4194048&sO)!==sO&&null!==o4.current||(sT=!0),0==(0x7ffffff&sA)&&0==(0x7ffffff&sz)||null===sj||ct(sj,sO,sD,!1)}function cu(e,t,n){var r=sk;sk|=2;var o=cl(),a=cs();(sj!==e||sO!==t)&&(s$=null,co(e,t)),t=!1;var i=sL;e:for(;;)try{if(0!==sC&&null!==sS){var l=sS,s=sP;switch(sC){case 8:cr(),i=6;break e;case 3:case 2:case 9:case 6:null===o4.current&&(t=!0);var c=sC;if(sC=0,sP=null,cp(e,l,s,c),n&&sT){i=0;break e}break;default:c=sC,sC=0,sP=null,cp(e,l,s,c)}}(function(){for(;null!==sS;)cd(sS)})(),i=sL;break}catch(t){ca(e,t)}return t&&e.shellSuspendCounter++,r4=r3=null,sk=r,B.H=o,B.A=a,null===sS&&(sj=null,sO=0,ru()),i}function cd(e){var t=ls(e.alternate,e,sN);e.memoizedProps=e.pendingProps,null===t?ch(e):sS=t}function cf(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=i1(n,t,t.pendingProps,t.type,void 0,sO);break;case 11:t=i1(n,t,t.pendingProps,t.type.render,t.ref,sO);break;case 5:aj(t);default:lm(n,t),t=ls(n,t=sS=rw(t,sN),sN)}e.memoizedProps=e.pendingProps,null===t?ch(e):sS=t}function cp(e,t,n,r){r4=r3=null,aj(t),oL=null,oA=0;var o=t.return;try{if(function(e,t,n,r,o){if(n.flags|=32768,null!==r&&"object"==typeof r&&"function"==typeof r.then){if(null!==(t=n.alternate)&&r7(t,n,o,!0),null!==(n=o4.current)){switch(n.tag){case 31:case 13:case 19:return null===o5?cc():null===n.alternate&&0===sL&&(sL=3),n.flags&=-257,n.flags|=65536,n.lanes=o,r===oO?n.flags|=16384:(null===(t=n.updateQueue)?n.updateQueue=new Set([r]):t.add(r),cC(e,r,o)),!1;case 22:return n.flags|=65536,r===oO?n.flags|=16384:(null===(t=n.updateQueue)?(t={transitions:null,markerInstances:null,retryQueue:new Set([r])},n.updateQueue=t):null===(n=t.retryQueue)?t.retryQueue=new Set([r]):n.add(r),cC(e,r,o)),!1}throw Error(l(435,n.tag))}return cC(e,r,o),cc(),!1}if(r$)return null!==(t=o4.current)?(0==(65536&t.flags)&&(t.flags|=256),t.flags|=65536,t.lanes=o,r!==rK&&r1(rP(e=Error(l(422),{cause:r}),n))):(r!==rK&&r1(rP(t=Error(l(423),{cause:r}),n)),e=e.current.alternate,e.flags|=65536,o&=-o,e.lanes|=o,r=rP(r,n),o=iZ(e.stateNode,r,o),oW(e,o),4!==sL&&(sL=2)),!1;var a=Error(l(520),{cause:r});if(a=rP(a,n),null===sZ?sZ=[a]:sZ.push(a),4!==sL&&(sL=2),null===t)return!0;r=rP(r,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=o&-o,n.lanes|=e,e=iZ(n.stateNode,r,e),oW(n,e),!1;case 1:if(t=n.type,a=n.stateNode,0==(128&n.flags)&&("function"==typeof t.getDerivedStateFromError||null!==a&&"function"==typeof a.componentDidCatch&&(null===sq||!sq.has(a))))return n.flags|=65536,o&=-o,n.lanes|=o,iU(o=iF(o),e,n,r),oW(n,o),!1;break;case 22:if(null!==n.memoizedState)return n.flags|=65536,!1}n=n.return}while(null!==n);return!1}(e,o,t,n,sO)){sL=1,iD(e,rP(n,e.current)),sS=null;return}}catch(t){if(null!==o)throw sS=o,t;sL=1,iD(e,rP(n,e.current)),sS=null;return}32768&t.flags?(r$||1===r?e=!0:sT||0!=(0x20000000&sO)?e=!1:(sE=e=!0,(2===r||9===r||3===r||6===r)&&null!==(r=o4.current)&&13===r.tag&&(r.flags|=16384)),cm(t,e)):ch(t)}function ch(e){var t=e;do{if(0!=(32768&t.flags))return void cm(t,sE);e=t.return;var n=function(e,t,n){var r=t.pendingProps;switch(rU(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:case 1:return lh(t),null;case 3:return n=t.stateNode,r=null,null!==e&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),r6(os),er(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(null===e||null===e.child)&&(rQ(t)?lc(t):null===e||e.memoizedState.isDehydrated&&0==(256&t.flags)||(t.flags|=1024,r0())),lh(t),null;case 26:var o=t.type,a=t.memoizedState;return null===e?(lc(t),null!==a?(lh(t),ld(t,a)):(lh(t),lu(t,o,null,r,n))):a?a!==e.memoizedState?(lc(t),lh(t),ld(t,a)):(lh(t),t.flags&=-0x1000001):((e=e.memoizedProps)!==r&&lc(t),lh(t),lu(t,o,e,r,n)),null;case 27:if(ea(t),n=ee.current,o=t.type,null!==e&&null!=t.stateNode)e.memoizedProps!==r&&lc(t);else{if(!r){if(null===t.stateNode)throw Error(l(166));return lh(t),t.subtreeFlags&=-0x2000001,null}e=Q.current,rQ(t)?rG(t,e):(t.stateNode=e=uG(o,r,n),lc(t))}return lh(t),t.subtreeFlags&=-0x2000001,null;case 5:if(ea(t),o=t.type,null!==e&&null!=t.stateNode)e.memoizedProps!==r&&lc(t);else{if(!r){if(null===t.stateNode)throw Error(l(166));return lh(t),t.subtreeFlags&=-0x2000001,null}if(a=Q.current,rQ(t))rG(t,a);else{var i=uc(ee.current);switch(a){case 1:a=i.createElementNS("http://www.w3.org/2000/svg",o);break;case 2:a=i.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;default:switch(o){case"svg":a=i.createElementNS("http://www.w3.org/2000/svg",o);break;case"math":a=i.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;case"script":(a=i.createElement("div")).innerHTML="<script><\/script>",a=a.removeChild(a.firstChild);break;case"select":a="string"==typeof r.is?i.createElement("select",{is:r.is}):i.createElement("select"),r.multiple?a.multiple=!0:r.size&&(a.size=r.size);break;default:a="string"==typeof r.is?i.createElement(o,{is:r.is}):i.createElement(o)}}a[eW]=t,a[eK]=r;e:for(i=t.child;null!==i;){if(5===i.tag||6===i.tag)a.appendChild(i.stateNode);else if(4!==i.tag&&27!==i.tag&&null!==i.child){i.child.return=i,i=i.child;continue}if(i===t)break;for(;null===i.sibling;){if(null===i.return||i.return===t)break e;i=i.return}i.sibling.return=i.return,i=i.sibling}switch(t.stateNode=a,ua(a,o,r),o){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break;case"img":r=!0;break;default:r=!1}r&&lc(t)}}return lh(t),t.subtreeFlags&=-0x2000001,lu(t,t.type,null===e?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&null!=t.stateNode)e.memoizedProps!==r&&lc(t);else{if("string"!=typeof r&&null===t.stateNode)throw Error(l(166));if(e=ee.current,rQ(t)){if(e=t.stateNode,n=t.memoizedProps,r=null,null!==(o=rV))switch(o.tag){case 27:case 5:r=o.memoizedProps}e[eW]=t,(e=!!(e.nodeValue===n||null!==r&&!0===r.suppressHydrationWarning||un(e.nodeValue,n)))||rY(t,!0)}else(e=uc(e).createTextNode(r))[eW]=t,t.stateNode=e}return lh(t),null;case 31:if(n=t.memoizedState,null===e||null!==e.memoizedState){if(r=rQ(t),null!==n){if(null===e){if(!r)throw Error(l(318));if(!(e=null!==(e=t.memoizedState)?e.dehydrated:null))throw Error(l(557));e[eW]=t}else rJ(),0==(128&t.flags)&&(t.memoizedState=null),t.flags|=4;lh(t),e=!1}else n=r0(),null!==e&&null!==e.memoizedState&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e){if(256&t.flags)return ae(t),t;return ae(t),null}if(0!=(128&t.flags))throw Error(l(558))}return lh(t),null;case 13:if(r=t.memoizedState,null===e||null!==e.memoizedState&&null!==e.memoizedState.dehydrated){if(o=rQ(t),null!==r&&null!==r.dehydrated){if(null===e){if(!o)throw Error(l(318));if(!(o=null!==(o=t.memoizedState)?o.dehydrated:null))throw Error(l(317));o[eW]=t}else rJ(),0==(128&t.flags)&&(t.memoizedState=null),t.flags|=4;lh(t),o=!1}else o=r0(),null!==e&&null!==e.memoizedState&&(e.memoizedState.hydrationErrors=o),o=!0;if(!o){if(256&t.flags)return ae(t),t;return ae(t),null}}if(ae(t),0!=(128&t.flags))return t.lanes=n,t;return n=null!==r,e=null!==e&&null!==e.memoizedState,n&&(r=t.child,o=null,null!==r.alternate&&null!==r.alternate.memoizedState&&null!==r.alternate.memoizedState.cachePool&&(o=r.alternate.memoizedState.cachePool.pool),a=null,null!==r.memoizedState&&null!==r.memoizedState.cachePool&&(a=r.memoizedState.cachePool.pool),a!==o&&(r.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),lf(t,t.updateQueue),lh(t),null;case 4:return er(),null===e&&c2(t.stateNode.containerInfo),t.flags|=0x4000000,lh(t),null;case 10:return r6(t.type),lh(t),null;case 19:if(ar(t),null===(r=t.memoizedState))return lh(t),null;if(o=0!=(128&t.flags),null===(a=r.rendering))if(o)lp(r,!1);else{if(0!==sL||null!==e&&0!=(128&e.flags))for(e=t.child;null!==e;){if(null!==(a=ao(e))){for(t.flags|=128,lp(r,!1),t.updateQueue=e=a.updateQueue,lf(t,e),t.subtreeFlags=0,e=n,n=t.child;null!==n;)rw(n,e),n=n.sibling;return an(t,1&at.current|2),r$&&rM(t,r.treeForkCount),t.child}e=e.sibling}null!==r.tail&&em()>sB&&(t.flags|=128,o=!0,lp(r,!1),t.lanes=4194304)}else{if(!o)if(null!==(e=ao(a))){if(t.flags|=128,o=!0,t.updateQueue=e=e.updateQueue,lf(t,e),lp(r,!0),null===r.tail&&"collapsed"!==r.tailMode&&"visible"!==r.tailMode&&!a.alternate&&!r$)return lh(t),null}else 2*em()-r.renderingStartTime>sB&&0x20000000!==n&&(t.flags|=128,o=!0,lp(r,!1),t.lanes=4194304);r.isBackwards?(a.sibling=t.child,t.child=a):(null!==(e=r.last)?e.sibling=a:t.child=a,r.last=a)}if(null!==r.tail){e=r.tail;e:{for(n=e;null!==n;){if(null!==n.alternate){n=!1;break e}n=n.sibling}n=!0}return r.rendering=e,r.tail=e.sibling,r.renderingStartTime=em(),e.sibling=null,a=at.current,a=o?1&a|2:1&a,"visible"===r.tailMode||"collapsed"===r.tailMode||!n||r$?an(t,a):(n=a,X(o4,t),X(at,n),null===o5&&(o5=t)),r$&&rM(t,r.treeForkCount),e}return lh(t),null;case 22:case 23:return ae(t),o3(),r=null!==t.memoizedState,null!==e?null!==e.memoizedState!==r&&(t.flags|=8192):r&&(t.flags|=8192),r?0!=(0x20000000&n)&&0==(128&t.flags)&&(lh(t),6&t.subtreeFlags&&(t.flags|=8192)):lh(t),null!==(n=t.updateQueue)&&lf(t,n.retryQueue),n=null,null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(n=e.memoizedState.cachePool.pool),r=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(r=t.memoizedState.cachePool.pool),r!==n&&(t.flags|=2048),null!==e&&G(ob),null;case 24:return n=null,null!==e&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),r6(os),lh(t),null;case 25:return null;case 30:return t.flags|=0x2000000,lh(t),null}throw Error(l(156,t.tag))}(t.alternate,t,sN);if(null!==n){sS=n;return}if(null!==(t=t.sibling)){sS=t;return}sS=t=e}while(null!==t);0===sL&&(sL=5)}function cm(e,t){do{var n=function(e,t){switch(rU(t),t.tag){case 1:return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 3:return r6(os),er(),0!=(65536&(e=t.flags))&&0==(128&e)?(t.flags=-65537&e|128,t):null;case 26:case 27:case 5:return ea(t),null;case 31:if(null!==t.memoizedState){if(ae(t),null===t.alternate)throw Error(l(340));rJ()}return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 13:if(ae(t),null!==(e=t.memoizedState)&&null!==e.dehydrated){if(null===t.alternate)throw Error(l(340));rJ()}return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 19:return ar(t),65536&(e=t.flags)?(t.flags=-65537&e|128,null!==(e=t.memoizedState)&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return er(),null;case 10:return r6(t.type),null;case 22:case 23:return ae(t),o3(),null!==e&&G(ob),65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 24:return r6(os),null;default:return null}}(e.alternate,e);if(null!==n){n.flags&=32767,sS=n;return}if(null!==(n=e.return)&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&null!==(e=e.sibling)){sS=e;return}sS=e=n}while(null!==e);sL=6,sS=null}function cg(e,t,n,r,o,a,i,s,c,u,d){e.cancelPendingCommit=null;do ck();while(0!==sW);if(0!=(6&sk))throw Error(l(327));if(null!==t){var f;if(t===e.current)throw Error(l(177));if(!function(e,t,n,r,o,a){var i=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var l=e.entanglements,s=e.expirationTimes,c=e.hiddenUpdates;for(n=i&~n;0<n;){var u=31-eC(n),d=1<<u;l[u]=0,s[u]=-1;var f=c[u];if(null!==f)for(c[u]=null,u=0;u<f.length;u++){var p=f[u];null!==p&&(p.lane&=-0x20000001)}n&=~d}0!==r&&eZ(e,r,0),0!==a&&0===o&&0!==e.tag&&(e.suspendedLanes|=a&~(i&~t))}(e,n,a=t.lanes|t.childLanes|rc,i,s,c),e===sj&&(sS=sj=null,sO=0),sY=t,sK=e,sG=n,sX=a,sQ=o,sJ=r,s1=null,(0x13ffff00&n)===n?(f=e.transitionTypes,e.transitionTypes=null,s2=f,r=10262):(s2=null,r=10256),0!=(t.subtreeFlags&r)||0!=(t.flags&r)?(e.callbackNode=null,e.callbackPriority=0,ed(eb,function(){return cj(),null})):(e.callbackNode=null,e.callbackPriority=0),lI=!1,r=0!=(13878&t.flags),0!=(13878&t.subtreeFlags)||r){r=B.T,B.T=null,o=$.p,$.p=2,i=sk,sk|=4;try{!function(e,t,n){if(e=e.containerInfo,ul=dO,nB(e=nV(e))){if("selectionStart"in e)var r={start:e.selectionStart,end:e.selectionEnd};else e:{var o=(r=(r=e.ownerDocument)&&r.defaultView||window).getSelection&&r.getSelection();if(o&&0!==o.rangeCount){r=o.anchorNode;var a,i=o.anchorOffset,l=o.focusNode;o=o.focusOffset;try{r.nodeType,l.nodeType}catch(e){r=null;break e}var s=0,c=-1,u=-1,d=0,f=0,p=e,h=null;t:for(;;){for(;p!==r||0!==i&&3!==p.nodeType||(c=s+i),p!==l||0!==o&&3!==p.nodeType||(u=s+o),3===p.nodeType&&(s+=p.nodeValue.length),null!==(a=p.firstChild);)h=p,p=a;for(;;){if(p===e)break t;if(h===r&&++d===i&&(c=s),h===l&&++f===o&&(u=s),null!==(a=p.nextSibling))break;h=(p=h).parentNode}p=a}r=-1===c||-1===u?null:{start:c,end:u}}else r=null}r=r||{start:0,end:0}}else r=null;for(us={focusedElem:e,selectionRange:r},dO=!1,n=(0x13ffff00&n)===n,lX=t,t=n?9270:1028;null!==lX;){if(e=lX,n&&null!==(r=e.deletions))for(i=0;i<r.length;i++)n&&lH(r[i]);if(null===e.alternate&&0!=(2&e.flags))n&&lL(e),l2(n);else{if(22===e.tag){if(r=e.alternate,null!==e.memoizedState){null!==r&&null===r.memoizedState&&n&&lH(r),l2(n);continue}else if(null!==r&&null!==r.memoizedState){n&&lL(e),l2(n);continue}}r=e.child,0!=(e.subtreeFlags&t)&&null!==r?(r.return=e,lX=r):(n&&function e(t){for(t=t.child;null!==t;){if(30===t.tag){var n=t.memoizedProps,r=rr(n,t.stateNode);n=ra(n.default,n.update),t.flags&=-5,"none"!==n&&lD(t,r,n,t.memoizedState=[],!1)}else 0!=(0x2000000&t.subtreeFlags)&&e(t);t=t.sibling}}(e),l2(n))}}lN=null}(e,t,n)}finally{sk=i,$.p=o,B.T=r}}sW=1,(t=lI)?s0=function(e,t,n,r,o,a,i,l,s){var c=9===t.nodeType?t:t.ownerDocument;try{var u=c.startViewTransition({update:function(){var t=c.defaultView,n=t.navigation&&t.navigation.transition,i=c.fonts.status;r();var l=[];if("loaded"===i&&(c.documentElement.clientHeight,"loading"===c.fonts.status&&l.push(c.fonts.ready)),i=l.length,null!==e)for(var s=e.suspenseyImages,u=0,d=0;d<s.length;d++){var f=s[d];if(!f.complete){var p=f.getBoundingClientRect();if(0<p.bottom&&0<p.right&&p.top<t.innerHeight&&p.left<t.innerWidth){if((u+=du(f))>df){l.length=i;break}f=new Promise(uC.bind(f)),l.push(f)}}}return 0<l.length?(t=Promise.race([Promise.all(l),new Promise(function(e){return setTimeout(e,500)})]).then(o,o),(n?Promise.allSettled([n.finished,t]):t).then(a,a)):(o(),n)?n.finished.then(a,a):void a()},types:n});return c.__reactViewTransition=u,u.ready.then(function(){for(var e=c.documentElement.getAnimations({subtree:!0}),t=0;t<e.length;t++){var n=e[t].effect,r=n.pseudoElement;if(null!=r&&r.startsWith("::view-transition")){r=n.getKeyframes();for(var o=void 0,a=void 0,l=!0,s=0;s<r.length;s++){var u=r[s],d=u.width;if(void 0===o)o=d;else if(o!==d){l=!1;break}if(d=u.height,void 0===a)a=d;else if(a!==d){l=!1;break}delete u.width,delete u.height,"none"===u.transform&&delete u.transform}l&&void 0!==o&&void 0!==a&&(n.setKeyframes(r),(l=getComputedStyle(n.target,n.pseudoElement)).width!==o||l.height!==a)&&((l=r[0]).width=o,l.height=a,(l=r[r.length-1]).width=o,l.height=a,n.setKeyframes(r))}}i()},function(e){c.__reactViewTransition===u&&(c.__reactViewTransition=null);try{"object"==typeof e&&null!==e&&"InvalidStateError"===e.name&&("View transition was skipped because document visibility state is hidden."===e.message||"Skipping view transition because document visibility state has become hidden."===e.message||"Skipping view transition because viewport size changed."===e.message||"Transition was aborted because of invalid state"===e.message)&&(e=null),null!==e&&s(e)}finally{r(),o(),i()}}),u.finished.finally(function(){for(var e=c.documentElement,t=e.getAnimations({subtree:!0}),n=0;n<t.length;n++){var r=t[n],o=r.effect,a=o.pseudoElement;null!=a&&a.startsWith("::view-transition")&&o.target===e&&r.cancel()}c.__reactViewTransition===u&&(c.__reactViewTransition=null),l()}),u}catch(e){return r(),o(),i(),null}}(d,e.containerInfo,s2,cb,cx,cy,cw,cj,cv,null,null):(cb(),cx(),cw())}}function cv(e){0!==sW&&(0,sK.onRecoverableError)(e,{componentStack:null})}function cy(){3===sW&&(sW=0,sl(sY,sK),sW=4)}function cb(){if(1===sW){sW=0;var e=sK,t=sY,n=sG,r=0!=(13878&t.flags);if(0!=(13878&t.subtreeFlags)||r){r=B.T,B.T=null;var o=$.p;$.p=2;var a=sk;sk|=4;try{lJ=l0=!1,so(t,e,n),n=us;var i=nV(e.containerInfo),l=n.focusedElem,s=n.selectionRange;if(i!==l&&l&&l.ownerDocument&&function e(t,n){return!!t&&!!n&&(t===n||(!t||3!==t.nodeType)&&(n&&3===n.nodeType?e(t,n.parentNode):"contains"in t?t.contains(n):!!t.compareDocumentPosition&&!!(16&t.compareDocumentPosition(n))))}(l.ownerDocument.documentElement,l)){if(null!==s&&nB(l)){var c=s.start,u=s.end;if(void 0===u&&(u=c),"selectionStart"in l)l.selectionStart=c,l.selectionEnd=Math.min(u,l.value.length);else{var d=l.ownerDocument||document,f=d&&d.defaultView||window;if(f.getSelection){var p=f.getSelection(),h=l.textContent.length,m=Math.min(s.start,h),g=void 0===s.end?m:Math.min(s.end,h);!p.extend&&m>g&&(i=g,g=m,m=i);var v=nH(l,m),y=nH(l,g);if(v&&y&&(1!==p.rangeCount||p.anchorNode!==v.node||p.anchorOffset!==v.offset||p.focusNode!==y.node||p.focusOffset!==y.offset)){var b=d.createRange();b.setStart(v.node,v.offset),p.removeAllRanges(),m>g?(p.addRange(b),p.extend(y.node,y.offset)):(b.setEnd(y.node,y.offset),p.addRange(b))}}}}for(d=[],p=l;p=p.parentNode;)1===p.nodeType&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for("function"==typeof l.focus&&l.focus(),l=0;l<d.length;l++){var x=d[l];x.element.scrollLeft=x.left,x.element.scrollTop=x.top}}dO=!!ul,us=ul=null}finally{sk=a,$.p=o,B.T=r}}e.current=t,sW=2}}function cx(){if(2===sW){sW=0;var e=sK,t=sY,n=0!=(8772&t.flags);if(0!=(8772&t.subtreeFlags)||n){n=B.T,B.T=null;var r=$.p;$.p=2;var o=sk;sk|=4;try{l3(e,t.alternate,t)}finally{sk=o,$.p=r,B.T=n}}sW=3}}function cw(){if(4===sW||3===sW){sW=0,s0=null,eh();var e=sK,t=sY,n=sG,r=sJ,o=(0x13ffff00&n)===n?10262:10256;if(0!=(t.subtreeFlags&o)||0!=(t.flags&o)?sW=5:(sW=0,sY=sK=null,c_(e,e.pendingLanes)),0===(o=e.pendingLanes)&&(sq=null),eV(n),t=t.stateNode,eS&&"function"==typeof eS.onCommitFiberRoot)try{eS.onCommitFiberRoot(ej,t,void 0,128==(128&t.current.flags))}catch(e){}if(null!==r){t=B.T,o=$.p,$.p=2,B.T=null;try{for(var a=e.onRecoverableError,i=0;i<r.length;i++){var l=r[i];a(l.value,{componentStack:l.stack})}}finally{B.T=t,$.p=o}}if(r=s1,a=s2,s2=null,null!==r)for(s1=null,null===a&&(a=[]),l=0;l<r.length;l++)(0,r[l])(a);0!=(3&sG)&&ck(),cM(e),o=e.pendingLanes,0!=(261930&n)&&0!=(42&o)?e===s4?s3++:(s3=0,s4=e):s3=0,cZ(0,!1)}}function c_(e,t){0==(e.pooledCacheLanes&=t)&&null!=(t=e.pooledCache)&&(e.pooledCache=null,ou(t))}function ck(){return null!==s0&&(s0.skipTransition(),s0=null),cb(),cx(),cw(),cj()}function cj(){if(5!==sW)return!1;var e=sK,t=sX;sX=0;var n=eV(sG),r=B.T,o=$.p;try{$.p=32>n?32:n,B.T=null,n=sQ,sQ=null;var a=sK,i=sG;if(sW=0,sY=sK=null,sG=0,0!=(6&sk))throw Error(l(331));var s=sk;if(sk|=4,sb(a.current),sf(a,a.current,i,n),sk=s,cZ(0,!1),eS&&"function"==typeof eS.onPostCommitFiberRoot)try{eS.onPostCommitFiberRoot(ej,a)}catch(e){}return!0}finally{$.p=o,B.T=r,c_(e,t)}}function cS(e,t,n){t=rP(n,t),t=iZ(e.stateNode,t,2),null!==(e=o$(e,t,2))&&(eM(e,2),cM(e))}function cO(e,t,n){if(3===e.tag)cS(e,e,n);else for(;null!==t;){if(3===t.tag){cS(t,e,n);break}if(1===t.tag){var r=t.stateNode;if("function"==typeof t.type.getDerivedStateFromError||"function"==typeof r.componentDidCatch&&(null===sq||!sq.has(r))){e=rP(n,e),null!==(r=o$(t,n=iF(2),2))&&(iU(n,r,t,e),eM(r,2),cM(r));break}}t=t.return}}function cC(e,t,n){var r=e.pingCache;if(null===r){r=e.pingCache=new s_;var o=new Set;r.set(t,o)}else void 0===(o=r.get(t))&&(o=new Set,r.set(t,o));o.has(n)||(sI=!0,o.add(n),e=cP.bind(null,e,t,n),t.then(e,e))}function cP(e,t,n){var r=e.pingCache;null!==r&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,sj===e&&(sO&n)===n&&(4===sL||3===sL&&(0x3c00000&sO)===sO&&300>em()-sH?0==(2&sk)&&co(e,0):sR|=n,sM===sO&&(sM=0)),cM(e)}function cE(e,t){0===t&&(t=eR()),null!==(e=rp(e,t))&&(eM(e,t),cM(e))}function cT(e){var t=e.memoizedState,n=0;null!==t&&(n=t.retryLane),cE(e,n)}function cI(e,t){var n=0;switch(e.tag){case 31:case 13:var r=e.stateNode,o=e.memoizedState;null!==o&&(n=o.retryLane);break;case 19:r=e.stateNode;break;case 22:r=e.stateNode._retryCache;break;default:throw Error(l(314))}null!==r&&r.delete(t),cE(e,n)}var cN=null,cL=null,cA=!1,cz=!1,cR=!1,cD=0;function cM(e){e!==cL&&null===e.next&&(null===cL?cN=cL=e:cL=cL.next=e),cz=!0,cA||(cA=!0,uv(function(){0!=(6&sk)?ed(ev,cF):cU()}))}function cZ(e,t){if(!cR&&cz){cR=!0;do for(var n=!1,r=cN;null!==r;){if(!t)if(0!==e){var o=r.pendingLanes;if(0===o)var a=0;else{var i=r.suspendedLanes,l=r.pingedLanes;a=0xc000095&(a=(1<<31-eC(42|e)+1)-1&(o&~(i&~l)))?0xc000095&a|1:a?2|a:0}0!==a&&(n=!0,cB(r,a))}else a=sO,0==(3&(a=eA(r,r===sj?a:0,null!==r.cancelPendingCommit||-1!==r.timeoutHandle)))||ez(r,a)||(n=!0,cB(r,a));r=r.next}while(n);cR=!1}}function cF(){cU()}function cU(){cz=cA=!1;var e,t=0;0===cD||((e=window.event)&&"popstate"===e.type?e===up||(up=e,0):(up=null,1))||(t=cD);for(var n=em(),r=null,o=cN;null!==o;){var a=o.next,i=cH(o,n);0===i?(o.next=null,null===r?cN=a:r.next=a,null===a&&(cL=r)):(r=o,(0!==t||0!=(3&i))&&(cz=!0)),o=a}0!==sW&&5!==sW||cZ(t,!1),0!==cD&&(cD=0)}function cH(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,o=e.expirationTimes,a=-0x3c00001&e.pendingLanes;0<a;){var i=31-eC(a),l=1<<i,s=o[i];-1===s?(0==(l&n)||0!=(l&r))&&(o[i]=function(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;default:return -1}}(l,t)):s<=t&&(e.expiredLanes|=l),a&=~l}if(t=sj,n=sO,n=eA(e,e===t?n:0,null!==e.cancelPendingCommit||-1!==e.timeoutHandle),r=e.callbackNode,0===n||e===t&&(2===sC||9===sC)||null!==e.cancelPendingCommit)return null!==r&&null!==r&&ef(r),e.callbackNode=null,e.callbackPriority=0;if(0==(3&n)||ez(e,n)){if((t=n&-n)===e.callbackPriority)return t;switch(null!==r&&ef(r),eV(n)){case 2:case 8:n=ey;break;case 32:default:n=eb;break;case 0x10000000:n=ew}return n=ed(n,r=cV.bind(null,e)),e.callbackPriority=t,e.callbackNode=n,t}return null!==r&&null!==r&&ef(r),e.callbackPriority=2,e.callbackNode=null,2}function cV(e,t){if(0!==sW&&5!==sW)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(ck()&&e.callbackNode!==n)return null;var r=sO;return 0===(r=eA(e,e===sj?r:0,null!==e.cancelPendingCommit||-1!==e.timeoutHandle))?null:(s7(e,r,t),cH(e,em()),null!=e.callbackNode&&e.callbackNode===n?cV.bind(null,e):null)}function cB(e,t){if(ck())return null;s7(e,t,!0)}function c$(){if(0===cD){var e=om;0===e&&(e=eT,0==(261888&(eT<<=1))&&(eT=256)),cD=e}return cD}function cq(e){return null==e||"symbol"==typeof e||"boolean"==typeof e?null:"function"==typeof e?e:tE(""+e)}function cW(e,t){var n=t.ownerDocument.createElement("input");return n.name=t.name,n.value=t.value,e.id&&n.setAttribute("form",e.id),t.parentNode.insertBefore(n,t),e=new FormData(e),n.parentNode.removeChild(n),e}for(var cK=0;cK<re.length;cK++){var cY=re[cK];rt(cY.toLowerCase(),"on"+(cY[0].toUpperCase()+cY.slice(1)))}rt(n2,"onAnimationEnd"),rt(n3,"onAnimationIteration"),rt(n4,"onAnimationStart"),rt("dblclick","onDoubleClick"),rt("focusin","onFocus"),rt("focusout","onBlur"),rt(n5,"onTransitionRun"),rt(n6,"onTransitionStart"),rt(n9,"onTransitionCancel"),rt(n8,"onTransitionEnd"),te("onMouseEnter",["mouseout","mouseover"]),te("onMouseLeave",["mouseout","mouseover"]),te("onPointerEnter",["pointerout","pointerover"]),te("onPointerLeave",["pointerout","pointerover"]),e7("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),e7("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),e7("onBeforeInput",["compositionend","keypress","textInput","paste"]),e7("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),e7("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),e7("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var cG="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),cX=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(cG));function cQ(e,t){t=0!=(4&t);for(var n=0;n<e.length;n++){var r=e[n],o=r.event;r=r.listeners;e:{var a=void 0;if(t)for(var i=r.length-1;0<=i;i--){var l=r[i],s=l.instance,c=l.currentTarget;if(l=l.listener,s!==a&&o.isPropagationStopped())break e;a=l,o.currentTarget=c;try{a(o)}catch(e){ri(e)}o.currentTarget=null,a=s}else for(i=0;i<r.length;i++){if(s=(l=r[i]).instance,c=l.currentTarget,l=l.listener,s!==a&&o.isPropagationStopped())break e;a=l,o.currentTarget=c;try{a(o)}catch(e){ri(e)}o.currentTarget=null,a=s}}}}function cJ(e,t){var n=t[eG];void 0===n&&(n=t[eG]=new Set);var r=e+"__bubble";n.has(r)||(c3(t,e,2,!1),n.add(r))}function c0(e,t,n){var r=0;t&&(r|=4),c3(n,e,r,t)}var c1="_reactListening"+Math.random().toString(36).slice(2);function c2(e){if(!e[c1]){e[c1]=!0,e9.forEach(function(t){"selectionchange"!==t&&(cX.has(t)||c0(t,!1,e),c0(t,!0,e))});var t=9===e.nodeType?e:e.ownerDocument;null===t||t[c1]||(t[c1]=!0,c0("selectionchange",!1,t))}}function c3(e,t,n,r){switch(dL(t)){case 2:var o=dC;break;case 8:o=dP;break;default:o=dE}n=o.bind(null,t,n,e),o=void 0,tF&&("touchstart"===t||"touchmove"===t||"wheel"===t)&&(o=!0),r?void 0!==o?e.addEventListener(t,n,{capture:!0,passive:o}):e.addEventListener(t,n,!0):void 0!==o?e.addEventListener(t,n,{passive:o}):e.addEventListener(t,n,!1)}function c4(e,t,n,r,o){var a=r;if(0==(1&t)&&0==(2&t)&&null!==r)e:for(;;){if(null===r)return;var i=r.tag;if(3===i||4===i){var l=r.stateNode.containerInfo;if(l===o)break;if(4===i)for(i=r.return;null!==i;){var c=i.tag;if((3===c||4===c)&&i.stateNode.containerInfo===o)return;i=i.return}for(;null!==l;){if(null===(i=e2(l)))return;if(5===(c=i.tag)||6===c||26===c||27===c){r=a=i;continue e}l=l.parentNode}}r=r.return}tD(function(){var r=a,o=tN(n),i=[];e:{var l=n7.get(e);if(void 0!==l){var c=t2,u=e;switch(e){case"keypress":if(0===tq(n))break e;case"keydown":case"keyup":c=nl;break;case"focusin":u="focus",c=t8;break;case"focusout":u="blur",c=t8;break;case"beforeblur":case"afterblur":c=t8;break;case"click":if(2===n.button)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":c=t6;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":c=t9;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":c=nc;break;case n2:case n3:case n4:c=t7;break;case n8:c=nu;break;case"scroll":case"scrollend":c=t4;break;case"wheel":c=nd;break;case"copy":case"cut":case"paste":c=ne;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":c=ns;break;case"toggle":case"beforetoggle":c=nf}var d=0!=(4&t),f=!d&&("scroll"===e||"scrollend"===e),p=d?null!==l?l+"Capture":null:l;d=[];for(var h,m=r;null!==m;){var g=m;if(h=g.stateNode,5!==(g=g.tag)&&26!==g&&27!==g||null===h||null===p||null!=(g=tM(m,p))&&d.push(c5(m,g,h)),f)break;m=m.return}0<d.length&&(l=new c(l,u,null,n,o),i.push({event:l,listeners:d}))}}if(0==(7&t)){c="mouseover"===e||"pointerover"===e,l="mouseout"===e||"pointerout"===e,!(c&&n!==tI&&(u=n.relatedTarget||n.fromElement)&&(e2(u)||u[eY]))&&(l||c)&&(u=o.window===o?o:(c=o.ownerDocument)?c.defaultView||c.parentWindow:window,l?(c=n.relatedTarget||n.toElement,l=r,null!==(c=c?e2(c):null)&&(f=s(c),d=c.tag,c!==f||5!==d&&27!==d&&6!==d)&&(c=null)):(l=null,c=r),l!==c&&(d=t6,g="onMouseLeave",p="onMouseEnter",m="mouse",("pointerout"===e||"pointerover"===e)&&(d=ns,g="onPointerLeave",p="onPointerEnter",m="pointer"),f=null==l?u:e4(l),h=null==c?u:e4(c),(u=new d(g,m+"leave",l,n,o)).target=f,u.relatedTarget=h,g=null,e2(o)===r&&((d=new d(p,m+"enter",c,n,o)).target=h,d.relatedTarget=f,g=d),f=g,d=l&&c?w(l,c,c9):null,null!==l&&c8(i,u,l,d,!1),null!==c&&null!==f&&c8(i,f,c,d,!0)));e:{if("select"===(c=(l=r?e4(r):window).nodeName&&l.nodeName.toLowerCase())||"input"===c&&"file"===l.type)var v,y=nE;else if(nk(l))if(nT)y=nM;else{y=nR;var b=nz}else(c=l.nodeName)&&"input"===c.toLowerCase()&&("checkbox"===l.type||"radio"===l.type)?y=nD:r&&tO(r.elementType)&&(y=nE);if(y&&(y=y(e,r))){nj(i,y,n,o);break e}b&&b(e,l,r),"focusout"===e&&r&&"number"===l.type&&null!=r.memoizedProps.value&&ty(l,"number",l.value)}switch(b=r?e4(r):window,e){case"focusin":(nk(b)||"true"===b.contentEditable)&&(nq=b,nW=r,nK=null);break;case"focusout":nK=nW=nq=null;break;case"mousedown":nY=!0;break;case"contextmenu":case"mouseup":case"dragend":nY=!1,nG(i,n,o);break;case"selectionchange":if(n$)break;case"keydown":case"keyup":nG(i,n,o)}if(nh)t:{switch(e){case"compositionstart":var x="onCompositionStart";break t;case"compositionend":x="onCompositionEnd";break t;case"compositionupdate":x="onCompositionUpdate";break t}x=void 0}else nw?nb(e,n)&&(x="onCompositionEnd"):"keydown"===e&&229===n.keyCode&&(x="onCompositionStart");x&&(nv&&"ko"!==n.locale&&(nw||"onCompositionStart"!==x?"onCompositionEnd"===x&&nw&&(v=t$()):(tV="value"in(tH=o)?tH.value:tH.textContent,nw=!0)),0<(b=c6(r,x)).length&&(x=new nt(x,e,null,n,o),i.push({event:x,listeners:b}),v?x.data=v:null!==(v=nx(n))&&(x.data=v))),(v=ng?function(e,t){switch(e){case"compositionend":return nx(t);case"keypress":if(32!==t.which)return null;return ny=!0," ";case"textInput":return" "===(e=t.data)&&ny?null:e;default:return null}}(e,n):function(e,t){if(nw)return"compositionend"===e||!nh&&nb(e,t)?(e=t$(),tB=tV=tH=null,nw=!1,e):null;switch(e){case"paste":default:return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return nv&&"ko"!==t.locale?null:t.data}}(e,n))&&0<(x=c6(r,"onBeforeInput")).length&&(b=new nt("onBeforeInput","beforeinput",null,n,o),i.push({event:b,listeners:x}),b.data=v);var _=e;if("submit"===_&&r&&r.stateNode===o){var k=cq((o[eK]||null).action),j=n.submitter;j&&null!==(_=(_=j[eK]||null)?cq(_.formAction):j.getAttribute("formAction"))&&(k=_,j=null);var S=new t2("action","action",null,n,o);i.push({event:S,listeners:[{instance:null,listener:function(){if(n.defaultPrevented){if(0!==cD){var e=j?cW(o,j):new FormData(o);iu(r,{pending:!0,data:e,method:o.method,action:k},null,e)}}else"function"==typeof k&&(S.preventDefault(),iu(r,{pending:!0,data:e=j?cW(o,j):new FormData(o),method:o.method,action:k},k,e))},currentTarget:o}]})}}cQ(i,t)})}function c5(e,t,n){return{instance:e,listener:t,currentTarget:n}}function c6(e,t){for(var n=t+"Capture",r=[];null!==e;){var o=e,a=o.stateNode;if(5!==(o=o.tag)&&26!==o&&27!==o||null===a||(null!=(o=tM(e,n))&&r.unshift(c5(e,o,a)),null!=(o=tM(e,t))&&r.push(c5(e,o,a))),3===e.tag)return r;e=e.return}return[]}function c9(e){if(null===e)return null;do e=e.return;while(e&&5!==e.tag&&27!==e.tag);return e||null}function c8(e,t,n,r,o){for(var a=t._reactName,i=[];null!==n&&n!==r;){var l=n,s=l.alternate,c=l.stateNode;if(l=l.tag,null!==s&&s===r)break;5!==l&&26!==l&&27!==l||null===c||(s=c,o?null!=(c=tM(n,a))&&i.unshift(c5(n,c,s)):o||null!=(c=tM(n,a))&&i.push(c5(n,c,s))),n=n.return}0!==i.length&&e.push({event:t,listeners:i})}var c7=/\r\n?/g,ue=/\u0000|\uFFFD/g;function ut(e){return("string"==typeof e?e:""+e).replace(c7,"\n").replace(ue,"")}function un(e,t){return t=ut(t),ut(e)===t}function ur(e,t,n,r,o,a){switch(n){case"children":if("string"==typeof r)"body"===t||"textarea"===t&&""===r||t_(e,r);else{if("number"!=typeof r&&"bigint"!=typeof r)return;"body"!==t&&t_(e,""+r)}break;case"className":tl(e,"class",r);break;case"tabIndex":tl(e,"tabindex",r);break;case"dir":case"role":case"viewBox":case"width":case"height":tl(e,n,r);break;case"style":tS(e,r,a);return;case"data":if("object"!==t){tl(e,"data",r);break}case"src":case"href":if(""===r&&("a"!==t||"href"!==n)||null==r||"function"==typeof r||"symbol"==typeof r||"boolean"==typeof r){e.removeAttribute(n);break}r=tE(""+r),e.setAttribute(n,r);break;case"action":case"formAction":if("function"==typeof r){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}if("function"==typeof a&&("formAction"===n?("input"!==t&&ur(e,t,"name",o.name,o,null),ur(e,t,"formEncType",o.formEncType,o,null),ur(e,t,"formMethod",o.formMethod,o,null),ur(e,t,"formTarget",o.formTarget,o,null)):(ur(e,t,"encType",o.encType,o,null),ur(e,t,"method",o.method,o,null),ur(e,t,"target",o.target,o,null))),null==r||"symbol"==typeof r||"boolean"==typeof r){e.removeAttribute(n);break}r=tE(""+r),e.setAttribute(n,r);break;case"onClick":null!=r&&(e.onclick=tT);return;case"onScroll":null!=r&&cJ("scroll",e);return;case"onScrollEnd":null!=r&&cJ("scrollend",e);return;case"dangerouslySetInnerHTML":if(null!=r){if("object"!=typeof r||!("__html"in r))throw Error(l(61));if(null!=(n=r.__html)){if(null!=o.children)throw Error(l(60));e.innerHTML=n}}break;case"multiple":e.multiple=r&&"function"!=typeof r&&"symbol"!=typeof r;break;case"muted":e.muted=r&&"function"!=typeof r&&"symbol"!=typeof r;break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":case"autoFocus":break;case"xlinkHref":if(null==r||"function"==typeof r||"boolean"==typeof r||"symbol"==typeof r){e.removeAttribute("xlink:href");break}n=tE(""+r),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":null!=r&&"function"!=typeof r&&"symbol"!=typeof r?e.setAttribute(n,""+r):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":r&&"function"!=typeof r&&"symbol"!=typeof r?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":!0===r?e.setAttribute(n,""):!1!==r&&null!=r&&"function"!=typeof r&&"symbol"!=typeof r?e.setAttribute(n,r):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":null!=r&&"function"!=typeof r&&"symbol"!=typeof r&&!isNaN(r)&&1<=r?e.setAttribute(n,r):e.removeAttribute(n);break;case"rowSpan":case"start":null==r||"function"==typeof r||"symbol"==typeof r||isNaN(r)?e.removeAttribute(n):e.setAttribute(n,r);break;case"popover":cJ("beforetoggle",e),cJ("toggle",e),ti(e,"popover",r);break;case"xlinkActuate":ts(e,"http://www.w3.org/1999/xlink","xlink:actuate",r);break;case"xlinkArcrole":ts(e,"http://www.w3.org/1999/xlink","xlink:arcrole",r);break;case"xlinkRole":ts(e,"http://www.w3.org/1999/xlink","xlink:role",r);break;case"xlinkShow":ts(e,"http://www.w3.org/1999/xlink","xlink:show",r);break;case"xlinkTitle":ts(e,"http://www.w3.org/1999/xlink","xlink:title",r);break;case"xlinkType":ts(e,"http://www.w3.org/1999/xlink","xlink:type",r);break;case"xmlBase":ts(e,"http://www.w3.org/XML/1998/namespace","xml:base",r);break;case"xmlLang":ts(e,"http://www.w3.org/XML/1998/namespace","xml:lang",r);break;case"xmlSpace":ts(e,"http://www.w3.org/XML/1998/namespace","xml:space",r);break;case"is":ti(e,"is",r);break;case"innerText":case"textContent":return;default:if(2<n.length&&("o"===n[0]||"O"===n[0])&&("n"===n[1]||"N"===n[1]))return;ti(e,n=tC.get(n)||n,r)}to=!0}function uo(e,t,n,r,o,a){switch(n){case"style":tS(e,r,a);return;case"dangerouslySetInnerHTML":if(null!=r){if("object"!=typeof r||!("__html"in r))throw Error(l(61));if(null!=(n=r.__html)){if(null!=o.children)throw Error(l(60));e.innerHTML=n}}break;case"children":if("string"==typeof r)t_(e,r);else{if("number"!=typeof r&&"bigint"!=typeof r)return;t_(e,""+r)}break;case"onScroll":null!=r&&cJ("scroll",e);return;case"onScrollEnd":null!=r&&cJ("scrollend",e);return;case"onClick":null!=r&&(e.onclick=tT);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":case"innerText":case"textContent":return;default:if(!e8.hasOwnProperty(n))e:{if("o"===n[0]&&"n"===n[1]&&(o=n.endsWith("Capture"),t=n.slice(2,o?n.length-7:void 0),"function"==typeof(a=null!=(a=e[eK]||null)?a[n]:null)&&e.removeEventListener(t,a,o),"function"==typeof r)){"function"!=typeof a&&null!==a&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(t,r,o);break e}to=!0,n in e?e[n]=r:!0===r?e.setAttribute(n,""):ti(e,n,r)}return}to=!0}function ua(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":cJ("error",e),cJ("load",e);var r,o=!1,a=!1;for(r in n)if(n.hasOwnProperty(r)){var i=n[r];if(null!=i)switch(r){case"src":o=!0;break;case"srcSet":a=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(l(137,t));default:ur(e,t,r,i,n,null)}}a&&ur(e,t,"srcSet",n.srcSet,n,null),o&&ur(e,t,"src",n.src,n,null);return;case"input":cJ("invalid",e);var s=r=i=a=null,c=null,u=null;for(o in n)if(n.hasOwnProperty(o)){var d=n[o];if(null!=d)switch(o){case"name":a=d;break;case"type":i=d;break;case"checked":c=d;break;case"defaultChecked":u=d;break;case"value":r=d;break;case"defaultValue":s=d;break;case"children":case"dangerouslySetInnerHTML":if(null!=d)throw Error(l(137,t));break;default:ur(e,t,o,d,n,null)}}tv(e,r,s,c,u,i,a,!1);return;case"select":for(a in cJ("invalid",e),o=i=r=null,n)if(n.hasOwnProperty(a)&&null!=(s=n[a]))switch(a){case"value":r=s;break;case"defaultValue":i=s;break;case"multiple":o=s;default:ur(e,t,a,s,n,null)}t=r,n=i,e.multiple=!!o,null!=t?tb(e,!!o,t,!1):null!=n&&tb(e,!!o,n,!0);return;case"textarea":for(i in cJ("invalid",e),r=a=o=null,n)if(n.hasOwnProperty(i)&&null!=(s=n[i]))switch(i){case"value":o=s;break;case"defaultValue":a=s;break;case"children":r=s;break;case"dangerouslySetInnerHTML":if(null!=s)throw Error(l(91));break;default:ur(e,t,i,s,n,null)}tw(e,o,a,r);return;case"option":for(c in n)n.hasOwnProperty(c)&&null!=(o=n[c])&&("selected"===c?e.selected=o&&"function"!=typeof o&&"symbol"!=typeof o:ur(e,t,c,o,n,null));return;case"dialog":cJ("beforetoggle",e),cJ("toggle",e),cJ("cancel",e),cJ("close",e);break;case"iframe":case"object":cJ("load",e);break;case"video":case"audio":for(o=0;o<cG.length;o++)cJ(cG[o],e);break;case"image":cJ("error",e),cJ("load",e);break;case"details":cJ("toggle",e);break;case"embed":case"source":case"link":cJ("error",e),cJ("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(u in n)if(n.hasOwnProperty(u)&&null!=(o=n[u]))switch(u){case"children":case"dangerouslySetInnerHTML":throw Error(l(137,t));default:ur(e,t,u,o,n,null)}return;default:if(tO(t)){for(d in n)n.hasOwnProperty(d)&&void 0!==(o=n[d])&&uo(e,t,d,o,n,void 0);return}}for(s in n)n.hasOwnProperty(s)&&null!=(o=n[s])&&ur(e,t,s,o,n,null)}function ui(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}var ul=null,us=null;function uc(e){return 9===e.nodeType?e:e.ownerDocument}function uu(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function ud(e,t){if(0===e)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return 1===e&&"foreignObject"===t?0:e}function uf(e,t){return"textarea"===e||"noscript"===e||"string"==typeof t.children||"number"==typeof t.children||"bigint"==typeof t.children||"object"==typeof t.dangerouslySetInnerHTML&&null!==t.dangerouslySetInnerHTML&&null!=t.dangerouslySetInnerHTML.__html}var up=null,uh="function"==typeof setTimeout?setTimeout:void 0,um="function"==typeof clearTimeout?clearTimeout:void 0,ug="function"==typeof Promise?Promise:void 0,uv="function"==typeof queueMicrotask?queueMicrotask:void 0!==ug?function(e){return ug.resolve(null).then(e).catch(uy)}:uh;function uy(e){setTimeout(function(){throw e})}function ub(e){return"head"===e}function ux(e,t){var n=t,r=0;do{var o=n.nextSibling;if(e.removeChild(n),o&&8===o.nodeType)if("/$"===(n=o.data)||"/&"===n){if(0===r){e.removeChild(o),dX(t);return}r--}else if("$"===n||"$?"===n||"$~"===n||"$!"===n||"&"===n)r++;else if("html"===n)uX(e.ownerDocument.documentElement);else if("head"===n){uX(n=e.ownerDocument.head);for(var a=n.firstChild;a;){var i=a.nextSibling,l=a.nodeName;a[e0]||"SCRIPT"===l||"STYLE"===l||"LINK"===l&&"stylesheet"===a.rel.toLowerCase()||n.removeChild(a),a=i}}else"body"===n&&uX(e.ownerDocument.body);n=o}while(n);dX(t)}function uw(e,t){var n=e;e=0;do{var r=n.nextSibling;if(1===n.nodeType?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",""===n.getAttribute("style")&&n.removeAttribute("style")):3===n.nodeType&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),r&&8===r.nodeType)if("/$"===(n=r.data))if(0===e)break;else e--;else"$"!==n&&"$?"!==n&&"$~"!==n&&"$!"!==n||e++;n=r}while(n)}function u_(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,null!=n&&(e.style.viewTransitionClass=n),"inline"===(n=getComputedStyle(e)).display){if(1===(t=e.getClientRects()).length)var r=1;else for(var o=r=0;o<t.length;o++){var a=t[o];0<a.width&&0<a.height&&r++}1===r&&((e=e.style).display=1===t.length?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function uk(e,t){e=e.style;var n=null!=(t=t.style)?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=null==n||"boolean"==typeof n?"":(""+n).trim(),n=null!=t?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=null==n||"boolean"==typeof n?"":(""+n).trim(),"inline-block"===e.display&&(null==t?e.display=e.margin="":(n=t.display,e.display=null==n||"boolean"==typeof n?"":n,null!=(n=t.margin)?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=null==n||"boolean"==typeof n?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=null==t||"boolean"==typeof t?"":t)))}function uj(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:"absolute"===t.position||"fixed"===t.position,clip:"none"!==t.clipPath||"visible"!==t.overflow||"none"!==t.filter||"none"!==t.mask||"none"!==t.mask||"0px"!==t.borderRadius,view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function uS(e){return uj(e.getBoundingClientRect(),getComputedStyle(e),e)}function uO(e){var t=e.getBoundingClientRect();return uj(t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height),getComputedStyle(e),e)}function uC(e){this.addEventListener("load",e),this.addEventListener("error",e)}function uP(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}function uE(e){return{name:e,group:new uP("group",e),imagePair:new uP("image-pair",e),old:new uP("old",e),new:new uP("new",e)}}function uT(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}function uI(e,t,n,r){return h(e).addEventListener(t,n,r),!1}function uN(e,t,n,r){return h(e).removeEventListener(t,n,r),!1}function uL(e){return null==e?"0":"boolean"==typeof e?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")+"&o="+(e.once?"1":"0")+"&p="+(e.passive?"1":"0")}function uA(e,t,n,r){for(var o=0;o<e.length;o++){var a=e[o];if(a.type===t&&a.listener===n&&uL(a.optionsOrUseCapture)===uL(r))return o}return -1}function uz(e,t){var n=e=h(e),r=t;function o(){a=!0}var a=!1;try{n.addEventListener("focus",o),(n.focus||HTMLElement.prototype.focus).call(n,r)}finally{n.removeEventListener("focus",o)}return a}function uR(e,t){return t.push(e),!1}function uD(e){return(e=h(e))===e.ownerDocument.activeElement&&(e.blur(),!0)}function uM(e,t){return e=h(e),t.observe(e),!1}function uZ(e,t){return e=h(e),t.unobserve(e),!1}function uF(e,t){return e=h(e),t.push.apply(t,e.getClientRects()),!1}function uU(e,t){var n=t._eventListeners;if(null!==n)for(var r=0;r<n.length;r++){var o=n[r];e.addEventListener(o.type,o.listener,o.optionsOrUseCapture)}null!==t._observers&&t._observers.forEach(function(t){t.observe(e)})}function uH(e){var t=e.firstChild;for(t&&10===t.nodeType&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":uH(n),e1(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if("stylesheet"===n.rel.toLowerCase())continue}e.removeChild(n)}}function uV(e,t){for(;8!==e.nodeType;)if((1!==e.nodeType||"INPUT"!==e.nodeName||"hidden"!==e.type)&&!t||null===(e=uq(e.nextSibling)))return null;return e}function uB(e){return"$?"===e.data||"$~"===e.data}function u$(e){return"$!"===e.data||"$?"===e.data&&"loading"!==e.ownerDocument.readyState}function uq(e){for(;null!=e;e=e.nextSibling){var t=e.nodeType;if(1===t||3===t)break;if(8===t){if("$"===(t=e.data)||"$!"===t||"$?"===t||"$~"===t||"&"===t||"F!"===t||"F"===t)break;if("/$"===t||"/&"===t)return null}}return e}uP.prototype.animate=function(e,t){return(t="number"==typeof t?{duration:t}:_({},t)).pseudoElement=this._selector,this._scope.animate(e,t)},uP.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),r=[],o=0;o<n.length;o++){var a=n[o].effect;null!==a&&a.target===e&&a.pseudoElement===t&&r.push(n[o])}return r},uP.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)},uT.prototype.addEventListener=function(e,t,n){null===this._eventListeners&&(this._eventListeners=[]);var r=this._eventListeners;-1===uA(r,e,t,n)&&(r.push({type:e,listener:t,optionsOrUseCapture:n}),f(this._fragmentFiber.child,!1,uI,e,t,n)),this._eventListeners=r},uT.prototype.removeEventListener=function(e,t,n){var r=this._eventListeners;null!=r&&0<r.length&&(f(this._fragmentFiber.child,!1,uN,e,t,n),e=uA(r,e,t,n),null!==this._eventListeners&&this._eventListeners.splice(e,1))},uT.prototype.dispatchEvent=function(e){var t=p(this._fragmentFiber);if(null===t)return!0;t=h(t);var n=this._eventListeners;if(null!==n&&0<n.length||!e.bubbles){var r=document.createTextNode("");if(n)for(var o=0;o<n.length;o++){var a=n[o];r.addEventListener(a.type,a.listener,a.optionsOrUseCapture)}if(t.appendChild(r),e=r.dispatchEvent(e),n)for(o=0;o<n.length;o++)a=n[o],r.removeEventListener(a.type,a.listener,a.optionsOrUseCapture);return t.removeChild(r),e}return t.dispatchEvent(e)},uT.prototype.focus=function(e){f(this._fragmentFiber.child,!0,uz,e,void 0,void 0)},uT.prototype.focusLast=function(e){var t=[];f(this._fragmentFiber.child,!0,uR,t,void 0,void 0);for(var n=t.length-1;0<=n&&!uz(t[n],e);n--);},uT.prototype.blur=function(){f(this._fragmentFiber.child,!1,uD,void 0,void 0,void 0)},uT.prototype.observeUsing=function(e){null===this._observers&&(this._observers=new Set),this._observers.add(e),f(this._fragmentFiber.child,!1,uM,e,void 0,void 0)},uT.prototype.unobserveUsing=function(e){var t=this._observers;null!==t&&t.has(e)&&(t.delete(e),f(this._fragmentFiber.child,!1,uZ,e,void 0,void 0))},uT.prototype.getClientRects=function(){var e=[];return f(this._fragmentFiber.child,!1,uF,e,void 0,void 0),e},uT.prototype.getRootNode=function(e){var t=p(this._fragmentFiber);return null===t?this:h(t).getRootNode(e)},uT.prototype.compareDocumentPosition=function(e){var t=p(this._fragmentFiber);if(null===t)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];f(this._fragmentFiber.child,!1,uR,n,void 0,void 0);var r=h(t);if(0===n.length){n=this._fragmentFiber;var o=r.compareDocumentPosition(e);return t=o,r===e?t=Node.DOCUMENT_POSITION_CONTAINS:o&Node.DOCUMENT_POSITION_CONTAINED_BY&&(f(n.sibling,!1,v),n=m,m=null,t=null===n?Node.DOCUMENT_POSITION_PRECEDING:0===(e=h(n).compareDocumentPosition(e))||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING),t|Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=h(n[0]),o=h(n[n.length-1]);for(var a=h(n[0]),i=!1,l=this._fragmentFiber.return;null!==l&&(4===l.tag&&(i=!0),3!==l.tag&&5!==l.tag);)l=l.return;if(null==(a=i?a.parentElement:r))return Node.DOCUMENT_POSITION_DISCONNECTED;r=a.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,a=a.compareDocumentPosition(o)&Node.DOCUMENT_POSITION_CONTAINED_BY,i=t.compareDocumentPosition(e);var s=o.compareDocumentPosition(e);return l=i&Node.DOCUMENT_POSITION_CONTAINED_BY||s&Node.DOCUMENT_POSITION_CONTAINED_BY,s=r&&a&&i&Node.DOCUMENT_POSITION_FOLLOWING&&s&Node.DOCUMENT_POSITION_PRECEDING,(t=r&&t===e||a&&o===e||l||s?Node.DOCUMENT_POSITION_CONTAINED_BY:(r||t!==e)&&(a||o!==e)?i:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC)&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||function(e,t,n,r,o){var a=e2(o);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!a)e:{for(;null!==a;){if(7===a.tag&&(a===t||a.alternate===t)){n=!0;break e}a=a.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(null===a)return a=o.ownerDocument,o===a||o===a.body;e:{for(a=t,t=p(t);null!==a;){if((5===a.tag||3===a.tag)&&(a===t||a.alternate===t)){a=!0;break e}a=a.return}a=!1}return a}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!a)&&!(t=a===n)&&(null===(t=w(n,a,x))?t=!1:(f(t,!0,y,a,n),a=m,m=null,t=null!==a)),t):!!(e&Node.DOCUMENT_POSITION_FOLLOWING)&&((t=!!a)&&!(t=a===r)&&(null===(t=w(r,a,x))?t=!1:(f(t,!0,b,a,r),a=m,g=m=null,t=null!==a)),t)}(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC},uT.prototype.scrollIntoView=function(e){if("object"==typeof e)throw Error(l(566));var t=[];f(this._fragmentFiber.child,!1,uR,t,void 0,void 0);var n=!1!==e;if(0===t.length){t=this._fragmentFiber;var r=[null,null],o=p(t);null!==o&&function e(t,n,r){for(var o=3<arguments.length&&void 0!==arguments[3]&&arguments[3];null!==r;){if(r===n)if(o=!0,!r.sibling)return!0;else r=r.sibling;if(5===r.tag){if(o)return t[1]=r,!0;t[0]=r}else if((22!==r.tag||null===r.memoizedState)&&e(t,n,r.child,o))return!0;r=r.sibling}return!1}(r,t,o.child),null!==(n=n?r[1]||r[0]||p(this._fragmentFiber):r[0]||r[1])&&h(n).scrollIntoView(e)}else for(r=n?t.length-1:0;r!==(n?-1:t.length);)h(t[r]).scrollIntoView(e),r+=n?-1:1};var uW=null;function uK(e){e=e.nextSibling;for(var t=0;e;){if(8===e.nodeType){var n=e.data;if("/$"===n||"/&"===n){if(0===t)return uq(e.nextSibling);t--}else"$"!==n&&"$!"!==n&&"$?"!==n&&"$~"!==n&&"&"!==n||t++}e=e.nextSibling}return null}function uY(e){e=e.previousSibling;for(var t=0;e;){if(8===e.nodeType){var n=e.data;if("$"===n||"$!"===n||"$?"===n||"$~"===n||"&"===n){if(0===t)return e;t--}else"/$"!==n&&"/&"!==n||t++}e=e.previousSibling}return null}function uG(e,t,n){switch(t=uc(n),e){case"html":if(!(e=t.documentElement))throw Error(l(452));return e;case"head":if(!(e=t.head))throw Error(l(453));return e;case"body":if(!(e=t.body))throw Error(l(454));return e;default:throw Error(l(451))}}function uX(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);e1(e)}var uQ=new Map,uJ=new Set;function u0(e){return"function"==typeof e.getRootNode?e.getRootNode():9===e.nodeType?e:e.ownerDocument}var u1=$.d;$.d={f:function(){var e=u1.f(),t=cn();return e||t},r:function(e){var t=e3(e);null!==t&&5===t.tag&&"form"===t.type?ip(t):u1.r(e)},D:function(e){u1.D(e),u3("dns-prefetch",e,null)},C:function(e,t){u1.C(e,t),u3("preconnect",e,t)},L:function(e,t,n){if(u1.L(e,t,n),u2&&e&&t){var r='link[rel="preload"][as="'+tm(t)+'"]';"image"===t&&n&&n.imageSrcSet?(r+='[imagesrcset="'+tm(n.imageSrcSet)+'"]',"string"==typeof n.imageSizes&&(r+='[imagesizes="'+tm(n.imageSizes)+'"]')):r+='[href="'+tm(e)+'"]';var o=r;switch(t){case"style":o=u5(e);break;case"script":o=u8(e)}uQ.has(o)||(e=_({rel:"preload",href:"image"===t&&n&&n.imageSrcSet?void 0:e,as:t},n),uQ.set(o,e),null!==u2.querySelector(r)||"style"===t&&u2.querySelector(u6(o))||"script"===t&&u2.querySelector(u7(o))||(ua(t=u2.createElement("link"),"link",e),e6(t),u2.head.appendChild(t)))}},m:function(e,t){if(u1.m(e,t),u2&&e){var n=t&&"string"==typeof t.as?t.as:"script",r='link[rel="modulepreload"][as="'+tm(n)+'"][href="'+tm(e)+'"]',o=r;switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=u8(e)}if(!uQ.has(o)&&(e=_({rel:"modulepreload",href:e},t),uQ.set(o,e),null===u2.querySelector(r))){switch(n){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(u2.querySelector(u7(o)))return}ua(n=u2.createElement("link"),"link",e),e6(n),u2.head.appendChild(n)}}},X:function(e,t){if(u1.X(e,t),u2&&e){var n=e5(u2).hoistableScripts,r=u8(e),o=n.get(r);o||((o=u2.querySelector(u7(r)))||(e=_({src:e,async:!0},t),(t=uQ.get(r))&&dr(e,t),e6(o=u2.createElement("script")),ua(o,"link",e),u2.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(r,o))}},S:function(e,t,n){if(u1.S(e,t,n),u2&&e){var r=e5(u2).hoistableStyles,o=u5(e);t=t||"default";var a=r.get(o);if(!a){var i={loading:0,preload:null};if(a=u2.querySelector(u6(o)))i.loading=5;else{e=_({rel:"stylesheet",href:e,"data-precedence":t},n),(n=uQ.get(o))&&dn(e,n);var l=a=u2.createElement("link");e6(l),ua(l,"link",e),l._p=new Promise(function(e,t){l.onload=e,l.onerror=t}),l.addEventListener("load",function(){i.loading|=1}),l.addEventListener("error",function(){i.loading|=2}),i.loading|=4,dt(a,t,u2)}a={type:"stylesheet",instance:a,count:1,state:i},r.set(o,a)}}},M:function(e,t){if(u1.M(e,t),u2&&e){var n=e5(u2).hoistableScripts,r=u8(e),o=n.get(r);o||((o=u2.querySelector(u7(r)))||(e=_({src:e,async:!0,type:"module"},t),(t=uQ.get(r))&&dr(e,t),e6(o=u2.createElement("script")),ua(o,"link",e),u2.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},n.set(r,o))}}};var u2="undefined"==typeof document?null:document;function u3(e,t,n){if(u2&&"string"==typeof t&&t){var r=tm(t);r='link[rel="'+e+'"][href="'+r+'"]',"string"==typeof n&&(r+='[crossorigin="'+n+'"]'),uJ.has(r)||(uJ.add(r),e={rel:e,crossOrigin:n,href:t},null===u2.querySelector(r)&&(ua(t=u2.createElement("link"),"link",e),e6(t),u2.head.appendChild(t)))}}function u4(e,t,n,r){var o=(o=ee.current)?u0(o):null;if(!o)throw Error(l(446));switch(e){case"meta":case"title":return null;case"style":return"string"==typeof n.precedence&&"string"==typeof n.href?(t=u5(n.href),(r=(n=e5(o).hoistableStyles).get(t))||(r={type:"style",instance:null,count:0,state:null},n.set(t,r)),r):{type:"void",instance:null,count:0,state:null};case"link":if("stylesheet"===n.rel&&"string"==typeof n.href&&"string"==typeof n.precedence){e=u5(n.href);var a,i,s,c,u=e5(o).hoistableStyles,d=u.get(e);if(d||(o=o.ownerDocument||o,d={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},u.set(e,d),(u=o.querySelector(u6(e)))&&!u._p&&(d.instance=u,d.state.loading=5),uQ.has(e)||(n={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},uQ.set(e,n),u||(a=o,i=e,s=n,c=d.state,a.querySelector('link[rel="preload"][as="style"]['+i+"]")?c.loading=1:(c.preload=i=a.createElement("link"),i.addEventListener("load",function(){return c.loading|=1}),i.addEventListener("error",function(){return c.loading|=2}),ua(i,"link",s),e6(i),a.head.appendChild(i))))),t&&null===r)throw Error(l(528,""));return d}if(t&&null!==r)throw Error(l(529,""));return null;case"script":return t=n.async,"string"==typeof(n=n.src)&&t&&"function"!=typeof t&&"symbol"!=typeof t?(t=u8(n),(r=(n=e5(o).hoistableScripts).get(t))||(r={type:"script",instance:null,count:0,state:null},n.set(t,r)),r):{type:"void",instance:null,count:0,state:null};default:throw Error(l(444,e))}}function u5(e){return'href="'+tm(e)+'"'}function u6(e){return'link[rel="stylesheet"]['+e+"]"}function u9(e){return _({},e,{"data-precedence":e.precedence,precedence:null})}function u8(e){return'[src="'+tm(e)+'"]'}function u7(e){return"script[async]"+e}function de(e,t,n){if(t.count++,null===t.instance)switch(t.type){case"style":var r=e.querySelector('style[data-href~="'+tm(n.href)+'"]');if(r)return t.instance=r,e6(r),r;var o=_({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return e6(r=(e.ownerDocument||e).createElement("style")),ua(r,"style",o),dt(r,n.precedence,e),t.instance=r;case"stylesheet":o=u5(n.href);var a=e.querySelector(u6(o));if(a)return t.state.loading|=4,t.instance=a,e6(a),a;r=u9(n),(o=uQ.get(o))&&dn(r,o),e6(a=(e.ownerDocument||e).createElement("link"));var i=a;return i._p=new Promise(function(e,t){i.onload=e,i.onerror=t}),ua(a,"link",r),t.state.loading|=4,dt(a,n.precedence,e),t.instance=a;case"script":if(a=u8(n.src),o=e.querySelector(u7(a)))return t.instance=o,e6(o),o;return r=n,(o=uQ.get(a))&&dr(r=_({},n),o),e6(o=(e=e.ownerDocument||e).createElement("script")),ua(o,"link",r),e.head.appendChild(o),t.instance=o;case"void":return null;default:throw Error(l(443,t.type))}return"stylesheet"===t.type&&0==(4&t.state.loading)&&(r=t.instance,t.state.loading|=4,dt(r,n.precedence,e)),t.instance}function dt(e,t,n){for(var r=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),o=r.length?r[r.length-1]:null,a=o,i=0;i<r.length;i++){var l=r[i];if(l.dataset.precedence===t)a=l;else if(a!==o)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=9===n.nodeType?n.head:n).insertBefore(e,t.firstChild)}function dn(e,t){null==e.crossOrigin&&(e.crossOrigin=t.crossOrigin),null==e.referrerPolicy&&(e.referrerPolicy=t.referrerPolicy),null==e.title&&(e.title=t.title)}function dr(e,t){null==e.crossOrigin&&(e.crossOrigin=t.crossOrigin),null==e.referrerPolicy&&(e.referrerPolicy=t.referrerPolicy),null==e.integrity&&(e.integrity=t.integrity)}var da=null;function di(e,t,n){if(null===da){var r=new Map,o=da=new Map;o.set(n,r)}else(r=(o=da).get(n))||(r=new Map,o.set(n,r));if(r.has(e))return r;for(r.set(e,null),n=n.getElementsByTagName(e),o=0;o<n.length;o++){var a=n[o];if(!(a[e0]||a[eW]||"link"===e&&"stylesheet"===a.getAttribute("rel"))&&"http://www.w3.org/2000/svg"!==a.namespaceURI){var i=a.getAttribute(t)||"";i=e+i;var l=r.get(i);l?l.push(a):r.set(i,[a])}}return r}function dl(e,t,n){(e=e.ownerDocument||e).head.insertBefore(n,"title"===t?e.querySelector("head > title"):null)}function ds(e,t){return"img"===e&&null!=t.src&&""!==t.src&&null==t.onLoad&&"lazy"!==t.loading}function dc(e){return"stylesheet"!==e.type||0!=(3&e.state.loading)}function du(e){return(e.width||100)*(e.height||100)*("number"==typeof devicePixelRatio?devicePixelRatio:1)*.25}function dd(e,t){"function"==typeof t.decode&&(e.imgCount++,t.complete||(e.imgBytes+=du(t),e.suspenseyImages.push(t)),e=dm.bind(e),t.decode().then(e,e))}var df=0;function dp(e){if(0===e.count&&(0===e.imgCount||!e.waitingForImages)){if(e.stylesheets)dv(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function dh(){this.count--,dp(this)}function dm(){this.imgCount--,dp(this)}var dg=null;function dv(e,t){e.stylesheets=null,null!==e.unsuspend&&(e.count++,dg=new Map,t.forEach(dy,e),dg=null,dh.call(e))}function dy(e,t){if(!(4&t.state.loading)){var n=dg.get(e);if(n)var r=n.get(null);else{n=new Map,dg.set(e,n);for(var o=e.querySelectorAll("link[data-precedence],style[data-precedence]"),a=0;a<o.length;a++){var i=o[a];("LINK"===i.nodeName||"not all"!==i.getAttribute("media"))&&(n.set(i.dataset.precedence,i),r=i)}r&&n.set(null,r)}i=(o=t.instance).getAttribute("data-precedence"),(a=n.get(i)||r)===r&&n.set(null,o),n.set(i,o),this.count++,r=dh.bind(this),o.addEventListener("load",r),o.addEventListener("error",r),a?a.parentNode.insertBefore(o,a.nextSibling):(e=9===e.nodeType?e.head:e).insertBefore(o,e.firstChild),t.state.loading|=4}}var db={$$typeof:T,Provider:null,Consumer:null,_currentValue:q,_currentValue2:q,_threadCount:0};function dx(e,t,n,r,o,a,i,l,s){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=eD(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=eD(0),this.hiddenUpdates=eD(null),this.identifierPrefix=r,this.onUncaughtError=o,this.onCaughtError=a,this.onRecoverableError=i,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=s,this.transitionTypes=null,this.incompleteTransitions=new Map}function dw(e,t,n,r,o,a){o=o?rg:rg,null===r.context?r.context=o:r.pendingContext=o,(r=oB(t)).payload={element:n},null!==(a=void 0===a?null:a)&&(r.callback=a),null!==(n=o$(e,r,t))&&(s8(n,e,t),oq(n,e,t))}function d_(e,t){if(null!==(e=e.memoizedState)&&null!==e.dehydrated){var n=e.retryLane;e.retryLane=0!==n&&n<t?n:t}}function dk(e,t){d_(e,t),(e=e.alternate)&&d_(e,t)}function dj(e){if(13===e.tag||31===e.tag){var t=rp(e,0x4000000);null!==t&&s8(t,e,0x4000000),dk(e,0x4000000)}}function dS(e){if(13===e.tag||31===e.tag){var t=s5(),n=rp(e,t=eH(t));null!==n&&s8(n,e,t),dk(e,t)}}var dO=!0;function dC(e,t,n,r){var o=B.T;B.T=null;var a=$.p;try{$.p=2,dE(e,t,n,r)}finally{$.p=a,B.T=o}}function dP(e,t,n,r){var o=B.T;B.T=null;var a=$.p;try{$.p=8,dE(e,t,n,r)}finally{$.p=a,B.T=o}}function dE(e,t,n,r){if(dO){var o=dT(r);if(null===o)c4(e,t,r,dI,n),dH(e,r);else if(function(e,t,n,r,o){switch(t){case"focusin":return dz=dV(dz,e,t,n,r,o),!0;case"dragenter":return dR=dV(dR,e,t,n,r,o),!0;case"mouseover":return dD=dV(dD,e,t,n,r,o),!0;case"pointerover":var a=o.pointerId;return dM.set(a,dV(dM.get(a)||null,e,t,n,r,o)),!0;case"gotpointercapture":return a=o.pointerId,dZ.set(a,dV(dZ.get(a)||null,e,t,n,r,o)),!0}return!1}(o,e,t,n,r))r.stopPropagation();else if(dH(e,r),4&t&&-1<dU.indexOf(e)){for(;null!==o;){var a=e3(o);if(null!==a)switch(a.tag){case 3:if((a=a.stateNode).current.memoizedState.isDehydrated){var i=eL(a.pendingLanes);if(0!==i){var l=a;for(l.pendingLanes|=2,l.entangledLanes|=2;i;){var s=1<<31-eC(i);l.entanglements[1]|=s,i&=~s}cM(a),0==(6&sk)&&(sB=em()+500,cZ(0,!1))}}break;case 31:case 13:null!==(l=rp(a,2))&&s8(l,a,2),cn(),dk(a,2)}if(null===(a=dT(r))&&c4(e,t,r,dI,n),a===o)break;o=a}null!==o&&r.stopPropagation()}else c4(e,t,r,null,n)}}function dT(e){return dN(e=tN(e))}var dI=null;function dN(e){if(dI=null,null!==(e=e2(e))){var t=s(e);if(null===t)e=null;else{var n=t.tag;if(13===n){if(null!==(e=c(t)))return e;e=null}else if(31===n){if(null!==(e=u(t)))return e;e=null}else if(3===n){if(t.stateNode.current.memoizedState.isDehydrated)return 3===t.tag?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return dI=e,null}function dL(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(eg()){case ev:return 2;case ey:return 8;case eb:case ex:return 32;case ew:return 0x10000000;default:return 32}default:return 32}}var dA=!1,dz=null,dR=null,dD=null,dM=new Map,dZ=new Map,dF=[],dU="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function dH(e,t){switch(e){case"focusin":case"focusout":dz=null;break;case"dragenter":case"dragleave":dR=null;break;case"mouseover":case"mouseout":dD=null;break;case"pointerover":case"pointerout":dM.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":dZ.delete(t.pointerId)}}function dV(e,t,n,r,o,a){return null===e||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[o]},null!==t&&null!==(t=e3(t))&&dj(t)):(e.eventSystemFlags|=r,t=e.targetContainers,null!==o&&-1===t.indexOf(o)&&t.push(o)),e}function dB(e){var t=e2(e.target);if(null!==t){var n=s(t);if(null!==n){if(13===(t=n.tag)){if(null!==(t=c(n))){e.blockedOn=t,e$(e.priority,function(){dS(n)});return}}else if(31===t){if(null!==(t=u(n))){e.blockedOn=t,e$(e.priority,function(){dS(n)});return}}else if(3===t&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=3===n.tag?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function d$(e){if(null!==e.blockedOn)return!1;for(var t=e.targetContainers;0<t.length;){var n=dT(e.nativeEvent);if(null!==n)return null!==(t=e3(n))&&dj(t),e.blockedOn=n,!1;var r=new(n=e.nativeEvent).constructor(n.type,n);tI=r,n.target.dispatchEvent(r),tI=null,t.shift()}return!0}function dq(e,t,n){d$(e)&&n.delete(t)}function dW(){dA=!1,null!==dz&&d$(dz)&&(dz=null),null!==dR&&d$(dR)&&(dR=null),null!==dD&&d$(dD)&&(dD=null),dM.forEach(dq),dZ.forEach(dq)}function dK(e,t){e.blockedOn===t&&(e.blockedOn=null,dA||(dA=!0,o.unstable_scheduleCallback(o.unstable_NormalPriority,dW)))}var dY=null;function dG(e){dY!==e&&(dY=e,o.unstable_scheduleCallback(o.unstable_NormalPriority,function(){dY===e&&(dY=null);for(var t=0;t<e.length;t+=3){var n=e[t],r=e[t+1],o=e[t+2];if("function"!=typeof r)if(null===dN(r||n))continue;else break;var a=e3(n);null!==a&&(e.splice(t,3),t-=3,iu(a,{pending:!0,data:o,method:n.method,action:r},r,o))}}))}function dX(e){function t(t){return dK(t,e)}null!==dz&&dK(dz,e),null!==dR&&dK(dR,e),null!==dD&&dK(dD,e),dM.forEach(t),dZ.forEach(t);for(var n=0;n<dF.length;n++){var r=dF[n];r.blockedOn===e&&(r.blockedOn=null)}for(;0<dF.length&&null===(n=dF[0]).blockedOn;)dB(n),null===n.blockedOn&&dF.shift();if(null!=(n=(e.ownerDocument||e).$$reactFormReplay))for(r=0;r<n.length;r+=3){var o=n[r],a=n[r+1],i=o[eK]||null;if("function"==typeof a)i||dG(n);else if(i){var l=null;if(a&&a.hasAttribute("formAction")){if(o=a,i=a[eK]||null)l=i.formAction;else if(null!==dN(o))continue}else l=i.action;"function"==typeof l?n[r+1]=l:(n.splice(r,3),r-=3),dG(n)}}}function dQ(){function e(e){e.canIntercept&&"react-transition"===e.info&&e.intercept({handler:function(){return new Promise(function(e){return o=e})},focusReset:"manual",scroll:"manual"})}function t(){null!==o&&(o(),o=null),r||setTimeout(n,20)}function n(){if(!r&&!navigation.transition){var e=navigation.currentEntry;e&&null!=e.url&&navigation.navigate(e.url,{state:e.getState(),info:"react-transition",history:"replace"})}}if("object"==typeof navigation){var r=!1,o=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){r=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),null!==o&&(o(),o=null)}}}function dJ(e){this._internalRoot=e}function d0(e){this._internalRoot=e}d0.prototype.render=dJ.prototype.render=function(e){var t=this._internalRoot;if(null===t)throw Error(l(409));dw(t.current,s5(),e,t,null,null)},d0.prototype.unmount=dJ.prototype.unmount=function(){var e=this._internalRoot;if(null!==e){this._internalRoot=null;var t=e.containerInfo;dw(e.current,2,null,e,null,null),cn(),t[eY]=null}},d0.prototype.unstable_scheduleHydration=function(e){if(e){var t=eB();e={blockedOn:null,target:e,priority:t};for(var n=0;n<dF.length&&0!==t&&t<dF[n].priority;n++);dF.splice(n,0,e),0===n&&dB(e)}};var d1=a.version;if("19.3.0-canary-52684925-20251110"!==d1)throw Error(l(527,d1,"19.3.0-canary-52684925-20251110"));if($.findDOMNode=function(e){var t=e._reactInternals;if(void 0===t){if("function"==typeof e.render)throw Error(l(188));throw Error(l(268,e=Object.keys(e).join(",")))}return null===(e=null!==(e=function(e){var t=e.alternate;if(!t){if(null===(t=s(e)))throw Error(l(188));return t!==e?null:e}for(var n=e,r=t;;){var o=n.return;if(null===o)break;var a=o.alternate;if(null===a){if(null!==(r=o.return)){n=r;continue}break}if(o.child===a.child){for(a=o.child;a;){if(a===n)return d(o),e;if(a===r)return d(o),t;a=a.sibling}throw Error(l(188))}if(n.return!==r.return)n=o,r=a;else{for(var i=!1,c=o.child;c;){if(c===n){i=!0,n=o,r=a;break}if(c===r){i=!0,r=o,n=a;break}c=c.sibling}if(!i){for(c=a.child;c;){if(c===n){i=!0,n=a,r=o;break}if(c===r){i=!0,r=a,n=o;break}c=c.sibling}if(!i)throw Error(l(189))}}if(n.alternate!==r)throw Error(l(190))}if(3!==n.tag)throw Error(l(188));return n.stateNode.current===n?e:t}(t))?function e(t){var n=t.tag;if(5===n||26===n||27===n||6===n)return t;for(t=t.child;null!==t;){if(null!==(n=e(t)))return n;t=t.sibling}return null}(e):null)?null:e.stateNode},"undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var d2=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!d2.isDisabled&&d2.supportsFiber)try{ej=d2.inject({bundleType:0,version:"19.3.0-canary-52684925-20251110",rendererPackageName:"react-dom",currentDispatcherRef:B,reconcilerVersion:"19.3.0-canary-52684925-20251110"}),eS=d2}catch(e){}}t.createRoot=function(e,t){if(!(n=e)||1!==n.nodeType&&9!==n.nodeType&&11!==n.nodeType)throw Error(l(299));var n,r,o,a,i,s,c,u,d=!1,f="",p=iA,h=iz,m=iR;return null!=t&&(!0===t.unstable_strictMode&&(d=!0),void 0!==t.identifierPrefix&&(f=t.identifierPrefix),void 0!==t.onUncaughtError&&(p=t.onUncaughtError),void 0!==t.onCaughtError&&(h=t.onCaughtError),void 0!==t.onRecoverableError&&(m=t.onRecoverableError)),r=e,o=1,a=!1,i=null,s=0,c=d,u=null,r=new dx(r,o,a,f,p,h,m,dQ,null),o=1,!0===c&&(o|=24),c=ry(3,null,null,o),r.current=c,c.stateNode=r,o=oc(),o.refCount++,r.pooledCache=o,o.refCount++,c.memoizedState={element:null,isDehydrated:a,cache:o},oH(c),t=r,e[eY]=t.current,c2(e),new dJ(t)}},"./dist/compiled/react-dom/cjs/react-dom.production.js":function(e,t,n){"use strict";var r=n("./dist/compiled/react/index.js");function o(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function a(){}var i={d:{f:a,r:function(){throw Error(o(522))},D:a,C:a,L:a,m:a,X:a,S:a,M:a},p:0,findDOMNode:null},l=Symbol.for("react.portal"),s=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function c(e,t){return"font"===e?"":"string"==typeof t?"use-credentials"===t?t:"":void 0}t.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,t.createPortal=function(e,t){var n=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!t||1!==t.nodeType&&9!==t.nodeType&&11!==t.nodeType)throw Error(o(299));return function(e,t,n){var r=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:l,key:null==r?null:""+r,children:e,containerInfo:t,implementation:n}}(e,t,null,n)},t.flushSync=function(e){var t=s.T,n=i.p;try{if(s.T=null,i.p=2,e)return e()}finally{s.T=t,i.p=n,i.d.f()}},t.preconnect=function(e,t){"string"==typeof e&&(t=t?"string"==typeof(t=t.crossOrigin)?"use-credentials"===t?t:"":void 0:null,i.d.C(e,t))},t.prefetchDNS=function(e){"string"==typeof e&&i.d.D(e)},t.preinit=function(e,t){if("string"==typeof e&&t&&"string"==typeof t.as){var n=t.as,r=c(n,t.crossOrigin),o="string"==typeof t.integrity?t.integrity:void 0,a="string"==typeof t.fetchPriority?t.fetchPriority:void 0;"style"===n?i.d.S(e,"string"==typeof t.precedence?t.precedence:void 0,{crossOrigin:r,integrity:o,fetchPriority:a}):"script"===n&&i.d.X(e,{crossOrigin:r,integrity:o,fetchPriority:a,nonce:"string"==typeof t.nonce?t.nonce:void 0})}},t.preinitModule=function(e,t){if("string"==typeof e)if("object"==typeof t&&null!==t){if(null==t.as||"script"===t.as){var n=c(t.as,t.crossOrigin);i.d.M(e,{crossOrigin:n,integrity:"string"==typeof t.integrity?t.integrity:void 0,nonce:"string"==typeof t.nonce?t.nonce:void 0})}}else null==t&&i.d.M(e)},t.preload=function(e,t){if("string"==typeof e&&"object"==typeof t&&null!==t&&"string"==typeof t.as){var n=t.as,r=c(n,t.crossOrigin);i.d.L(e,n,{crossOrigin:r,integrity:"string"==typeof t.integrity?t.integrity:void 0,nonce:"string"==typeof t.nonce?t.nonce:void 0,type:"string"==typeof t.type?t.type:void 0,fetchPriority:"string"==typeof t.fetchPriority?t.fetchPriority:void 0,referrerPolicy:"string"==typeof t.referrerPolicy?t.referrerPolicy:void 0,imageSrcSet:"string"==typeof t.imageSrcSet?t.imageSrcSet:void 0,imageSizes:"string"==typeof t.imageSizes?t.imageSizes:void 0,media:"string"==typeof t.media?t.media:void 0})}},t.preloadModule=function(e,t){if("string"==typeof e)if(t){var n=c(t.as,t.crossOrigin);i.d.m(e,{as:"string"==typeof t.as&&"script"!==t.as?t.as:void 0,crossOrigin:n,integrity:"string"==typeof t.integrity?t.integrity:void 0})}else i.d.m(e)},t.requestFormReset=function(e){i.d.r(e)},t.unstable_batchedUpdates=function(e,t){return e(t)},t.useFormState=function(e,t,n){return s.H.useFormState(e,t,n)},t.useFormStatus=function(){return s.H.useHostTransitionStatus()},t.version="19.3.0-canary-52684925-20251110"},"./dist/compiled/react-dom/client.js":function(e,t,n){"use strict";!function e(){if("undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(e){console.error(e)}}(),e.exports=n("./dist/compiled/react-dom/cjs/react-dom-client.production.js")},"./dist/compiled/react-dom/index.js":function(e,t,n){"use strict";!function e(){if("undefined"!=typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(e){console.error(e)}}(),e.exports=n("./dist/compiled/react-dom/cjs/react-dom.production.js")},"./dist/compiled/react/cjs/react-compiler-runtime.production.js":function(e,t,n){"use strict";var r=n("./dist/compiled/react/index.js").__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;t.c=function(e){return r.H.useMemoCache(e)}},"./dist/compiled/react/cjs/react-jsx-runtime.production.js":function(e,t){"use strict";var n=Symbol.for("react.transitional.element");function r(e,t,r){var o=null;if(void 0!==r&&(o=""+r),void 0!==t.key&&(o=""+t.key),"key"in t)for(var a in r={},t)"key"!==a&&(r[a]=t[a]);else r=t;return{$$typeof:n,type:e,key:o,ref:void 0!==(t=r.ref)?t:null,props:r}}t.Fragment=Symbol.for("react.fragment"),t.jsx=r,t.jsxs=r},"./dist/compiled/react/cjs/react.production.js":function(e,t){"use strict";var n=Symbol.for("react.transitional.element"),r=Symbol.for("react.portal"),o=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),i=Symbol.for("react.profiler"),l=Symbol.for("react.consumer"),s=Symbol.for("react.context"),c=Symbol.for("react.forward_ref"),u=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),f=Symbol.for("react.lazy"),p=Symbol.for("react.activity"),h=Symbol.for("react.view_transition"),m=Symbol.iterator,g={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},v=Object.assign,y={};function b(e,t,n){this.props=e,this.context=t,this.refs=y,this.updater=n||g}function x(){}function w(e,t,n){this.props=e,this.context=t,this.refs=y,this.updater=n||g}b.prototype.isReactComponent={},b.prototype.setState=function(e,t){if("object"!=typeof e&&"function"!=typeof e&&null!=e)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},b.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},x.prototype=b.prototype;var _=w.prototype=new x;_.constructor=w,v(_,b.prototype),_.isPureReactComponent=!0;var k=Array.isArray;function j(){}var S={H:null,A:null,T:null,S:null},O=Object.prototype.hasOwnProperty;function C(e,t,r){var o=r.ref;return{$$typeof:n,type:e,key:t,ref:void 0!==o?o:null,props:r}}function P(e){return"object"==typeof e&&null!==e&&e.$$typeof===n}var E=/\/+/g;function T(e,t){var n,r;return"object"==typeof e&&null!==e&&null!=e.key?(n=""+e.key,r={"=":"=0",":":"=2"},"$"+n.replace(/[=:]/g,function(e){return r[e]})):t.toString(36)}function I(e,t,o){if(null==e)return e;var a=[],i=0;return!function e(t,o,a,i,l){var s,c,u,d=typeof t;("undefined"===d||"boolean"===d)&&(t=null);var p=!1;if(null===t)p=!0;else switch(d){case"bigint":case"string":case"number":p=!0;break;case"object":switch(t.$$typeof){case n:case r:p=!0;break;case f:return e((p=t._init)(t._payload),o,a,i,l)}}if(p)return l=l(t),p=""===i?"."+T(t,0):i,k(l)?(a="",null!=p&&(a=p.replace(E,"$&/")+"/"),e(l,o,a,"",function(e){return e})):null!=l&&(P(l)&&(s=l,c=a+(null==l.key||t&&t.key===l.key?"":(""+l.key).replace(E,"$&/")+"/")+p,l=C(s.type,c,s.props)),o.push(l)),1;p=0;var h=""===i?".":i+":";if(k(t))for(var g=0;g<t.length;g++)d=h+T(i=t[g],g),p+=e(i,o,a,d,l);else if("function"==typeof(g=null===(u=t)||"object"!=typeof u?null:"function"==typeof(u=m&&u[m]||u["@@iterator"])?u:null))for(t=g.call(t),g=0;!(i=t.next()).done;)d=h+T(i=i.value,g++),p+=e(i,o,a,d,l);else if("object"===d){if("function"==typeof t.then)return e(function(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch("string"==typeof e.status?e.then(j,j):(e.status="pending",e.then(function(t){"pending"===e.status&&(e.status="fulfilled",e.value=t)},function(t){"pending"===e.status&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}(t),o,a,i,l);throw Error("Objects are not valid as a React child (found: "+("[object Object]"===(o=String(t))?"object with keys {"+Object.keys(t).join(", ")+"}":o)+"). If you meant to render a collection of children, use an array instead.")}return p}(e,a,"","",function(e){return t.call(o,e,i++)}),a}function N(e){if(-1===e._status){var t=e._result;(t=t()).then(function(t){(0===e._status||-1===e._status)&&(e._status=1,e._result=t)},function(t){(0===e._status||-1===e._status)&&(e._status=2,e._result=t)}),-1===e._status&&(e._status=0,e._result=t)}if(1===e._status)return e._result.default;throw e._result}var L="function"==typeof reportError?reportError:function(e){if("object"==typeof window&&"function"==typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"==typeof e&&null!==e&&"string"==typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"==typeof process&&"function"==typeof process.emit)return void process.emit("uncaughtException",e);console.error(e)};function A(e){var t=S.T,n={};n.types=null!==t?t.types:null,S.T=n;try{var r=e(),o=S.S;null!==o&&o(n,r),"object"==typeof r&&null!==r&&"function"==typeof r.then&&r.then(j,L)}catch(e){L(e)}finally{null!==t&&null!==n.types&&(t.types=n.types),S.T=t}}function z(e){var t=S.T;if(null!==t){var n=t.types;null===n?t.types=[e]:-1===n.indexOf(e)&&n.push(e)}else A(z.bind(null,e))}t.Activity=p,t.Children={map:I,forEach:function(e,t,n){I(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return I(e,function(){t++}),t},toArray:function(e){return I(e,function(e){return e})||[]},only:function(e){if(!P(e))throw Error("React.Children.only expected to receive a single React element child.");return e}},t.Component=b,t.Fragment=o,t.Profiler=i,t.PureComponent=w,t.StrictMode=a,t.Suspense=u,t.ViewTransition=h,t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=S,t.__COMPILER_RUNTIME={__proto__:null,c:function(e){return S.H.useMemoCache(e)}},t.addTransitionType=z,t.cache=function(e){return function(){return e.apply(null,arguments)}},t.cacheSignal=function(){return null},t.cloneElement=function(e,t,n){if(null==e)throw Error("The argument must be a React element, but you passed "+e+".");var r=v({},e.props),o=e.key;if(null!=t)for(a in void 0!==t.key&&(o=""+t.key),t)O.call(t,a)&&"key"!==a&&"__self"!==a&&"__source"!==a&&("ref"!==a||void 0!==t.ref)&&(r[a]=t[a]);var a=arguments.length-2;if(1===a)r.children=n;else if(1<a){for(var i=Array(a),l=0;l<a;l++)i[l]=arguments[l+2];r.children=i}return C(e.type,o,r)},t.createContext=function(e){return(e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider=e,e.Consumer={$$typeof:l,_context:e},e},t.createElement=function(e,t,n){var r,o={},a=null;if(null!=t)for(r in void 0!==t.key&&(a=""+t.key),t)O.call(t,r)&&"key"!==r&&"__self"!==r&&"__source"!==r&&(o[r]=t[r]);var i=arguments.length-2;if(1===i)o.children=n;else if(1<i){for(var l=Array(i),s=0;s<i;s++)l[s]=arguments[s+2];o.children=l}if(e&&e.defaultProps)for(r in i=e.defaultProps)void 0===o[r]&&(o[r]=i[r]);return C(e,a,o)},t.createRef=function(){return{current:null}},t.forwardRef=function(e){return{$$typeof:c,render:e}},t.isValidElement=P,t.lazy=function(e){return{$$typeof:f,_payload:{_status:-1,_result:e},_init:N}},t.memo=function(e,t){return{$$typeof:d,type:e,compare:void 0===t?null:t}},t.startTransition=A,t.unstable_useCacheRefresh=function(){return S.H.useCacheRefresh()},t.use=function(e){return S.H.use(e)},t.useActionState=function(e,t,n){return S.H.useActionState(e,t,n)},t.useCallback=function(e,t){return S.H.useCallback(e,t)},t.useContext=function(e){return S.H.useContext(e)},t.useDebugValue=function(){},t.useDeferredValue=function(e,t){return S.H.useDeferredValue(e,t)},t.useEffect=function(e,t){return S.H.useEffect(e,t)},t.useEffectEvent=function(e){return S.H.useEffectEvent(e)},t.useId=function(){return S.H.useId()},t.useImperativeHandle=function(e,t,n){return S.H.useImperativeHandle(e,t,n)},t.useInsertionEffect=function(e,t){return S.H.useInsertionEffect(e,t)},t.useLayoutEffect=function(e,t){return S.H.useLayoutEffect(e,t)},t.useMemo=function(e,t){return S.H.useMemo(e,t)},t.useOptimistic=function(e,t){return S.H.useOptimistic(e,t)},t.useReducer=function(e,t,n){return S.H.useReducer(e,t,n)},t.useRef=function(e){return S.H.useRef(e)},t.useState=function(e){return S.H.useState(e)},t.useSyncExternalStore=function(e,t,n){return S.H.useSyncExternalStore(e,t,n)},t.useTransition=function(){return S.H.useTransition()},t.version="19.3.0-canary-52684925-20251110"},"./dist/compiled/react/compiler-runtime.js":function(e,t,n){"use strict";e.exports=n("./dist/compiled/react/cjs/react-compiler-runtime.production.js")},"./dist/compiled/react/index.js":function(e,t,n){"use strict";e.exports=n("./dist/compiled/react/cjs/react.production.js")},"./dist/compiled/react/jsx-runtime.js":function(e,t,n){"use strict";e.exports=n("./dist/compiled/react/cjs/react-jsx-runtime.production.js")},"./dist/compiled/scheduler/cjs/scheduler.production.js":function(e,t){"use strict";function n(e,t){var n=e.length;for(e.push(t);0<n;){var r=n-1>>>1,o=e[r];if(0<a(o,t))e[r]=t,e[n]=o,n=r;else break}}function r(e){return 0===e.length?null:e[0]}function o(e){if(0===e.length)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;for(var r=0,o=e.length,i=o>>>1;r<i;){var l=2*(r+1)-1,s=e[l],c=l+1,u=e[c];if(0>a(s,n))c<o&&0>a(u,s)?(e[r]=u,e[c]=n,r=c):(e[r]=s,e[l]=n,r=l);else if(c<o&&0>a(u,n))e[r]=u,e[c]=n,r=c;else break}}return t}function a(e,t){var n=e.sortIndex-t.sortIndex;return 0!==n?n:e.id-t.id}if(t.unstable_now=void 0,"object"==typeof performance&&"function"==typeof performance.now){var i,l=performance;t.unstable_now=function(){return l.now()}}else{var s=Date,c=s.now();t.unstable_now=function(){return s.now()-c}}var u=[],d=[],f=1,p=null,h=3,m=!1,g=!1,v=!1,y=!1,b="function"==typeof setTimeout?setTimeout:null,x="function"==typeof clearTimeout?clearTimeout:null,w="undefined"!=typeof setImmediate?setImmediate:null;function _(e){for(var t=r(d);null!==t;){if(null===t.callback)o(d);else if(t.startTime<=e)o(d),t.sortIndex=t.expirationTime,n(u,t);else break;t=r(d)}}function k(e){if(v=!1,_(e),!g)if(null!==r(u))g=!0,j||(j=!0,i());else{var t=r(d);null!==t&&N(k,t.startTime-e)}}var j=!1,S=-1,O=5,C=-1;function P(){return!!y||!(t.unstable_now()-C<O)}function E(){if(y=!1,j){var e=t.unstable_now();C=e;var n=!0;try{e:{g=!1,v&&(v=!1,x(S),S=-1),m=!0;var a=h;try{t:{for(_(e),p=r(u);null!==p&&!(p.expirationTime>e&&P());){var l=p.callback;if("function"==typeof l){p.callback=null,h=p.priorityLevel;var s=l(p.expirationTime<=e);if(e=t.unstable_now(),"function"==typeof s){p.callback=s,_(e),n=!0;break t}p===r(u)&&o(u),_(e)}else o(u);p=r(u)}if(null!==p)n=!0;else{var c=r(d);null!==c&&N(k,c.startTime-e),n=!1}}break e}finally{p=null,h=a,m=!1}}}finally{n?i():j=!1}}}if("function"==typeof w)i=function(){w(E)};else if("undefined"!=typeof MessageChannel){var T=new MessageChannel,I=T.port2;T.port1.onmessage=E,i=function(){I.postMessage(null)}}else i=function(){b(E,0)};function N(e,n){S=b(function(){e(t.unstable_now())},n)}t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(e){e.callback=null},t.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):O=0<e?Math.floor(1e3/e):5},t.unstable_getCurrentPriorityLevel=function(){return h},t.unstable_next=function(e){switch(h){case 1:case 2:case 3:var t=3;break;default:t=h}var n=h;h=t;try{return e()}finally{h=n}},t.unstable_requestPaint=function(){y=!0},t.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=h;h=e;try{return t()}finally{h=n}},t.unstable_scheduleCallback=function(e,o,a){var l=t.unstable_now();switch(a="object"==typeof a&&null!==a&&"number"==typeof(a=a.delay)&&0<a?l+a:l,e){case 1:var s=-1;break;case 2:s=250;break;case 5:s=0x3fffffff;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,e={id:f++,callback:o,priorityLevel:e,startTime:a,expirationTime:s,sortIndex:-1},a>l?(e.sortIndex=a,n(d,e),null===r(u)&&e===r(d)&&(v?(x(S),S=-1):v=!0,N(k,a-l))):(e.sortIndex=s,n(u,e),g||m||(g=!0,j||(j=!0,i()))),e},t.unstable_shouldYield=P,t.unstable_wrapCallback=function(e){var t=h;return function(){var n=h;h=t;try{return e.apply(this,arguments)}finally{h=n}}}},"./dist/compiled/scheduler/index.js":function(e,t,n){"use strict";e.exports=n("./dist/compiled/scheduler/cjs/scheduler.production.js")},"./dist/compiled/stacktrace-parser/stack-trace-parser.cjs.js":function(e){(()=>{"use strict";"undefined"!=typeof __nccwpck_require__&&(__nccwpck_require__.ab="//");var t,n,r,o,a,i,l,s,c={};Object.defineProperty(c,"__esModule",{value:!0}),t="<unknown>",n=/^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|webpack-internal|rsc|about|turbopack|<anonymous>|\/|[a-z]:\\|\\\\).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,r=/\((\S*)(?::(\d+))(?::(\d+))\)/,o=/^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|webpack-internal|rsc|about|turbopack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i,a=/^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|webpack-internal|rsc|about|turbopack|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i,i=/(\S+) line (\d+)(?: > eval line \d+)* > eval/i,l=/^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?):(\d+)(?::(\d+))?\s*$/i,s=/^\s*at (?:((?:\[object object\])?[^\\/]+(?: \[as \S+\])?) )?\(?(.*?):(\d+)(?::(\d+))?\)?\s*$/i,c.parse=function(e){return e.split("\n").reduce(function(e,c){var u,d,f,p,h,m,g=function(e){var o=n.exec(e);if(!o)return null;var a=o[2]&&0===o[2].indexOf("native"),i=o[2]&&0===o[2].indexOf("eval"),l=r.exec(o[2]);return i&&null!=l&&(o[2]=l[1],o[3]=l[2],o[4]=l[3]),{file:a?null:o[2],methodName:o[1]||t,arguments:a?[o[2]]:[],lineNumber:o[3]?+o[3]:null,column:o[4]?+o[4]:null}}(c)||(u=c,(d=o.exec(u))?{file:d[2],methodName:d[1]||t,arguments:[],lineNumber:+d[3],column:d[4]?+d[4]:null}:null)||function(e){var n=a.exec(e);if(!n)return null;var r=n[3]&&n[3].indexOf(" > eval")>-1,o=i.exec(n[3]);return r&&null!=o&&(n[3]=o[1],n[4]=o[2],n[5]=null),{file:n[3],methodName:n[1]||t,arguments:n[2]?n[2].split(","):[],lineNumber:n[4]?+n[4]:null,column:n[5]?+n[5]:null}}(c)||(f=c,(p=s.exec(f))?{file:p[2],methodName:p[1]||t,arguments:[],lineNumber:+p[3],column:p[4]?+p[4]:null}:null)||(h=c,(m=l.exec(h))?{file:m[3],methodName:m[1]||t,arguments:[],lineNumber:+m[4],column:m[5]?+m[5]:null}:null);return g&&e.push(g),e},[])},e.exports=c})()},"./dist/compiled/strip-ansi/index.js":function(e){(()=>{"use strict";var t={511:e=>{e.exports=({onlyFirst:e=!1}={})=>RegExp("[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))",e?void 0:"g")},532:(e,t,n)=>{let r=n(511);e.exports=e=>"string"==typeof e?e.replace(r(),""):e}},n={};function r(e){var o=n[e];if(void 0!==o)return o.exports;var a=n[e]={exports:{}},i=!0;try{t[e](a,a.exports,r),i=!1}finally{i&&delete n[e]}return a.exports}r.ab="//",e.exports=r(532)})()},"./src/build/webpack/loaders/devtool/devtool-style-inject.js":function(e){function t(){let e=window._nextjsDevtoolsStyleCache;if(e.cachedShadowRoot)return e.cachedShadowRoot;let t=document.querySelector("nextjs-portal"),n=t?.shadowRoot||null;return n&&(e.cachedShadowRoot=n),n}function n(e,t){let n=window._nextjsDevtoolsStyleCache;n.lastInsertedElement?n.lastInsertedElement.nextSibling?t.insertBefore(e,n.lastInsertedElement.nextSibling):t.appendChild(e):t.insertBefore(e,t.firstChild),n.lastInsertedElement=e}function r(){let e=window._nextjsDevtoolsStyleCache,r=t();r&&(e.pendingElements.forEach(e=>{n(e,r)}),e.pendingElements=[])}"undefined"!=typeof window&&(window._nextjsDevtoolsStyleCache=window._nextjsDevtoolsStyleCache||{pendingElements:[],isObserving:!1,lastInsertedElement:null,cachedShadowRoot:null}),e.exports=function(e){e.setAttribute("data-nextjs-dev-tool-style","true");let o=t();o?n(e,o):(window._nextjsDevtoolsStyleCache.pendingElements.push(e),function(){let e=window._nextjsDevtoolsStyleCache;if(e.isObserving)return;if(e.isObserving=!0,t())return r();let n=new MutationObserver(o=>{if(0!==o.length){for(let a of o)if(0!==a.addedNodes.length)for(let o of a.addedNodes){if(o.nodeType!==Node.ELEMENT_NODE)continue;let a=null;if("SCRIPT"===o.tagName&&o.getAttribute("data-nextjs-dev-overlay")?a=o.firstChild:"NEXTJS-PORTAL"===o.tagName&&(a=o),a){let o=()=>{t()?(r(),n.disconnect(),e.isObserving=!1):setTimeout(o,20)};o();return}}}});n.observe(document.body,{childList:!0,subtree:!0})}())}},"./dist/compiled/zod/index.cjs":function(e){(()=>{"use strict";var t={629:function(e,t,n){var r=this&&this.__createBinding||(Object.create?function(e,t,n,r){void 0===r&&(r=n);var o=Object.getOwnPropertyDescriptor(t,n);(!o||("get"in o?!t.__esModule:o.writable||o.configurable))&&(o={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,o)}:function(e,t,n,r){void 0===r&&(r=n),e[r]=t[n]}),o=this&&this.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),a=this&&this.__importStar||function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)"default"!==n&&Object.prototype.hasOwnProperty.call(e,n)&&r(t,e,n);return o(t,e),t},i=this&&this.__exportStar||function(e,t){for(var n in e)"default"===n||Object.prototype.hasOwnProperty.call(t,n)||r(t,e,n)};Object.defineProperty(t,"__esModule",{value:!0}),t.z=void 0;let l=a(n(923));t.z=l,i(n(923),t),t.default=l},348:(e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),t.ZodError=t.quotelessJson=t.ZodIssueCode=void 0;let r=n(709);t.ZodIssueCode=r.util.arrayToEnum(["invalid_type","invalid_literal","custom","invalid_union","invalid_union_discriminator","invalid_enum_value","unrecognized_keys","invalid_arguments","invalid_return_type","invalid_date","invalid_string","too_small","too_big","invalid_intersection_types","not_multiple_of","not_finite"]),t.quotelessJson=e=>JSON.stringify(e,null,2).replace(/"([^"]+)":/g,"$1:");class o extends Error{get errors(){return this.issues}constructor(e){super(),this.issues=[],this.addIssue=e=>{this.issues=[...this.issues,e]},this.addIssues=(e=[])=>{this.issues=[...this.issues,...e]};const t=new.target.prototype;Object.setPrototypeOf?Object.setPrototypeOf(this,t):this.__proto__=t,this.name="ZodError",this.issues=e}format(e){let t=e||function(e){return e.message},n={_errors:[]},r=e=>{for(let o of e.issues)if("invalid_union"===o.code)o.unionErrors.map(r);else if("invalid_return_type"===o.code)r(o.returnTypeError);else if("invalid_arguments"===o.code)r(o.argumentsError);else if(0===o.path.length)n._errors.push(t(o));else{let e=n,r=0;for(;r<o.path.length;){let n=o.path[r];r===o.path.length-1?(e[n]=e[n]||{_errors:[]},e[n]._errors.push(t(o))):e[n]=e[n]||{_errors:[]},e=e[n],r++}}};return r(this),n}static assert(e){if(!(e instanceof o))throw Error(`Not a ZodError: ${e}`)}toString(){return this.message}get message(){return JSON.stringify(this.issues,r.util.jsonStringifyReplacer,2)}get isEmpty(){return 0===this.issues.length}flatten(e=e=>e.message){let t={},n=[];for(let r of this.issues)if(r.path.length>0){let n=r.path[0];t[n]=t[n]||[],t[n].push(e(r))}else n.push(e(r));return{formErrors:n,fieldErrors:t}}get formErrors(){return this.flatten()}}t.ZodError=o,o.create=e=>new o(e)},61:function(e,t,n){var r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.defaultErrorMap=void 0,t.setErrorMap=function(e){a=e},t.getErrorMap=function(){return a};let o=r(n(871));t.defaultErrorMap=o.default;let a=o.default},923:function(e,t,n){var r=this&&this.__createBinding||(Object.create?function(e,t,n,r){void 0===r&&(r=n);var o=Object.getOwnPropertyDescriptor(t,n);(!o||("get"in o?!t.__esModule:o.writable||o.configurable))&&(o={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,o)}:function(e,t,n,r){void 0===r&&(r=n),e[r]=t[n]}),o=this&&this.__exportStar||function(e,t){for(var n in e)"default"===n||Object.prototype.hasOwnProperty.call(t,n)||r(t,e,n)};Object.defineProperty(t,"__esModule",{value:!0}),o(n(61),t),o(n(818),t),o(n(515),t),o(n(709),t),o(n(155),t),o(n(348),t)},538:(e,t)=>{var n,r;Object.defineProperty(t,"__esModule",{value:!0}),t.errorUtil=void 0,(r=n||(t.errorUtil=n={})).errToObj=e=>"string"==typeof e?{message:e}:e||{},r.toString=e=>"string"==typeof e?e:e?.message},818:function(e,t,n){var r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.isAsync=t.isValid=t.isDirty=t.isAborted=t.OK=t.DIRTY=t.INVALID=t.ParseStatus=t.EMPTY_PATH=t.makeIssue=void 0,t.addIssueToContext=function(e,n){let r=(0,o.getErrorMap)(),i=(0,t.makeIssue)({issueData:n,data:e.data,path:e.path,errorMaps:[e.common.contextualErrorMap,e.schemaErrorMap,r,r===a.default?void 0:a.default].filter(e=>!!e)});e.common.issues.push(i)};let o=n(61),a=r(n(871));t.makeIssue=e=>{let{data:t,path:n,errorMaps:r,issueData:o}=e,a=[...n,...o.path||[]],i={...o,path:a};if(void 0!==o.message)return{...o,path:a,message:o.message};let l="";for(let e of r.filter(e=>!!e).slice().reverse())l=e(i,{data:t,defaultError:l}).message;return{...o,path:a,message:l}},t.EMPTY_PATH=[];class i{constructor(){this.value="valid"}dirty(){"valid"===this.value&&(this.value="dirty")}abort(){"aborted"!==this.value&&(this.value="aborted")}static mergeArray(e,n){let r=[];for(let o of n){if("aborted"===o.status)return t.INVALID;"dirty"===o.status&&e.dirty(),r.push(o.value)}return{status:e.value,value:r}}static async mergeObjectAsync(e,t){let n=[];for(let e of t){let t=await e.key,r=await e.value;n.push({key:t,value:r})}return i.mergeObjectSync(e,n)}static mergeObjectSync(e,n){let r={};for(let o of n){let{key:n,value:a}=o;if("aborted"===n.status||"aborted"===a.status)return t.INVALID;"dirty"===n.status&&e.dirty(),"dirty"===a.status&&e.dirty(),"__proto__"!==n.value&&(void 0!==a.value||o.alwaysSet)&&(r[n.value]=a.value)}return{status:e.value,value:r}}}t.ParseStatus=i,t.INVALID=Object.freeze({status:"aborted"}),t.DIRTY=e=>({status:"dirty",value:e}),t.OK=e=>({status:"valid",value:e}),t.isAborted=e=>"aborted"===e.status,t.isDirty=e=>"dirty"===e.status,t.isValid=e=>"valid"===e.status,t.isAsync=e=>"undefined"!=typeof Promise&&e instanceof Promise},515:(e,t)=>{Object.defineProperty(t,"__esModule",{value:!0})},709:(e,t)=>{var n,r,o;Object.defineProperty(t,"__esModule",{value:!0}),t.getParsedType=t.ZodParsedType=t.objectUtil=t.util=void 0,(o=n||(t.util=n={})).assertEqual=e=>{},o.assertIs=function(e){},o.assertNever=function(e){throw Error()},o.arrayToEnum=e=>{let t={};for(let n of e)t[n]=n;return t},o.getValidEnumValues=e=>{let t=o.objectKeys(e).filter(t=>"number"!=typeof e[e[t]]),n={};for(let r of t)n[r]=e[r];return o.objectValues(n)},o.objectValues=e=>o.objectKeys(e).map(function(t){return e[t]}),o.objectKeys="function"==typeof Object.keys?e=>Object.keys(e):e=>{let t=[];for(let n in e)Object.prototype.hasOwnProperty.call(e,n)&&t.push(n);return t},o.find=(e,t)=>{for(let n of e)if(t(n))return n},o.isInteger="function"==typeof Number.isInteger?e=>Number.isInteger(e):e=>"number"==typeof e&&Number.isFinite(e)&&Math.floor(e)===e,o.joinValues=function(e,t=" | "){return e.map(e=>"string"==typeof e?`'${e}'`:e).join(t)},o.jsonStringifyReplacer=(e,t)=>"bigint"==typeof t?t.toString():t,(r||(t.objectUtil=r={})).mergeShapes=(e,t)=>({...e,...t}),t.ZodParsedType=n.arrayToEnum(["string","nan","number","integer","float","boolean","date","bigint","symbol","function","undefined","null","array","object","unknown","promise","void","never","map","set"]),t.getParsedType=e=>{switch(typeof e){case"undefined":return t.ZodParsedType.undefined;case"string":return t.ZodParsedType.string;case"number":return Number.isNaN(e)?t.ZodParsedType.nan:t.ZodParsedType.number;case"boolean":return t.ZodParsedType.boolean;case"function":return t.ZodParsedType.function;case"bigint":return t.ZodParsedType.bigint;case"symbol":return t.ZodParsedType.symbol;case"object":if(Array.isArray(e))return t.ZodParsedType.array;if(null===e)return t.ZodParsedType.null;if(e.then&&"function"==typeof e.then&&e.catch&&"function"==typeof e.catch)return t.ZodParsedType.promise;if("undefined"!=typeof Map&&e instanceof Map)return t.ZodParsedType.map;if("undefined"!=typeof Set&&e instanceof Set)return t.ZodParsedType.set;if("undefined"!=typeof Date&&e instanceof Date)return t.ZodParsedType.date;return t.ZodParsedType.object;default:return t.ZodParsedType.unknown}}},871:(e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0});let r=n(348),o=n(709);t.default=(e,t)=>{let n;switch(e.code){case r.ZodIssueCode.invalid_type:n=e.received===o.ZodParsedType.undefined?"Required":`Expected ${e.expected}, received ${e.received}`;break;case r.ZodIssueCode.invalid_literal:n=`Invalid literal value, expected ${JSON.stringify(e.expected,o.util.jsonStringifyReplacer)}`;break;case r.ZodIssueCode.unrecognized_keys:n=`Unrecognized key(s) in object: ${o.util.joinValues(e.keys,", ")}`;break;case r.ZodIssueCode.invalid_union:n="Invalid input";break;case r.ZodIssueCode.invalid_union_discriminator:n=`Invalid discriminator value. Expected ${o.util.joinValues(e.options)}`;break;case r.ZodIssueCode.invalid_enum_value:n=`Invalid enum value. Expected ${o.util.joinValues(e.options)}, received '${e.received}'`;break;case r.ZodIssueCode.invalid_arguments:n="Invalid function arguments";break;case r.ZodIssueCode.invalid_return_type:n="Invalid function return type";break;case r.ZodIssueCode.invalid_date:n="Invalid date";break;case r.ZodIssueCode.invalid_string:"object"==typeof e.validation?"includes"in e.validation?(n=`Invalid input: must include "${e.validation.includes}"`,"number"==typeof e.validation.position&&(n=`${n} at one or more positions greater than or equal to ${e.validation.position}`)):"startsWith"in e.validation?n=`Invalid input: must start with "${e.validation.startsWith}"`:"endsWith"in e.validation?n=`Invalid input: must end with "${e.validation.endsWith}"`:o.util.assertNever(e.validation):n="regex"!==e.validation?`Invalid ${e.validation}`:"Invalid";break;case r.ZodIssueCode.too_small:n="array"===e.type?`Array must contain ${e.exact?"exactly":e.inclusive?"at least":"more than"} ${e.minimum} element(s)`:"string"===e.type?`String must contain ${e.exact?"exactly":e.inclusive?"at least":"over"} ${e.minimum} character(s)`:"number"===e.type||"bigint"===e.type?`Number must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${e.minimum}`:"date"===e.type?`Date must be ${e.exact?"exactly equal to ":e.inclusive?"greater than or equal to ":"greater than "}${new Date(Number(e.minimum))}`:"Invalid input";break;case r.ZodIssueCode.too_big:n="array"===e.type?`Array must contain ${e.exact?"exactly":e.inclusive?"at most":"less than"} ${e.maximum} element(s)`:"string"===e.type?`String must contain ${e.exact?"exactly":e.inclusive?"at most":"under"} ${e.maximum} character(s)`:"number"===e.type?`Number must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:"bigint"===e.type?`BigInt must be ${e.exact?"exactly":e.inclusive?"less than or equal to":"less than"} ${e.maximum}`:"date"===e.type?`Date must be ${e.exact?"exactly":e.inclusive?"smaller than or equal to":"smaller than"} ${new Date(Number(e.maximum))}`:"Invalid input";break;case r.ZodIssueCode.custom:n="Invalid input";break;case r.ZodIssueCode.invalid_intersection_types:n="Intersection results could not be merged";break;case r.ZodIssueCode.not_multiple_of:n=`Number must be a multiple of ${e.multipleOf}`;break;case r.ZodIssueCode.not_finite:n="Number must be finite";break;default:n=t.defaultError,o.util.assertNever(e)}return{message:n}}},155:(e,t,n)=>{var r,o;let a;Object.defineProperty(t,"__esModule",{value:!0}),t.discriminatedUnion=t.date=t.boolean=t.bigint=t.array=t.any=t.coerce=t.ZodFirstPartyTypeKind=t.late=t.ZodSchema=t.Schema=t.ZodReadonly=t.ZodPipeline=t.ZodBranded=t.BRAND=t.ZodNaN=t.ZodCatch=t.ZodDefault=t.ZodNullable=t.ZodOptional=t.ZodTransformer=t.ZodEffects=t.ZodPromise=t.ZodNativeEnum=t.ZodEnum=t.ZodLiteral=t.ZodLazy=t.ZodFunction=t.ZodSet=t.ZodMap=t.ZodRecord=t.ZodTuple=t.ZodIntersection=t.ZodDiscriminatedUnion=t.ZodUnion=t.ZodObject=t.ZodArray=t.ZodVoid=t.ZodNever=t.ZodUnknown=t.ZodAny=t.ZodNull=t.ZodUndefined=t.ZodSymbol=t.ZodDate=t.ZodBoolean=t.ZodBigInt=t.ZodNumber=t.ZodString=t.ZodType=void 0,t.NEVER=t.void=t.unknown=t.union=t.undefined=t.tuple=t.transformer=t.symbol=t.string=t.strictObject=t.set=t.record=t.promise=t.preprocess=t.pipeline=t.ostring=t.optional=t.onumber=t.oboolean=t.object=t.number=t.nullable=t.null=t.never=t.nativeEnum=t.nan=t.map=t.literal=t.lazy=t.intersection=t.instanceof=t.function=t.enum=t.effect=void 0,t.datetimeRegex=N,t.custom=ey;let i=n(348),l=n(61),s=n(538),c=n(818),u=n(709);class d{constructor(e,t,n,r){this._cachedPath=[],this.parent=e,this.data=t,this._path=n,this._key=r}get path(){return this._cachedPath.length||(Array.isArray(this._key)?this._cachedPath.push(...this._path,...this._key):this._cachedPath.push(...this._path,this._key)),this._cachedPath}}let f=(e,t)=>{if((0,c.isValid)(t))return{success:!0,data:t.value};if(!e.common.issues.length)throw Error("Validation failed but no issues detected.");return{success:!1,get error(){if(this._error)return this._error;let t=new i.ZodError(e.common.issues);return this._error=t,this._error}}};function p(e){if(!e)return{};let{errorMap:t,invalid_type_error:n,required_error:r,description:o}=e;if(t&&(n||r))throw Error('Can\'t use "invalid_type_error" or "required_error" in conjunction with custom error map.');return t?{errorMap:t,description:o}:{errorMap:(t,o)=>{let{message:a}=e;return"invalid_enum_value"===t.code?{message:a??o.defaultError}:void 0===o.data?{message:a??r??o.defaultError}:"invalid_type"!==t.code?{message:o.defaultError}:{message:a??n??o.defaultError}},description:o}}class h{get description(){return this._def.description}_getType(e){return(0,u.getParsedType)(e.data)}_getOrReturnCtx(e,t){return t||{common:e.parent.common,data:e.data,parsedType:(0,u.getParsedType)(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}_processInputParams(e){return{status:new c.ParseStatus,ctx:{common:e.parent.common,data:e.data,parsedType:(0,u.getParsedType)(e.data),schemaErrorMap:this._def.errorMap,path:e.path,parent:e.parent}}}_parseSync(e){let t=this._parse(e);if((0,c.isAsync)(t))throw Error("Synchronous parse encountered promise.");return t}_parseAsync(e){return Promise.resolve(this._parse(e))}parse(e,t){let n=this.safeParse(e,t);if(n.success)return n.data;throw n.error}safeParse(e,t){let n={common:{issues:[],async:t?.async??!1,contextualErrorMap:t?.errorMap},path:t?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:(0,u.getParsedType)(e)},r=this._parseSync({data:e,path:n.path,parent:n});return f(n,r)}"~validate"(e){let t={common:{issues:[],async:!!this["~standard"].async},path:[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:(0,u.getParsedType)(e)};if(!this["~standard"].async)try{let n=this._parseSync({data:e,path:[],parent:t});return(0,c.isValid)(n)?{value:n.value}:{issues:t.common.issues}}catch(e){e?.message?.toLowerCase()?.includes("encountered")&&(this["~standard"].async=!0),t.common={issues:[],async:!0}}return this._parseAsync({data:e,path:[],parent:t}).then(e=>(0,c.isValid)(e)?{value:e.value}:{issues:t.common.issues})}async parseAsync(e,t){let n=await this.safeParseAsync(e,t);if(n.success)return n.data;throw n.error}async safeParseAsync(e,t){let n={common:{issues:[],contextualErrorMap:t?.errorMap,async:!0},path:t?.path||[],schemaErrorMap:this._def.errorMap,parent:null,data:e,parsedType:(0,u.getParsedType)(e)},r=this._parse({data:e,path:n.path,parent:n});return f(n,await ((0,c.isAsync)(r)?r:Promise.resolve(r)))}refine(e,t){return this._refinement((n,r)=>{let o=e(n),a=()=>r.addIssue({code:i.ZodIssueCode.custom,..."string"==typeof t||void 0===t?{message:t}:"function"==typeof t?t(n):t});return"undefined"!=typeof Promise&&o instanceof Promise?o.then(e=>!!e||(a(),!1)):!!o||(a(),!1)})}refinement(e,t){return this._refinement((n,r)=>!!e(n)||(r.addIssue("function"==typeof t?t(n,r):t),!1))}_refinement(e){return new es({schema:this,typeName:r.ZodEffects,effect:{type:"refinement",refinement:e}})}superRefine(e){return this._refinement(e)}constructor(e){this.spa=this.safeParseAsync,this._def=e,this.parse=this.parse.bind(this),this.safeParse=this.safeParse.bind(this),this.parseAsync=this.parseAsync.bind(this),this.safeParseAsync=this.safeParseAsync.bind(this),this.spa=this.spa.bind(this),this.refine=this.refine.bind(this),this.refinement=this.refinement.bind(this),this.superRefine=this.superRefine.bind(this),this.optional=this.optional.bind(this),this.nullable=this.nullable.bind(this),this.nullish=this.nullish.bind(this),this.array=this.array.bind(this),this.promise=this.promise.bind(this),this.or=this.or.bind(this),this.and=this.and.bind(this),this.transform=this.transform.bind(this),this.brand=this.brand.bind(this),this.default=this.default.bind(this),this.catch=this.catch.bind(this),this.describe=this.describe.bind(this),this.pipe=this.pipe.bind(this),this.readonly=this.readonly.bind(this),this.isNullable=this.isNullable.bind(this),this.isOptional=this.isOptional.bind(this),this["~standard"]={version:1,vendor:"zod",validate:e=>this["~validate"](e)}}optional(){return ec.create(this,this._def)}nullable(){return eu.create(this,this._def)}nullish(){return this.nullable().optional()}array(){return $.create(this)}promise(){return el.create(this,this._def)}or(e){return W.create([this,e],this._def)}and(e){return G.create(this,e,this._def)}transform(e){return new es({...p(this._def),schema:this,typeName:r.ZodEffects,effect:{type:"transform",transform:e}})}default(e){return new ed({...p(this._def),innerType:this,defaultValue:"function"==typeof e?e:()=>e,typeName:r.ZodDefault})}brand(){return new eh({typeName:r.ZodBranded,type:this,...p(this._def)})}catch(e){return new ef({...p(this._def),innerType:this,catchValue:"function"==typeof e?e:()=>e,typeName:r.ZodCatch})}describe(e){return new this.constructor({...this._def,description:e})}pipe(e){return em.create(this,e)}readonly(){return eg.create(this)}isOptional(){return this.safeParse(void 0).success}isNullable(){return this.safeParse(null).success}}t.ZodType=h,t.Schema=h,t.ZodSchema=h;let m=/^c[^\s-]{8,}$/i,g=/^[0-9a-z]+$/,v=/^[0-9A-HJKMNP-TV-Z]{26}$/i,y=/^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i,b=/^[a-z0-9_-]{21}$/i,x=/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/,w=/^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/,_=/^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i,k=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,j=/^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,S=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/,O=/^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,C=/^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,P=/^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,E="((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))",T=RegExp(`^${E}$`);function I(e){let t="[0-5]\\d";e.precision?t=`${t}\\.\\d{${e.precision}}`:null==e.precision&&(t=`${t}(\\.\\d+)?`);let n=e.precision?"+":"?";return`([01]\\d|2[0-3]):[0-5]\\d(:${t})${n}`}function N(e){let t=`${E}T${I(e)}`,n=[];return n.push(e.local?"Z?":"Z"),e.offset&&n.push("([+-]\\d{2}:?\\d{2})"),t=`${t}(${n.join("|")})`,RegExp(`^${t}$`)}class L extends h{_parse(e){var t,n,r,o;let l;if(this._def.coerce&&(e.data=String(e.data)),this._getType(e)!==u.ZodParsedType.string){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.string,received:t.parsedType}),c.INVALID}let s=new c.ParseStatus;for(let d of this._def.checks)if("min"===d.kind)e.data.length<d.value&&(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.too_small,minimum:d.value,type:"string",inclusive:!0,exact:!1,message:d.message}),s.dirty());else if("max"===d.kind)e.data.length>d.value&&(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.too_big,maximum:d.value,type:"string",inclusive:!0,exact:!1,message:d.message}),s.dirty());else if("length"===d.kind){let t=e.data.length>d.value,n=e.data.length<d.value;(t||n)&&(l=this._getOrReturnCtx(e,l),t?(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.too_big,maximum:d.value,type:"string",inclusive:!0,exact:!0,message:d.message}):n&&(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.too_small,minimum:d.value,type:"string",inclusive:!0,exact:!0,message:d.message}),s.dirty())}else if("email"===d.kind)_.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"email",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty());else if("emoji"===d.kind)a||(a=RegExp("^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$","u")),a.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"emoji",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty());else if("uuid"===d.kind)y.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"uuid",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty());else if("nanoid"===d.kind)b.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"nanoid",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty());else if("cuid"===d.kind)m.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"cuid",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty());else if("cuid2"===d.kind)g.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"cuid2",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty());else if("ulid"===d.kind)v.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"ulid",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty());else if("url"===d.kind)try{new URL(e.data)}catch{l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"url",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty()}else"regex"===d.kind?(d.regex.lastIndex=0,d.regex.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"regex",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty())):"trim"===d.kind?e.data=e.data.trim():"includes"===d.kind?e.data.includes(d.value,d.position)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.invalid_string,validation:{includes:d.value,position:d.position},message:d.message}),s.dirty()):"toLowerCase"===d.kind?e.data=e.data.toLowerCase():"toUpperCase"===d.kind?e.data=e.data.toUpperCase():"startsWith"===d.kind?e.data.startsWith(d.value)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.invalid_string,validation:{startsWith:d.value},message:d.message}),s.dirty()):"endsWith"===d.kind?e.data.endsWith(d.value)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.invalid_string,validation:{endsWith:d.value},message:d.message}),s.dirty()):"datetime"===d.kind?N(d).test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.invalid_string,validation:"datetime",message:d.message}),s.dirty()):"date"===d.kind?T.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.invalid_string,validation:"date",message:d.message}),s.dirty()):"time"===d.kind?RegExp(`^${I(d)}$`).test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{code:i.ZodIssueCode.invalid_string,validation:"time",message:d.message}),s.dirty()):"duration"===d.kind?w.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"duration",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty()):"ip"===d.kind?(t=e.data,!(("v4"===(n=d.version)||!n)&&k.test(t)||("v6"===n||!n)&&S.test(t))&&1&&(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"ip",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty())):"jwt"===d.kind?!function(e,t){if(!x.test(e))return!1;try{let[n]=e.split(".");if(!n)return!1;let r=n.replace(/-/g,"+").replace(/_/g,"/").padEnd(n.length+(4-n.length%4)%4,"="),o=JSON.parse(atob(r));if("object"!=typeof o||null===o||"typ"in o&&o?.typ!=="JWT"||!o.alg||t&&o.alg!==t)return!1;return!0}catch{return!1}}(e.data,d.alg)&&(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"jwt",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty()):"cidr"===d.kind?(r=e.data,!(("v4"===(o=d.version)||!o)&&j.test(r)||("v6"===o||!o)&&O.test(r))&&1&&(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"cidr",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty())):"base64"===d.kind?C.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"base64",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty()):"base64url"===d.kind?P.test(e.data)||(l=this._getOrReturnCtx(e,l),(0,c.addIssueToContext)(l,{validation:"base64url",code:i.ZodIssueCode.invalid_string,message:d.message}),s.dirty()):u.util.assertNever(d);return{status:s.value,value:e.data}}_regex(e,t,n){return this.refinement(t=>e.test(t),{validation:t,code:i.ZodIssueCode.invalid_string,...s.errorUtil.errToObj(n)})}_addCheck(e){return new L({...this._def,checks:[...this._def.checks,e]})}email(e){return this._addCheck({kind:"email",...s.errorUtil.errToObj(e)})}url(e){return this._addCheck({kind:"url",...s.errorUtil.errToObj(e)})}emoji(e){return this._addCheck({kind:"emoji",...s.errorUtil.errToObj(e)})}uuid(e){return this._addCheck({kind:"uuid",...s.errorUtil.errToObj(e)})}nanoid(e){return this._addCheck({kind:"nanoid",...s.errorUtil.errToObj(e)})}cuid(e){return this._addCheck({kind:"cuid",...s.errorUtil.errToObj(e)})}cuid2(e){return this._addCheck({kind:"cuid2",...s.errorUtil.errToObj(e)})}ulid(e){return this._addCheck({kind:"ulid",...s.errorUtil.errToObj(e)})}base64(e){return this._addCheck({kind:"base64",...s.errorUtil.errToObj(e)})}base64url(e){return this._addCheck({kind:"base64url",...s.errorUtil.errToObj(e)})}jwt(e){return this._addCheck({kind:"jwt",...s.errorUtil.errToObj(e)})}ip(e){return this._addCheck({kind:"ip",...s.errorUtil.errToObj(e)})}cidr(e){return this._addCheck({kind:"cidr",...s.errorUtil.errToObj(e)})}datetime(e){return"string"==typeof e?this._addCheck({kind:"datetime",precision:null,offset:!1,local:!1,message:e}):this._addCheck({kind:"datetime",precision:void 0===e?.precision?null:e?.precision,offset:e?.offset??!1,local:e?.local??!1,...s.errorUtil.errToObj(e?.message)})}date(e){return this._addCheck({kind:"date",message:e})}time(e){return"string"==typeof e?this._addCheck({kind:"time",precision:null,message:e}):this._addCheck({kind:"time",precision:void 0===e?.precision?null:e?.precision,...s.errorUtil.errToObj(e?.message)})}duration(e){return this._addCheck({kind:"duration",...s.errorUtil.errToObj(e)})}regex(e,t){return this._addCheck({kind:"regex",regex:e,...s.errorUtil.errToObj(t)})}includes(e,t){return this._addCheck({kind:"includes",value:e,position:t?.position,...s.errorUtil.errToObj(t?.message)})}startsWith(e,t){return this._addCheck({kind:"startsWith",value:e,...s.errorUtil.errToObj(t)})}endsWith(e,t){return this._addCheck({kind:"endsWith",value:e,...s.errorUtil.errToObj(t)})}min(e,t){return this._addCheck({kind:"min",value:e,...s.errorUtil.errToObj(t)})}max(e,t){return this._addCheck({kind:"max",value:e,...s.errorUtil.errToObj(t)})}length(e,t){return this._addCheck({kind:"length",value:e,...s.errorUtil.errToObj(t)})}nonempty(e){return this.min(1,s.errorUtil.errToObj(e))}trim(){return new L({...this._def,checks:[...this._def.checks,{kind:"trim"}]})}toLowerCase(){return new L({...this._def,checks:[...this._def.checks,{kind:"toLowerCase"}]})}toUpperCase(){return new L({...this._def,checks:[...this._def.checks,{kind:"toUpperCase"}]})}get isDatetime(){return!!this._def.checks.find(e=>"datetime"===e.kind)}get isDate(){return!!this._def.checks.find(e=>"date"===e.kind)}get isTime(){return!!this._def.checks.find(e=>"time"===e.kind)}get isDuration(){return!!this._def.checks.find(e=>"duration"===e.kind)}get isEmail(){return!!this._def.checks.find(e=>"email"===e.kind)}get isURL(){return!!this._def.checks.find(e=>"url"===e.kind)}get isEmoji(){return!!this._def.checks.find(e=>"emoji"===e.kind)}get isUUID(){return!!this._def.checks.find(e=>"uuid"===e.kind)}get isNANOID(){return!!this._def.checks.find(e=>"nanoid"===e.kind)}get isCUID(){return!!this._def.checks.find(e=>"cuid"===e.kind)}get isCUID2(){return!!this._def.checks.find(e=>"cuid2"===e.kind)}get isULID(){return!!this._def.checks.find(e=>"ulid"===e.kind)}get isIP(){return!!this._def.checks.find(e=>"ip"===e.kind)}get isCIDR(){return!!this._def.checks.find(e=>"cidr"===e.kind)}get isBase64(){return!!this._def.checks.find(e=>"base64"===e.kind)}get isBase64url(){return!!this._def.checks.find(e=>"base64url"===e.kind)}get minLength(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return e}get maxLength(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return e}}t.ZodString=L,L.create=e=>new L({checks:[],typeName:r.ZodString,coerce:e?.coerce??!1,...p(e)});class A extends h{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte,this.step=this.multipleOf}_parse(e){let t;if(this._def.coerce&&(e.data=Number(e.data)),this._getType(e)!==u.ZodParsedType.number){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.number,received:t.parsedType}),c.INVALID}let n=new c.ParseStatus;for(let r of this._def.checks)"int"===r.kind?u.util.isInteger(e.data)||(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:"integer",received:"float",message:r.message}),n.dirty()):"min"===r.kind?(r.inclusive?e.data<r.value:e.data<=r.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,minimum:r.value,type:"number",inclusive:r.inclusive,exact:!1,message:r.message}),n.dirty()):"max"===r.kind?(r.inclusive?e.data>r.value:e.data>=r.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,maximum:r.value,type:"number",inclusive:r.inclusive,exact:!1,message:r.message}),n.dirty()):"multipleOf"===r.kind?0!==function(e,t){let n=(e.toString().split(".")[1]||"").length,r=(t.toString().split(".")[1]||"").length,o=n>r?n:r;return Number.parseInt(e.toFixed(o).replace(".",""))%Number.parseInt(t.toFixed(o).replace(".",""))/10**o}(e.data,r.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.not_multiple_of,multipleOf:r.value,message:r.message}),n.dirty()):"finite"===r.kind?Number.isFinite(e.data)||(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.not_finite,message:r.message}),n.dirty()):u.util.assertNever(r);return{status:n.value,value:e.data}}gte(e,t){return this.setLimit("min",e,!0,s.errorUtil.toString(t))}gt(e,t){return this.setLimit("min",e,!1,s.errorUtil.toString(t))}lte(e,t){return this.setLimit("max",e,!0,s.errorUtil.toString(t))}lt(e,t){return this.setLimit("max",e,!1,s.errorUtil.toString(t))}setLimit(e,t,n,r){return new A({...this._def,checks:[...this._def.checks,{kind:e,value:t,inclusive:n,message:s.errorUtil.toString(r)}]})}_addCheck(e){return new A({...this._def,checks:[...this._def.checks,e]})}int(e){return this._addCheck({kind:"int",message:s.errorUtil.toString(e)})}positive(e){return this._addCheck({kind:"min",value:0,inclusive:!1,message:s.errorUtil.toString(e)})}negative(e){return this._addCheck({kind:"max",value:0,inclusive:!1,message:s.errorUtil.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:0,inclusive:!0,message:s.errorUtil.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:0,inclusive:!0,message:s.errorUtil.toString(e)})}multipleOf(e,t){return this._addCheck({kind:"multipleOf",value:e,message:s.errorUtil.toString(t)})}finite(e){return this._addCheck({kind:"finite",message:s.errorUtil.toString(e)})}safe(e){return this._addCheck({kind:"min",inclusive:!0,value:Number.MIN_SAFE_INTEGER,message:s.errorUtil.toString(e)})._addCheck({kind:"max",inclusive:!0,value:Number.MAX_SAFE_INTEGER,message:s.errorUtil.toString(e)})}get minValue(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return e}get maxValue(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return e}get isInt(){return!!this._def.checks.find(e=>"int"===e.kind||"multipleOf"===e.kind&&u.util.isInteger(e.value))}get isFinite(){let e=null,t=null;for(let n of this._def.checks)if("finite"===n.kind||"int"===n.kind||"multipleOf"===n.kind)return!0;else"min"===n.kind?(null===t||n.value>t)&&(t=n.value):"max"===n.kind&&(null===e||n.value<e)&&(e=n.value);return Number.isFinite(t)&&Number.isFinite(e)}}t.ZodNumber=A,A.create=e=>new A({checks:[],typeName:r.ZodNumber,coerce:e?.coerce||!1,...p(e)});class z extends h{constructor(){super(...arguments),this.min=this.gte,this.max=this.lte}_parse(e){let t;if(this._def.coerce)try{e.data=BigInt(e.data)}catch{return this._getInvalidInput(e)}if(this._getType(e)!==u.ZodParsedType.bigint)return this._getInvalidInput(e);let n=new c.ParseStatus;for(let r of this._def.checks)"min"===r.kind?(r.inclusive?e.data<r.value:e.data<=r.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,type:"bigint",minimum:r.value,inclusive:r.inclusive,message:r.message}),n.dirty()):"max"===r.kind?(r.inclusive?e.data>r.value:e.data>=r.value)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,type:"bigint",maximum:r.value,inclusive:r.inclusive,message:r.message}),n.dirty()):"multipleOf"===r.kind?e.data%r.value!==BigInt(0)&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.not_multiple_of,multipleOf:r.value,message:r.message}),n.dirty()):u.util.assertNever(r);return{status:n.value,value:e.data}}_getInvalidInput(e){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.bigint,received:t.parsedType}),c.INVALID}gte(e,t){return this.setLimit("min",e,!0,s.errorUtil.toString(t))}gt(e,t){return this.setLimit("min",e,!1,s.errorUtil.toString(t))}lte(e,t){return this.setLimit("max",e,!0,s.errorUtil.toString(t))}lt(e,t){return this.setLimit("max",e,!1,s.errorUtil.toString(t))}setLimit(e,t,n,r){return new z({...this._def,checks:[...this._def.checks,{kind:e,value:t,inclusive:n,message:s.errorUtil.toString(r)}]})}_addCheck(e){return new z({...this._def,checks:[...this._def.checks,e]})}positive(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!1,message:s.errorUtil.toString(e)})}negative(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!1,message:s.errorUtil.toString(e)})}nonpositive(e){return this._addCheck({kind:"max",value:BigInt(0),inclusive:!0,message:s.errorUtil.toString(e)})}nonnegative(e){return this._addCheck({kind:"min",value:BigInt(0),inclusive:!0,message:s.errorUtil.toString(e)})}multipleOf(e,t){return this._addCheck({kind:"multipleOf",value:e,message:s.errorUtil.toString(t)})}get minValue(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return e}get maxValue(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return e}}t.ZodBigInt=z,z.create=e=>new z({checks:[],typeName:r.ZodBigInt,coerce:e?.coerce??!1,...p(e)});class R extends h{_parse(e){if(this._def.coerce&&(e.data=!!e.data),this._getType(e)!==u.ZodParsedType.boolean){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.boolean,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodBoolean=R,R.create=e=>new R({typeName:r.ZodBoolean,coerce:e?.coerce||!1,...p(e)});class D extends h{_parse(e){let t;if(this._def.coerce&&(e.data=new Date(e.data)),this._getType(e)!==u.ZodParsedType.date){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.date,received:t.parsedType}),c.INVALID}if(Number.isNaN(e.data.getTime())){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_date}),c.INVALID}let n=new c.ParseStatus;for(let r of this._def.checks)"min"===r.kind?e.data.getTime()<r.value&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,message:r.message,inclusive:!0,exact:!1,minimum:r.value,type:"date"}),n.dirty()):"max"===r.kind?e.data.getTime()>r.value&&(t=this._getOrReturnCtx(e,t),(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,message:r.message,inclusive:!0,exact:!1,maximum:r.value,type:"date"}),n.dirty()):u.util.assertNever(r);return{status:n.value,value:new Date(e.data.getTime())}}_addCheck(e){return new D({...this._def,checks:[...this._def.checks,e]})}min(e,t){return this._addCheck({kind:"min",value:e.getTime(),message:s.errorUtil.toString(t)})}max(e,t){return this._addCheck({kind:"max",value:e.getTime(),message:s.errorUtil.toString(t)})}get minDate(){let e=null;for(let t of this._def.checks)"min"===t.kind&&(null===e||t.value>e)&&(e=t.value);return null!=e?new Date(e):null}get maxDate(){let e=null;for(let t of this._def.checks)"max"===t.kind&&(null===e||t.value<e)&&(e=t.value);return null!=e?new Date(e):null}}t.ZodDate=D,D.create=e=>new D({checks:[],coerce:e?.coerce||!1,typeName:r.ZodDate,...p(e)});class M extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.symbol){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.symbol,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodSymbol=M,M.create=e=>new M({typeName:r.ZodSymbol,...p(e)});class Z extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.undefined){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.undefined,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodUndefined=Z,Z.create=e=>new Z({typeName:r.ZodUndefined,...p(e)});class F extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.null){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.null,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodNull=F,F.create=e=>new F({typeName:r.ZodNull,...p(e)});class U extends h{constructor(){super(...arguments),this._any=!0}_parse(e){return(0,c.OK)(e.data)}}t.ZodAny=U,U.create=e=>new U({typeName:r.ZodAny,...p(e)});class H extends h{constructor(){super(...arguments),this._unknown=!0}_parse(e){return(0,c.OK)(e.data)}}t.ZodUnknown=H,H.create=e=>new H({typeName:r.ZodUnknown,...p(e)});class V extends h{_parse(e){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.never,received:t.parsedType}),c.INVALID}}t.ZodNever=V,V.create=e=>new V({typeName:r.ZodNever,...p(e)});class B extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.undefined){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.void,received:t.parsedType}),c.INVALID}return(0,c.OK)(e.data)}}t.ZodVoid=B,B.create=e=>new B({typeName:r.ZodVoid,...p(e)});class $ extends h{_parse(e){let{ctx:t,status:n}=this._processInputParams(e),r=this._def;if(t.parsedType!==u.ZodParsedType.array)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.array,received:t.parsedType}),c.INVALID;if(null!==r.exactLength){let e=t.data.length>r.exactLength.value,o=t.data.length<r.exactLength.value;(e||o)&&((0,c.addIssueToContext)(t,{code:e?i.ZodIssueCode.too_big:i.ZodIssueCode.too_small,minimum:o?r.exactLength.value:void 0,maximum:e?r.exactLength.value:void 0,type:"array",inclusive:!0,exact:!0,message:r.exactLength.message}),n.dirty())}if(null!==r.minLength&&t.data.length<r.minLength.value&&((0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_small,minimum:r.minLength.value,type:"array",inclusive:!0,exact:!1,message:r.minLength.message}),n.dirty()),null!==r.maxLength&&t.data.length>r.maxLength.value&&((0,c.addIssueToContext)(t,{code:i.ZodIssueCode.too_big,maximum:r.maxLength.value,type:"array",inclusive:!0,exact:!1,message:r.maxLength.message}),n.dirty()),t.common.async)return Promise.all([...t.data].map((e,n)=>r.type._parseAsync(new d(t,e,t.path,n)))).then(e=>c.ParseStatus.mergeArray(n,e));let o=[...t.data].map((e,n)=>r.type._parseSync(new d(t,e,t.path,n)));return c.ParseStatus.mergeArray(n,o)}get element(){return this._def.type}min(e,t){return new $({...this._def,minLength:{value:e,message:s.errorUtil.toString(t)}})}max(e,t){return new $({...this._def,maxLength:{value:e,message:s.errorUtil.toString(t)}})}length(e,t){return new $({...this._def,exactLength:{value:e,message:s.errorUtil.toString(t)}})}nonempty(e){return this.min(1,e)}}t.ZodArray=$,$.create=(e,t)=>new $({type:e,minLength:null,maxLength:null,exactLength:null,typeName:r.ZodArray,...p(t)});class q extends h{constructor(){super(...arguments),this._cached=null,this.nonstrict=this.passthrough,this.augment=this.extend}_getCached(){if(null!==this._cached)return this._cached;let e=this._def.shape(),t=u.util.objectKeys(e);return this._cached={shape:e,keys:t},this._cached}_parse(e){if(this._getType(e)!==u.ZodParsedType.object){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.object,received:t.parsedType}),c.INVALID}let{status:t,ctx:n}=this._processInputParams(e),{shape:r,keys:o}=this._getCached(),a=[];if(!(this._def.catchall instanceof V&&"strip"===this._def.unknownKeys))for(let e in n.data)o.includes(e)||a.push(e);let l=[];for(let e of o){let t=r[e],o=n.data[e];l.push({key:{status:"valid",value:e},value:t._parse(new d(n,o,n.path,e)),alwaysSet:e in n.data})}if(this._def.catchall instanceof V){let e=this._def.unknownKeys;if("passthrough"===e)for(let e of a)l.push({key:{status:"valid",value:e},value:{status:"valid",value:n.data[e]}});else if("strict"===e)a.length>0&&((0,c.addIssueToContext)(n,{code:i.ZodIssueCode.unrecognized_keys,keys:a}),t.dirty());else if("strip"===e);else throw Error("Internal ZodObject error: invalid unknownKeys value.")}else{let e=this._def.catchall;for(let t of a){let r=n.data[t];l.push({key:{status:"valid",value:t},value:e._parse(new d(n,r,n.path,t)),alwaysSet:t in n.data})}}return n.common.async?Promise.resolve().then(async()=>{let e=[];for(let t of l){let n=await t.key,r=await t.value;e.push({key:n,value:r,alwaysSet:t.alwaysSet})}return e}).then(e=>c.ParseStatus.mergeObjectSync(t,e)):c.ParseStatus.mergeObjectSync(t,l)}get shape(){return this._def.shape()}strict(e){return s.errorUtil.errToObj,new q({...this._def,unknownKeys:"strict",...void 0!==e?{errorMap:(t,n)=>{let r=this._def.errorMap?.(t,n).message??n.defaultError;return"unrecognized_keys"===t.code?{message:s.errorUtil.errToObj(e).message??r}:{message:r}}}:{}})}strip(){return new q({...this._def,unknownKeys:"strip"})}passthrough(){return new q({...this._def,unknownKeys:"passthrough"})}extend(e){return new q({...this._def,shape:()=>({...this._def.shape(),...e})})}merge(e){return new q({unknownKeys:e._def.unknownKeys,catchall:e._def.catchall,shape:()=>({...this._def.shape(),...e._def.shape()}),typeName:r.ZodObject})}setKey(e,t){return this.augment({[e]:t})}catchall(e){return new q({...this._def,catchall:e})}pick(e){let t={};for(let n of u.util.objectKeys(e))e[n]&&this.shape[n]&&(t[n]=this.shape[n]);return new q({...this._def,shape:()=>t})}omit(e){let t={};for(let n of u.util.objectKeys(this.shape))e[n]||(t[n]=this.shape[n]);return new q({...this._def,shape:()=>t})}deepPartial(){return function e(t){if(t instanceof q){let n={};for(let r in t.shape){let o=t.shape[r];n[r]=ec.create(e(o))}return new q({...t._def,shape:()=>n})}if(t instanceof $)return new $({...t._def,type:e(t.element)});if(t instanceof ec)return ec.create(e(t.unwrap()));if(t instanceof eu)return eu.create(e(t.unwrap()));if(t instanceof X)return X.create(t.items.map(t=>e(t)));else return t}(this)}partial(e){let t={};for(let n of u.util.objectKeys(this.shape)){let r=this.shape[n];e&&!e[n]?t[n]=r:t[n]=r.optional()}return new q({...this._def,shape:()=>t})}required(e){let t={};for(let n of u.util.objectKeys(this.shape))if(e&&!e[n])t[n]=this.shape[n];else{let e=this.shape[n];for(;e instanceof ec;)e=e._def.innerType;t[n]=e}return new q({...this._def,shape:()=>t})}keyof(){return eo(u.util.objectKeys(this.shape))}}t.ZodObject=q,q.create=(e,t)=>new q({shape:()=>e,unknownKeys:"strip",catchall:V.create(),typeName:r.ZodObject,...p(t)}),q.strictCreate=(e,t)=>new q({shape:()=>e,unknownKeys:"strict",catchall:V.create(),typeName:r.ZodObject,...p(t)}),q.lazycreate=(e,t)=>new q({shape:e,unknownKeys:"strip",catchall:V.create(),typeName:r.ZodObject,...p(t)});class W extends h{_parse(e){let{ctx:t}=this._processInputParams(e),n=this._def.options;if(t.common.async)return Promise.all(n.map(async e=>{let n={...t,common:{...t.common,issues:[]},parent:null};return{result:await e._parseAsync({data:t.data,path:t.path,parent:n}),ctx:n}})).then(function(e){for(let t of e)if("valid"===t.result.status)return t.result;for(let n of e)if("dirty"===n.result.status)return t.common.issues.push(...n.ctx.common.issues),n.result;let n=e.map(e=>new i.ZodError(e.ctx.common.issues));return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_union,unionErrors:n}),c.INVALID});{let e,r=[];for(let o of n){let n={...t,common:{...t.common,issues:[]},parent:null},a=o._parseSync({data:t.data,path:t.path,parent:n});if("valid"===a.status)return a;"dirty"!==a.status||e||(e={result:a,ctx:n}),n.common.issues.length&&r.push(n.common.issues)}if(e)return t.common.issues.push(...e.ctx.common.issues),e.result;let o=r.map(e=>new i.ZodError(e));return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_union,unionErrors:o}),c.INVALID}}get options(){return this._def.options}}t.ZodUnion=W,W.create=(e,t)=>new W({options:e,typeName:r.ZodUnion,...p(t)});let K=e=>{if(e instanceof en)return K(e.schema);if(e instanceof es)return K(e.innerType());if(e instanceof er)return[e.value];if(e instanceof ea)return e.options;if(e instanceof ei)return u.util.objectValues(e.enum);else if(e instanceof ed)return K(e._def.innerType);else if(e instanceof Z)return[void 0];else if(e instanceof F)return[null];else if(e instanceof ec)return[void 0,...K(e.unwrap())];else if(e instanceof eu)return[null,...K(e.unwrap())];else if(e instanceof eh)return K(e.unwrap());else if(e instanceof eg)return K(e.unwrap());else if(e instanceof ef)return K(e._def.innerType);else return[]};class Y extends h{_parse(e){let{ctx:t}=this._processInputParams(e);if(t.parsedType!==u.ZodParsedType.object)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.object,received:t.parsedType}),c.INVALID;let n=this.discriminator,r=t.data[n],o=this.optionsMap.get(r);return o?t.common.async?o._parseAsync({data:t.data,path:t.path,parent:t}):o._parseSync({data:t.data,path:t.path,parent:t}):((0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_union_discriminator,options:Array.from(this.optionsMap.keys()),path:[n]}),c.INVALID)}get discriminator(){return this._def.discriminator}get options(){return this._def.options}get optionsMap(){return this._def.optionsMap}static create(e,t,n){let o=new Map;for(let n of t){let t=K(n.shape[e]);if(!t.length)throw Error(`A discriminator value for key \`${e}\` could not be extracted from all schema options`);for(let r of t){if(o.has(r))throw Error(`Discriminator property ${String(e)} has duplicate value ${String(r)}`);o.set(r,n)}}return new Y({typeName:r.ZodDiscriminatedUnion,discriminator:e,options:t,optionsMap:o,...p(n)})}}t.ZodDiscriminatedUnion=Y;class G extends h{_parse(e){let{status:t,ctx:n}=this._processInputParams(e),r=(e,r)=>{if((0,c.isAborted)(e)||(0,c.isAborted)(r))return c.INVALID;let o=function e(t,n){let r=(0,u.getParsedType)(t),o=(0,u.getParsedType)(n);if(t===n)return{valid:!0,data:t};if(r===u.ZodParsedType.object&&o===u.ZodParsedType.object){let r=u.util.objectKeys(n),o=u.util.objectKeys(t).filter(e=>-1!==r.indexOf(e)),a={...t,...n};for(let r of o){let o=e(t[r],n[r]);if(!o.valid)return{valid:!1};a[r]=o.data}return{valid:!0,data:a}}if(r===u.ZodParsedType.array&&o===u.ZodParsedType.array){if(t.length!==n.length)return{valid:!1};let r=[];for(let o=0;o<t.length;o++){let a=e(t[o],n[o]);if(!a.valid)return{valid:!1};r.push(a.data)}return{valid:!0,data:r}}if(r===u.ZodParsedType.date&&o===u.ZodParsedType.date&&+t==+n)return{valid:!0,data:t};return{valid:!1}}(e.value,r.value);return o.valid?(((0,c.isDirty)(e)||(0,c.isDirty)(r))&&t.dirty(),{status:t.value,value:o.data}):((0,c.addIssueToContext)(n,{code:i.ZodIssueCode.invalid_intersection_types}),c.INVALID)};return n.common.async?Promise.all([this._def.left._parseAsync({data:n.data,path:n.path,parent:n}),this._def.right._parseAsync({data:n.data,path:n.path,parent:n})]).then(([e,t])=>r(e,t)):r(this._def.left._parseSync({data:n.data,path:n.path,parent:n}),this._def.right._parseSync({data:n.data,path:n.path,parent:n}))}}t.ZodIntersection=G,G.create=(e,t,n)=>new G({left:e,right:t,typeName:r.ZodIntersection,...p(n)});class X extends h{_parse(e){let{status:t,ctx:n}=this._processInputParams(e);if(n.parsedType!==u.ZodParsedType.array)return(0,c.addIssueToContext)(n,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.array,received:n.parsedType}),c.INVALID;if(n.data.length<this._def.items.length)return(0,c.addIssueToContext)(n,{code:i.ZodIssueCode.too_small,minimum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),c.INVALID;!this._def.rest&&n.data.length>this._def.items.length&&((0,c.addIssueToContext)(n,{code:i.ZodIssueCode.too_big,maximum:this._def.items.length,inclusive:!0,exact:!1,type:"array"}),t.dirty());let r=[...n.data].map((e,t)=>{let r=this._def.items[t]||this._def.rest;return r?r._parse(new d(n,e,n.path,t)):null}).filter(e=>!!e);return n.common.async?Promise.all(r).then(e=>c.ParseStatus.mergeArray(t,e)):c.ParseStatus.mergeArray(t,r)}get items(){return this._def.items}rest(e){return new X({...this._def,rest:e})}}t.ZodTuple=X,X.create=(e,t)=>{if(!Array.isArray(e))throw Error("You must pass an array of schemas to z.tuple([ ... ])");return new X({items:e,typeName:r.ZodTuple,rest:null,...p(t)})};class Q extends h{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){let{status:t,ctx:n}=this._processInputParams(e);if(n.parsedType!==u.ZodParsedType.object)return(0,c.addIssueToContext)(n,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.object,received:n.parsedType}),c.INVALID;let r=[],o=this._def.keyType,a=this._def.valueType;for(let e in n.data)r.push({key:o._parse(new d(n,e,n.path,e)),value:a._parse(new d(n,n.data[e],n.path,e)),alwaysSet:e in n.data});return n.common.async?c.ParseStatus.mergeObjectAsync(t,r):c.ParseStatus.mergeObjectSync(t,r)}get element(){return this._def.valueType}static create(e,t,n){return new Q(t instanceof h?{keyType:e,valueType:t,typeName:r.ZodRecord,...p(n)}:{keyType:L.create(),valueType:e,typeName:r.ZodRecord,...p(t)})}}t.ZodRecord=Q;class J extends h{get keySchema(){return this._def.keyType}get valueSchema(){return this._def.valueType}_parse(e){let{status:t,ctx:n}=this._processInputParams(e);if(n.parsedType!==u.ZodParsedType.map)return(0,c.addIssueToContext)(n,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.map,received:n.parsedType}),c.INVALID;let r=this._def.keyType,o=this._def.valueType,a=[...n.data.entries()].map(([e,t],a)=>({key:r._parse(new d(n,e,n.path,[a,"key"])),value:o._parse(new d(n,t,n.path,[a,"value"]))}));if(n.common.async){let e=new Map;return Promise.resolve().then(async()=>{for(let n of a){let r=await n.key,o=await n.value;if("aborted"===r.status||"aborted"===o.status)return c.INVALID;("dirty"===r.status||"dirty"===o.status)&&t.dirty(),e.set(r.value,o.value)}return{status:t.value,value:e}})}{let e=new Map;for(let n of a){let r=n.key,o=n.value;if("aborted"===r.status||"aborted"===o.status)return c.INVALID;("dirty"===r.status||"dirty"===o.status)&&t.dirty(),e.set(r.value,o.value)}return{status:t.value,value:e}}}}t.ZodMap=J,J.create=(e,t,n)=>new J({valueType:t,keyType:e,typeName:r.ZodMap,...p(n)});class ee extends h{_parse(e){let{status:t,ctx:n}=this._processInputParams(e);if(n.parsedType!==u.ZodParsedType.set)return(0,c.addIssueToContext)(n,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.set,received:n.parsedType}),c.INVALID;let r=this._def;null!==r.minSize&&n.data.size<r.minSize.value&&((0,c.addIssueToContext)(n,{code:i.ZodIssueCode.too_small,minimum:r.minSize.value,type:"set",inclusive:!0,exact:!1,message:r.minSize.message}),t.dirty()),null!==r.maxSize&&n.data.size>r.maxSize.value&&((0,c.addIssueToContext)(n,{code:i.ZodIssueCode.too_big,maximum:r.maxSize.value,type:"set",inclusive:!0,exact:!1,message:r.maxSize.message}),t.dirty());let o=this._def.valueType;function a(e){let n=new Set;for(let r of e){if("aborted"===r.status)return c.INVALID;"dirty"===r.status&&t.dirty(),n.add(r.value)}return{status:t.value,value:n}}let l=[...n.data.values()].map((e,t)=>o._parse(new d(n,e,n.path,t)));return n.common.async?Promise.all(l).then(e=>a(e)):a(l)}min(e,t){return new ee({...this._def,minSize:{value:e,message:s.errorUtil.toString(t)}})}max(e,t){return new ee({...this._def,maxSize:{value:e,message:s.errorUtil.toString(t)}})}size(e,t){return this.min(e,t).max(e,t)}nonempty(e){return this.min(1,e)}}t.ZodSet=ee,ee.create=(e,t)=>new ee({valueType:e,minSize:null,maxSize:null,typeName:r.ZodSet,...p(t)});class et extends h{constructor(){super(...arguments),this.validate=this.implement}_parse(e){let{ctx:t}=this._processInputParams(e);if(t.parsedType!==u.ZodParsedType.function)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.function,received:t.parsedType}),c.INVALID;function n(e,n){return(0,c.makeIssue)({data:e,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,(0,l.getErrorMap)(),l.defaultErrorMap].filter(e=>!!e),issueData:{code:i.ZodIssueCode.invalid_arguments,argumentsError:n}})}function r(e,n){return(0,c.makeIssue)({data:e,path:t.path,errorMaps:[t.common.contextualErrorMap,t.schemaErrorMap,(0,l.getErrorMap)(),l.defaultErrorMap].filter(e=>!!e),issueData:{code:i.ZodIssueCode.invalid_return_type,returnTypeError:n}})}let o={errorMap:t.common.contextualErrorMap},a=t.data;if(this._def.returns instanceof el){let e=this;return(0,c.OK)(async function(...t){let l=new i.ZodError([]),s=await e._def.args.parseAsync(t,o).catch(e=>{throw l.addIssue(n(t,e)),l}),c=await Reflect.apply(a,this,s);return await e._def.returns._def.type.parseAsync(c,o).catch(e=>{throw l.addIssue(r(c,e)),l})})}{let e=this;return(0,c.OK)(function(...t){let l=e._def.args.safeParse(t,o);if(!l.success)throw new i.ZodError([n(t,l.error)]);let s=Reflect.apply(a,this,l.data),c=e._def.returns.safeParse(s,o);if(!c.success)throw new i.ZodError([r(s,c.error)]);return c.data})}}parameters(){return this._def.args}returnType(){return this._def.returns}args(...e){return new et({...this._def,args:X.create(e).rest(H.create())})}returns(e){return new et({...this._def,returns:e})}implement(e){return this.parse(e)}strictImplement(e){return this.parse(e)}static create(e,t,n){return new et({args:e||X.create([]).rest(H.create()),returns:t||H.create(),typeName:r.ZodFunction,...p(n)})}}t.ZodFunction=et;class en extends h{get schema(){return this._def.getter()}_parse(e){let{ctx:t}=this._processInputParams(e);return this._def.getter()._parse({data:t.data,path:t.path,parent:t})}}t.ZodLazy=en,en.create=(e,t)=>new en({getter:e,typeName:r.ZodLazy,...p(t)});class er extends h{_parse(e){if(e.data!==this._def.value){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{received:t.data,code:i.ZodIssueCode.invalid_literal,expected:this._def.value}),c.INVALID}return{status:"valid",value:e.data}}get value(){return this._def.value}}function eo(e,t){return new ea({values:e,typeName:r.ZodEnum,...p(t)})}t.ZodLiteral=er,er.create=(e,t)=>new er({value:e,typeName:r.ZodLiteral,...p(t)});class ea extends h{_parse(e){if("string"!=typeof e.data){let t=this._getOrReturnCtx(e),n=this._def.values;return(0,c.addIssueToContext)(t,{expected:u.util.joinValues(n),received:t.parsedType,code:i.ZodIssueCode.invalid_type}),c.INVALID}if(this._cache||(this._cache=new Set(this._def.values)),!this._cache.has(e.data)){let t=this._getOrReturnCtx(e),n=this._def.values;return(0,c.addIssueToContext)(t,{received:t.data,code:i.ZodIssueCode.invalid_enum_value,options:n}),c.INVALID}return(0,c.OK)(e.data)}get options(){return this._def.values}get enum(){let e={};for(let t of this._def.values)e[t]=t;return e}get Values(){let e={};for(let t of this._def.values)e[t]=t;return e}get Enum(){let e={};for(let t of this._def.values)e[t]=t;return e}extract(e,t=this._def){return ea.create(e,{...this._def,...t})}exclude(e,t=this._def){return ea.create(this.options.filter(t=>!e.includes(t)),{...this._def,...t})}}t.ZodEnum=ea,ea.create=eo;class ei extends h{_parse(e){let t=u.util.getValidEnumValues(this._def.values),n=this._getOrReturnCtx(e);if(n.parsedType!==u.ZodParsedType.string&&n.parsedType!==u.ZodParsedType.number){let e=u.util.objectValues(t);return(0,c.addIssueToContext)(n,{expected:u.util.joinValues(e),received:n.parsedType,code:i.ZodIssueCode.invalid_type}),c.INVALID}if(this._cache||(this._cache=new Set(u.util.getValidEnumValues(this._def.values))),!this._cache.has(e.data)){let e=u.util.objectValues(t);return(0,c.addIssueToContext)(n,{received:n.data,code:i.ZodIssueCode.invalid_enum_value,options:e}),c.INVALID}return(0,c.OK)(e.data)}get enum(){return this._def.values}}t.ZodNativeEnum=ei,ei.create=(e,t)=>new ei({values:e,typeName:r.ZodNativeEnum,...p(t)});class el extends h{unwrap(){return this._def.type}_parse(e){let{ctx:t}=this._processInputParams(e);if(t.parsedType!==u.ZodParsedType.promise&&!1===t.common.async)return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.promise,received:t.parsedType}),c.INVALID;let n=t.parsedType===u.ZodParsedType.promise?t.data:Promise.resolve(t.data);return(0,c.OK)(n.then(e=>this._def.type.parseAsync(e,{path:t.path,errorMap:t.common.contextualErrorMap})))}}t.ZodPromise=el,el.create=(e,t)=>new el({type:e,typeName:r.ZodPromise,...p(t)});class es extends h{innerType(){return this._def.schema}sourceType(){return this._def.schema._def.typeName===r.ZodEffects?this._def.schema.sourceType():this._def.schema}_parse(e){let{status:t,ctx:n}=this._processInputParams(e),r=this._def.effect||null,o={addIssue:e=>{(0,c.addIssueToContext)(n,e),e.fatal?t.abort():t.dirty()},get path(){return n.path}};if(o.addIssue=o.addIssue.bind(o),"preprocess"===r.type){let e=r.transform(n.data,o);if(n.common.async)return Promise.resolve(e).then(async e=>{if("aborted"===t.value)return c.INVALID;let r=await this._def.schema._parseAsync({data:e,path:n.path,parent:n});return"aborted"===r.status?c.INVALID:"dirty"===r.status||"dirty"===t.value?(0,c.DIRTY)(r.value):r});{if("aborted"===t.value)return c.INVALID;let r=this._def.schema._parseSync({data:e,path:n.path,parent:n});return"aborted"===r.status?c.INVALID:"dirty"===r.status||"dirty"===t.value?(0,c.DIRTY)(r.value):r}}if("refinement"===r.type){let e=e=>{let t=r.refinement(e,o);if(n.common.async)return Promise.resolve(t);if(t instanceof Promise)throw Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");return e};if(!1!==n.common.async)return this._def.schema._parseAsync({data:n.data,path:n.path,parent:n}).then(n=>"aborted"===n.status?c.INVALID:("dirty"===n.status&&t.dirty(),e(n.value).then(()=>({status:t.value,value:n.value}))));{let r=this._def.schema._parseSync({data:n.data,path:n.path,parent:n});return"aborted"===r.status?c.INVALID:("dirty"===r.status&&t.dirty(),e(r.value),{status:t.value,value:r.value})}}if("transform"===r.type)if(!1!==n.common.async)return this._def.schema._parseAsync({data:n.data,path:n.path,parent:n}).then(e=>(0,c.isValid)(e)?Promise.resolve(r.transform(e.value,o)).then(e=>({status:t.value,value:e})):c.INVALID);else{let e=this._def.schema._parseSync({data:n.data,path:n.path,parent:n});if(!(0,c.isValid)(e))return c.INVALID;let a=r.transform(e.value,o);if(a instanceof Promise)throw Error("Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.");return{status:t.value,value:a}}u.util.assertNever(r)}}t.ZodEffects=es,t.ZodTransformer=es,es.create=(e,t,n)=>new es({schema:e,typeName:r.ZodEffects,effect:t,...p(n)}),es.createWithPreprocess=(e,t,n)=>new es({schema:t,effect:{type:"preprocess",transform:e},typeName:r.ZodEffects,...p(n)});class ec extends h{_parse(e){return this._getType(e)===u.ZodParsedType.undefined?(0,c.OK)(void 0):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}t.ZodOptional=ec,ec.create=(e,t)=>new ec({innerType:e,typeName:r.ZodOptional,...p(t)});class eu extends h{_parse(e){return this._getType(e)===u.ZodParsedType.null?(0,c.OK)(null):this._def.innerType._parse(e)}unwrap(){return this._def.innerType}}t.ZodNullable=eu,eu.create=(e,t)=>new eu({innerType:e,typeName:r.ZodNullable,...p(t)});class ed extends h{_parse(e){let{ctx:t}=this._processInputParams(e),n=t.data;return t.parsedType===u.ZodParsedType.undefined&&(n=this._def.defaultValue()),this._def.innerType._parse({data:n,path:t.path,parent:t})}removeDefault(){return this._def.innerType}}t.ZodDefault=ed,ed.create=(e,t)=>new ed({innerType:e,typeName:r.ZodDefault,defaultValue:"function"==typeof t.default?t.default:()=>t.default,...p(t)});class ef extends h{_parse(e){let{ctx:t}=this._processInputParams(e),n={...t,common:{...t.common,issues:[]}},r=this._def.innerType._parse({data:n.data,path:n.path,parent:{...n}});return(0,c.isAsync)(r)?r.then(e=>({status:"valid",value:"valid"===e.status?e.value:this._def.catchValue({get error(){return new i.ZodError(n.common.issues)},input:n.data})})):{status:"valid",value:"valid"===r.status?r.value:this._def.catchValue({get error(){return new i.ZodError(n.common.issues)},input:n.data})}}removeCatch(){return this._def.innerType}}t.ZodCatch=ef,ef.create=(e,t)=>new ef({innerType:e,typeName:r.ZodCatch,catchValue:"function"==typeof t.catch?t.catch:()=>t.catch,...p(t)});class ep extends h{_parse(e){if(this._getType(e)!==u.ZodParsedType.nan){let t=this._getOrReturnCtx(e);return(0,c.addIssueToContext)(t,{code:i.ZodIssueCode.invalid_type,expected:u.ZodParsedType.nan,received:t.parsedType}),c.INVALID}return{status:"valid",value:e.data}}}t.ZodNaN=ep,ep.create=e=>new ep({typeName:r.ZodNaN,...p(e)}),t.BRAND=Symbol("zod_brand");class eh extends h{_parse(e){let{ctx:t}=this._processInputParams(e),n=t.data;return this._def.type._parse({data:n,path:t.path,parent:t})}unwrap(){return this._def.type}}t.ZodBranded=eh;class em extends h{_parse(e){let{status:t,ctx:n}=this._processInputParams(e);if(n.common.async)return(async()=>{let e=await this._def.in._parseAsync({data:n.data,path:n.path,parent:n});return"aborted"===e.status?c.INVALID:"dirty"===e.status?(t.dirty(),(0,c.DIRTY)(e.value)):this._def.out._parseAsync({data:e.value,path:n.path,parent:n})})();{let e=this._def.in._parseSync({data:n.data,path:n.path,parent:n});return"aborted"===e.status?c.INVALID:"dirty"===e.status?(t.dirty(),{status:"dirty",value:e.value}):this._def.out._parseSync({data:e.value,path:n.path,parent:n})}}static create(e,t){return new em({in:e,out:t,typeName:r.ZodPipeline})}}t.ZodPipeline=em;class eg extends h{_parse(e){let t=this._def.innerType._parse(e),n=e=>((0,c.isValid)(e)&&(e.value=Object.freeze(e.value)),e);return(0,c.isAsync)(t)?t.then(e=>n(e)):n(t)}unwrap(){return this._def.innerType}}function ev(e,t){let n="function"==typeof e?e(t):"string"==typeof e?{message:e}:e;return"string"==typeof n?{message:n}:n}function ey(e,t={},n){return e?U.create().superRefine((r,o)=>{let a=e(r);if(a instanceof Promise)return a.then(e=>{if(!e){let e=ev(t,r),a=e.fatal??n??!0;o.addIssue({code:"custom",...e,fatal:a})}});if(!a){let e=ev(t,r),a=e.fatal??n??!0;o.addIssue({code:"custom",...e,fatal:a})}}):U.create()}t.ZodReadonly=eg,eg.create=(e,t)=>new eg({innerType:e,typeName:r.ZodReadonly,...p(t)}),t.late={object:q.lazycreate},(o=r||(t.ZodFirstPartyTypeKind=r={})).ZodString="ZodString",o.ZodNumber="ZodNumber",o.ZodNaN="ZodNaN",o.ZodBigInt="ZodBigInt",o.ZodBoolean="ZodBoolean",o.ZodDate="ZodDate",o.ZodSymbol="ZodSymbol",o.ZodUndefined="ZodUndefined",o.ZodNull="ZodNull",o.ZodAny="ZodAny",o.ZodUnknown="ZodUnknown",o.ZodNever="ZodNever",o.ZodVoid="ZodVoid",o.ZodArray="ZodArray",o.ZodObject="ZodObject",o.ZodUnion="ZodUnion",o.ZodDiscriminatedUnion="ZodDiscriminatedUnion",o.ZodIntersection="ZodIntersection",o.ZodTuple="ZodTuple",o.ZodRecord="ZodRecord",o.ZodMap="ZodMap",o.ZodSet="ZodSet",o.ZodFunction="ZodFunction",o.ZodLazy="ZodLazy",o.ZodLiteral="ZodLiteral",o.ZodEnum="ZodEnum",o.ZodEffects="ZodEffects",o.ZodNativeEnum="ZodNativeEnum",o.ZodOptional="ZodOptional",o.ZodNullable="ZodNullable",o.ZodDefault="ZodDefault",o.ZodCatch="ZodCatch",o.ZodPromise="ZodPromise",o.ZodBranded="ZodBranded",o.ZodPipeline="ZodPipeline",o.ZodReadonly="ZodReadonly",t.instanceof=(e,t={message:`Input not instance of ${e.name}`})=>ey(t=>t instanceof e,t);let eb=L.create;t.string=eb;let ex=A.create;t.number=ex,t.nan=ep.create,t.bigint=z.create;let ew=R.create;t.boolean=ew,t.date=D.create,t.symbol=M.create,t.undefined=Z.create,t.null=F.create,t.any=U.create,t.unknown=H.create,t.never=V.create,t.void=B.create,t.array=$.create,t.object=q.create,t.strictObject=q.strictCreate,t.union=W.create,t.discriminatedUnion=Y.create,t.intersection=G.create,t.tuple=X.create,t.record=Q.create,t.map=J.create,t.set=ee.create,t.function=et.create,t.lazy=en.create,t.literal=er.create,t.enum=ea.create,t.nativeEnum=ei.create,t.promise=el.create;let e_=es.create;t.effect=e_,t.transformer=e_,t.optional=ec.create,t.nullable=eu.create,t.preprocess=es.createWithPreprocess,t.pipeline=em.create,t.ostring=()=>eb().optional(),t.onumber=()=>ex().optional(),t.oboolean=()=>ew().optional(),t.coerce={string:e=>L.create({...e,coerce:!0}),number:e=>A.create({...e,coerce:!0}),boolean:e=>R.create({...e,coerce:!0}),bigint:e=>z.create({...e,coerce:!0}),date:e=>D.create({...e,coerce:!0})},t.NEVER=c.INVALID}},n={};function r(e){var o=n[e];if(void 0!==o)return o.exports;var a=n[e]={exports:{}},i=!0;try{t[e].call(a.exports,a,a.exports,r),i=!1}finally{i&&delete n[e]}return a.exports}r.ab="//",e.exports=r(629)})()}},__webpack_module_cache__={};function __webpack_require__(e){var t=__webpack_module_cache__[e];if(void 0!==t)return t.exports;var n=__webpack_module_cache__[e]={id:e,exports:{}};return __webpack_modules__[e](n,n.exports,__webpack_require__),n.exports}__webpack_require__.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return __webpack_require__.d(t,{a:t}),t},(()=>{var e,t=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__;__webpack_require__.t=function(n,r){if(1&r&&(n=this(n)),8&r||"object"==typeof n&&n&&(4&r&&n.__esModule||16&r&&"function"==typeof n.then))return n;var o=Object.create(null);__webpack_require__.r(o);var a={};e=e||[null,t({}),t([]),t(t)];for(var i=2&r&&n;("object"==typeof i||"function"==typeof i)&&!~e.indexOf(i);i=t(i))Object.getOwnPropertyNames(i).forEach(e=>{a[e]=()=>n[e]});return a.default=()=>n,__webpack_require__.d(o,a),o}})(),__webpack_require__.d=(e,t)=>{for(var n in t)__webpack_require__.o(t,n)&&!__webpack_require__.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},__webpack_require__.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),__webpack_require__.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},__webpack_require__.nc=void 0;var __webpack_exports__={};for(var __webpack_i__ in(()=>{"use strict";__webpack_require__.r(__webpack_exports__),__webpack_require__.d(__webpack_exports__,{DevOverlayContext:()=>d_,dispatcher:()=>dx,renderPagesDevOverlay:()=>dP,getSerializedOverlayState:()=>dv,useDevOverlayContext:()=>dk,renderAppDevOverlay:()=>dC,getSegmentTrieData:()=>dy});var e,t,n,r,o,a,i,l,s,c=__webpack_require__("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"),u=__webpack_require__.n(c),d=__webpack_require__("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleDomAPI.js"),f=__webpack_require__.n(d),p=__webpack_require__("./src/build/webpack/loaders/devtool/devtool-style-inject.js"),h=__webpack_require__.n(p),m=__webpack_require__("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js"),g=__webpack_require__.n(m),v=__webpack_require__("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/insertStyleElement.js"),y=__webpack_require__.n(v),b=__webpack_require__("../../node_modules/.pnpm/style-loader@4.0.0_webpack@5.98.0_@swc+core@1.11.24_@swc+helpers@0.5.15__esbuild@0.25.9_/node_modules/style-loader/dist/runtime/styleTagTransform.js"),x=__webpack_require__.n(b),w=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/global.css"),_={};_.styleTagTransform=x(),_.setAttributes=g(),_.insert=h(),_.domAPI=f(),_.insertStyleElement=y(),u()(w.A,_),w.A&&w.A.locals&&w.A.locals;var k=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/toast/style.css"),j={};j.styleTagTransform=x(),j.setAttributes=g(),j.insert=h(),j.domAPI=f(),j.insertStyleElement=y(),u()(k.A,j),k.A&&k.A.locals&&k.A.locals;var S=__webpack_require__("./dist/compiled/react/jsx-runtime.js"),O=__webpack_require__("./dist/compiled/react/compiler-runtime.js"),C=__webpack_require__("./dist/compiled/react/index.js"),P=__webpack_require__.t(C,2),E=__webpack_require__("./dist/compiled/stacktrace-parser/stack-trace-parser.cjs.js"),T=/\/_next(\/static\/.+)/,I=Symbol.for("next.console.error.digest");function N(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function L(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){N(e,t,n[t])})}return e}function A(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}var z={Small:16/14,Medium:1,Large:16/18},R="cache-indicator",D="static-indicator",M="build-ok",Z="build-error",F="before-fast-refresh",U="fast-refresh",H="version-info",V="unhandled-error",B="unhandled-rejection",$="debug-info",q="dev-indicator",W="dev-indicator-disable",K="error-overlay-open",Y="error-overlay-close",G="error-overlay-toggle",X="building-indicator-show",Q="building-indicator-hide",J="rendering-indicator-show",ee="rendering-indicator-hide",et="devtools-position",en="devtools-panel-position",er="devtools-scale",eo="devtools-config",ea="__nextjs-dev-tools-panel-position",ei="__nextjs-dev-tools-panel-size",el="__nextjs-dev-tools-shared-panel-size",es="__nextjs-dev-tools-shared-panel-location",ec="segment-explorer-update-route-state",eu=/\s+(at Object\.react_stack_bottom_frame.*)|(react_stack_bottom_frame@.*)|(at react-stack-bottom-frame.*)|(react-stack-bottom-frame@.*)/;function ed(e){return null==e?void 0:e.split(eu)[0]}var ef=(null==(a=process.env.__NEXT_DEV_INDICATOR)?void 0:a.toString())==="false",ep=null!=(i=process.env.__NEXT_DEV_INDICATOR_POSITION)?i:"bottom-left",eh={nextId:1,buildError:null,errors:[],notFound:!1,renderingIndicator:!1,cacheIndicator:"disabled",staticIndicator:"disabled",showIndicator:!1,disableDevIndicator:!1,buildingIndicator:!1,refreshState:{type:"idle"},versionInfo:{installed:"0.0.0",staleness:"unknown"},debugInfo:{devtoolsFrontendUrl:void 0},devToolsPosition:ep,devToolsPanelPosition:N({},es,ep),devToolsPanelSize:{},scale:z.Medium,page:"",theme:"system",hideShortcut:null},em=__webpack_require__("./dist/compiled/react-dom/client.js");function eg(e){for(var t=arguments.length,n=Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];var o=e.length-1;return(e.slice(0,o).reduce(function(e,t,r){return e+t+n[r]},"")+e[o]).replace(/\/\*[\s\S]*?\*\//g,"").replace(/\s+/g," ").replace(/\s*([:;,{}])\s*/g,"$1").replace(/;+}/g,"}").trim()}function ev(){var e,t,n=(e=["\n      /* latin-ext */\n      @font-face {\n        font-family: '__nextjs-Geist';\n        font-style: normal;\n        font-weight: 400 600;\n        font-display: swap;\n        src: url(/__nextjs_font/geist-latin-ext.woff2) format('woff2');\n        unicode-range:\n          U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF,\n          U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020,\n          U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;\n      }\n      /* latin-ext */\n      @font-face {\n        font-family: '__nextjs-Geist Mono';\n        font-style: normal;\n        font-weight: 400 600;\n        font-display: swap;\n        src: url(/__nextjs_font/geist-mono-latin-ext.woff2) format('woff2');\n        unicode-range:\n          U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF,\n          U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020,\n          U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;\n      }\n      /* latin */\n      @font-face {\n        font-family: '__nextjs-Geist';\n        font-style: normal;\n        font-weight: 400 600;\n        font-display: swap;\n        src: url(/__nextjs_font/geist-latin.woff2) format('woff2');\n        unicode-range:\n          U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,\n          U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,\n          U+2212, U+2215, U+FEFF, U+FFFD;\n      }\n      /* latin */\n      @font-face {\n        font-family: '__nextjs-Geist Mono';\n        font-style: normal;\n        font-weight: 400 600;\n        font-display: swap;\n        src: url(/__nextjs_font/geist-mono-latin.woff2) format('woff2');\n        unicode-range:\n          U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,\n          U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193,\n          U+2212, U+2215, U+FEFF, U+FFFD;\n      }\n    "],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return ev=function(){return n},n}var ey=function(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=[],t[0]=e):e=t[0],(0,C.useInsertionEffect)(eb,e),null};function eb(){var e=document.createElement("style");return e.textContent=eg(ev()),document.head.appendChild(e),function(){document.head.removeChild(e)}}var ex=__webpack_require__("./dist/compiled/react-dom/index.js");function ew(e){var t,n=(0,O.c)(3),r=e.children,o=dk().shadowRoot;return n[0]!==r||n[1]!==o?(t=(0,ex.createPortal)(r,o),n[0]=r,n[1]=o,n[2]=t):t=n[2],t}function e_(e){if(""===e.trim())throw Error("can't decode empty hex");var t=parseInt(e,16);if(isNaN(t))throw Error("invalid hex: `".concat(e,"`"));return String.fromCodePoint(t)}var ek=/^__TURBOPACK__([a-zA-Z0-9_$]+)__$/,ej=/__TURBOPACK__[a-zA-Z0-9_$]+__/g;function eS(e){return e.replace(/\[project\]/g,".").replace(/\s\[([^\]]*)\]/g,"").replace(/\s\(([^)]*)\)/g,"").replace(/\s<([^>]*)>/g,"").trim()}function eO(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}var eC=/https?:\/\/[^\s/$.?#].[^\s)'"]*/i,eP=function(e){var t,n=(0,O.c)(7),r=e.text,o=e.matcher;if(n[0]!==o||n[1]!==r){var a,i,l=function(e){for(var t=e.replace(RegExp("\\(0\\s*,\\s*(__TURBOPACK__[a-zA-Z0-9_$]+__\\.[\\p{ID_Start}_$][\\p{ID_Continue}$]*)\\)","u"),"$1"),n=[],r=0,o=RegExp(ej.source,"g"),a=o.exec(t);null!==a;a=o.exec(t)){var i=a.index,l=o.lastIndex,s=a[0];if(i>r){var c=t.substring(r,i);n.push(["raw",c])}try{var u=function(e){var t=e.match(ek);if(!t)return e;for(var n=t[1],r="",o=0,a="",i=0;i<n.length;i++){var l=n[i];if(0===o)"_"===l?o=1:"$"===l?o=2:r+=l;else if(1===o)"_"===l?(r+=" ",o=0):"$"===l?(r+="_",o=2):(r+=l,o=0);else if(2===o)if(2===a.length&&(r+=e_(a),a=""),"_"===l){if(""!==a)throw Error("invalid hex: `".concat(a,"`"));o=3}else if("$"===l){if(""!==a)throw Error("invalid hex: `".concat(a,"`"));o=0}else a+=l;else if(3===o)if("_"===l)throw Error("invalid hex: `".concat(a+l,"`"));else"$"===l?(r+=e_(a),a="",o=0):a+=l}return r}(s);if(u!==s){var d=u.match(/^imported module (.+)$/);if(d){var f=d[1],p=eS(f);n.push(["deobfuscated","{imported module ".concat(p,"}")])}else{var h=eS(u);n.push(["deobfuscated","{".concat(h,"}")])}}else n.push(["raw",s])}catch(e){n.push(["deobfuscated","{".concat(s," (decoding failed: ").concat(e,")}")])}r=l}if(r<t.length){var m=t.substring(r);n.push(["raw",m])}return n}(r);n[3]!==o?(i=function(e,t){var n,r=function(e){if(Array.isArray(e))return e}(n=e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(n,2)||function(e,t){if(e){if("string"==typeof e)return eO(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return eO(e,2)}}(n,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}(),a=r[0],i=r[1];if("raw"===a)return i.split(/(\s+|https?:\/\/[^\s/$.?#].[^\s)'"]*)/).map(function(e,n){if(!eC.test(e))return(0,S.jsx)(C.Fragment,{children:e},"text-".concat(t,"-").concat(n));var r=eC.exec(e)[0];return"function"!=typeof o||o(r)?(0,S.jsx)(C.Fragment,{children:(0,S.jsx)("a",{href:r,target:"_blank",rel:"noreferrer noopener",children:e})},"link-".concat(t,"-").concat(n)):(0,S.jsx)(C.Fragment,{children:e},"link-".concat(t,"-").concat(n))});if("deobfuscated"===a)return(0,S.jsx)("i",{children:i},"ident-".concat(t));throw Error("Unknown text part type: ".concat(a))},n[3]=o,n[4]=i):i=n[4],a=l.map(i),n[0]=o,n[1]=r,n[2]=a}else a=n[2];return n[5]!==a?(t=(0,S.jsx)(S.Fragment,{children:a}),n[5]=a,n[6]=t):t=n[6],t},eE=[/^webpack-internal:\/\/\/(\([\w-]+\)\/)?/,/^(webpack:\/\/\/|webpack:\/\/(_N_E\/)?)(\([\w-]+\)\/)?/];function eT(e){var t=!0,n=!1,r=void 0;try{for(var o,a=eE[Symbol.iterator]();!(t=(o=a.next()).done);t=!0){var i=o.value;if(i.test(e))return!0;e=e.replace(i,"")}}catch(e){n=!0,r=e}finally{try{t||null==a.return||a.return()}finally{if(n)throw r}}return!1}function eI(e){var t=!0,n=!1,r=void 0;try{for(var o,a=eE[Symbol.iterator]();!(t=(o=a.next()).done);t=!0){var i=o.value;e=e.replace(i,"")}}catch(e){n=!0,r=e}finally{try{t||null==a.return||a.return()}finally{if(n)throw r}}return e}function eN(e,t,n,r,o,a,i){try{var l=e[a](i),s=l.value}catch(e){n(e);return}l.done?t(s):Promise.resolve(s).then(r,o)}function eL(e){return function(){var t=this,n=arguments;return new Promise(function(r,o){var a=e.apply(t,n);function i(e){eN(a,r,o,i,l,"next",e)}function l(e){eN(a,r,o,i,l,"throw",e)}i(void 0)})}}function eA(e,t){var n,r,o,a={label:0,sent:function(){if(1&o[0])throw o[1];return o[1]},trys:[],ops:[]},i=Object.create(("function"==typeof Iterator?Iterator:Object).prototype);return i.next=l(0),i.throw=l(1),i.return=l(2),"function"==typeof Symbol&&(i[Symbol.iterator]=function(){return this}),i;function l(l){return function(s){var c=[l,s];if(n)throw TypeError("Generator is already executing.");for(;i&&(i=0,c[0]&&(a=0)),a;)try{if(n=1,r&&(o=2&c[0]?r.return:c[0]?r.throw||((o=r.return)&&o.call(r),0):r.next)&&!(o=o.call(r,c[1])).done)return o;switch(r=0,o&&(c=[2&c[0],o.value]),c[0]){case 0:case 1:o=c;break;case 4:return a.label++,{value:c[1],done:!1};case 5:a.label++,r=c[1],c=[0];continue;case 7:c=a.ops.pop(),a.trys.pop();continue;default:if(!(o=(o=a.trys).length>0&&o[o.length-1])&&(6===c[0]||2===c[0])){a=0;continue}if(3===c[0]&&(!o||c[1]>o[0]&&c[1]<o[3])){a.label=c[1];break}if(6===c[0]&&a.label<o[1]){a.label=o[1],o=c;break}if(o&&a.label<o[2]){a.label=o[2],a.ops.push(c);break}o[2]&&a.ops.pop(),a.trys.pop();continue}c=t.call(e,a)}catch(e){c=[6,e],r=0}finally{n=o=0}if(5&c[0])throw c[1];return{value:c[0]?c[1]:void 0,done:!0}}}}function ez(e,t){var n;return"file://"===e.file||(null==(n=e.file)?void 0:n.match(/https?:\/\//))?Promise.resolve({error:!1,reason:null,external:!0,sourceStackFrame:e,originalStackFrame:null,originalCodeFrame:null,ignored:!0}):eL(function(){var n,r;return eA(this,function(o){if("rejected"===t.status)throw Error(t.reason);return[2,{error:!1,reason:null,external:!1,sourceStackFrame:e,originalStackFrame:(r=t.value).originalStackFrame,originalCodeFrame:r.originalCodeFrame||null,ignored:(null==(n=r.originalStackFrame)?void 0:n.ignored)||!1}]})})().catch(function(t){var n,r;return{error:!0,reason:null!=(r=null!=(n=null==t?void 0:t.message)?n:null==t?void 0:t.toString())?r:"Unknown Error",external:!1,sourceStackFrame:e,originalStackFrame:null,originalCodeFrame:null,ignored:!1}})}function eR(e,t,n){return eL(function(){var r,o,a,i;return eA(this,function(l){switch(l.label){case 0:r={frames:e,isServer:"server"===t,isEdgeServer:"edge-server"===t,isAppDirectory:n},o=void 0,a=void 0,l.label=1;case 1:return l.trys.push([1,3,,4]),[4,fetch("/__nextjs_original-stack-frames",{method:"POST",body:JSON.stringify(r)})];case 2:return o=l.sent(),[3,4];case 3:return a=l.sent()+"",[3,4];case 4:if(!(o&&o.ok&&204!==o.status))return[3,6];return[4,o.json()];case 5:return i=l.sent(),[2,Promise.all(e.map(function(e,t){return ez(e,i[t])}))];case 6:if(!o)return[3,8];return[4,o.text()];case 7:a=l.sent(),l.label=8;case 8:return[2,Promise.all(e.map(function(e){return ez(e,{status:"rejected",reason:"Failed to fetch the original stack frames ".concat(a?": ".concat(a):"")})}))]}})})()}function eD(e){if(!e.file)return"";var t=eT(e.file),n="";if(t)n=eI(e.file);else try{var r,o=new URL(e.file),a="";(null==(r=globalThis.location)?void 0:r.origin)!==o.origin&&("null"===o.origin?a+=o.protocol:a+=o.origin),a+=o.pathname,n=eI(a)}catch(t){n=eI(e.file)}return!eT(e.file)&&null!=e.line1&&n&&"<anonymous>"!==e.file&&(null!=e.column1?n+=" (".concat(e.line1,":").concat(e.column1,")"):n+=" (".concat(e.line1,")")),n}function eM(e){var t,n,r=(0,O.c)(6);r[0]!==e?(t=void 0===e?{}:e,r[0]=e,r[1]=t):t=r[1];var o=t.file,a=t.line1,i=t.column1;return r[2]!==i||r[3]!==o||r[4]!==a?(n=function(){if(null!=o&&null!=a&&null!=i){var e=new URLSearchParams;e.append("file",o),e.append("line1",String(a)),e.append("column1",String(i)),self.fetch("".concat(process.env.__NEXT_ROUTER_BASEPATH||"","/__nextjs_launch-editor?").concat(e.toString())).then(eZ,function(e){console.error('Failed to open file "'.concat(o," (").concat(a,":").concat(i,')" in your editor. Cause:'),e)})}},r[2]=i,r[3]=o,r[4]=a,r[5]=n):n=r[5],n}function eZ(){}function eF(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function eU(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function eH(e){var t,n,r=(0,O.c)(3);return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",fill:"currentColor",d:"M11.5 9.75V11.25C11.5 11.3881 11.3881 11.5 11.25 11.5H4.75C4.61193 11.5 4.5 11.3881 4.5 11.25L4.5 4.75C4.5 4.61193 4.61193 4.5 4.75 4.5H6.25H7V3H6.25H4.75C3.7835 3 3 3.7835 3 4.75V11.25C3 12.2165 3.7835 13 4.75 13H11.25C12.2165 13 13 12.2165 13 11.25V9.75V9H11.5V9.75ZM8.5 3H9.25H12.2495C12.6637 3 12.9995 3.33579 12.9995 3.75V6.75V7.5H11.4995V6.75V5.56066L8.53033 8.52978L8 9.06011L6.93934 7.99945L7.46967 7.46912L10.4388 4.5H9.25H8.5V3Z"}),r[0]=t):t=r[0],r[1]!==e?(n=(0,S.jsx)("svg",eU(eF({xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none"},e),{children:t})),r[1]=e,r[2]=n):n=r[2],n}function eV(e){var t,n,r=(0,O.c)(3);return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.55846 2H7.44148L1.88975 13.5H14.1102L8.55846 2ZM9.90929 1.34788C9.65902 0.829456 9.13413 0.5 8.55846 0.5H7.44148C6.86581 0.5 6.34092 0.829454 6.09065 1.34787L0.192608 13.5653C-0.127943 14.2293 0.355835 15 1.09316 15H14.9068C15.6441 15 16.1279 14.2293 15.8073 13.5653L9.90929 1.34788ZM8.74997 4.75V5.5V8V8.75H7.24997V8V5.5V4.75H8.74997ZM7.99997 12C8.55226 12 8.99997 11.5523 8.99997 11C8.99997 10.4477 8.55226 10 7.99997 10C7.44769 10 6.99997 10.4477 6.99997 11C6.99997 11.5523 7.44769 12 7.99997 12Z",fill:"currentColor"}),r[0]=t):t=r[0],r[1]!==e?(n=(0,S.jsx)("svg",eU(eF({xmlns:"http://www.w3.org/2000/svg",height:"16",strokeLinejoin:"round",viewBox:"-4 -4 24 24",width:"16"},e),{children:t})),r[1]=e,r[2]=n):n=r[2],n}function eB(e){var t,n,r,o,a,i,l=(0,O.c)(6),s=e.lang;if(!s)return l[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)(eK,{}),l[0]=t):t=l[0],t;switch(s.toLowerCase()){case"jsx":case"tsx":return l[1]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsx)(eY,{}),l[1]=n):n=l[1],n;case"ts":case"typescript":return l[2]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)(eW,{}),l[2]=r):r=l[2],r;case"javascript":case"js":case"mjs":return l[3]===Symbol.for("react.memo_cache_sentinel")?(o=(0,S.jsx)(eq,{}),l[3]=o):o=l[3],o;case"json":return l[4]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)(e$,{}),l[4]=a):a=l[4],a;default:return l[5]===Symbol.for("react.memo_cache_sentinel")?(i=(0,S.jsx)(eK,{}),l[5]=i):i=l[5],i}}function e$(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{clipRule:"evenodd",fillRule:"evenodd",height:"16",viewBox:"0 0 1321.45 1333.33",width:"16",children:(0,S.jsx)("path",{d:"M221.37 618.44h757.94V405.15H755.14c-23.5 0-56.32-12.74-71.82-28.24-15.5-15.5-25-43.47-25-66.97V82.89H88.39c-1.99 0-3.49 1-4.49 2-1.5 1-2 2.5-2 4.5v1155.04c0 1.5 1 3.5 2 4.5 1 1.49 3 1.99 4.49 1.99H972.8c2 0 1.89-.99 2.89-1.99 1.5-1 3.61-3 3.61-4.5v-121.09H221.36c-44.96 0-82-36.9-82-81.99V700.44c0-45.1 36.9-82 82-82zm126.51 117.47h75.24v146.61c0 30.79-2.44 54.23-7.33 70.31-4.92 16.03-14.8 29.67-29.65 40.85-14.86 11.12-33.91 16.72-57.05 16.72-24.53 0-43.51-3.71-56.94-11.06-13.5-7.36-23.89-18.1-31.23-32.3-7.35-14.14-11.69-31.67-12.99-52.53l71.5-10.81c.11 11.81 1.07 20.61 2.81 26.33 1.76 5.78 4.75 10.37 9 13.95 2.87 2.33 6.94 3.46 12.25 3.46 8.4 0 14.58-3.46 18.53-10.37 3.9-6.92 5.87-18.6 5.87-35V735.92zm112.77 180.67l71.17-4.97c1.54 12.81 4.69 22.62 9.44 29.28 7.74 10.88 18.74 16.34 33.09 16.34 10.68 0 18.93-2.76 24.68-8.36 5.81-5.58 8.7-12.07 8.7-19.41 0-6.97-2.71-13.26-8.2-18.79-5.47-5.53-18.23-10.68-38.28-15.65-32.89-8.17-56.27-19.1-70.26-32.74-14.12-13.57-21.18-30.92-21.18-52.03 0-13.83 3.61-26.89 10.85-39.21 7.22-12.38 18.07-22.06 32.59-29.09 14.52-7.04 34.4-10.56 59.65-10.56 31 0 54.62 6.41 70.88 19.29 16.28 12.81 25.92 33.24 29.04 61.27l-70.5 4.65c-1.87-12.25-5.81-21.17-11.81-26.7-6.05-5.6-14.35-8.36-24.9-8.36-8.71 0-15.31 2.07-19.73 6.16-4.4 4.09-6.59 9.12-6.59 15.02 0 4.27 1.81 8.11 5.37 11.57 3.45 3.59 11.8 6.85 25.02 9.93 32.75 7.86 56.2 15.84 70.31 23.87 14.18 8.05 24.52 17.98 30.96 29.92 6.44 11.88 9.66 25.2 9.66 39.96 0 17.29-4.3 33.24-12.88 47.89-8.63 14.58-20.61 25.7-36.08 33.24-15.41 7.54-34.85 11.31-58.33 11.31-41.24 0-69.81-8.86-85.68-26.52-15.88-17.65-24.85-40.09-26.96-67.3zm248.74-45.5c0-44.05 11.02-78.36 33.09-102.87 22.09-24.57 52.82-36.82 92.24-36.82 40.38 0 71.5 12.07 93.34 36.13 21.86 24.13 32.77 57.94 32.77 101.37 0 31.54-4.75 57.36-14.3 77.54-9.54 20.18-23.37 35.89-41.4 47.13-18.07 11.24-40.55 16.84-67.48 16.84-27.33 0-49.99-4.83-67.94-14.52-17.92-9.74-32.49-25.07-43.62-46.06-11.13-20.92-16.72-47.19-16.72-78.74zm74.89.19c0 27.21 4.57 46.81 13.68 58.68 9.13 11.88 21.57 17.85 37.26 17.85 16.1 0 28.65-5.84 37.45-17.47 8.87-11.68 13.28-32.54 13.28-62.77 0-25.39-4.63-43.92-13.84-55.61-9.26-11.76-21.75-17.6-37.56-17.6-15.13 0-27.34 5.97-36.49 17.85-9.21 11.88-13.78 31.61-13.78 59.07zm209.08-135.36h69.99l90.98 149.05V735.91h70.83v269.96h-70.83l-90.48-148.24v148.24h-70.49V735.91zm67.71-117.47h178.37c45.1 0 82 37.04 82 82v340.91c0 44.96-37.03 81.99-82 81.99h-178.37v147c0 17.5-6.99 32.99-18.5 44.5-11.5 11.49-27 18.5-44.5 18.5H62.97c-17.5 0-32.99-7-44.5-18.5-11.49-11.5-18.5-27-18.5-44.5V63.49c0-17.5 7-33 18.5-44.5S45.97.49 62.97.49H700.1c1.5-.5 3-.5 4.5-.5 7 0 14 3 19 7.49h1c1 .5 1.5 1 2.5 2l325.46 329.47c5.5 5.5 9.5 13 9.5 21.5 0 2.5-.5 4.5-1 7v250.98zM732.61 303.47V96.99l232.48 235.47H761.6c-7.99 0-14.99-3.5-20.5-8.49-4.99-5-8.49-12.5-8.49-20.5z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function eq(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{height:"16",viewBox:"0 0 50 50",width:"16",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("path",{d:"M 43.335938 4 L 6.667969 4 C 5.195313 4 4 5.195313 4 6.667969 L 4 43.332031 C 4 44.804688 5.195313 46 6.667969 46 L 43.332031 46 C 44.804688 46 46 44.804688 46 43.335938 L 46 6.667969 C 46 5.195313 44.804688 4 43.335938 4 Z M 27 36.183594 C 27 40.179688 24.65625 42 21.234375 42 C 18.140625 42 15.910156 39.925781 15 38 L 18.144531 36.097656 C 18.75 37.171875 19.671875 38 21 38 C 22.269531 38 23 37.503906 23 35.574219 L 23 23 L 27 23 Z M 35.675781 42 C 32.132813 42 30.121094 40.214844 29 38 L 32 36 C 32.816406 37.335938 33.707031 38.613281 35.589844 38.613281 C 37.171875 38.613281 38 37.824219 38 36.730469 C 38 35.425781 37.140625 34.960938 35.402344 34.199219 L 34.449219 33.789063 C 31.695313 32.617188 29.863281 31.148438 29.863281 28.039063 C 29.863281 25.179688 32.046875 23 35.453125 23 C 37.878906 23 39.621094 23.84375 40.878906 26.054688 L 37.910156 27.964844 C 37.253906 26.789063 36.550781 26.328125 35.453125 26.328125 C 34.335938 26.328125 33.628906 27.039063 33.628906 27.964844 C 33.628906 29.109375 34.335938 29.570313 35.972656 30.28125 L 36.925781 30.691406 C 40.171875 32.078125 42 33.496094 42 36.683594 C 42 40.117188 39.300781 42 35.675781 42 Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function eW(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsxs)("svg",{fill:"none",height:"14",viewBox:"0 0 512 512",width:"14",xmlns:"http://www.w3.org/2000/svg",children:[(0,S.jsx)("rect",{fill:"currentColor",height:"512",rx:"50",width:"512"}),(0,S.jsx)("rect",{fill:"currentColor",height:"512",rx:"50",width:"512"}),(0,S.jsx)("path",{clipRule:"evenodd",d:"m316.939 407.424v50.061c8.138 4.172 17.763 7.3 28.875 9.386s22.823 3.129 35.135 3.129c11.999 0 23.397-1.147 34.196-3.442 10.799-2.294 20.268-6.075 28.406-11.342 8.138-5.266 14.581-12.15 19.328-20.65s7.121-19.007 7.121-31.522c0-9.074-1.356-17.026-4.069-23.857s-6.625-12.906-11.738-18.225c-5.112-5.319-11.242-10.091-18.389-14.315s-15.207-8.213-24.18-11.967c-6.573-2.712-12.468-5.345-17.685-7.9-5.217-2.556-9.651-5.163-13.303-7.822-3.652-2.66-6.469-5.476-8.451-8.448-1.982-2.973-2.974-6.336-2.974-10.091 0-3.441.887-6.544 2.661-9.308s4.278-5.136 7.512-7.118c3.235-1.981 7.199-3.52 11.894-4.615 4.696-1.095 9.912-1.642 15.651-1.642 4.173 0 8.581.313 13.224.938 4.643.626 9.312 1.591 14.008 2.894 4.695 1.304 9.259 2.947 13.694 4.928 4.434 1.982 8.529 4.276 12.285 6.884v-46.776c-7.616-2.92-15.937-5.084-24.962-6.492s-19.381-2.112-31.066-2.112c-11.895 0-23.163 1.278-33.805 3.833s-20.006 6.544-28.093 11.967c-8.086 5.424-14.476 12.333-19.171 20.729-4.695 8.395-7.043 18.433-7.043 30.114 0 14.914 4.304 27.638 12.912 38.172 8.607 10.533 21.675 19.45 39.204 26.751 6.886 2.816 13.303 5.579 19.25 8.291s11.086 5.528 15.415 8.448c4.33 2.92 7.747 6.101 10.252 9.543 2.504 3.441 3.756 7.352 3.756 11.733 0 3.233-.783 6.231-2.348 8.995s-3.939 5.162-7.121 7.196-7.147 3.624-11.894 4.771c-4.748 1.148-10.303 1.721-16.668 1.721-10.851 0-21.597-1.903-32.24-5.71-10.642-3.806-20.502-9.516-29.579-17.13zm-84.159-123.342h64.22v-41.082h-179v41.082h63.906v182.918h50.874z",fill:"var(--color-background-100)",fillRule:"evenodd"})]}),t[0]=e):e=t[0],e}function eK(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"16",height:"17",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.5 7v7a2.5 2.5 0 0 1-2.5 2.5H4A2.5 2.5 0 0 1 1.5 14V.5h7.586a1 1 0 0 1 .707.293l4.414 4.414a1 1 0 0 1 .293.707V7zM13 7v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2h5v5h5zM9.5 2.621V5.5h2.879L9.5 2.621z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function eY(){var e,t,n=(0,O.c)(2);return n[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("g",{clipPath:"url(#file_react_clip0_872_3183)",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M4.5 1.93782C4.70129 1.82161 4.99472 1.7858 5.41315 1.91053C5.83298 2.03567 6.33139 2.31073 6.87627 2.73948C7.01136 2.84578 7.14803 2.96052 7.28573 3.08331C6.86217 3.53446 6.44239 4.04358 6.03752 4.60092C5.35243 4.67288 4.70164 4.78186 4.09916 4.92309C4.06167 4.74244 4.03064 4.56671 4.00612 4.39656C3.90725 3.71031 3.91825 3.14114 4.01979 2.71499C4.12099 2.29025 4.29871 2.05404 4.5 1.93782ZM7.49466 1.95361C7.66225 2.08548 7.83092 2.22804 7.99999 2.38067C8.16906 2.22804 8.33773 2.08548 8.50532 1.95361C9.10921 1.47842 9.71982 1.12549 10.3012 0.952202C10.8839 0.778496 11.4838 0.7738 12 1.0718C12.5161 1.3698 12.812 1.89169 12.953 2.48322C13.0936 3.07333 13.0932 3.77858 12.9836 4.53917C12.9532 4.75024 12.9141 4.9676 12.8665 5.19034C13.0832 5.26044 13.291 5.33524 13.489 5.41444C14.2025 5.69983 14.8134 6.05217 15.2542 6.46899C15.696 6.8868 16 7.404 16 8C16 8.596 15.696 9.11319 15.2542 9.53101C14.8134 9.94783 14.2025 10.3002 13.489 10.5856C13.291 10.6648 13.0832 10.7396 12.8665 10.8097C12.9141 11.0324 12.9532 11.2498 12.9837 11.4608C13.0932 12.2214 13.0936 12.9267 12.953 13.5168C12.812 14.1083 12.5161 14.6302 12 14.9282C11.4839 15.2262 10.8839 15.2215 10.3012 15.0478C9.71984 14.8745 9.10923 14.5216 8.50534 14.0464C8.33775 13.9145 8.16906 13.7719 7.99999 13.6193C7.83091 13.7719 7.66223 13.9145 7.49464 14.0464C6.89075 14.5216 6.28014 14.8745 5.69879 15.0478C5.11605 15.2215 4.51613 15.2262 3.99998 14.9282C3.48383 14.6302 3.18794 14.1083 3.047 13.5168C2.9064 12.9267 2.90674 12.2214 3.01632 11.4608C3.04673 11.2498 3.08586 11.0324 3.13351 10.8097C2.91679 10.7395 2.709 10.6648 2.511 10.5856C1.79752 10.3002 1.18658 9.94783 0.745833 9.53101C0.304028 9.11319 0 8.596 0 8C0 7.404 0.304028 6.8868 0.745833 6.46899C1.18658 6.05217 1.79752 5.69983 2.511 5.41444C2.709 5.33524 2.9168 5.26044 3.13352 5.19034C3.08587 4.9676 3.04675 4.75024 3.01634 4.53917C2.90676 3.77858 2.90642 3.07332 3.04702 2.48321C3.18796 1.89169 3.48385 1.3698 4 1.0718C4.51615 0.773798 5.11607 0.778495 5.69881 0.952201C6.28016 1.12549 6.89077 1.47841 7.49466 1.95361ZM7.36747 4.51025C7.57735 4.25194 7.78881 4.00927 7.99999 3.78356C8.21117 4.00927 8.42263 4.25194 8.63251 4.51025C8.42369 4.50346 8.21274 4.5 8 4.5C7.78725 4.5 7.5763 4.50345 7.36747 4.51025ZM8.71425 3.08331C9.13781 3.53447 9.55759 4.04358 9.96246 4.60092C10.6475 4.67288 11.2983 4.78186 11.9008 4.92309C11.9383 4.74244 11.9693 4.56671 11.9939 4.39657C12.0927 3.71031 12.0817 3.14114 11.9802 2.71499C11.879 2.29025 11.7013 2.05404 11.5 1.93782C11.2987 1.82161 11.0053 1.7858 10.5868 1.91053C10.167 2.03568 9.66859 2.31073 9.12371 2.73948C8.98862 2.84578 8.85196 2.96052 8.71425 3.08331ZM8 5.5C8.48433 5.5 8.95638 5.51885 9.41188 5.55456C9.67056 5.93118 9.9229 6.33056 10.1651 6.75C10.4072 7.16944 10.6269 7.58766 10.8237 7.99998C10.6269 8.41232 10.4072 8.83055 10.165 9.25C9.92288 9.66944 9.67053 10.0688 9.41185 10.4454C8.95636 10.4812 8.48432 10.5 8 10.5C7.51567 10.5 7.04363 10.4812 6.58813 10.4454C6.32945 10.0688 6.0771 9.66944 5.83494 9.25C5.59277 8.83055 5.37306 8.41232 5.17624 7.99998C5.37306 7.58765 5.59275 7.16944 5.83492 6.75C6.07708 6.33056 6.32942 5.93118 6.5881 5.55456C7.04361 5.51884 7.51566 5.5 8 5.5ZM11.0311 6.25C11.1375 6.43423 11.2399 6.61864 11.3385 6.80287C11.4572 6.49197 11.5616 6.18752 11.6515 5.89178C11.3505 5.82175 11.0346 5.75996 10.706 5.70736C10.8163 5.8848 10.9247 6.06576 11.0311 6.25ZM11.0311 9.75C11.1374 9.56576 11.2399 9.38133 11.3385 9.19709C11.4572 9.50801 11.5617 9.81246 11.6515 10.1082C11.3505 10.1782 11.0346 10.24 10.7059 10.2926C10.8162 10.1152 10.9247 9.93424 11.0311 9.75ZM11.9249 7.99998C12.2051 8.62927 12.4362 9.24738 12.6151 9.83977C12.7903 9.78191 12.958 9.72092 13.1176 9.65708C13.7614 9.39958 14.2488 9.10547 14.5671 8.80446C14.8843 8.50445 15 8.23243 15 8C15 7.76757 14.8843 7.49555 14.5671 7.19554C14.2488 6.89453 13.7614 6.60042 13.1176 6.34292C12.958 6.27907 12.7903 6.21808 12.6151 6.16022C12.4362 6.7526 12.2051 7.37069 11.9249 7.99998ZM9.96244 11.3991C10.6475 11.3271 11.2983 11.2181 11.9008 11.0769C11.9383 11.2576 11.9694 11.4333 11.9939 11.6034C12.0928 12.2897 12.0817 12.8589 11.9802 13.285C11.879 13.7098 11.7013 13.946 11.5 14.0622C11.2987 14.1784 11.0053 14.2142 10.5868 14.0895C10.167 13.9643 9.66861 13.6893 9.12373 13.2605C8.98863 13.1542 8.85196 13.0395 8.71424 12.9167C9.1378 12.4655 9.55758 11.9564 9.96244 11.3991ZM8.63249 11.4898C8.42262 11.7481 8.21116 11.9907 7.99999 12.2164C7.78881 11.9907 7.57737 11.7481 7.36749 11.4897C7.57631 11.4965 7.78726 11.5 8 11.5C8.21273 11.5 8.42367 11.4965 8.63249 11.4898ZM4.96891 9.75C5.07528 9.93424 5.18375 10.1152 5.29404 10.2926C4.9654 10.24 4.64951 10.1782 4.34844 10.1082C4.43833 9.81246 4.54276 9.508 4.66152 9.19708C4.76005 9.38133 4.86254 9.56575 4.96891 9.75ZM6.03754 11.3991C5.35244 11.3271 4.70163 11.2181 4.09914 11.0769C4.06165 11.2576 4.03062 11.4333 4.0061 11.6034C3.90723 12.2897 3.91823 12.8589 4.01977 13.285C4.12097 13.7098 4.29869 13.946 4.49998 14.0622C4.70127 14.1784 4.9947 14.2142 5.41313 14.0895C5.83296 13.9643 6.33137 13.6893 6.87625 13.2605C7.01135 13.1542 7.14802 13.0395 7.28573 12.9167C6.86217 12.4655 6.4424 11.9564 6.03754 11.3991ZM4.07507 7.99998C3.79484 8.62927 3.56381 9.24737 3.38489 9.83977C3.20969 9.78191 3.042 9.72092 2.88239 9.65708C2.23864 9.39958 1.75123 9.10547 1.43294 8.80446C1.11571 8.50445 1 8.23243 1 8C1 7.76757 1.11571 7.49555 1.43294 7.19554C1.75123 6.89453 2.23864 6.60042 2.88239 6.34292C3.042 6.27907 3.2097 6.21808 3.3849 6.16022C3.56383 6.75261 3.79484 7.37069 4.07507 7.99998ZM4.66152 6.80287C4.54277 6.49197 4.43835 6.18752 4.34846 5.89178C4.64952 5.82175 4.96539 5.75996 5.29402 5.70736C5.18373 5.8848 5.07526 6.06576 4.96889 6.25C4.86253 6.43423 4.76005 6.61864 4.66152 6.80287ZM9.25 8C9.25 8.69036 8.69036 9.25 8 9.25C7.30964 9.25 6.75 8.69036 6.75 8C6.75 7.30965 7.30964 6.75 8 6.75C8.69036 6.75 9.25 7.30965 9.25 8Z",fill:"currentColor"})}),n[0]=e):e=n[0],n[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsxs)("svg",{height:"16",strokeLinejoin:"round",viewBox:"0 0 16 16",width:"16",children:[e,(0,S.jsx)("defs",{children:(0,S.jsx)("clipPath",{id:"file_react_clip0_872_3183",children:(0,S.jsx)("rect",{width:"16",height:"16",fill:"white"})})})]}),n[1]=t):t=n[1],t}var eG=__webpack_require__("./dist/compiled/anser/index.js"),eX=__webpack_require__.n(eG),eQ=__webpack_require__("./dist/compiled/strip-ansi/index.js"),eJ=__webpack_require__.n(eQ);function e0(e){var t=e.split(/\r?\n/g),n=t.map(function(e){return null===/^>? +\d+ +\| [ ]+/.exec(eJ()(e))?null:/^>? +\d+ +\| ( *)/.exec(eJ()(e))}).filter(Boolean).map(function(e){return e.pop()}).reduce(function(e,t){return isNaN(e)?t.length:Math.min(e,t.length)},NaN);return n>1?t.map(function(e,t){return~(t=e.indexOf("|"))?e.substring(0,t)+e.substring(t).replace("^\\ {".concat(n,"}"),""):e}).join("\n"):t.join("\n")}function e1(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function e2(e){var t,n,r,o=e.stackFrame,a=e.codeFrame,i=(0,C.useMemo)(function(){return(function(e){var t=eX().ansiToJson(e,{json:!0,use_classes:!0,remove_empty:!0}),n=[],r=[],o=!0,a=!1,i=void 0;try{for(var l,s=t[Symbol.iterator]();!(o=(l=s.next()).done);o=!0){var c=l.value;if("string"==typeof c.content&&c.content.includes("\n"))for(var u=c.content.split("\n"),d=0;d<u.length;d++){var f=u[d];f&&r.push(function(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}(function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},c),{content:f})),d<u.length-1&&(n.push(r),r=[])}else r.push(c)}}catch(e){a=!0,i=e}finally{try{o||null==s.return||s.return()}finally{if(a)throw i}}return r.length>0&&n.push(r),n})(e0(a)).map(function(e){var t,n,r,a,i,l,s,c,u;return{line:e,parsedLine:(t=e,n=o,((null==(r=t[0])?void 0:r.content)===">"||(null==(a=t[0])?void 0:a.content)===" ")&&(s=null==(l=t[1])||null==(u=l.content)||null==(c=u.replace("|",""))?void 0:c.trim()),{lineNumber:s,isErroredLine:s===(null==(i=n.line1)?void 0:i.toString())})}})},[a,o]),l=eM({file:o.file,line1:null!=(n=o.line1)?n:1,column1:null!=(r=o.column1)?r:1}),s=null==o||null==(t=o.file)?void 0:t.split(".").pop();return(0,S.jsxs)("div",{"data-nextjs-codeframe":!0,children:[(0,S.jsx)("div",{className:"code-frame-header",children:(0,S.jsxs)("p",{className:"code-frame-link",children:[(0,S.jsx)("span",{className:"code-frame-icon",children:(0,S.jsx)(eB,{lang:s})}),(0,S.jsxs)("span",{"data-text":!0,children:[eD(o)," @"," ",(0,S.jsx)(eP,{text:o.methodName})]}),(0,S.jsx)("button",{"aria-label":"Open in editor","data-with-open-in-editor-link-source-file":!0,onClick:l,children:(0,S.jsx)("span",{className:"code-frame-icon","data-icon":"right",children:(0,S.jsx)(eH,{width:16,height:16})})})]})}),(0,S.jsx)("pre",{className:"code-frame-pre",children:(0,S.jsx)("div",{className:"code-frame-lines",children:i.map(function(e,t){var n,r,o=e.line,a=e.parsedLine,i=a.lineNumber,l=a.isErroredLine,s={};return i&&(s["data-nextjs-codeframe-line"]=i),l&&(s["data-nextjs-codeframe-line--errored"]=!0),(0,S.jsx)("div",(n=e1({},s),r=r={children:o.map(function(e,t){return(0,S.jsx)("span",{style:e1({color:e.fg?"var(--color-".concat(e.fg,")"):void 0},"bold"===e.decoration?{fontWeight:500}:"italic"===e.decoration?{fontStyle:"italic"}:void 0),children:e.content},"frame-".concat(t))})},Object.getOwnPropertyDescriptors?Object.defineProperties(n,Object.getOwnPropertyDescriptors(r)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(r)).forEach(function(e){Object.defineProperty(n,e,Object.getOwnPropertyDescriptor(r,e))}),n),"line-".concat(t))})})})]})}var e3=function(e){var t,n,r,o,a,i,l=(0,O.c)(8);return(l[0]!==e?(a=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children","className"]),r=e.children,o=e.className,l[0]=e,l[1]=r,l[2]=o,l[3]=a):(r=l[1],o=l[2],a=l[3]),l[4]!==r||l[5]!==o||l[6]!==a)?(i=(0,S.jsx)("div",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"data-nextjs-dialog-body":!0,className:o},a),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),l[4]=r,l[5]=o,l[6]=a,l[7]=i):i=l[7],i},e4=function(e){var t,n,r,o,a,i,l=(0,O.c)(8);return(l[0]!==e?(a=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children","className"]),r=e.children,o=e.className,l[0]=e,l[1]=r,l[2]=o,l[3]=a):(r=l[1],o=l[2],a=l[3]),l[4]!==r||l[5]!==o||l[6]!==a)?(i=(0,S.jsx)("div",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"data-nextjs-dialog-content":!0,className:o},a),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),l[4]=r,l[5]=o,l[6]=a,l[7]=i):i=l[7],i};function e5(){var e,t,n=(e=["\n  [data-nextjs-dialog-root] {\n    --next-dialog-radius: var(--rounded-xl);\n    --next-dialog-max-width: 960px;\n    --next-dialog-row-padding: 16px;\n    --next-dialog-padding: 12px;\n    --next-dialog-notch-height: 42px;\n    --next-dialog-border-width: 1px;\n\n    display: flex;\n    flex-direction: column;\n    width: 100%;\n    max-height: calc(100% - 56px);\n    max-width: var(--next-dialog-max-width);\n    margin-right: auto;\n    margin-left: auto;\n    scale: 0.97;\n    opacity: 0;\n    transition-property: scale, opacity;\n    transition-duration: var(--transition-duration);\n    transition-timing-function: var(--timing-overlay);\n\n    &[data-rendered='true'] {\n      opacity: 1;\n      scale: 1;\n    }\n\n    [data-nextjs-scroll-fader][data-side='top'] {\n      left: 1px;\n      top: calc(\n        var(--next-dialog-notch-height) + var(--next-dialog-border-width)\n      );\n      width: calc(100% - var(--next-dialog-padding));\n      opacity: 0;\n    }\n  }\n\n  [data-nextjs-dialog] {\n    outline: 0;\n  }\n\n  [data-nextjs-dialog-backdrop] {\n    opacity: 0;\n    transition: opacity var(--transition-duration) var(--timing-overlay);\n  }\n\n  [data-nextjs-dialog-overlay] {\n    margin: 8px;\n  }\n\n  [data-nextjs-dialog-overlay][data-rendered='true']\n    [data-nextjs-dialog-backdrop] {\n    opacity: 1;\n  }\n\n  [data-nextjs-dialog-content] {\n    border: none;\n    margin: 0;\n    display: flex;\n    flex-direction: column;\n    position: relative;\n    padding: var(--next-dialog-padding);\n  }\n\n  [data-nextjs-dialog-content] > [data-nextjs-dialog-header] {\n    flex-shrink: 0;\n    margin-bottom: 8px;\n  }\n\n  [data-nextjs-dialog-content] > [data-nextjs-dialog-body] {\n    position: relative;\n    flex: 1 1 auto;\n  }\n\n  @media (max-height: 812px) {\n    [data-nextjs-dialog-overlay] {\n      max-height: calc(100% - 15px);\n    }\n  }\n\n  @media (min-width: 576px) {\n    [data-nextjs-dialog-root] {\n      --next-dialog-max-width: 540px;\n    }\n  }\n\n  @media (min-width: 768px) {\n    [data-nextjs-dialog-root] {\n      --next-dialog-max-width: 720px;\n    }\n  }\n\n  @media (min-width: 992px) {\n    [data-nextjs-dialog-root] {\n      --next-dialog-max-width: 960px;\n    }\n  }\n"],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return e5=function(){return n},n}var e6=eg(e5());function e9(){for(var e=arguments.length,t=Array(e),n=0;n<e;n++)t[n]=arguments[n];return t.filter(Boolean).join(" ")}function e8(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function e7(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function te(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function tt(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return e8(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return e8(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function tn(e,t){return"reset"===t.type?{state:"initial"}:"copied"===t.type?{state:"success"}:"copying"===t.type?{state:"pending"}:"error"===t.type?{state:"error",error:t.error}:e}function tr(e){return{state:"error",error:e}}function to(){return{state:"success"}}var ta="function"==typeof C.useActionState?function(e){var t,n,r,o,a,i=(0,O.c)(8);i[0]!==e?(t=function(t,n){return"reset"===n?{state:"initial"}:"copy"===n?navigator.clipboard?navigator.clipboard.writeText(e).then(to,tr):{state:"error",error:"Copy to clipboard is not supported in this browser"}:t},i[0]=e,i[1]=t):t=i[1],i[2]===Symbol.for("react.memo_cache_sentinel")?(n={state:"initial"},i[2]=n):n=i[2];var l=tt(C.useActionState(t,n),3),s=l[0],c=l[1],u=l[2];i[3]===Symbol.for("react.memo_cache_sentinel")?(r=function(){C.startTransition(function(){c("copy")})},i[3]=r):r=i[3];var d=r;i[4]===Symbol.for("react.memo_cache_sentinel")?(o=function(){c("reset")},i[4]=o):o=i[4];var f=o;return i[5]!==s||i[6]!==u?(a=[s,d,f,u],i[5]=s,i[6]=u,i[7]=a):a=i[7],a}:function(e){var t,n,r,o,a,i,l,s=(0,O.c)(14);s[0]===Symbol.for("react.memo_cache_sentinel")?(t={state:"initial"},s[0]=t):t=s[0];var c=tt(C.useReducer(tn,t),2),u=c[0],d=c[1];return s[1]!==e||s[2]!==u.state?(s[6]!==e?(a=function(){r||(navigator.clipboard?(d({type:"copying"}),navigator.clipboard.writeText(e).then(function(){d({type:"copied"})},function(e){d({type:"error",error:e})})):d({type:"error",error:"Copy to clipboard is not supported in this browser"}))},s[6]=e,s[7]=a):a=s[7],n=a,s[8]===Symbol.for("react.memo_cache_sentinel")?(i=function(){d({type:"reset"})},s[8]=i):i=s[8],o=i,r="pending"===u.state,s[1]=e,s[2]=u.state,s[3]=n,s[4]=r,s[5]=o):(n=s[3],r=s[4],o=s[5]),s[9]!==n||s[10]!==u||s[11]!==r||s[12]!==o?(l=[u,n,o,r],s[9]=n,s[10]=u,s[11]=r,s[12]=o,s[13]=l):l=s[13],l};function ti(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v=(0,O.c)(38);v[0]!==e?(i=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["content","getContent","actionLabel","successLabel","icon","disabled"]),n=e.content,o=e.getContent,t=e.actionLabel,l=e.successLabel,a=e.icon,r=e.disabled,v[0]=e,v[1]=t,v[2]=n,v[3]=r,v[4]=o,v[5]=a,v[6]=i,v[7]=l):(t=v[1],n=v[2],r=v[3],o=v[4],a=v[5],i=v[6],l=v[7]),v[8]!==n||v[9]!==o?(s=n||(o?o():""),v[8]=n,v[9]=o,v[10]=s):s=v[10];var y=tt(ta(s),4),b=y[0],x=y[1],w=y[2],_=y[3],k="error"===b.state?b.error:null;v[11]!==k?(c=function(){null!==k&&console.warn(k)},u=[k],v[11]=k,v[12]=c,v[13]=u):(c=v[12],u=v[13]),C.useEffect(c,u),v[14]!==b.state||v[15]!==w?(d=function(){if("success"===b.state){var e=setTimeout(function(){w()},2e3);return function(){clearTimeout(e)}}},v[14]=b.state,v[15]=w,v[16]=d):d=v[16],v[17]!==b.state||v[18]!==_||v[19]!==w?(f=[_,b.state,w],v[17]=b.state,v[18]=_,v[19]=w,v[20]=f):f=v[20],C.useEffect(d,f);var j=!navigator.clipboard||_||r||!!k,P="success"===b.state?l:t;v[21]!==b.state||v[22]!==a?(p="success"===b.state?(0,S.jsx)(ts,{}):a||(0,S.jsx)(tl,{width:14,height:14,className:"error-overlay-toolbar-button-icon"}),v[21]=b.state,v[22]=a,v[23]=p):p=v[23];var E=p,T="nextjs-data-copy-button--".concat(b.state);v[24]!==e.className||v[25]!==T?(h=e9(e.className,"nextjs-data-copy-button",T),v[24]=e.className,v[25]=T,v[26]=h):h=v[26],v[27]!==x||v[28]!==j?(m=function(){j||x()},v[27]=x,v[28]=j,v[29]=m):m=v[29];var I="error"===b.state?" ".concat(b.error):null;return v[30]!==j||v[31]!==P||v[32]!==E||v[33]!==i||v[34]!==h||v[35]!==m||v[36]!==I?(g=(0,S.jsxs)("button",te(e7({},i),{type:"button",title:P,"aria-label":P,"aria-disabled":j,disabled:j,"data-nextjs-copy-button":!0,className:h,onClick:m,children:[E,I]})),v[30]=j,v[31]=P,v[32]=E,v[33]=i,v[34]=h,v[35]=m,v[36]=I,v[37]=g):g=v[37],g}function tl(e){var t,n,r=(0,O.c)(3);return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M2.406.438c-.845 0-1.531.685-1.531 1.53v6.563c0 .846.686 1.531 1.531 1.531H3.937V8.75H2.406a.219.219 0 0 1-.219-.219V1.97c0-.121.098-.219.22-.219h4.812c.12 0 .218.098.218.219v.656H8.75v-.656c0-.846-.686-1.532-1.531-1.532H2.406zm4.375 3.5c-.845 0-1.531.685-1.531 1.53v6.563c0 .846.686 1.531 1.531 1.531h4.813c.845 0 1.531-.685 1.531-1.53V5.468c0-.846-.686-1.532-1.531-1.532H6.78zm-.218 1.53c0-.12.097-.218.218-.218h4.813c.12 0 .219.098.219.219v6.562c0 .121-.098.219-.22.219H6.782a.219.219 0 0 1-.218-.219V5.47z",fill:"currentColor"}),r[0]=t):t=r[0],r[1]!==e?(n=(0,S.jsx)("svg",te(e7({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),{children:t})),r[1]=e,r[2]=n):n=r[2],n}function ts(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{height:"16",xlinkTitle:"copied",viewBox:"0 0 16 16",width:"16",stroke:"currentColor",fill:"currentColor",children:(0,S.jsx)("path",{d:"M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"})}),t[0]=e):e=t[0],e}function tc(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function tu(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}var td=function(){if("undefined"==typeof window)return!1;var e="chrome"in window&&window.chrome,t=window.navigator.vendor;return null!=e&&"Google Inc."===t}();function tf(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h=(0,O.c)(14);return h[0]===Symbol.for("react.memo_cache_sentinel")?(t={maskType:"luminance"},h[0]=t):t=h[0],h[1]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsx)("mask",{id:"nodejs_icon_mask_a",style:t,maskUnits:"userSpaceOnUse",x:"0",y:"0",width:"14",height:"14",children:(0,S.jsx)("path",{d:"M6.67.089 1.205 3.256a.663.663 0 0 0-.33.573v6.339c0 .237.126.455.33.574l5.466 3.17a.66.66 0 0 0 .66 0l5.465-3.17a.664.664 0 0 0 .329-.574V3.829a.663.663 0 0 0-.33-.573L7.33.089a.663.663 0 0 0-.661 0",fill:"#fff"})}),h[1]=n):n=h[1],h[2]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("g",{mask:"url(#nodejs_icon_mask_a)",children:(0,S.jsx)("path",{d:"M18.648 2.717 3.248-4.86-4.648 11.31l15.4 7.58 7.896-16.174z",fill:"url(#nodejs_icon_linear_gradient_b)"})}),h[2]=r):r=h[2],h[3]===Symbol.for("react.memo_cache_sentinel")?(o={maskType:"luminance"},h[3]=o):o=h[3],h[4]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)("mask",{id:"nodejs_icon_mask_c",style:o,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"12",height:"14",children:(0,S.jsx)("path",{d:"M1.01 10.57a.663.663 0 0 0 .195.17l4.688 2.72.781.45a.66.66 0 0 0 .51.063l5.764-10.597a.653.653 0 0 0-.153-.122L9.216 1.18 7.325.087a.688.688 0 0 0-.171-.07L1.01 10.57z",fill:"#fff"})}),h[4]=a):a=h[4],h[5]===Symbol.for("react.memo_cache_sentinel")?(i=(0,S.jsx)("g",{mask:"url(#nodejs_icon_mask_c)",children:(0,S.jsx)("path",{d:"M-5.647 4.958 5.226 19.734l14.38-10.667L8.734-5.71-5.647 4.958z",fill:"url(#nodejs_icon_linear_gradient_d)"})}),h[5]=i):i=h[5],h[6]===Symbol.for("react.memo_cache_sentinel")?(l={maskType:"luminance"},h[6]=l):l=h[6],h[7]===Symbol.for("react.memo_cache_sentinel")?(s=(0,S.jsx)("mask",{id:"nodejs_icon_mask_e",style:l,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"13",height:"14",children:(0,S.jsx)("path",{d:"M6.934.004A.665.665 0 0 0 6.67.09L1.22 3.247l5.877 10.746a.655.655 0 0 0 .235-.08l5.465-3.17a.665.665 0 0 0 .319-.453L7.126.015a.684.684 0 0 0-.189-.01",fill:"#fff"})}),h[7]=s):s=h[7],h[8]===Symbol.for("react.memo_cache_sentinel")?(c=(0,S.jsxs)("g",{children:[s,(0,S.jsx)("g",{mask:"url(#nodejs_icon_mask_e)",children:(0,S.jsx)("path",{d:"M1.22.002v13.992h11.894V.002H1.22z",fill:"url(#nodejs_icon_linear_gradient_f)"})})]}),h[8]=c):c=h[8],h[9]===Symbol.for("react.memo_cache_sentinel")?(u=(0,S.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_b",x1:"10.943",y1:"-1.084",x2:"2.997",y2:"15.062",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{offset:".3",stopColor:"#3E863D"}),(0,S.jsx)("stop",{offset:".5",stopColor:"#55934F"}),(0,S.jsx)("stop",{offset:".8",stopColor:"#5AAD45"})]}),h[9]=u):u=h[9],h[10]===Symbol.for("react.memo_cache_sentinel")?(d=(0,S.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_d",x1:"-.145",y1:"12.431",x2:"14.277",y2:"1.818",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{offset:".57",stopColor:"#3E863D"}),(0,S.jsx)("stop",{offset:".72",stopColor:"#619857"}),(0,S.jsx)("stop",{offset:"1",stopColor:"#76AC64"})]}),h[10]=d):d=h[10],h[11]===Symbol.for("react.memo_cache_sentinel")?(f=(0,S.jsxs)("defs",{children:[u,d,(0,S.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_f",x1:"1.225",y1:"6.998",x2:"13.116",y2:"6.998",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{offset:".16",stopColor:"#6BBF47"}),(0,S.jsx)("stop",{offset:".38",stopColor:"#79B461"}),(0,S.jsx)("stop",{offset:".47",stopColor:"#75AC64"}),(0,S.jsx)("stop",{offset:".7",stopColor:"#659E5A"}),(0,S.jsx)("stop",{offset:".9",stopColor:"#3E863D"})]})]}),h[11]=f):f=h[11],h[12]!==e?(p=(0,S.jsxs)("svg",tu(tc({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),{children:[n,r,a,i,c,f]})),h[12]=e,h[13]=p):p=h[13],p}function tp(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h=(0,O.c)(14);return h[0]===Symbol.for("react.memo_cache_sentinel")?(t={maskType:"luminance"},h[0]=t):t=h[0],h[1]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsx)("mask",{id:"nodejs_icon_mask_a",style:t,maskUnits:"userSpaceOnUse",x:"0",y:"0",width:"14",height:"14",children:(0,S.jsx)("path",{d:"M6.67.089 1.205 3.256a.663.663 0 0 0-.33.573v6.339c0 .237.126.455.33.574l5.466 3.17a.66.66 0 0 0 .66 0l5.465-3.17a.664.664 0 0 0 .329-.574V3.829a.663.663 0 0 0-.33-.573L7.33.089a.663.663 0 0 0-.661 0",fill:"#fff"})}),h[1]=n):n=h[1],h[2]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("g",{mask:"url(#nodejs_icon_mask_a)",children:(0,S.jsx)("path",{d:"M18.648 2.717 3.248-4.86-4.646 11.31l15.399 7.58 7.896-16.174z",fill:"url(#nodejs_icon_linear_gradient_b)"})}),h[2]=r):r=h[2],h[3]===Symbol.for("react.memo_cache_sentinel")?(o={maskType:"luminance"},h[3]=o):o=h[3],h[4]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)("mask",{id:"nodejs_icon_mask_c",style:o,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"12",height:"15",children:(0,S.jsx)("path",{d:"M1.01 10.571a.66.66 0 0 0 .195.172l4.688 2.718.781.451a.66.66 0 0 0 .51.063l5.764-10.597a.653.653 0 0 0-.153-.122L9.216 1.181 7.325.09a.688.688 0 0 0-.171-.07L1.01 10.572z",fill:"#fff"})}),h[4]=a):a=h[4],h[5]===Symbol.for("react.memo_cache_sentinel")?(i=(0,S.jsx)("g",{mask:"url(#nodejs_icon_mask_c)",children:(0,S.jsx)("path",{d:"M-5.647 4.96 5.226 19.736 19.606 9.07 8.734-5.707-5.647 4.96z",fill:"url(#nodejs_icon_linear_gradient_d)"})}),h[5]=i):i=h[5],h[6]===Symbol.for("react.memo_cache_sentinel")?(l={maskType:"luminance"},h[6]=l):l=h[6],h[7]===Symbol.for("react.memo_cache_sentinel")?(s=(0,S.jsx)("mask",{id:"nodejs_icon_mask_e",style:l,maskUnits:"userSpaceOnUse",x:"1",y:"0",width:"13",height:"14",children:(0,S.jsx)("path",{d:"M6.935.003a.665.665 0 0 0-.264.085l-5.45 3.158 5.877 10.747a.653.653 0 0 0 .235-.082l5.465-3.17a.665.665 0 0 0 .319-.452L7.127.014a.684.684 0 0 0-.189-.01",fill:"#fff"})}),h[7]=s):s=h[7],h[8]===Symbol.for("react.memo_cache_sentinel")?(c=(0,S.jsxs)("g",{children:[s,(0,S.jsx)("g",{mask:"url(#nodejs_icon_mask_e)",children:(0,S.jsx)("path",{d:"M1.222.001v13.992h11.893V0H1.222z",fill:"url(#nodejs_icon_linear_gradient_f)"})})]}),h[8]=c):c=h[8],h[9]===Symbol.for("react.memo_cache_sentinel")?(u=(0,S.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_b",x1:"10.944",y1:"-1.084",x2:"2.997",y2:"15.062",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{offset:".3",stopColor:"#676767"}),(0,S.jsx)("stop",{offset:".5",stopColor:"#858585"}),(0,S.jsx)("stop",{offset:".8",stopColor:"#989A98"})]}),h[9]=u):u=h[9],h[10]===Symbol.for("react.memo_cache_sentinel")?(d=(0,S.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_d",x1:"-.145",y1:"12.433",x2:"14.277",y2:"1.819",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{offset:".57",stopColor:"#747474"}),(0,S.jsx)("stop",{offset:".72",stopColor:"#707070"}),(0,S.jsx)("stop",{offset:"1",stopColor:"#929292"})]}),h[10]=d):d=h[10],h[11]===Symbol.for("react.memo_cache_sentinel")?(f=(0,S.jsxs)("defs",{children:[u,d,(0,S.jsxs)("linearGradient",{id:"nodejs_icon_linear_gradient_f",x1:"1.226",y1:"6.997",x2:"13.117",y2:"6.997",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{offset:".16",stopColor:"#878787"}),(0,S.jsx)("stop",{offset:".38",stopColor:"#A9A9A9"}),(0,S.jsx)("stop",{offset:".47",stopColor:"#A5A5A5"}),(0,S.jsx)("stop",{offset:".7",stopColor:"#8F8F8F"}),(0,S.jsx)("stop",{offset:".9",stopColor:"#626262"})]})]}),h[11]=f):f=h[11],h[12]!==e?(p=(0,S.jsxs)("svg",tu(tc({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),{children:[n,r,a,i,c,f]})),h[12]=e,h[13]=p):p=h[13],p}var th="Learn more about enabling Node.js inspector for server code with Chrome DevTools";function tm(e){var t,n,r,o=(0,O.c)(4),a=e.devtoolsFrontendUrl||"";return a&&td?(o[1]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsx)(tf,{className:"error-overlay-toolbar-button-icon",width:14,height:14}),o[1]=n):n=o[1],o[2]!==a?(r=(0,S.jsx)(ti,{"data-nextjs-data-runtime-error-copy-devtools-url":!0,className:"nodejs-inspector-button",actionLabel:"Copy Chrome DevTools URL",successLabel:"Copied",content:a,icon:n}),o[2]=a,o[3]=r):r=o[3],r):(o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("a",{title:th,"aria-label":th,className:"nodejs-inspector-button",href:"https://nextjs.org/docs/app/building-your-application/configuring/debugging#server-side-code",target:"_blank",rel:"noopener noreferrer",children:(0,S.jsx)(tp,{className:"error-overlay-toolbar-button-icon",width:14,height:14})}),o[0]=t):t=o[0],t)}function tg(e){var t,n=(0,O.c)(3),r=e.error,o=e.generateErrorInfo,a=!r;return n[0]!==o||n[1]!==a?(t=(0,S.jsx)(ti,{"data-nextjs-data-runtime-error-copy-stack":!0,className:"copy-error-button",actionLabel:"Copy Error Info",successLabel:"Error Info Copied",getContent:o,disabled:a}),n[0]=o,n[1]=a,n[2]=t):t=n[2],t}function tv(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function ty(e){if(Array.isArray(e))return e}function tb(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function tx(e,t){return ty(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||t_(e,t)||tb()}function tw(e){return ty(e)||function(e){if("undefined"!=typeof Symbol&&null!=e[Symbol.iterator]||null!=e["@@iterator"])return Array.from(e)}(e)||t_(e)||tb()}function t_(e,t){if(e){if("string"==typeof e)return tv(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return tv(e,t)}}var tk="https://react.dev/link/hydration-mismatch",tj="https://nextjs.org/docs/messages/react-hydration-error",tS=[/^In HTML, (.+?) cannot be a child of <(.+?)>\.(.*)\nThis will cause a hydration error\.(.*)/,/^In HTML, (.+?) cannot be a descendant of <(.+?)>\.\nThis will cause a hydration error\.(.*)/,/^In HTML, text nodes cannot be a child of <(.+?)>\.\nThis will cause a hydration error\./,/^In HTML, whitespace text nodes cannot be a child of <(.+?)>\. Make sure you don't have any extra whitespace between tags on each line of your source code\.\nThis will cause a hydration error\./];function tO(e){return tS.some(function(t){return t.test(e)})}var tC=["https://nextjs.org","https://react.dev"];function tP(e){return tC.some(function(t){return e.startsWith(t)})}function tE(e){var t,n,r,o,a=(0,O.c)(6),i=e.errorMessage;a[0]!==i?(t=function(e){var t,n,r,o=(t=e,n=tP,r=Array.from(t.matchAll(/https?:\/\/[^\s/$.?#].[^\s)'"]*/gi),function(e){return e[0]}),n?r.filter(function(e){return n(e)}):r);if(0===o.length)return null;var a=o[0];return a===tk?tj:a}(i),a[0]=i,a[1]=t):t=a[1];var l=t;return l?(a[3]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)(tT,{className:"error-overlay-toolbar-button-icon",width:14,height:14}),a[3]=r):r=a[3],a[4]!==l?(o=(0,S.jsx)("a",{title:"Go to related documentation","aria-label":"Go to related documentation",className:"docs-link-button",href:l,target:"_blank",rel:"noopener noreferrer",children:r}),a[4]=l,a[5]=o):o=a[5],o):(a[2]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsx)("button",{title:"No related documentation found","aria-label":"No related documentation found",className:"docs-link-button",disabled:!0,children:(0,S.jsx)(tT,{className:"error-overlay-toolbar-button-icon",width:14,height:14})}),a[2]=n):n=a[2],n)}function tT(e){var t,n,r,o,a=(0,O.c)(3);return(a[0]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M0 .875h4.375C5.448.875 6.401 1.39 7 2.187A3.276 3.276 0 0 1 9.625.875H14v11.156H9.4c-.522 0-1.023.208-1.392.577l-.544.543h-.928l-.544-.543c-.369-.37-.87-.577-1.392-.577H0V.875zm6.344 3.281a1.969 1.969 0 0 0-1.969-1.968H1.312v8.53H4.6c.622 0 1.225.177 1.744.502V4.156zm1.312 7.064V4.156c0-1.087.882-1.968 1.969-1.968h3.063v8.53H9.4c-.622 0-1.225.177-1.744.502z",fill:"currentColor"}),a[0]=r):r=a[0],a[1]!==e)?(o=(0,S.jsx)("svg",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),a[1]=e,a[2]=o):o=a[2],o}function tI(e){var t,n,r,o,a=(0,O.c)(12),i=e.error,l=e.debugInfo,s=e.feedbackButton,c=e.generateErrorInfo;a[0]!==i||a[1]!==c?(t=(0,S.jsx)(tg,{error:i,generateErrorInfo:c}),a[0]=i,a[1]=c,a[2]=t):t=a[2],a[3]!==i.message?(n=(0,S.jsx)(tE,{errorMessage:i.message}),a[3]=i.message,a[4]=n):n=a[4];var u=null==l?void 0:l.devtoolsFrontendUrl;return a[5]!==u?(r=(0,S.jsx)(tm,{devtoolsFrontendUrl:u}),a[5]=u,a[6]=r):r=a[6],a[7]!==s||a[8]!==t||a[9]!==n||a[10]!==r?(o=(0,S.jsxs)("span",{className:"error-overlay-toolbar",children:[s,t,n,r]}),a[7]=s,a[8]=t,a[9]=n,a[10]=r,a[11]=o):o=a[11],o}function tN(e){var t,n,r,o,a=(0,O.c)(3);return(a[0]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("g",{id:"thumb-up-16",children:(0,S.jsx)("path",{id:"Union",fillRule:"evenodd",clipRule:"evenodd",d:"M6.89531 2.23959C6.72984 2.1214 6.5 2.23968 6.5 2.44303V5.24989C6.5 6.21639 5.7165 6.99989 4.75 6.99989H2.5V13.4999H12.1884C12.762 13.4999 13.262 13.1095 13.4011 12.5531L14.4011 8.55306C14.5984 7.76412 14.0017 6.99989 13.1884 6.99989H9.25H8.5V6.24989V3.51446C8.5 3.43372 8.46101 3.35795 8.39531 3.31102L6.89531 2.23959ZM5 2.44303C5 1.01963 6.6089 0.191656 7.76717 1.01899L9.26717 2.09042C9.72706 2.41892 10 2.94929 10 3.51446V5.49989H13.1884C14.9775 5.49989 16.2903 7.18121 15.8563 8.91686L14.8563 12.9169C14.5503 14.1411 13.4503 14.9999 12.1884 14.9999H1.75H1V14.2499V6.24989V5.49989H1.75H4.75C4.88807 5.49989 5 5.38796 5 5.24989V2.44303Z",fill:"currentColor"})}),a[0]=r):r=a[0],a[1]!==e)?(o=(0,S.jsx)("svg",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:"thumbs-up-icon"},e),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),a[1]=e,a[2]=o):o=a[2],o}function tL(e){var t,n,r,o,a=(0,O.c)(3);return(a[0]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M5.89531 12.7603C5.72984 12.8785 5.5 12.7602 5.5 12.5569V9.75C5.5 8.7835 4.7165 8 3.75 8H1.5V1.5H11.1884C11.762 1.5 12.262 1.89037 12.4011 2.44683L13.4011 6.44683C13.5984 7.23576 13.0017 8 12.1884 8H8.25H7.5V8.75V11.4854C7.5 11.5662 7.46101 11.6419 7.39531 11.6889L5.89531 12.7603ZM4 12.5569C4 13.9803 5.6089 14.8082 6.76717 13.9809L8.26717 12.9095C8.72706 12.581 9 12.0506 9 11.4854V9.5H12.1884C13.9775 9.5 15.2903 7.81868 14.8563 6.08303L13.8563 2.08303C13.5503 0.858816 12.4503 0 11.1884 0H0.75H0V0.75V8.75V9.5H0.75H3.75C3.88807 9.5 4 9.61193 4 9.75V12.5569Z",fill:"currentColor"}),a[0]=r):r=a[0],a[1]!==e)?(o=(0,S.jsx)("svg",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:"thumbs-down-icon"},e),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),a[1]=e,a[2]=o):o=a[2],o}function tA(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function tz(e,t,n,r,o,a,i){try{var l=e[a](i),s=l.value}catch(e){n(e);return}l.done?t(s):Promise.resolve(s).then(r,o)}function tR(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function tD(e){var t,n=e.errorCode,r=e.className,o=(t=(0,C.useState)({}),function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return tA(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return tA(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),a=o[0],i=o[1],l=a[n],s=process.env.__NEXT_TELEMETRY_DISABLED,c=(0,C.useCallback)(function(e){var t;return(t=function(){return function(e,t){var n,r,o,a={label:0,sent:function(){if(1&o[0])throw o[1];return o[1]},trys:[],ops:[]},i=Object.create(("function"==typeof Iterator?Iterator:Object).prototype);return i.next=l(0),i.throw=l(1),i.return=l(2),"function"==typeof Symbol&&(i[Symbol.iterator]=function(){return this}),i;function l(l){return function(s){var c=[l,s];if(n)throw TypeError("Generator is already executing.");for(;i&&(i=0,c[0]&&(a=0)),a;)try{if(n=1,r&&(o=2&c[0]?r.return:c[0]?r.throw||((o=r.return)&&o.call(r),0):r.next)&&!(o=o.call(r,c[1])).done)return o;switch(r=0,o&&(c=[2&c[0],o.value]),c[0]){case 0:case 1:o=c;break;case 4:return a.label++,{value:c[1],done:!1};case 5:a.label++,r=c[1],c=[0];continue;case 7:c=a.ops.pop(),a.trys.pop();continue;default:if(!(o=(o=a.trys).length>0&&o[o.length-1])&&(6===c[0]||2===c[0])){a=0;continue}if(3===c[0]&&(!o||c[1]>o[0]&&c[1]<o[3])){a.label=c[1];break}if(6===c[0]&&a.label<o[1]){a.label=o[1],o=c;break}if(o&&a.label<o[2]){a.label=o[2],a.ops.push(c);break}o[2]&&a.ops.pop(),a.trys.pop();continue}c=t.call(e,a)}catch(e){c=[6,e],r=0}finally{n=o=0}if(5&c[0])throw c[1];return{value:c[0]?c[1]:void 0,done:!0}}}}(this,function(t){switch(t.label){case 0:i(function(t){var r,o;return r=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){tR(e,t,n[t])})}return e}({},t),o=null!=(o=tR({},n,e))?o:{},Object.getOwnPropertyDescriptors?Object.defineProperties(r,Object.getOwnPropertyDescriptors(o)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(o)).forEach(function(e){Object.defineProperty(r,e,Object.getOwnPropertyDescriptor(o,e))}),r}),t.label=1;case 1:return t.trys.push([1,3,,4]),[4,fetch("".concat(process.env.__NEXT_ROUTER_BASEPATH||"","/__nextjs_error_feedback?").concat(new URLSearchParams({errorCode:n,wasHelpful:e.toString()})))];case 2:return t.sent().ok||console.error("Failed to record feedback on the server."),[3,4];case 3:return console.error("Failed to record feedback:",t.sent()),[3,4];case 4:return[2]}})},function(){var e=this,n=arguments;return new Promise(function(r,o){var a=t.apply(e,n);function i(e){tz(a,r,o,i,l,"next",e)}function l(e){tz(a,r,o,i,l,"throw",e)}i(void 0)})})()},[n]);return(0,S.jsx)("div",{className:e9("error-feedback",r),role:"region","aria-label":"Error feedback",children:void 0!==l?(0,S.jsx)("p",{className:"error-feedback-thanks",role:"status","aria-live":"polite",children:"Thanks for your feedback!"}):(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)("p",{children:(0,S.jsx)("a",{href:"https://nextjs.org/telemetry#error-feedback",rel:"noopener noreferrer",target:"_blank",children:"Was this helpful?"})}),(0,S.jsx)("button",{"aria-disabled":s?"true":void 0,"aria-label":"Mark as helpful",onClick:s?void 0:function(){return c(!0)},className:e9("feedback-button",!0===l&&"voted"),title:s?"Feedback disabled due to setting NEXT_TELEMETRY_DISABLED":void 0,type:"button",children:(0,S.jsx)(tN,{"aria-hidden":"true"})}),(0,S.jsx)("button",{"aria-disabled":s?"true":void 0,"aria-label":"Mark as not helpful",onClick:s?void 0:function(){return c(!1)},className:e9("feedback-button",!1===l&&"voted"),title:s?"Feedback disabled due to setting NEXT_TELEMETRY_DISABLED":void 0,type:"button",children:(0,S.jsx)(tL,{"aria-hidden":"true",style:{translate:"1px 1px"}})})]})})}function tM(e){var t,n,r=(0,O.c)(4),o=e.errorCode;return r[0]!==o?(t=o?(0,S.jsx)(tD,{className:"error-feedback",errorCode:o}):null,r[0]=o,r[1]=t):t=r[1],r[2]!==t?(n=(0,S.jsx)("footer",{"data-nextjs-error-overlay-footer":!0,className:"error-overlay-footer",children:t}),r[2]=t,r[3]=n):n=r[3],n}var tZ="\n  .error-overlay-footer {\n    display: flex;\n    flex-direction: row;\n    justify-content: space-between;\n\n    gap: 8px;\n    padding: 12px;\n    background: var(--color-background-200);\n    border-top: 1px solid var(--color-gray-400);\n  }\n\n  .error-feedback {\n    margin-left: auto;\n\n    p {\n      font-size: var(--size-14);\n      font-weight: 500;\n      margin: 0;\n    }\n  }\n\n  ".concat("\n  .error-feedback {\n    display: flex;\n    align-items: center;\n    gap: 8px;\n    white-space: nowrap;\n    color: var(--color-gray-900);\n  }\n\n  .error-feedback-thanks {\n    height: var(--size-24);\n    display: flex;\n    align-items: center;\n    padding-right: 4px; /* To match the 4px inner padding of the thumbs up and down icons */\n  }\n\n  .feedback-button {\n    background: none;\n    border: none;\n    border-radius: var(--rounded-md);\n    width: var(--size-24);\n    height: var(--size-24);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    cursor: pointer;\n\n    &:focus {\n      outline: var(--focus-ring);\n    }\n\n    &:hover {\n      background: var(--color-gray-alpha-100);\n    }\n\n    &:active {\n      background: var(--color-gray-alpha-200);\n    }\n  }\n\n  .feedback-button[aria-disabled='true'] {\n    opacity: 0.7;\n    cursor: not-allowed;\n  }\n\n  .feedback-button.voted {\n    background: var(--color-gray-alpha-200);\n  }\n\n  .thumbs-up-icon,\n  .thumbs-down-icon {\n    color: var(--color-gray-900);\n    width: var(--size-16);\n    height: var(--size-16);\n  }\n","\n");function tF(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function tU(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return tF(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return tF(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function tH(e){var t,n,r,o,a,i=(0,O.c)(12),l=e.errorMessage,s=e.errorType,c=tU((0,C.useState)(!1),2),u=c[0],d=c[1],f=tU((0,C.useState)(!1),2),p=f[0],h=f[1],m=(0,C.useRef)(null);i[0]===Symbol.for("react.memo_cache_sentinel")?(t=function(){m.current&&h(m.current.scrollHeight>200)},i[0]=t):t=i[0],i[1]!==l?(n=[l],i[1]=l,i[2]=n):n=i[2],(0,C.useLayoutEffect)(t,n);var g=p&&"Blocking Route"!==s,v="nextjs__container_errors_desc ".concat(g&&!u?"truncated":"");return i[3]!==l||i[4]!==v?(r=(0,S.jsx)("div",{ref:m,id:"nextjs__container_errors_desc",className:v,children:l}),i[3]=l,i[4]=v,i[5]=r):r=i[5],i[6]!==u||i[7]!==g?(o=g&&!u&&(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)("div",{className:"nextjs__container_errors_gradient_overlay"}),(0,S.jsx)("button",{onClick:function(){return d(!0)},className:"nextjs__container_errors_expand_button","aria-expanded":u,"aria-controls":"nextjs__container_errors_desc",children:"Show More"})]}),i[6]=u,i[7]=g,i[8]=o):o=i[8],i[9]!==r||i[10]!==o?(a=(0,S.jsxs)("div",{className:"nextjs__container_errors_wrapper",children:[r,o]}),i[9]=r,i[10]=o,i[11]=a):a=i[11],a}function tV(e){var t,n=(0,O.c)(3),r=e.errorType,o="nextjs__container_errors_label ".concat("Blocking Route"===r?"nextjs__container_errors_label_blocking_page":"");return n[0]!==r||n[1]!==o?(t=(0,S.jsx)("span",{id:"nextjs__container_errors_label",className:o,children:r}),n[0]=r,n[1]=o,n[2]=t):t=n[2],t}function tB(e){var t,n,r=(0,O.c)(4),o=e.title,a=e.className;return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M9.24996 12.0608L8.71963 11.5304L5.89641 8.70722C5.50588 8.3167 5.50588 7.68353 5.89641 7.29301L8.71963 4.46978L9.24996 3.93945L10.3106 5.00011L9.78029 5.53044L7.31062 8.00011L9.78029 10.4698L10.3106 11.0001L9.24996 12.0608Z",fill:"currentColor"}),r[0]=t):t=r[0],r[1]!==a||r[2]!==o?(n=(0,S.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg","aria-label":o,className:a,children:t}),r[1]=a,r[2]=o,r[3]=n):n=r[3],n}function t$(e){var t,n,r=(0,O.c)(4),o=e.title,a=e.className;return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M6.75011 3.93945L7.28044 4.46978L10.1037 7.29301C10.4942 7.68353 10.4942 8.3167 10.1037 8.70722L7.28044 11.5304L6.75011 12.0608L5.68945 11.0001L6.21978 10.4698L8.68945 8.00011L6.21978 5.53044L5.68945 5.00011L6.75011 3.93945Z",fill:"currentColor"}),r[0]=t):t=r[0],r[1]!==a||r[2]!==o?(n=(0,S.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:a,"aria-label":o,children:t}),r[1]=a,r[2]=o,r[3]=n):n=r[3],n}function tq(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function tW(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v=(0,O.c)(40),y=e.runtimeErrors,b=e.activeIdx,x=e.onActiveIndexChange;v[0]!==b||v[1]!==x?(n=function(){return(0,C.startTransition)(function(){b>0&&x(Math.max(0,b-1))})},v[0]=b,v[1]=x,v[2]=n):n=v[2];var w=n;v[3]!==b||v[4]!==x||v[5]!==y.length?(r=function(){return(0,C.startTransition)(function(){b<y.length-1&&x(Math.max(0,Math.min(y.length-1,b+1)))})},v[3]=b,v[4]=x,v[5]=y.length,v[6]=r):r=v[6];var _=r,k=(0,C.useRef)(null),j=(0,C.useRef)(null),P=(t=(0,C.useState)(null),function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return tq(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return tq(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),E=P[0],T=P[1];v[7]===Symbol.for("react.memo_cache_sentinel")?(o=function(e){T(e)},v[7]=o):o=v[7];var I=o;v[8]!==_||v[9]!==w||v[10]!==E?(a=function(){if(null!=E){var e=E.getRootNode(),t=self.document,n=function(e){"ArrowLeft"===e.key?(e.preventDefault(),e.stopPropagation(),w&&w()):"ArrowRight"===e.key&&(e.preventDefault(),e.stopPropagation(),_&&_())};return e.addEventListener("keydown",n),e!==t&&t.addEventListener("keydown",n),function(){e.removeEventListener("keydown",n),e!==t&&t.removeEventListener("keydown",n)}}},i=[E,_,w],v[8]=_,v[9]=w,v[10]=E,v[11]=a,v[12]=i):(a=v[11],i=v[12]),(0,C.useEffect)(a,i),v[13]!==b||v[14]!==E||v[15]!==y.length?(l=function(){if(null!=E){var e,t,n=E.getRootNode();if(e=n,null!=(t=ShadowRoot)&&"undefined"!=typeof Symbol&&t[Symbol.hasInstance]?!!t[Symbol.hasInstance](e):e instanceof t){var r=n.activeElement;0===b?k.current&&r===k.current&&k.current.blur():b===y.length-1&&j.current&&r===j.current&&j.current.blur()}}},s=[E,b,y.length],v[13]=b,v[14]=E,v[15]=y.length,v[16]=l,v[17]=s):(l=v[16],s=v[17]),(0,C.useEffect)(l,s);var N=0===b,L=0===b;v[18]===Symbol.for("react.memo_cache_sentinel")?(c=(0,S.jsx)(tB,{title:"previous",className:"error-overlay-pagination-button-icon"}),v[18]=c):c=v[18],v[19]!==w||v[20]!==N||v[21]!==L?(u=(0,S.jsx)("button",{ref:k,type:"button",disabled:N,"aria-disabled":L,onClick:w,"data-nextjs-dialog-error-previous":!0,className:"error-overlay-pagination-button",children:c}),v[19]=w,v[20]=N,v[21]=L,v[22]=u):u=v[22];var A=b+1;v[23]!==b||v[24]!==A?(d=(0,S.jsxs)("span",{"data-nextjs-dialog-error-index":b,children:[A,"/"]}),v[23]=b,v[24]=A,v[25]=d):d=v[25];var z=y.length||1;v[26]!==z?(f=(0,S.jsx)("span",{"data-nextjs-dialog-header-total-count":!0,children:z}),v[26]=z,v[27]=f):f=v[27],v[28]!==d||v[29]!==f?(p=(0,S.jsxs)("div",{className:"error-overlay-pagination-count",children:[d,f]}),v[28]=d,v[29]=f,v[30]=p):p=v[30];var R=b>=y.length-1,D=b>=y.length-1;return v[31]===Symbol.for("react.memo_cache_sentinel")?(h=(0,S.jsx)(t$,{title:"next",className:"error-overlay-pagination-button-icon"}),v[31]=h):h=v[31],v[32]!==_||v[33]!==R||v[34]!==D?(m=(0,S.jsx)("button",{ref:j,type:"button",disabled:R,"aria-disabled":D,onClick:_,"data-nextjs-dialog-error-next":!0,className:"error-overlay-pagination-button",children:h}),v[32]=_,v[33]=R,v[34]=D,v[35]=m):m=v[35],v[36]!==u||v[37]!==p||v[38]!==m?(g=(0,S.jsxs)("nav",{className:"error-overlay-pagination dialog-exclude-closing-from-outside-click",ref:I,children:[u,p,m]}),v[36]=u,v[37]=p,v[38]=m,v[39]=g):g=v[39],g}function tK(e){var t,n,r,o,a=(0,O.c)(3);return(a[0]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("circle",{cx:"7",cy:"7",r:"5.5",strokeWidth:"3"}),a[0]=r):r=a[0],a[1]!==e)?(o=(0,S.jsx)("svg",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({width:"14",height:"14",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),a[1]=e,a[2]=o):o=a[2],o}function tY(e){var t,n,r,o,a,i=(0,O.c)(31),l=e.versionInfo,s=e.bundlerName,c=l.staleness;if(i[0]!==s||i[1]!==c||i[2]!==l){y=Symbol.for("react.early_return_sentinel");n:{var u=function(e){var t=e.installed,n=e.staleness,r=e.expected,o="",a="",i="",l="Next.js ".concat(t);switch(n){case"newer-than-npm":case"fresh":o=l,a="Latest available version is detected (".concat(t,")."),i="fresh";break;case"stale-patch":case"stale-minor":o="".concat(l," (stale)"),a="There is a newer version (".concat(r,") available, upgrade recommended! "),i="stale";break;case"stale-major":o="".concat(l," (outdated)"),a="An outdated version detected (latest is ".concat(r,"), upgrade is highly recommended!"),i="outdated";break;case"stale-prerelease":o="".concat(l," (stale)"),a="There is a newer canary version (".concat(r,") available, please upgrade! "),i="stale";break;case"unknown":o="".concat(l," (unknown)"),a="No Next.js version data was found.",i="unknown"}return{text:o,indicatorClass:i,title:a}}(l),d=u.text,f=u.indicatorClass,p=u.title;if(b=d,x=p,m="Turbopack"===s,c.startsWith("stale")){var h,m,g,v,y,b,x,w,_,k=m&&"turbopack-text";i[10]!==k?(w=e9(k),i[10]=k,i[11]=w):w=i[11],i[12]!==s||i[13]!==w?(_=(0,S.jsx)("span",{className:w,children:s}),i[12]=s,i[13]=w,i[14]=_):_=i[14],y=(0,S.jsxs)("a",{className:"nextjs-container-build-error-version-status dialog-exclude-closing-from-outside-click",target:"_blank",rel:"noopener noreferrer",href:"https://nextjs.org/docs/messages/version-staleness",children:[(0,S.jsx)(tK,{className:e9("version-staleness-indicator",f)}),(0,S.jsx)("span",{"data-nextjs-version-checker":!0,title:x,children:b}),_]});break n}v="nextjs-container-build-error-version-status dialog-exclude-closing-from-outside-click",h=tK,g=e9("version-staleness-indicator",f)}i[0]=s,i[1]=c,i[2]=l,i[3]=h,i[4]=m,i[5]=g,i[6]=v,i[7]=y,i[8]=b,i[9]=x}else h=i[3],m=i[4],g=i[5],v=i[6],y=i[7],b=i[8],x=i[9];if(y!==Symbol.for("react.early_return_sentinel"))return y;i[15]!==h||i[16]!==g?(t=(0,S.jsx)(h,{className:g}),i[15]=h,i[16]=g,i[17]=t):t=i[17],i[18]!==b||i[19]!==x?(n=(0,S.jsx)("span",{"data-nextjs-version-checker":!0,title:x,children:b}),i[18]=b,i[19]=x,i[20]=n):n=i[20];var j=m&&"turbopack-text";return i[21]!==j?(r=e9(j),i[21]=j,i[22]=r):r=i[22],i[23]!==s||i[24]!==r?(o=(0,S.jsx)("span",{className:r,children:s}),i[23]=s,i[24]=r,i[25]=o):o=i[25],i[26]!==v||i[27]!==t||i[28]!==n||i[29]!==o?(a=(0,S.jsxs)("span",{className:v,children:[t,n,o]}),i[26]=v,i[27]=t,i[28]=n,i[29]=o,i[30]=a):a=i[30],a}function tG(e){var t,n,r,o,a=(0,O.c)(11),i=e.runtimeErrors,l=e.activeIdx,s=e.setActiveIndex,c=e.versionInfo,u=process.env.__NEXT_BUNDLER||"Webpack";a[0]!==i?(t=null!=i?i:[],a[0]=i,a[1]=t):t=a[1];var d=null!=l?l:0,f=null!=s?s:tX;return a[2]!==t||a[3]!==d||a[4]!==f?(n=(0,S.jsx)(tQ,{side:"left",children:(0,S.jsx)(tW,{runtimeErrors:t,activeIdx:d,onActiveIndexChange:f})}),a[2]=t,a[3]=d,a[4]=f,a[5]=n):n=a[5],a[6]!==c?(r=c&&(0,S.jsx)(tQ,{side:"right",children:(0,S.jsx)(tY,{versionInfo:c,bundlerName:u})}),a[6]=c,a[7]=r):r=a[7],a[8]!==n||a[9]!==r?(o=(0,S.jsxs)("div",{"data-nextjs-error-overlay-nav":!0,children:[n,r]}),a[8]=n,a[9]=r,a[10]=o):o=a[10],o}function tX(){}function tQ(e){var t,n,r=(0,O.c)(4),o=e.children,a=e.side,i=void 0===a?"left":a;return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)(tJ,{}),r[0]=t):t=r[0],r[1]!==o||r[2]!==i?(n=(0,S.jsxs)("div",{className:"error-overlay-notch","data-side":i,children:[o,t]}),r[1]=o,r[2]=i,r[3]=n):n=r[3],n}function tJ(){var e,t,n,r=(0,O.c)(3);return r[0]===Symbol.for("react.memo_cache_sentinel")?(e={maskType:"alpha"},r[0]=e):e=r[0],r[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsxs)("mask",{id:"error_overlay_nav_mask0_2667_14687",style:e,maskUnits:"userSpaceOnUse",x:"0",y:"-1",width:"60",height:"43",children:[(0,S.jsxs)("mask",{id:"error_overlay_nav_path_1_outside_1_2667_14687",maskUnits:"userSpaceOnUse",x:"0",y:"-1",width:"60",height:"43",fill:"black",children:[(0,S.jsx)("rect",{fill:"white",y:"-1",width:"60",height:"43"}),(0,S.jsx)("path",{d:"M1 0L8.0783 0C15.772 0 22.7836 4.41324 26.111 11.3501L34.8889 29.6498C38.2164 36.5868 45.228 41 52.9217 41H60H1L1 0Z"})]}),(0,S.jsx)("path",{d:"M1 0L8.0783 0C15.772 0 22.7836 4.41324 26.111 11.3501L34.8889 29.6498C38.2164 36.5868 45.228 41 52.9217 41H60H1L1 0Z",fill:"white"}),(0,S.jsx)("path",{d:"M1 0V-1H0V0L1 0ZM1 41H0V42H1V41ZM34.8889 29.6498L33.9873 30.0823L34.8889 29.6498ZM26.111 11.3501L27.0127 10.9177L26.111 11.3501ZM1 1H8.0783V-1H1V1ZM60 40H1V42H60V40ZM2 41V0L0 0L0 41H2ZM25.2094 11.7826L33.9873 30.0823L35.7906 29.2174L27.0127 10.9177L25.2094 11.7826ZM52.9217 42H60V40H52.9217V42ZM33.9873 30.0823C37.4811 37.3661 44.8433 42 52.9217 42V40C45.6127 40 38.9517 35.8074 35.7906 29.2174L33.9873 30.0823ZM8.0783 1C15.3873 1 22.0483 5.19257 25.2094 11.7826L27.0127 10.9177C23.5188 3.6339 16.1567 -1 8.0783 -1V1Z",fill:"black",mask:"url(#error_overlay_nav_path_1_outside_1_2667_14687)"})]}),r[1]=t):t=r[1],r[2]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsxs)("svg",{width:"60",height:"42",viewBox:"0 0 60 42",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:"error-overlay-notch-tail",preserveAspectRatio:"none",children:[t,(0,S.jsxs)("g",{mask:"url(#error_overlay_nav_mask0_2667_14687)",children:[(0,S.jsxs)("mask",{id:"error_overlay_nav_path_3_outside_2_2667_14687",maskUnits:"userSpaceOnUse",x:"-1",y:"0.0244141",width:"60",height:"43",fill:"black",children:[(0,S.jsx)("rect",{fill:"white",x:"-1",y:"0.0244141",width:"60",height:"43"}),(0,S.jsx)("path",{d:"M0 1.02441H7.0783C14.772 1.02441 21.7836 5.43765 25.111 12.3746L33.8889 30.6743C37.2164 37.6112 44.228 42.0244 51.9217 42.0244H59H0L0 1.02441Z"})]}),(0,S.jsx)("path",{d:"M0 1.02441H7.0783C14.772 1.02441 21.7836 5.43765 25.111 12.3746L33.8889 30.6743C37.2164 37.6112 44.228 42.0244 51.9217 42.0244H59H0L0 1.02441Z",fill:"var(--background-color)"}),(0,S.jsx)("path",{d:"M0 1.02441L0 0.0244141H-1V1.02441H0ZM0 42.0244H-1V43.0244H0L0 42.0244ZM33.8889 30.6743L32.9873 31.1068L33.8889 30.6743ZM25.111 12.3746L26.0127 11.9421L25.111 12.3746ZM0 2.02441H7.0783V0.0244141H0L0 2.02441ZM59 41.0244H0L0 43.0244H59V41.0244ZM1 42.0244L1 1.02441H-1L-1 42.0244H1ZM24.2094 12.8071L32.9873 31.1068L34.7906 30.2418L26.0127 11.9421L24.2094 12.8071ZM51.9217 43.0244H59V41.0244H51.9217V43.0244ZM32.9873 31.1068C36.4811 38.3905 43.8433 43.0244 51.9217 43.0244V41.0244C44.6127 41.0244 37.9517 36.8318 34.7906 30.2418L32.9873 31.1068ZM7.0783 2.02441C14.3873 2.02441 21.0483 6.21699 24.2094 12.8071L26.0127 11.9421C22.5188 4.65831 15.1567 0.0244141 7.0783 0.0244141V2.02441Z",fill:"var(--stroke-color)",mask:"url(#error_overlay_nav_path_3_outside_2_2667_14687)"})]})]}),r[2]=n):n=r[2],n}function t0(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}var t1=["[data-next-mark]","[data-issues-open]","#nextjs-dev-tools-menu","[data-nextjs-error-overlay-nav]","[data-info-popover]","[data-nextjs-devtools-panel-overlay]","[data-nextjs-devtools-panel-footer]","[data-nextjs-error-overlay-footer]"],t2=function(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x,w,_,k=(0,O.c)(23);k[0]!==e?(m=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children","className","onClose","aria-labelledby","aria-describedby"]),f=e.children,p=e.className,h=e.onClose,d=e["aria-labelledby"],u=e["aria-describedby"],k[0]=e,k[1]=u,k[2]=d,k[3]=f,k[4]=p,k[5]=h,k[6]=m):(u=k[1],d=k[2],f=k[3],p=k[4],h=k[5],m=k[6]);var j=C.useRef(null),P=(t=C.useState("undefined"!=typeof document&&document.hasFocus()?"dialog":void 0),function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return t0(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return t0(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),E=P[0],T=P[1];return(k[7]!==h?(g=function(e){return e.preventDefault(),null==h?void 0:h()},k[7]=h,k[8]=g):g=k[8],n=j,r=t1,o=g,(l=(0,O.c)(5))[0]!==r||l[1]!==n||l[2]!==o?(a=function(){var e=n&&"current"in n?n.current:n;if(null!=e&&null!=o){var t=function(t){!e||e.contains(t.target)||r.some(function(e){return t.target.closest(e)})||o(t)},a=e.getRootNode();return a.addEventListener("mouseup",t),a.addEventListener("touchend",t,{passive:!1}),function(){a.removeEventListener("mouseup",t),a.removeEventListener("touchend",t)}}},i=[o,n,r],l[0]=r,l[1]=n,l[2]=o,l[3]=a,l[4]=i):(a=l[3],i=l[4]),C.useEffect(a,i),k[9]===Symbol.for("react.memo_cache_sentinel")?(v=function(){if(null!=j.current){var e=function(){T(document.hasFocus()?"dialog":void 0)};return window.addEventListener("focus",e),window.addEventListener("blur",e),function(){window.removeEventListener("focus",e),window.removeEventListener("blur",e)}}},y=[],k[9]=v,k[10]=y):(v=k[9],y=k[10]),C.useEffect(v,y),k[11]===Symbol.for("react.memo_cache_sentinel")?(b=function(){var e,t,n=j.current,r=null==n?void 0:n.getRootNode(),o=(e=r,null!=(t=ShadowRoot)&&"undefined"!=typeof Symbol&&t[Symbol.hasInstance]?!!t[Symbol.hasInstance](e):e instanceof t)?null==r?void 0:r.activeElement:null;return null==n||n.focus(),function(){null==n||n.blur(),null==o||o.focus()}},x=[],k[11]=b,k[12]=x):(b=k[11],x=k[12]),C.useEffect(b,x),k[13]!==h?(w=function(e){"Escape"===e.key&&(null==h||h())},k[13]=h,k[14]=w):w=k[14],k[15]!==u||k[16]!==d||k[17]!==f||k[18]!==p||k[19]!==m||k[20]!==E||k[21]!==w)?(_=(0,S.jsx)("div",(s=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({ref:j,tabIndex:-1,"data-nextjs-dialog":!0,"data-nextjs-scrollable-content":!0,role:E,"aria-labelledby":d,"aria-describedby":u,"aria-modal":"true",className:p,onKeyDown:w},m),c=c={children:f},Object.getOwnPropertyDescriptors?Object.defineProperties(s,Object.getOwnPropertyDescriptors(c)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(c)).forEach(function(e){Object.defineProperty(s,e,Object.getOwnPropertyDescriptor(c,e))}),s)),k[15]=u,k[16]=d,k[17]=f,k[18]=p,k[19]=m,k[20]=E,k[21]=w,k[22]=_):_=k[22],_};function t3(e){var t,n,r,o,a,i,l,s,c=(0,O.c)(12);return(c[0]!==e?(i=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children","onClose","footer"]),r=e.children,a=e.onClose,o=e.footer,c[0]=e,c[1]=r,c[2]=o,c[3]=a,c[4]=i):(r=c[1],o=c[2],a=c[3],i=c[4]),c[5]!==r||c[6]!==a||c[7]!==i)?(l=(0,S.jsx)(t2,(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"aria-labelledby":"nextjs__container_errors_label","aria-describedby":"nextjs__container_errors_desc",className:"error-overlay-dialog-scroll",onClose:a},i),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),c[5]=r,c[6]=a,c[7]=i,c[8]=l):l=c[8],c[9]!==o||c[10]!==l?(s=(0,S.jsxs)("div",{className:"error-overlay-dialog-container",children:[l,o]}),c[9]=o,c[10]=l,c[11]=s):s=c[11],s}function t4(e){var t,n,r,o=(0,O.c)(2);return o[0]!==e?(r=(0,S.jsx)("div",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"data-nextjs-dialog-header":!0},e),n=n={children:e.children},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),o[0]=e,o[1]=r):r=o[1],r}function t5(e){var t,n=(0,O.c)(2),r=e.children;return n[0]!==r?(t=(0,S.jsx)(t4,{className:"nextjs-container-errors-header",children:r}),n[0]=r,n[1]=t):t=n[1],t}function t6(e){var t,n=(0,O.c)(2),r=e.children;return n[0]!==r?(t=(0,S.jsx)(e3,{className:"nextjs-container-errors-body",children:r}),n[0]=r,n[1]=t):t=n[1],t}var t9=0,t8=function(e){var t,n,r,o,a,i,l,s=(0,O.c)(9);return(s[0]!==e?(a=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["className","children"]),o=e.className,r=e.children,s[0]=e,s[1]=r,s[2]=o,s[3]=a):(r=s[1],o=s[2],a=s[3]),s[4]===Symbol.for("react.memo_cache_sentinel")?(i=[],s[4]=i):i=s[4],C.useEffect(ne,i),s[5]!==r||s[6]!==o||s[7]!==a)?(l=(0,S.jsx)("div",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"data-nextjs-dialog-overlay":!0,className:o},a),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),s[5]=r,s[6]=o,s[7]=a,s[8]=l):l=s[8],l};function t7(){setTimeout(function(){0!==t9&&0==--t9&&(void 0!==l&&(document.body.style.paddingRight=l,l=void 0),void 0!==s&&(document.body.style.overflow=s,s=void 0))})}function ne(){return setTimeout(function(){if(!(t9++>0)){var e=window.innerWidth-document.documentElement.clientWidth;e>0&&(l=document.body.style.paddingRight,document.body.style.paddingRight="".concat(e,"px")),s=document.body.style.overflow,document.body.style.overflow="hidden"}}),t7}function nt(){var e,t,n=(e=["\n  [data-nextjs-dialog-overlay] {\n    padding: initial;\n    top: 10vh;\n  }\n"],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return nt=function(){return n},n}function nn(e){var t,n,r,o,a,i=(0,O.c)(6);return(i[0]!==e?(o=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children"]),r=e.children,i[0]=e,i[1]=r,i[2]=o):(r=i[1],o=i[2]),i[3]!==r||i[4]!==o)?(a=(0,S.jsx)(t8,(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},o),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),i[3]=r,i[4]=o,i[5]=a):a=i[5],a}var nr=eg(nt());function no(e){var t,n,r,o=(0,O.c)(4),a=Math.min(e.errorCount-e.activeIdx-1,2);return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("div",{className:"error-overlay-bottom-stack-layer error-overlay-bottom-stack-layer-1",children:"1"}),n=(0,S.jsx)("div",{className:"error-overlay-bottom-stack-layer error-overlay-bottom-stack-layer-2",children:"2"}),o[0]=t,o[1]=n):(t=o[0],n=o[1]),o[2]!==a?(r=(0,S.jsx)("div",{"aria-hidden":!0,className:"error-overlay-bottom-stack",children:(0,S.jsxs)("div",{className:"error-overlay-bottom-stack-stack","data-stack-count":a,children:[t,n]})}),o[2]=a,o[3]=r):r=o[3],r}function na(e){var t,n=(0,O.c)(2),r=e.environmentName;return n[0]!==r?(t=(0,S.jsx)("span",{"data-nextjs-environment-name-label":!0,children:r}),n[0]=r,n[1]=t):t=n[1],t}function ni(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function nl(e){var t,n,r=null==e?void 0:e.getRootNode();return(t=r,null!=(n=ShadowRoot)&&"undefined"!=typeof Symbol&&n[Symbol.hasInstance]?!!n[Symbol.hasInstance](t):t instanceof n)?null==r?void 0:r.activeElement:null}function ns(e,t,n,r,o){var a,i,l=(0,O.c)(7);l[0]!==n||l[1]!==r||l[2]!==o||l[3]!==e||l[4]!==t?(a=function(){if(n){var a,i=o||(null==(a=e.current)?void 0:a.ownerDocument),l=function(n){var o,a,i=n.target;!(e.current&&e.current.contains(i))&&(null!=(o=e.current)&&o.getBoundingClientRect()&&n.clientX>=e.current.getBoundingClientRect().left-10&&n.clientX<=e.current.getBoundingClientRect().right+10&&n.clientY>=e.current.getBoundingClientRect().top-10&&n.clientY<=e.current.getBoundingClientRect().bottom+10||null!=(a=t.current)&&a.getBoundingClientRect()&&n.clientX>=t.current.getBoundingClientRect().left-10&&n.clientX<=t.current.getBoundingClientRect().right+10&&n.clientY>=t.current.getBoundingClientRect().top-10&&n.clientY<=t.current.getBoundingClientRect().bottom+10||r("outside"))},s=function(e){"Escape"===e.key&&r("escape")};return null==i||i.addEventListener("mousedown",l),null==i||i.addEventListener("keydown",s),function(){null==i||i.removeEventListener("mousedown",l),null==i||i.removeEventListener("keydown",s)}}},i=[n,r,o,e,t],l[0]=n,l[1]=r,l[2]=o,l[3]=e,l[4]=t,l[5]=a,l[6]=i):(a=l[5],i=l[6]),(0,C.useEffect)(a,i)}var nc="cubic-bezier(0.175, 0.885, 0.32, 1.1)",nu=(0,C.forwardRef)(function(e,t){var n,r,o=(0,O.c)(9),a=e.stop,i=e.blur,l=e.side,s=e.style,c=e.height,u="".concat(c,"px");o[0]!==i||o[1]!==a||o[2]!==s||o[3]!==u?(n=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"--stop":a,"--blur":i,"--height":u},s),o[0]=i,o[1]=a,o[2]=s,o[3]=u,o[4]=n):n=o[4];var d=n;return o[5]!==t||o[6]!==l||o[7]!==d?(r=(0,S.jsx)("div",{ref:t,"aria-hidden":!0,"data-nextjs-scroll-fader":!0,className:"nextjs-scroll-fader","data-side":l,style:d}),o[5]=t,o[6]=l,o[7]=d,o[8]=r):r=o[8],r});function nd(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function nf(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return nd(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return nd(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}var np=(0,C.forwardRef)(function(e,t){var n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x,w,_=(0,O.c)(13);_[0]!==e?(y=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children","measure"]),g=e.children,v=e.measure,_[0]=e,_[1]=g,_[2]=v,_[3]=y):(g=_[1],v=_[2],y=_[3]);var k=nf((0,C.useState)(null),2),j=k[0],P=k[1],E=nf((n=j,r=v,l=(0,O.c)(7),c=(s=nf((0,C.useState)(0),2))[0],u=s[1],f=(d=nf((0,C.useState)(!0),2))[0],p=d[1],l[0]!==n||l[1]!==r?(o=function(){if(r&&n){var e,t=new ResizeObserver(function(t){var n=nf(t,1)[0].contentRect;clearTimeout(e),e=window.setTimeout(function(){p(!1)},100),u(n.height)});return t.observe(n),function(){return t.disconnect()}}},a=[r,n],l[0]=n,l[1]=r,l[2]=o,l[3]=a):(o=l[2],a=l[3]),(0,C.useEffect)(o,a),l[4]!==c||l[5]!==f?(i=[c,f],l[4]=c,l[5]=f,l[6]=i):i=l[6],i),2),T=E[0],I=E[1]?"auto":T;return(_[4]!==I?(b={height:I,transition:"height 250ms var(--timing-swift)"},_[4]=I,_[5]=b):b=_[5],_[6]!==g?(x=(0,S.jsx)("div",{ref:P,children:g}),_[6]=g,_[7]=x):x=_[7],_[8]!==y||_[9]!==t||_[10]!==b||_[11]!==x)?(w=(0,S.jsx)("div",(h=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},y),m=m={ref:t,style:b,children:x},Object.getOwnPropertyDescriptors?Object.defineProperties(h,Object.getOwnPropertyDescriptors(m)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(m)).forEach(function(e){Object.defineProperty(h,e,Object.getOwnPropertyDescriptor(m,e))}),h)),_[8]=y,_[9]=t,_[10]=b,_[11]=x,_[12]=w):w=_[12],w});function nh(e){var t,n,r,o=(0,O.c)(6);o[0]!==e?(n=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["fixed"]),t=e.fixed,o[0]=e,o[1]=t,o[2]=n):(t=o[1],n=o[2]);var a=!!t||void 0;return o[3]!==n||o[4]!==a?(r=(0,S.jsx)("div",function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"data-nextjs-dialog-backdrop":!0,"data-nextjs-dialog-backdrop-fixed":a},n)),o[3]=n,o[4]=a,o[5]=r):r=o[5],r}function nm(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function ng(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function nv(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function ny(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return nm(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return nm(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function nb(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x,w,_,k,j,P,E,T,I,N,L=(0,O.c)(66),A=e.errorMessage,z=e.errorType,R=e.children,D=e.errorCode,M=e.errorCount,Z=e.error,F=e.debugInfo,U=e.isBuildError,H=e.onClose,V=e.versionInfo,B=e.runtimeErrors,$=e.activeIdx,q=e.setActiveIndex,W=e.isTurbopack,K=e.dialogResizerRef,Y=e.generateErrorInfo,G=e.rendered,X=e.transitionDurationMs,Q=void 0===G||G,J="".concat(X,"ms");L[0]!==J?(s={"--transition-duration":J},L[0]=J,L[1]=s):s=L[1];var ee=s;L[2]!==Q||L[3]!==ee?(c={"data-rendered":Q,style:ee},L[2]=Q,L[3]=ee,L[4]=c):c=L[4];var et=c,en=ny(C.useState(!!X),2),er=en[0],eo=en[1],ea=C.useRef(null),ei=!!D,el=C.useRef(null);t=el,n=Q,void 0!==(i=(0,O.c)(11))[0]?(r=function(e){null==e||e.focus()},i[0]=void 0,i[1]=r):r=i[1],l=(0,C.useEffectEvent)(r),i[2]!==n||i[3]!==l||i[4]!==t||null!==i[5]?(o=function(){var e=null,r=function(t){if("Tab"===t.key&&null!==e){var n,r,o=(r=(n=e.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'))?[n[0],n[n.length-1]]:[],function(e){if(Array.isArray(e))return e}(r)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(r,2)||function(e,t){if(e){if("string"==typeof e)return ni(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return ni(e,2)}}(r,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),a=o[0],i=o[1],l=nl(e);t.shiftKey?l===a&&(null==i||i.focus(),t.preventDefault()):l===i&&(null==a||a.focus(),t.preventDefault())}},o=setTimeout(function(){if(e=t.current,n)l(e),null==e||e.addEventListener("keydown",r);else nl(e)});return function(){clearTimeout(o),null==e||e.removeEventListener("keydown",r)}},i[2]=n,i[3]=l,i[4]=t,i[5]=null,i[6]=o):o=i[6],i[7]!==n||i[8]!==t||null!==i[9]?(a=[n,t,null],i[7]=n,i[8]=t,i[9]=null,i[10]=a):a=i[10],(0,C.useEffect)(o,a),L[5]===Symbol.for("react.memo_cache_sentinel")?(u=function(e){if(ea.current){var t,n,r=(t=e.currentTarget.scrollTop/17,Math.min(Math.max(t,(n=ny([0,1],2))[0]),n[1]));ea.current.style.opacity=String(r)}},L[5]=u):u=L[5];var es=u;L[6]===Symbol.for("react.memo_cache_sentinel")?(d=function(e){var t=e.propertyName,n=e.target;"scale"===t&&n===el.current&&eo(!1)},L[6]=d):d=L[6];var ec=d;L[7]!==U?(f=(0,S.jsx)(nh,{fixed:U}),L[7]=U,L[8]=f):f=L[8],L[9]!==$||L[10]!==W||L[11]!==B||L[12]!==q||L[13]!==V?(p=(0,S.jsx)(tG,{runtimeErrors:B,activeIdx:$,setActiveIndex:q,versionInfo:V,isTurbopack:W}),L[9]=$,L[10]=W,L[11]=B,L[12]=q,L[13]=V,L[14]=p):p=L[14],L[15]!==D||L[16]!==ei?(h=ei&&(0,S.jsx)(tM,{errorCode:D}),L[15]=D,L[16]=ei,L[17]=h):h=L[17];var eu=!er;L[18]!==z?(m=(0,S.jsx)(tV,{errorType:z}),L[18]=z,L[19]=m):m=L[19],L[20]!==Z.environmentName?(g=Z.environmentName&&(0,S.jsx)(na,{environmentName:Z.environmentName}),L[20]=Z.environmentName,L[21]=g):g=L[21],L[22]!==m||L[23]!==g?(v=(0,S.jsxs)("span",{"data-nextjs-error-label-group":!0,children:[m,g]}),L[22]=m,L[23]=g,L[24]=v):v=L[24],L[25]!==F||L[26]!==Z||L[27]!==Y?(y=(0,S.jsx)(tI,{error:Z,debugInfo:F,generateErrorInfo:Y}),L[25]=F,L[26]=Z,L[27]=Y,L[28]=y):y=L[28],L[29]!==D||L[30]!==v||L[31]!==y?(b=(0,S.jsxs)("div",{className:"nextjs__container_errors__error_title","data-nextjs-error-code":D,children:[v,y]}),L[29]=D,L[30]=v,L[31]=y,L[32]=b):b=L[32],L[33]!==A||L[34]!==z?(x=(0,S.jsx)(tH,{errorMessage:A,errorType:z}),L[33]=A,L[34]=z,L[35]=x):x=L[35],L[36]!==b||L[37]!==x?(w=(0,S.jsxs)(t5,{children:[b,x]}),L[36]=b,L[37]=x,L[38]=w):w=L[38],L[39]!==R?(_=(0,S.jsx)(t6,{children:R}),L[39]=R,L[40]=_):_=L[40],L[41]!==w||L[42]!==_?(k=(0,S.jsxs)(e4,{children:[w,_]}),L[41]=w,L[42]=_,L[43]=k):k=L[43],L[44]!==K||L[45]!==eu||L[46]!==k?(j=(0,S.jsx)(np,{ref:K,measure:eu,"data-nextjs-dialog-sizer":!0,children:k}),L[44]=K,L[45]=eu,L[46]=k,L[47]=j):j=L[47];var ed=null!=$?$:0;return L[48]!==M||L[49]!==ed?(P=(0,S.jsx)(no,{errorCount:M,activeIdx:ed}),L[48]=M,L[49]=ed,L[50]=P):P=L[50],L[51]!==ei||L[52]!==H||L[53]!==h||L[54]!==j||L[55]!==P?(E=(0,S.jsxs)(t3,{onClose:H,"data-has-footer":ei,onScroll:es,footer:h,children:[j,P]}),L[51]=ei,L[52]=H,L[53]=h,L[54]=j,L[55]=P,L[56]=E):E=L[56],L[57]===Symbol.for("react.memo_cache_sentinel")?(T=(0,S.jsx)(nu,{ref:ea,side:"top",stop:"50%",blur:"4px",height:48}),L[57]=T):T=L[57],L[58]!==et||L[59]!==E||L[60]!==p?(I=(0,S.jsxs)("div",nv(ng({"data-nextjs-dialog-root":!0,onTransitionEnd:ec,ref:el},et),{children:[p,E,T]})),L[58]=et,L[59]=E,L[60]=p,L[61]=I):I=L[61],L[62]!==et||L[63]!==I||L[64]!==f?(N=(0,S.jsxs)(nn,nv(ng({},et),{children:[f,I]})),L[62]=et,L[63]=I,L[64]=f,L[65]=N):N=L[65],N}var nx="\n  ".concat(nr,"\n  ").concat("\n  .error-overlay-dialog-container {\n    display: flex;\n    flex-direction: column;\n    background: var(--color-background-100);\n    background-clip: padding-box;\n    border: var(--next-dialog-border-width) solid var(--color-gray-400);\n    border-radius: 0 0 var(--next-dialog-radius) var(--next-dialog-radius);\n    box-shadow: var(--shadow-menu);\n    position: relative;\n    overflow: hidden;\n  }\n\n  .error-overlay-dialog-scroll {\n    overflow-y: auto;\n    height: 100%;\n  }\n","\n  ").concat("\n  .nextjs-container-errors-header {\n    position: relative;\n  }\n  .nextjs-container-errors-header > h1 {\n    font-size: var(--size-20);\n    line-height: var(--size-24);\n    font-weight: bold;\n    margin: calc(16px * 1.5) 0;\n    color: var(--color-title-h1);\n  }\n  .nextjs-container-errors-header small {\n    font-size: var(--size-14);\n    color: var(--color-accents-1);\n    margin-left: 16px;\n  }\n  .nextjs-container-errors-header small > span {\n    font-family: var(--font-stack-monospace);\n  }\n  .nextjs-container-errors-header > div > small {\n    margin: 0;\n    margin-top: 4px;\n  }\n  .nextjs-container-errors-header > p > a {\n    color: inherit;\n    font-weight: bold;\n  }\n  .nextjs-container-errors-header\n    > .nextjs-container-build-error-version-status {\n    position: absolute;\n    top: 16px;\n    right: 16px;\n  }\n","\n  ").concat("","\n\n  ").concat("\n  [data-nextjs-error-overlay-nav] {\n    --stroke-color: var(--color-gray-400);\n    --background-color: var(--color-background-100);\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n\n    width: 100%;\n\n    position: relative;\n    z-index: 2;\n    outline: none;\n    translate: var(--next-dialog-border-width) var(--next-dialog-border-width);\n    max-width: var(--next-dialog-max-width);\n\n    .error-overlay-notch {\n      translate: calc(var(--next-dialog-border-width) * -1);\n      width: auto;\n      height: var(--next-dialog-notch-height);\n      padding: 12px;\n      background: var(--background-color);\n      border: var(--next-dialog-border-width) solid var(--stroke-color);\n      border-bottom: none;\n      position: relative;\n\n      &[data-side='left'] {\n        padding-right: 0;\n        border-radius: var(--next-dialog-radius) 0 0 0;\n\n        .error-overlay-notch-tail {\n          right: -54px;\n        }\n\n        > *:not(.error-overlay-notch-tail) {\n          margin-right: -10px;\n        }\n      }\n\n      &[data-side='right'] {\n        padding-left: 0;\n        border-radius: 0 var(--next-dialog-radius) 0 0;\n\n        .error-overlay-notch-tail {\n          left: -54px;\n          transform: rotateY(180deg);\n        }\n\n        > *:not(.error-overlay-notch-tail) {\n          margin-left: -12px;\n        }\n      }\n\n      .error-overlay-notch-tail {\n        position: absolute;\n        top: calc(var(--next-dialog-border-width) * -1);\n        pointer-events: none;\n        z-index: -1;\n        height: calc(100% + var(--next-dialog-border-width));\n      }\n    }\n  }\n\n  @media (max-width: 600px) {\n    [data-nextjs-error-overlay-nav] {\n      background: var(--background-color);\n      border-radius: var(--next-dialog-radius) var(--next-dialog-radius) 0 0;\n      border: var(--next-dialog-border-width) solid var(--stroke-color);\n      border-bottom: none;\n      overflow: hidden;\n      translate: 0 var(--next-dialog-border-width);\n      \n      .error-overlay-notch {\n        border-radius: 0;\n        border: 0;\n\n        &[data-side=\"left\"], &[data-side=\"right\"] {\n          border-radius: 0;\n        }\n\n        .error-overlay-notch-tail {\n          display: none;\n        }\n      }\n    }\n  }\n","\n  ").concat("\n  .nextjs__container_errors_label {\n    padding: 2px 6px;\n    margin: 0;\n    border-radius: var(--rounded-md-2);\n    background: var(--color-red-100);\n    font-weight: 600;\n    font-size: var(--size-12);\n    color: var(--color-red-900);\n    font-family: var(--font-stack-monospace);\n    line-height: var(--size-20);\n  }\n\n  .nextjs__container_errors_label_blocking_page {\n    background: var(--color-blue-100);\n    color: var(--color-blue-900);\n  }\n","\n  ").concat("\n  .nextjs__container_errors_wrapper {\n    position: relative;\n  }\n\n  .nextjs__container_errors_desc {\n    margin: 0;\n    margin-left: 4px;\n    color: var(--color-red-900);\n    font-weight: 500;\n    font-size: var(--size-16);\n    letter-spacing: -0.32px;\n    line-height: var(--size-24);\n    overflow-wrap: break-word;\n    white-space: pre-wrap;\n  }\n\n  .nextjs__container_errors_desc.truncated {\n    max-height: 200px;\n    overflow: hidden;\n  }\n\n  .nextjs__container_errors_gradient_overlay {\n    position: absolute;\n    bottom: 0;\n    left: 0;\n    right: 0;\n    height: 85px;\n    background: linear-gradient(\n      180deg,\n      rgba(250, 250, 250, 0) 0%,\n      var(--color-background-100) 100%\n    );\n  }\n\n  .nextjs__container_errors_expand_button {\n    position: absolute;\n    bottom: 10px;\n    left: 50%;\n    transform: translateX(-50%);\n    display: flex;\n    align-items: center;\n    padding: 6px 8px;\n    background: var(--color-background-100);\n    border: 1px solid var(--color-gray-alpha-400);\n    border-radius: 999px;\n    box-shadow:\n      0px 2px 2px var(--color-gray-alpha-100),\n      0px 8px 8px -8px var(--color-gray-alpha-100);\n    font-size: var(--size-13);\n    cursor: pointer;\n    color: var(--color-gray-900);\n    font-weight: 500;\n    transition: background-color 0.2s ease;\n  }\n\n  .nextjs__container_errors_expand_button:hover {\n    background: var(--color-gray-100);\n  }\n","\n  ").concat("\n  .error-overlay-toolbar {\n    display: flex;\n    gap: 6px;\n  }\n\n  .nodejs-inspector-button,\n  .copy-error-button,\n  .docs-link-button {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n\n    width: var(--size-28);\n    height: var(--size-28);\n    background: var(--color-background-100);\n    background-clip: padding-box;\n    border: 1px solid var(--color-gray-alpha-400);\n    box-shadow: var(--shadow-small);\n    border-radius: var(--rounded-full);\n\n    svg {\n      width: var(--size-14);\n      height: var(--size-14);\n    }\n\n    &:focus {\n      outline: var(--focus-ring);\n    }\n\n    &:not(:disabled):hover {\n      background: var(--color-gray-alpha-100);\n    }\n\n    &:not(:disabled):active {\n      background: var(--color-gray-alpha-200);\n    }\n\n    &:disabled {\n      background-color: var(--color-gray-100);\n      cursor: not-allowed;\n    }\n  }\n\n  .error-overlay-toolbar-button-icon {\n    color: var(--color-gray-900);\n  }\n","\n\n  [data-nextjs-error-label-group] {\n    display: flex;\n    align-items: center;\n    gap: 8px;\n  }\n");function nw(){var e,t,n=(e=["\n  [data-nextjs-dialog-overlay] {\n    position: fixed;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    /* secondary z-index, -1 than toast z-index */\n    z-index: 2147483646;\n\n    display: flex;\n    align-content: center;\n    align-items: center;\n    flex-direction: column;\n    padding: 10vh 15px 0;\n  }\n\n  @media (max-height: 812px) {\n    [data-nextjs-dialog-overlay] {\n      padding: 15px 15px 0;\n    }\n  }\n\n  [data-nextjs-dialog-backdrop] {\n    position: fixed;\n    top: 0;\n    right: 0;\n    bottom: 0;\n    left: 0;\n    background-color: var(--color-backdrop);\n    backdrop-filter: blur(10px);\n    pointer-events: all;\n    z-index: -1;\n  }\n\n  [data-nextjs-dialog-backdrop-fixed] {\n    cursor: not-allowed;\n    -webkit-backdrop-filter: blur(8px);\n    backdrop-filter: blur(8px);\n  }\n"],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return nw=function(){return n},n}var n_=eg(nw());function nk(e){var t,n,r,o,a,i=(0,O.c)(9),l=e.file,s=e.location,c=null!=(t=null==s?void 0:s.line)?t:1,u=null!=(n=null==s?void 0:s.column)?n:1;i[0]!==l||i[1]!==c||i[2]!==u?(r={file:l,line1:c,column1:u},i[0]=l,i[1]=c,i[2]=u,i[3]=r):r=i[3];var d=eM(r),f=s?":".concat(s.line,":").concat(s.column):null;return i[4]===Symbol.for("react.memo_cache_sentinel")?(o=(0,S.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,S.jsx)("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"}),(0,S.jsx)("polyline",{points:"15 3 21 3 21 9"}),(0,S.jsx)("line",{x1:"10",y1:"14",x2:"21",y2:"3"})]}),i[4]=o):o=i[4],i[5]!==l||i[6]!==d||i[7]!==f?(a=(0,S.jsxs)("div",{"data-with-open-in-editor-link":!0,"data-with-open-in-editor-link-import-trace":!0,role:"link",onClick:d,title:"Click to open in your editor",children:[l,f,o]}),i[5]=l,i[6]=d,i[7]=f,i[8]=a):a=i[8],a}function nj(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}var nS=function(e){var t,n,r,o,a,i,l,s,c,u,d=e.content,f=C.useMemo(function(){var e,t,n;return t=function(e){var t,n=e.shift();if(!n)return null;var r=(t=n.split(":",3),function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),3!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,3)||function(e,t){if(e){if("string"==typeof e)return nj(e,3);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return nj(e,3)}}(t,3)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),o=r[0],a=r[1],i=r[2],l=Number(a),s=Number(i),c=!Number.isNaN(l)&&!Number.isNaN(s);return{fileName:c?o:n,location:c?{line1:l,column1:s}:void 0}}(e=d.split("\n")),n=function(e){if(e.some(function(e){return/ReactServerComponentsError:/.test(e)})||e.some(function(e){return/Import trace for requested module:/.test(e)})){for(var t=[];/.+\..+/.test(e[e.length-1])&&!e[e.length-1].includes(":");){var n=e.pop().trim();t.unshift(n)}return t}return[]}(e),{file:t,source:e.join("\n"),importTraceFiles:n}},[d]),p=f.file,h=f.source,m=f.importTraceFiles,g=C.useMemo(function(){return eX().ansiToJson(h,{json:!0,use_classes:!0,remove_empty:!0})},[h]),v=eM({file:null==p?void 0:p.fileName,line1:null!=(i=null==p||null==(t=p.location)?void 0:t.line1)?i:1,column1:null!=(l=null==p||null==(n=p.location)?void 0:n.column1)?l:1}),y={file:null!=(s=null==p?void 0:p.fileName)?s:null,methodName:"",arguments:[],line1:null!=(c=null==p||null==(r=p.location)?void 0:r.line1)?c:null,column1:null!=(u=null==p||null==(o=p.location)?void 0:o.column1)?u:null},b=null==y||null==(a=y.file)?void 0:a.split(".").pop();return(0,S.jsxs)("div",{"data-nextjs-codeframe":!0,children:[(0,S.jsx)("div",{className:"code-frame-header",children:(0,S.jsxs)("div",{className:"code-frame-link",children:[(0,S.jsx)("span",{className:"code-frame-icon",children:(0,S.jsx)(eB,{lang:b})}),(0,S.jsx)("span",{"data-text":!0,children:eD(y)}),(0,S.jsx)("button",{"aria-label":"Open in editor","data-with-open-in-editor-link-source-file":!0,onClick:v,children:(0,S.jsx)("span",{className:"code-frame-icon","data-icon":"right",children:(0,S.jsx)(eH,{width:16,height:16})})})]})}),(0,S.jsx)("pre",{className:"code-frame-pre",children:(0,S.jsxs)("div",{className:"code-frame-lines",children:[g.map(function(e,t){return(0,S.jsx)("span",{style:function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({color:e.fg?"var(--color-".concat(e.fg,")"):void 0},"bold"===e.decoration?{fontWeight:500}:"italic"===e.decoration?{fontStyle:"italic"}:void 0),children:(0,S.jsx)(eP,{text:e.content})},"terminal-entry-".concat(t))}),m.map(function(e){return(0,S.jsx)(nk,{isSourceFile:!1,file:e},e)})]})})]})},nO=function(e){var t=e.split("\n");return eJ()(t[1]||"").replace(/^Error: /,"")},nC=function(e){var t,n,r,o,a,i,l,s,c,u=(0,O.c)(19);u[0]!==e?(o=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["message"]),r=e.message,u[0]=e,u[1]=r,u[2]=o):(r=u[1],o=u[2]),u[3]!==r?(a=Error(r),u[3]=r,u[4]=a):a=u[4];var d=a;u[5]!==r?(i=nO(r)||"Failed to compile",u[5]=r,u[6]=i):i=u[6];var f=i;u[7]!==f||u[8]!==r||u[9]!==o.versionInfo.installed?(l=function(){var e=[];if(e.push("## Error Type\nBuild Error"),f&&e.push("## Error Message\n".concat(f)),r){var t=eJ()(r);e.push("## Build Output\n".concat(t))}return"".concat(e.join("\n\n"),"\n\nNext.js version: ").concat(o.versionInfo.installed," (").concat(process.env.__NEXT_BUNDLER,")\n")},u[7]=f,u[8]=r,u[9]=o.versionInfo.installed,u[10]=l):l=u[10];var p=l;return(u[11]!==r?(s=(0,S.jsx)(nS,{content:r}),u[11]=r,u[12]=s):s=u[12],u[13]!==d||u[14]!==f||u[15]!==p||u[16]!==o||u[17]!==s)?(c=(0,S.jsx)(nb,(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({errorType:"Build Error",errorMessage:f,onClose:nP,error:d,generateErrorInfo:p},o),n=n={children:s},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),u[13]=d,u[14]=f,u[15]=p,u[16]=o,u[17]=s,u[18]=c):c=u[18],c};function nP(){}var nE=function(e){var t,n,r,o,a,i,l,s,c,u,d,f=(0,O.c)(26),p=e.frame,h=null!=(t=p.originalStackFrame)?t:p.sourceStackFrame,m=!!p.originalCodeFrame;f[0]!==h||f[1]!==m?(n=m?{file:h.file,line1:null!=(r=h.line1)?r:1,column1:null!=(o=h.column1)?o:1}:void 0,f[0]=h,f[1]=m,f[2]=n):n=f[2];var g=eM(n);f[3]!==h?(a=eD(h),f[3]=h,f[4]=a):a=f[4];var v=a;if(!v)return null;var y=!m;return f[5]!==h.methodName?(i=(0,S.jsx)(eP,{text:h.methodName}),f[5]=h.methodName,f[6]=i):i=f[6],f[7]!==h.methodName||f[8]!==m||f[9]!==g?(l=m&&(0,S.jsx)("button",{onClick:g,className:"open-in-editor-button","aria-label":"Open ".concat(h.methodName," in editor"),children:(0,S.jsx)(eH,{width:16,height:16})}),f[7]=h.methodName,f[8]=m,f[9]=g,f[10]=l):l=f[10],f[11]!==p.error||f[12]!==p.reason?(s=p.error?(0,S.jsx)("button",{className:"source-mapping-error-button",onClick:function(){return console.error(p.reason)},title:"Sourcemapping failed. Click to log cause of error.",children:(0,S.jsx)(eV,{width:16,height:16})}):null,f[11]=p.error,f[12]=p.reason,f[13]=s):s=f[13],f[14]!==i||f[15]!==l||f[16]!==s?(c=(0,S.jsxs)("div",{className:"call-stack-frame-method-name",children:[i,l,s]}),f[14]=i,f[15]=l,f[16]=s,f[17]=c):c=f[17],f[18]!==v||f[19]!==m?(u=(0,S.jsx)("span",{className:"call-stack-frame-file-source","data-has-source":m,children:v}),f[18]=v,f[19]=m,f[20]=u):u=f[20],f[21]!==p.ignored||f[22]!==y||f[23]!==c||f[24]!==u?(d=(0,S.jsxs)("div",{"data-nextjs-call-stack-frame":!0,"data-nextjs-call-stack-frame-no-source":y,"data-nextjs-call-stack-frame-ignored":p.ignored,children:[c,u]}),f[21]=p.ignored,f[22]=y,f[23]=c,f[24]=u,f[25]=d):d=f[25],d};function nT(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.70722 2.39641C8.3167 2.00588 7.68353 2.00588 7.29301 2.39641L4.46978 5.21963L3.93945 5.74996L5.00011 6.81062L5.53044 6.28029L8.00011 3.81062L10.4698 6.28029L11.0001 6.81062L12.0608 5.74996L11.5304 5.21963L8.70722 2.39641ZM5.53044 9.71963L5.00011 9.1893L3.93945 10.25L4.46978 10.7803L7.29301 13.6035C7.68353 13.994 8.3167 13.994 8.70722 13.6035L11.5304 10.7803L12.0608 10.25L11.0001 9.1893L10.4698 9.71963L8.00011 12.1893L5.53044 9.71963Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function nI(){var e,t,n=(e=["\n  [data-nextjs-call-stack-container] {\n    position: relative;\n    margin-top: 8px;\n  }\n\n  [data-nextjs-call-stack-header] {\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    min-height: var(--size-28);\n    padding: 8px 8px 12px 4px;\n    width: 100%;\n  }\n\n  [data-nextjs-call-stack-title] {\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    gap: 8px;\n\n    margin: 0;\n\n    color: var(--color-gray-1000);\n    font-size: var(--size-16);\n    font-weight: 500;\n  }\n\n  [data-nextjs-call-stack-count] {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n\n    width: var(--size-20);\n    height: var(--size-20);\n    gap: 4px;\n\n    color: var(--color-gray-1000);\n    text-align: center;\n    font-size: var(--size-11);\n    font-weight: 500;\n    line-height: var(--size-16);\n\n    border-radius: var(--rounded-full);\n    background: var(--color-gray-300);\n  }\n\n  [data-nextjs-call-stack-ignored-list-toggle-button] {\n    all: unset;\n    display: flex;\n    align-items: center;\n    gap: 6px;\n    color: var(--color-gray-900);\n    font-size: var(--size-14);\n    line-height: var(--size-20);\n    border-radius: 6px;\n    padding: 4px 6px;\n    margin-right: -6px;\n    transition: background 150ms ease;\n\n    &:hover {\n      background: var(--color-gray-100);\n    }\n\n    &:focus {\n      outline: var(--focus-ring);\n    }\n\n    svg {\n      width: var(--size-16);\n      height: var(--size-16);\n    }\n  }\n"],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return nI=function(){return n},n}function nN(e){var t,n,r,o,a,i,l=(0,O.c)(17),s=e.frames,c=e.isIgnoreListOpen,u=e.ignoredFramesTally,d=e.onToggleIgnoreList;return l[0]!==s.length?(t=(0,S.jsxs)("p",{"data-nextjs-call-stack-title":!0,children:["Call Stack ",(0,S.jsx)("span",{"data-nextjs-call-stack-count":!0,children:s.length})]}),l[0]=s.length,l[1]=t):t=l[1],l[2]!==u||l[3]!==c||l[4]!==d?(n=u>0&&(0,S.jsxs)("button",{"data-nextjs-call-stack-ignored-list-toggle-button":c,onClick:d,children:["".concat(c?"Hide":"Show"," ").concat(u," ignore-listed frame(s)"),(0,S.jsx)(nT,{})]}),l[2]=u,l[3]=c,l[4]=d,l[5]=n):n=l[5],l[6]!==t||l[7]!==n?(r=(0,S.jsxs)("div",{"data-nextjs-call-stack-header":!0,children:[t,n]}),l[6]=t,l[7]=n,l[8]=r):r=l[8],l[9]!==s||l[10]!==c?(l[12]!==c?(a=function(e,t){return!e.ignored||c?(0,S.jsx)(nE,{frame:e},t):null},l[12]=c,l[13]=a):a=l[13],o=s.map(a),l[9]=s,l[10]=c,l[11]=o):o=l[11],l[14]!==r||l[15]!==o?(i=(0,S.jsxs)("div",{"data-nextjs-call-stack-container":!0,children:[r,o]}),l[14]=r,l[15]=o,l[16]=i):i=l[16],i}var nL=eg(nI());function nA(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function nz(e){var t,n=e.frames,r=e.dialogResizerRef,o=(0,C.useRef)(NaN),a=(t=(0,C.useState)(!1),function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return nA(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return nA(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),i=a[0],l=a[1],s=(0,C.useMemo)(function(){return n.reduce(function(e,t){return e+ +!!t.ignored},0)},[n]);return(0,S.jsx)(nN,{frames:n,isIgnoreListOpen:i,onToggleIgnoreList:function(){var e=null==r?void 0:r.current;if(e){var t=e.getBoundingClientRect().height;o.current||(o.current=t),i?(e.style.height="".concat(o.current,"px"),e.addEventListener("transitionend",function t(){e.removeEventListener("transitionend",t),l(!1)})):l(!0)}},ignoredFramesTally:s})}function nR(e){var t,n,r,o,a,i,l=(0,O.c)(8);l[0]!==e?(r=void 0===e?{}:e,l[0]=e,l[1]=r):r=l[1];var s=r.collapsed;return(l[2]!==s?(o="boolean"==typeof s?{style:{transform:s?void 0:"rotate(90deg)"}}:{},l[2]=s,l[3]=o):o=l[3],l[4]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)("path",{style:{fill:"var(--color-font)"},fillRule:"evenodd",d:"m6.75 3.94.53.53 2.824 2.823a1 1 0 0 1 0 1.414L7.28 11.53l-.53.53L5.69 11l.53-.53L8.69 8 6.22 5.53 5.69 5l1.06-1.06Z",clipRule:"evenodd"}),l[4]=a):a=l[4],l[5]!==s||l[6]!==o)?(i=(0,S.jsx)("svg",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"data-nextjs-call-stack-chevron-icon":!0,"data-collapsed":s,width:"16",height:"16",fill:"none"},o),n=n={children:a},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),l[5]=s,l[6]=o,l[7]=i):i=l[7],i}function nD(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function nM(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return nD(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return nD(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function nZ(e){var t,n,r,o,a,i,l=(0,O.c)(15),s=e.reactOutputComponentDiff,c=nM((0,C.useState)(!0),2),u=c[0],d=c[1];l[0]!==s?(t=[],s.split("\n").forEach(function(e,n){var r,o,a="+"===e[0]||"-"===e[0],i=">"===e[0],l=a||i,s=l?e[0]:"",c=l?e.indexOf(s):-1,u=nM(l?[e.slice(0,c),e.slice(c+1)]:[e,""],2),d=u[0],f=u[1];a?t.push((0,S.jsx)("span",{"data-nextjs-container-errors-pseudo-html-line":!0,"data-nextjs-container-errors-pseudo-html--diff":"+"===s?"add":"remove",children:(0,S.jsxs)("span",{children:[d,(0,S.jsx)("span",{"data-nextjs-container-errors-pseudo-html-line-sign":!0,children:s}),f,"\n"]})},"comp-diff"+n)):t.push((0,S.jsxs)("span",(r=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({"data-nextjs-container-errors-pseudo-html-line":!0},i?{"data-nextjs-container-errors-pseudo-html--diff":"error"}:void 0),o=o={children:[d,(0,S.jsx)("span",{"data-nextjs-container-errors-pseudo-html-line-sign":!0,children:s}),f,"\n"]},Object.getOwnPropertyDescriptors?Object.defineProperties(r,Object.getOwnPropertyDescriptors(o)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(o)).forEach(function(e){Object.defineProperty(r,e,Object.getOwnPropertyDescriptor(o,e))}),r),"comp-diff"+n))}),l[0]=s,l[1]=t):t=l[1];var f=t,p=!u;return l[2]!==u?(n=function(){return d(!u)},r=(0,S.jsx)(nR,{collapsed:u}),l[2]=u,l[3]=n,l[4]=r):(n=l[3],r=l[4]),l[5]!==p||l[6]!==n||l[7]!==r?(o=(0,S.jsx)("button",{"aria-expanded":p,"aria-label":"complete Component Stack","data-nextjs-container-errors-pseudo-html-collapse-button":!0,onClick:n,children:r}),l[5]=p,l[6]=n,l[7]=r,l[8]=o):o=l[8],l[9]!==f?(a=(0,S.jsx)("pre",{className:"nextjs__container_errors__component-stack",children:(0,S.jsx)("code",{children:f})}),l[9]=f,l[10]=a):a=l[10],l[11]!==u||l[12]!==o||l[13]!==a?(i=(0,S.jsxs)("div",{"data-nextjs-container-errors-pseudo-html":!0,"data-nextjs-container-errors-pseudo-html-collapse":u,children:[o,a]}),l[11]=u,l[12]=o,l[13]=a,l[14]=i):i=l[14],i}var nF=Symbol.for("NextjsError");function nU(e){return e[nF]||null}function nH(e,t,n,r,o,a,i){try{var l=e[a](i),s=l.value}catch(e){n(e);return}l.done?t(s):Promise.resolve(s).then(r,o)}function nV(e){return function(){var t=this,n=arguments;return new Promise(function(r,o){var a=e.apply(t,n);function i(e){nH(a,r,o,i,l,"next",e)}function l(e){nH(a,r,o,i,l,"throw",e)}i(void 0)})}}function nB(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function n$(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function nq(e,t){var n,r,o,a={label:0,sent:function(){if(1&o[0])throw o[1];return o[1]},trys:[],ops:[]},i=Object.create(("function"==typeof Iterator?Iterator:Object).prototype);return i.next=l(0),i.throw=l(1),i.return=l(2),"function"==typeof Symbol&&(i[Symbol.iterator]=function(){return this}),i;function l(l){return function(s){var c=[l,s];if(n)throw TypeError("Generator is already executing.");for(;i&&(i=0,c[0]&&(a=0)),a;)try{if(n=1,r&&(o=2&c[0]?r.return:c[0]?r.throw||((o=r.return)&&o.call(r),0):r.next)&&!(o=o.call(r,c[1])).done)return o;switch(r=0,o&&(c=[2&c[0],o.value]),c[0]){case 0:case 1:o=c;break;case 4:return a.label++,{value:c[1],done:!1};case 5:a.label++,r=c[1],c=[0];continue;case 7:c=a.ops.pop(),a.trys.pop();continue;default:if(!(o=(o=a.trys).length>0&&o[o.length-1])&&(6===c[0]||2===c[0])){a=0;continue}if(3===c[0]&&(!o||c[1]>o[0]&&c[1]<o[3])){a.label=c[1];break}if(6===c[0]&&a.label<o[1]){a.label=o[1],o=c;break}if(o&&a.label<o[2]){a.label=o[2],a.ops.push(c);break}o[2]&&a.ops.pop(),a.trys.pop();continue}c=t.call(e,a)}catch(e){c=[6,e],r=0}finally{n=o=0}if(5&c[0])throw c[1];return{value:c[0]?c[1]:void 0,done:!0}}}}var nW=function(e){if(!e)return[];var t=e.frames;if("function"!=typeof t)throw Error("Invariant: frames must be a function when the React version has React.use. This is a bug in Next.js.");return C.use(t())};function nK(e){var t,n,r,o,a=(0,O.c)(8),i=e.error,l=e.dialogResizerRef,s=nW(i),c=s.findIndex(nY),u=null!=(t=s[c])?t:null;return a[0]!==u?(n=u&&(0,S.jsx)(e2,{stackFrame:u.originalStackFrame,codeFrame:u.originalCodeFrame}),a[0]=u,a[1]=n):n=a[1],a[2]!==l||a[3]!==s?(r=s.length>0&&(0,S.jsx)(nz,{dialogResizerRef:l,frames:s}),a[2]=l,a[3]=s,a[4]=r):r=a[4],a[5]!==n||a[6]!==r?(o=(0,S.jsxs)(S.Fragment,{children:[n,r]}),a[5]=n,a[6]=r,a[7]=o):o=a[7],o}function nY(e){return!e.ignored&&!!e.originalCodeFrame&&!!e.originalStackFrame}var nG="\n  ".concat("\n  [data-nextjs-container-errors-pseudo-html] {\n    padding: 8px 0;\n    margin: 8px 0;\n    border: 1px solid var(--color-gray-400);\n    background: var(--color-background-200);\n    color: var(--color-syntax-constant);\n    font-family: var(--font-stack-monospace);\n    font-size: var(--size-12);\n    line-height: 1.33em; /* 16px in 12px font size */\n    border-radius: var(--rounded-md-2);\n  }\n  [data-nextjs-container-errors-pseudo-html-line] {\n    display: inline-block;\n    width: 100%;\n    padding-left: 40px;\n    line-height: calc(5 / 3);\n  }\n  [data-nextjs-container-errors-pseudo-html--diff='error'] {\n    background: var(--color-amber-100);\n    box-shadow: 2px 0 0 0 var(--color-amber-900) inset;\n    font-weight: bold;\n  }\n  [data-nextjs-container-errors-pseudo-html-collapse-button] {\n    all: unset;\n    margin-left: 12px;\n    &:focus {\n      outline: none;\n    }\n  }\n  [data-nextjs-container-errors-pseudo-html--diff='add'] {\n    background: var(--color-green-300);\n  }\n  [data-nextjs-container-errors-pseudo-html-line-sign] {\n    margin-left: calc(24px * -1);\n    margin-right: 24px;\n  }\n  [data-nextjs-container-errors-pseudo-html--diff='add']\n    [data-nextjs-container-errors-pseudo-html-line-sign] {\n    color: var(--color-green-900);\n  }\n  [data-nextjs-container-errors-pseudo-html--diff='remove'] {\n    background: var(--color-red-300);\n  }\n  [data-nextjs-container-errors-pseudo-html--diff='remove']\n    [data-nextjs-container-errors-pseudo-html-line-sign] {\n    color: var(--color-red-900);\n    margin-left: calc(24px * -1);\n    margin-right: 24px;\n  }\n  [data-nextjs-container-errors-pseudo-html--diff='error']\n    [data-nextjs-container-errors-pseudo-html-line-sign] {\n    color: var(--color-amber-900);\n  }\n  \n  [data-nextjs-container-errors-pseudo-html--hint] {\n    display: inline-block;\n    font-size: 0;\n    height: 0;\n  }\n  [data-nextjs-container-errors-pseudo-html--tag-adjacent='false'] {\n    color: var(--color-accents-1);\n  }\n  .nextjs__container_errors__component-stack {\n    margin: 0;\n  }\n  [data-nextjs-container-errors-pseudo-html-collapse='true']\n    .nextjs__container_errors__component-stack\n    code {\n    max-height: 120px;\n    mask-image: linear-gradient(to bottom,rgba(0,0,0,0) 0%,black 10%);\n    padding-bottom: 40px;\n  }\n  .nextjs__container_errors__component-stack code {\n    display: block;\n    width: 100%;\n    white-space: pre-wrap;\n    scroll-snap-type: y mandatory;\n    overflow-y: hidden;\n  }\n  [data-nextjs-container-errors-pseudo-html--diff] {\n    scroll-snap-align: center;\n  }\n  .error-overlay-hydration-error-diff-plus-icon {\n    color: var(--color-green-900);\n  }\n  .error-overlay-hydration-error-diff-minus-icon {\n    color: var(--color-red-900);\n  }\n","\n");function nX(e){return e&&"undefined"!=typeof Symbol&&e.constructor===Symbol?"symbol":typeof e}function nQ(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function nJ(e){return e.startsWith("https://nextjs.org")}function n0(e){var t,n=(0,O.c)(2),r=e.message;return n[0]!==r?(t=(0,S.jsx)(eP,{text:r,matcher:nJ}),n[0]=r,n[1]=t):t=n[1],t}function n1(e){var t,n,r=(0,O.c)(5),o=e.error,a="environmentName"in o?o.environmentName:"",i=a?"[ ".concat(a," ] "):"",l=o.message;return l.startsWith(i)&&(r[0]!==i.length||r[1]!==l?(t=l.slice(i.length),r[0]=i.length,r[1]=l,r[2]=t):t=r[2],l=t),r[3]!==l?(n=(0,S.jsx)(S.Fragment,{children:(0,S.jsx)(eP,{text:l,matcher:nJ})}),r[3]=l,r[4]=n):n=r[4],n}function n2(){var e,t,n,r,o,a,i,l,s=(0,O.c)(8);return s[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsxs)("h3",{className:"nextjs__blocking_page_load_error_description_title",children:["Uncached data was accessed outside of ","<Suspense>"]}),t=(0,S.jsx)("p",{children:"This delays the entire page from rendering, resulting in a slow user experience. Next.js uses this error to ensure your app loads instantly on every navigation."}),n=(0,S.jsx)("h4",{children:"To fix this, you can either:"}),s[0]=e,s[1]=t,s[2]=n):(e=s[0],t=s[1],n=s[2]),s[3]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsxs)("p",{className:"nextjs__blocking_page_load_error_fix_option",children:[(0,S.jsxs)("strong",{children:["Wrap the component in a ","<Suspense>"," boundary."]})," This allows Next.js to stream its contents to the user as soon as it's ready, without blocking the rest of the app."]}),o=(0,S.jsx)("h4",{className:"nextjs__blocking_page_load_error_fix_option_separator",children:"or"}),s[3]=r,s[4]=o):(r=s[3],o=s[4]),s[5]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsxs)("p",{className:"nextjs__blocking_page_load_error_fix_option",children:[(0,S.jsxs)("strong",{children:["Move the asynchronous await into a Cache Component (",(0,S.jsx)("code",{children:'"use cache"'}),")"]}),". This allows Next.js to statically prerender the component as part of the HTML document, so it's instantly visible to the user."]}),i=(0,S.jsxs)("p",{children:["Note that request-specific information — such as params, cookies, and headers — is not available during static prerendering, so must be wrapped in ","<Suspense>","."]}),s[5]=a,s[6]=i):(a=s[5],i=s[6]),s[7]===Symbol.for("react.memo_cache_sentinel")?(l=(0,S.jsxs)("div",{className:"nextjs__blocking_page_load_error_description",children:[e,t,n,r,o,a,i,(0,S.jsxs)("p",{children:["Learn more:"," ",(0,S.jsx)("a",{href:"https://nextjs.org/docs/messages/blocking-route",children:"https://nextjs.org/docs/messages/blocking-route"})]})]}),s[7]=l):l=s[7],l}var n3={hydrationWarning:null,notes:null,reactOutputComponentDiff:null};function n4(e){var t,n,r=e.getSquashedHydrationErrorDetails,o=e.runtimeErrors,a=e.debugInfo,i=e.onClose,l=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["getSquashedHydrationErrorDetails","runtimeErrors","debugInfo","onClose"]),s=(0,C.useRef)(null),c=function(e){var t,n,r,o,a,i,l,s,c,u=(0,O.c)(17),d=e.runtimeErrors,f=e.getSquashedHydrationErrorDetails,p=(r=(0,C.useState)(0),function(e){if(Array.isArray(e))return e}(r)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(r,2)||function(e,t){if(e){if("string"==typeof e)return nQ(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return nQ(e,2)}}(r,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),h=p[0],m=p[1],g=0===d.length,v=null!=(a=d[h])?a:null,y=function(e,t){var n=(0,O.c)(12);n:{if(void 0===e){o=n3;break n}n[0]!==e||n[1]!==t?(s=t(e),n[0]=e,n[1]=t,n[2]=s):s=n[2];var r,o,a,i,l=s;if(null!==l){var s,c,u,d,f=null!=(c=l.warning)?c:null,p=null!=(u=l.reactOutputComponentDiff)?u:null;n[3]!==f||n[4]!==p?(d={hydrationWarning:f,notes:null,reactOutputComponentDiff:p},n[3]=f,n[4]=p,n[5]=d):d=n[5],o=d;break n}if(!(tO((r=e).message)||/Hydration failed because the server rendered (text|HTML) didn't match the client\./.test(r.message)||/A tree hydrated but some attributes of the server rendered HTML didn't match the client properties./.test(r.message))){o=n3;break n}n[6]!==e?(a=function(e){var t=e.message;if(tO(t)){var n=tx(t.split("\n\n"),2),r=n[0],o=n[1],a=(void 0===o?"":o).trim();return{message:""===a?t.trim():r.trim(),diff:a,notes:null}}var i=tx(t.split("".concat(tk)),2),l=i[0],s=i[1],c=l.trim();if(void 0!==s&&s.length>1){var u=[];s.split("\n").forEach(function(e){""!==e.trim()&&(e.trim().startsWith("at ")||u.push(e))});var d=tw(c.split("\n\n")),f=d[0],p=d.slice(1);return{message:f,diff:u.join("\n"),notes:p.join("\n\n")||null}}var h=tw(c.split("\n\n"));return{message:h[0],diff:null,notes:h.slice(1).join("\n\n")}}(e),n[6]=e,n[7]=a):a=n[7];var h=a.message,m=a.notes,g=a.diff;if(null===h){o=n3;break n}n[8]!==g||n[9]!==h||n[10]!==m?(i={hydrationWarning:h,notes:m,reactOutputComponentDiff:g},n[8]=g,n[9]=h,n[10]=m,n[11]=i):i=n[11],o=i}return o}(null==v?void 0:v.error,f);if(g||!v)return u[0]!==h||u[1]!==g?(i={isLoading:g,activeIdx:h,setActiveIndex:m,activeError:null,errorDetails:null,errorCode:null,errorType:null,notes:null,hydrationWarning:null},u[0]=h,u[1]=g,u[2]=i):i=u[2],i;var b=v.error;u[3]!==b?(l=(void 0===(o=b)?"undefined":nX(o))==="object"&&null!==o&&"__NEXT_ERROR_CODE"in o&&"string"==typeof o.__NEXT_ERROR_CODE?o.__NEXT_ERROR_CODE:(void 0===o?"undefined":nX(o))==="object"&&null!==o&&"digest"in o&&"string"==typeof o.digest?o.digest.split("@").find(function(e){return e.startsWith("E")}):void 0,u[3]=b,u[4]=l):l=u[4];var x=l;u[5]!==v.type||u[6]!==b?(t=b,s="recoverable"===(n=v.type)?"Recoverable ".concat(t.name):"console"===n?t.message.includes("https://nextjs.org/docs/messages/blocking-route")?"Blocking Route":"Console ".concat(t.name):"Runtime ".concat(t.name),u[5]=v.type,u[6]=b,u[7]=s):s=u[7];var w=s,_=y.notes,k=y.hydrationWarning;return u[8]!==v||u[9]!==h||u[10]!==x||u[11]!==y||u[12]!==w||u[13]!==k||u[14]!==g||u[15]!==_?(c={isLoading:g,activeIdx:h,setActiveIndex:m,activeError:v,errorDetails:y,errorCode:x,errorType:w,notes:_,hydrationWarning:k},u[8]=v,u[9]=h,u[10]=x,u[11]=y,u[12]=w,u[13]=k,u[14]=g,u[15]=_,u[16]=c):c=u[16],c}({runtimeErrors:o,getSquashedHydrationErrorDetails:r}),u=c.isLoading,d=c.errorCode,f=c.errorType,p=c.notes,h=c.hydrationWarning,m=c.activeIdx,g=c.errorDetails,v=c.activeError,y=c.setActiveIndex,b=nW(v),x=(0,C.useMemo)(function(){var e,t=b.findIndex(function(e){return!e.ignored&&!!e.originalCodeFrame&&!!e.originalStackFrame});return null!=(e=b[t])?e:null},[b]),w=(0,C.useCallback)(function(){if(!v)return"";var e=[];f&&e.push("## Error Type\n".concat(f));var t=v.error,n=t.message;if("environmentName"in t&&t.environmentName){var r="[ ".concat(t.environmentName," ] ");n.startsWith(r)&&(n=n.slice(r.length))}if(n&&e.push("## Error Message\n".concat(n)),b.length>0){var o=b.filter(function(e){return!e.ignored});if(o.length>0){var a=o.map(function(e){if(e.originalStackFrame){var t=e.originalStackFrame,n=t.methodName,r=t.file,o=t.line1,a=t.column1;return"    at ".concat(n," (").concat(r,":").concat(o,":").concat(a,")")}if(e.sourceStackFrame){var i=e.sourceStackFrame,l=i.methodName,s=i.file,c=i.line1,u=i.column1;return"    at ".concat(l," (").concat(s,":").concat(c,":").concat(u,")")}return""}).filter(Boolean);a.length>0&&e.push("\n".concat(a.join("\n")))}}if(null==x?void 0:x.originalCodeFrame){var i=eJ()(e0(x.originalCodeFrame));e.push("## Code Frame\n".concat(i))}return"".concat(e.join("\n\n"),"\n\nNext.js version: ").concat(l.versionInfo.installed," (").concat(process.env.__NEXT_BUNDLER,")\n")},[v,f,x,b,l.versionInfo]);if(u)return(0,S.jsx)(t8,{children:(0,S.jsx)(nh,{})});if(!v)return null;var _=v.error,k=["server","edge-server"].includes(nU(_)||"");return(0,S.jsxs)(nb,(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({errorCode:d,errorType:f,errorMessage:h?(0,S.jsx)(n0,{message:h}):"Blocking Route"===f?(0,S.jsx)(n2,{}):(0,S.jsx)(n1,{error:_}),onClose:k?void 0:i,debugInfo:a,error:_,runtimeErrors:o,activeIdx:m,setActiveIndex:y,dialogResizerRef:s,generateErrorInfo:w},l),n=n={children:[(0,S.jsxs)("div",{className:"error-overlay-notes-container",children:[p?(0,S.jsx)(S.Fragment,{children:(0,S.jsx)("p",{id:"nextjs__container_errors__notes",className:"nextjs__container_errors__notes",children:p})}):null,h?(0,S.jsx)("p",{id:"nextjs__container_errors__link",className:"nextjs__container_errors__link",children:(0,S.jsx)(eP,{text:"See more info here: ".concat(tj)})}):null]}),g.reactOutputComponentDiff?(0,S.jsx)(nZ,{reactOutputComponentDiff:g.reactOutputComponentDiff||""}):null,(0,S.jsx)(C.Suspense,{fallback:(0,S.jsx)("div",{"data-nextjs-error-suspended":!0}),children:(0,S.jsx)(nK,{error:v,dialogResizerRef:s},v.id.toString())})]},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t))}function n5(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x=(0,O.c)(19);return(x[0]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("code",{className:"dev-tools-info-code",children:"pages"}),x[0]=r):r=x[0],x[1]===Symbol.for("react.memo_cache_sentinel")?(o=(0,S.jsxs)("p",{className:"dev-tools-info-paragraph",children:["Turbopack is an incremental bundler optimized for JavaScript and TypeScript, written in Rust, and built into Next.js. Turbopack can be used in Next.js in both the"," ",r," and"," ",(0,S.jsx)("code",{className:"dev-tools-info-code",children:"app"})," directories for faster local development."]}),x[1]=o):o=x[1],x[2]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsxs)("p",{className:"dev-tools-info-paragraph",children:["To enable Turbopack, use the"," ",(0,S.jsx)("code",{className:"dev-tools-info-code",children:"--turbopack"})," flag when running the Next.js development server."]}),x[2]=a):a=x[2],x[3]!==e)?(i=(0,S.jsxs)("article",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({className:"dev-tools-info-article"},e),n=n={children:[o,a]},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),x[3]=e,x[4]=i):i=x[4],x[5]===Symbol.for("react.memo_cache_sentinel")?(l=(0,S.jsx)(ti,{actionLabel:"Copy Next.js Turbopack Command",successLabel:"Next.js Turbopack Command Copied",content:"--turbopack",className:"dev-tools-info-copy-button"}),x[5]=l):l=x[5],x[6]===Symbol.for("react.memo_cache_sentinel")?(s=(0,S.jsx)("div",{className:"dev-tools-info-code-block-line",children:"  "}),c=(0,S.jsx)("div",{className:"dev-tools-info-code-block-line",children:"{"}),x[6]=s,x[7]=c):(s=x[6],c=x[7]),x[8]===Symbol.for("react.memo_cache_sentinel")?(u=(0,S.jsxs)("div",{className:"dev-tools-info-code-block-line",children:["  ",(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-key",children:'"scripts"'}),": ","{"]}),x[8]=u):u=x[8],x[9]===Symbol.for("react.memo_cache_sentinel")?(d=(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-key",children:'"dev"'}),x[9]=d):d=x[9],x[10]===Symbol.for("react.memo_cache_sentinel")?(f=(0,S.jsxs)("div",{className:"dev-tools-info-code-block-line dev-tools-info-highlight",children:["    ",d,":"," ",(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-value",children:'"next dev --turbopack"'}),","]}),x[10]=f):f=x[10],x[11]===Symbol.for("react.memo_cache_sentinel")?(p=(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-key",children:'"build"'}),x[11]=p):p=x[11],x[12]===Symbol.for("react.memo_cache_sentinel")?(h=(0,S.jsxs)("div",{className:"dev-tools-info-code-block-line",children:["    ",p,":"," ",(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-value",children:'"next build"'}),","]}),x[12]=h):h=x[12],x[13]===Symbol.for("react.memo_cache_sentinel")?(m=(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-key",children:'"start"'}),x[13]=m):m=x[13],x[14]===Symbol.for("react.memo_cache_sentinel")?(g=(0,S.jsxs)("div",{className:"dev-tools-info-code-block-line",children:["    ",m,":"," ",(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-value",children:'"next start"'}),","]}),x[14]=g):g=x[14],x[15]===Symbol.for("react.memo_cache_sentinel")?(v=(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-key",children:'"lint"'}),x[15]=v):v=x[15],x[16]===Symbol.for("react.memo_cache_sentinel")?(y=(0,S.jsx)("div",{className:"dev-tools-info-code-block-container",children:(0,S.jsxs)("div",{className:"dev-tools-info-code-block",children:[l,(0,S.jsx)("pre",{className:"dev-tools-info-code-block-pre",children:(0,S.jsxs)("code",{children:[s,c,u,f,h,g,(0,S.jsxs)("div",{className:"dev-tools-info-code-block-line",children:["    ",v,":"," ",(0,S.jsx)("span",{className:"dev-tools-info-code-block-json-value",children:'"next lint"'})]}),(0,S.jsx)("div",{className:"dev-tools-info-code-block-line",children:"  }"}),(0,S.jsx)("div",{className:"dev-tools-info-code-block-line",children:"}"}),(0,S.jsx)("div",{className:"dev-tools-info-code-block-line",children:"  "})]})})]})}),x[16]=y):y=x[16],x[17]!==i?(b=(0,S.jsxs)(S.Fragment,{children:[i,y]}),x[17]=i,x[18]=b):b=x[18],b}function n6(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function n9(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function n8(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}function n7(e){var t,n,r,o,a,i,l=(0,O.c)(10);l[0]!==e?(t=n8(e,["routerType"]),n=e.routerType,l[0]=e,l[1]=t,l[2]=n):(t=l[1],n=l[2]),l[3]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsxs)("p",{className:"dev-tools-info-paragraph",children:["The path"," ",(0,S.jsx)("code",{className:"dev-tools-info-code",children:window.location.pathname})," ",'is marked as "static" since it will be prerendered during the build time.']}),l[3]=r):r=l[3];var s="pages"===n?"https://nextjs.org/docs/pages/building-your-application/data-fetching/incremental-static-regeneration":"https://nextjs.org/docs/app/building-your-application/data-fetching/incremental-static-regeneration";return l[4]!==s?(o=(0,S.jsxs)("p",{className:"dev-tools-info-paragraph",children:["With Static Rendering, routes are rendered at build time, or in the background after"," ",(0,S.jsx)("a",{className:"dev-tools-info-link",href:s,target:"_blank",rel:"noopener noreferrer",children:"data revalidation"}),"."]}),l[4]=s,l[5]=o):o=l[5],l[6]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)("p",{className:"dev-tools-info-paragraph",children:"Static rendering is useful when a route has data that is not personalized to the user and can be known at build time, such as a static blog post or a product page."}),l[6]=a):a=l[6],l[7]!==t||l[8]!==o?(i=(0,S.jsxs)("article",n9(n6({className:"dev-tools-info-article"},t),{children:[r,o,a]})),l[7]=t,l[8]=o,l[9]=i):i=l[9],i}function re(e){var t,n,r,o,a,i,l,s=(0,O.c)(11);return s[0]!==e?(t=n8(e,["routerType"]),n=e.routerType,s[0]=e,s[1]=t,s[2]=n):(t=s[1],n=s[2]),s[3]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("code",{className:"dev-tools-info-code",children:window.location.pathname}),s[3]=r):r=s[3],s[4]===Symbol.for("react.memo_cache_sentinel")?(o=(0,S.jsxs)("p",{className:"dev-tools-info-paragraph",children:["The path"," ",r," ",'is marked as "dynamic" since it will be rendered for each user at'," ",(0,S.jsx)("strong",{children:"request time"}),"."]}),a=(0,S.jsx)("p",{className:"dev-tools-info-paragraph",children:"Dynamic rendering is useful when a route has data that is personalized to the user or has information that can only be known at request time, such as cookies or the URL's search params."}),s[4]=o,s[5]=a):(o=s[4],a=s[5]),s[6]!==n?(i="pages"===n?(0,S.jsxs)("p",{className:"dev-tools-info-pagraph",children:["Exporting the"," ",(0,S.jsx)("a",{className:"dev-tools-info-link",href:"https://nextjs.org/docs/pages/building-your-application/data-fetching/get-server-side-props",target:"_blank",rel:"noopener noreferrer",children:"getServerSideProps"})," ","function will opt the route into dynamic rendering. This function will be called by the server on every request."]}):(0,S.jsxs)("p",{className:"dev-tools-info-paragraph",children:["During rendering, if a"," ",(0,S.jsx)("a",{className:"dev-tools-info-link",href:"https://nextjs.org/docs/app/building-your-application/rendering/server-components#dynamic-apis",target:"_blank",rel:"noopener noreferrer",children:"Dynamic API"})," ","or a"," ",(0,S.jsx)("a",{className:"dev-tools-info-link",href:"https://nextjs.org/docs/app/api-reference/functions/fetch",target:"_blank",rel:"noopener noreferrer",children:"fetch"})," ","option of"," ",(0,S.jsx)("code",{className:"dev-tools-info-code",children:"{ cache: 'no-store' }"})," ","is discovered, Next.js will switch to dynamically rendering the whole route."]}),s[6]=n,s[7]=i):i=s[7],s[8]!==t||s[9]!==i?(l=(0,S.jsxs)("article",n9(n6({className:"dev-tools-info-article"},t),{children:[o,a,i]})),s[8]=t,s[9]=i,s[10]=l):l=s[10],l}var rt={pages:{static:"https://nextjs.org/docs/pages/building-your-application/rendering/static-site-generation",dynamic:"https://nextjs.org/docs/pages/building-your-application/rendering/server-side-rendering"},app:{static:"https://nextjs.org/docs/app/building-your-application/rendering/server-components#static-rendering-default",dynamic:"https://nextjs.org/docs/app/building-your-application/rendering/server-components#dynamic-rendering"}};function rn(e){var t,n,r,o,a=(0,O.c)(8);return a[0]!==e?(n=n8(e,["routerType","isStaticRoute"]),r=e.routerType,t=e.isStaticRoute,a[0]=e,a[1]=t,a[2]=n,a[3]=r):(t=a[1],n=a[2],r=a[3]),a[4]!==t||a[5]!==n||a[6]!==r?(o=t?(0,S.jsx)(n7,n6({routerType:r},n)):(0,S.jsx)(re,n6({routerType:r},n)),a[4]=t,a[5]=n,a[6]=r,a[7]=o):o=a[7],o}function rr(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",fill:"none",children:(0,S.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"m.191 2.063.56.498 13.5 12 .561.498.997-1.121-.56-.498-1.81-1.608 2.88-3.342v-.98l-3.204-3.72C10.645.923 6.365.686 3.594 3.08L1.748 1.44 1.188.94.19 2.063ZM14.761 8l-2.442 2.836-1.65-1.466a3.001 3.001 0 0 0-4.342-3.86l-1.6-1.422a5.253 5.253 0 0 1 7.251.682L14.76 8ZM7.526 6.576l1.942 1.727a1.499 1.499 0 0 0-1.942-1.727Zm-7.845.935 1.722-2 1.137.979L1.24 8l2.782 3.23A5.25 5.25 0 0 0 9.9 12.703l.54 1.4a6.751 6.751 0 0 1-7.555-1.892L-.318 8.49v-.98Z",clipRule:"evenodd"})}),t[0]=e):e=t[0],e}function ro(){var e,t,n=(0,O.c)(2);return n[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("g",{clipPath:"url(#light_icon_clip_path)",children:(0,S.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"M8.75.75V0h-1.5v2h1.5V.75ZM3.26 4.32l-.53-.53-.354-.353-.53-.53 1.06-1.061.53.53.354.354.53.53-1.06 1.06Zm8.42-1.06.53-.53.353-.354.53-.53 1.061 1.06-.53.53-.354.354-.53.53-1.06-1.06ZM8 11.25a3.25 3.25 0 1 0 0-6.5 3.25 3.25 0 0 0 0 6.5Zm0 1.5a4.75 4.75 0 1 0 0-9.5 4.75 4.75 0 0 0 0 9.5Zm6-5.5h2v1.5h-2v-1.5Zm-13.25 0H0v1.5h2v-1.5H.75Zm1.62 5.32-.53.53 1.06 1.06.53-.53.354-.353.53-.53-1.06-1.061-.53.53-.354.354Zm10.2 1.06.53.53 1.06-1.06-.53-.53-.354-.354-.53-.53-1.06 1.06.53.53.353.354ZM8.75 14v2h-1.5v-2h1.5Z",clipRule:"evenodd"})}),n[0]=e):e=n[0],n[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"20",height:"16",viewBox:"0 0 16 16",fill:"none",children:[e,(0,S.jsx)("defs",{children:(0,S.jsx)("clipPath",{id:"light_icon_clip_path",children:(0,S.jsx)("path",{fill:"currentColor",d:"M0 0h16v16H0z"})})})]}),n[1]=t):t=n[1],t}function ra(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{"data-testid":"geist-icon",height:"16",strokeLinejoin:"round",viewBox:"0 0 16 16",width:"16",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M1.5 8.00005C1.5 5.53089 2.99198 3.40932 5.12349 2.48889C4.88136 3.19858 4.75 3.95936 4.75 4.7501C4.75 8.61609 7.88401 11.7501 11.75 11.7501C11.8995 11.7501 12.048 11.7454 12.1953 11.7361C11.0955 13.1164 9.40047 14.0001 7.5 14.0001C4.18629 14.0001 1.5 11.3138 1.5 8.00005ZM6.41706 0.577759C2.78784 1.1031 0 4.22536 0 8.00005C0 12.1422 3.35786 15.5001 7.5 15.5001C10.5798 15.5001 13.2244 13.6438 14.3792 10.9921L13.4588 9.9797C12.9218 10.155 12.3478 10.2501 11.75 10.2501C8.71243 10.2501 6.25 7.78767 6.25 4.7501C6.25 3.63431 6.58146 2.59823 7.15111 1.73217L6.41706 0.577759ZM13.25 1V1.75V2.75L14.25 2.75H15V4.25H14.25H13.25V5.25V6H11.75V5.25V4.25H10.75L10 4.25V2.75H10.75L11.75 2.75V1.75V1H13.25Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function ri(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"16",height:"16",strokeLinejoin:"round",children:(0,S.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v8.5a1 1 0 0 1-1 1H8.75v3h1.75V16h-5v-1.5h1.75v-3H1a1 1 0 0 1-1-1V2Zm1.5.5V10h13V2.5h-13Z",clipRule:"evenodd"})}),t[0]=e):e=t[0],e}function rl(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function rs(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||ru(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function rc(e){return function(e){if(Array.isArray(e))return rl(e)}(e)||function(e){if("undefined"!=typeof Symbol&&null!=e[Symbol.iterator]||null!=e["@@iterator"])return Array.from(e)}(e)||ru(e)||function(){throw TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function ru(e,t){if(e){if("string"==typeof e)return rl(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return rl(e,t)}}function rd(){var e,t,n=(e=["\n  .shortcut-recorder {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    gap: 8px;\n    position: relative;\n    font-family: var(--font-stack-sans);\n\n    .shortcut-recorder-button {\n      display: flex;\n      align-items: center;\n      gap: 4px;\n      background: transparent;\n      border: 1px dashed var(--color-gray-500);\n      border-radius: var(--rounded-lg);\n      padding: 6px 8px;\n      font-weight: 400;\n      font-size: var(--size-14);\n      color: var(--color-gray-1000);\n      transition: border-color 150ms var(--timing-swift);\n\n      &[data-has-shortcut='true'] {\n        border: 1px solid var(--color-gray-alpha-400);\n\n        &:hover {\n          border-color: var(--color-gray-500);\n        }\n      }\n\n      &:hover {\n        border-color: var(--color-gray-600);\n      }\n\n      &::placeholder {\n        color: var(--color-gray-900);\n      }\n\n      &[data-pristine='false']::placeholder {\n        color: transparent;\n      }\n\n      &:focus-visible {\n        outline: var(--focus-ring);\n        outline-offset: -1px;\n      }\n    }\n\n    kbd {\n      display: inline-flex;\n      align-items: center;\n      justify-content: center;\n      font-family: var(--font-stack-sans);\n      background: var(--color-gray-200);\n      min-width: 20px;\n      height: 20px;\n      font-size: 14px;\n      border-radius: 4px;\n      color: var(--color-gray-1000);\n\n      &[data-symbol='false'] {\n        padding: 0 4px;\n      }\n    }\n\n    .shortcut-recorder-clear-button {\n      cursor: pointer;\n      color: var(--color-gray-1000);\n      width: 20px;\n      height: 20px;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      border-radius: 4px;\n      transition: background 150ms var(--timing-swift);\n\n      &:hover {\n        background: var(--color-gray-300);\n      }\n\n      &:focus-visible {\n        outline: var(--focus-ring);\n      }\n\n      svg {\n        width: 14px;\n        height: 14px;\n      }\n    }\n  }\n\n  .shortcut-recorder-keys {\n    pointer-events: none;\n    user-select: none;\n    display: flex;\n    align-items: center;\n    gap: 2px;\n  }\n\n  .shortcut-recorder-tooltip {\n    --gap: 8px;\n    --background: var(--color-gray-1000);\n    background: var(--background);\n    color: var(--color-background-100);\n    font-size: var(--size-14);\n    padding: 4px 8px;\n    border-radius: 8px;\n    position: absolute;\n    bottom: calc(100% + var(--gap));\n    text-align: center;\n    opacity: 0;\n    scale: 0.96;\n    white-space: nowrap;\n    user-select: none;\n    transition:\n      opacity 150ms var(--timing-swift),\n      scale 150ms var(--timing-swift);\n\n    &[data-show='true'] {\n      opacity: 1;\n      scale: 1;\n    }\n\n    svg {\n      position: absolute;\n      transform: translateX(-50%);\n      bottom: -6px;\n      left: 50%;\n    }\n\n    .shortcut-recorder-status {\n      display: flex;\n      align-items: center;\n      gap: 6px;\n    }\n\n    .shortcut-recorder-status-icon {\n      width: 7px;\n      height: 7px;\n      border-radius: 50%;\n      flex-shrink: 0;\n      background: var(--color-red-700);\n\n      &[data-success='true'] {\n        background: var(--color-green-700);\n      }\n    }\n  }\n"],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return rd=function(){return n},n}var rf=["Meta","Control","Ctrl","Alt","Option","Shift"];function rp(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h=(0,O.c)(33),m=e.value,g=e.onChange,v=rs((0,C.useState)(!0),2),y=v[0],b=v[1],x=rs((0,C.useState)(!1),2),w=x[0],_=x[1];h[0]!==m?(t=null!=m?m:[],h[0]=m,h[1]=t):t=h[1];var k=rs((0,C.useState)(t),2),j=k[0],P=k[1],E=rs((0,C.useState)(!1),2),T=E[0],I=E[1],N=(0,C.useRef)(null),L=(0,C.useRef)(null),A=!!m||j.length>0;h[2]!==g||h[3]!==y||h[4]!==w?(n=function(e){if(e.target===L.current&&"Tab"!==e.key){N.current&&clearTimeout(N.current),w||_(!0),y&&(P([]),b(!1));var t=function(e){N.current=window.setTimeout(function(){I(!0),g(e.join("+")),N.current=window.setTimeout(function(){_(!1)},1e3)},180)};e.preventDefault(),e.stopPropagation(),P(function(n){if(n.includes(e.code)||n.includes(e.key))return n;if(!rf.includes(e.key)){var r=n.findIndex(rg);if(-1!==r){var o=rc(n);return o[r]=e.code,t(o),o}var a=rc(n).concat([e.code]);return t(a),a}for(var i=rc(n),l=rf.indexOf(e.key),s=0,c=0;c<i.length;c++)if(rf.includes(i[c])){if(l<rf.indexOf(i[c])){s=c;break}s=c+1}else break;return i.splice(s,0,e.key),t(i),i})}},h[2]=g,h[3]=y,h[4]=w,h[5]=n):n=h[5];var z=n;h[6]!==g?(r=function(){var e;null==(e=L.current)||e.focus(),P([]),I(!1),setTimeout(function(){_(!0)}),g(null)},h[6]=g,h[7]=r):r=h[7];var R=r;h[8]===Symbol.for("react.memo_cache_sentinel")?(o=function(){I(!1),_(!1),b(!0)},h[8]=o):o=h[8];var D=o;h[9]===Symbol.for("react.memo_cache_sentinel")?(a=function(){var e;N.current&&clearTimeout(N.current),_(!0),null==(e=L.current)||e.focus()},h[9]=a):a=h[9];var M=a;h[10]!==A||h[11]!==j?(i=A?(0,S.jsx)("div",{className:"shortcut-recorder-keys",children:j.map(rm)}):"Record Shortcut",h[10]=A,h[11]=j,h[12]=i):i=h[12],h[13]!==R||h[14]!==A?(l=A&&(0,S.jsx)("div",{className:"shortcut-recorder-clear-button",role:"button",onClick:R,onFocus:rh,onKeyDown:function(e){("Enter"===e.key||" "===e.key)&&(R(),e.stopPropagation())},"aria-label":"Clear shortcut",tabIndex:0,children:(0,S.jsx)(rx,{})}),h[13]=R,h[14]=A,h[15]=l):l=h[15],h[16]!==z||h[17]!==A||h[18]!==i||h[19]!==l?(s=(0,S.jsxs)("button",{className:"shortcut-recorder-button",ref:L,onClick:M,onFocus:M,onBlur:D,onKeyDown:z,"data-has-shortcut":A,"data-shortcut-recorder":"true",children:[i,l]}),h[16]=z,h[17]=A,h[18]=i,h[19]=l,h[20]=s):s=h[20],h[21]!==T?(c=(0,S.jsx)("div",{className:"shortcut-recorder-status-icon","data-success":T}),h[21]=T,h[22]=c):c=h[22];var Z=T?"Shortcut set":"Recording";return h[23]!==Z||h[24]!==c?(u=(0,S.jsxs)("div",{className:"shortcut-recorder-status",children:[c,Z]}),h[23]=Z,h[24]=c,h[25]=u):u=h[25],h[26]===Symbol.for("react.memo_cache_sentinel")?(d=(0,S.jsx)(rv,{}),h[26]=d):d=h[26],h[27]!==w||h[28]!==u?(f=(0,S.jsxs)("div",{className:"shortcut-recorder-tooltip","data-show":w,children:[u,d]}),h[27]=w,h[28]=u,h[29]=f):f=h[29],h[30]!==f||h[31]!==s?(p=(0,S.jsxs)("div",{className:"shortcut-recorder",children:[s,f]}),h[30]=f,h[31]=s,h[32]=p):p=h[32],p}function rh(e){return e.stopPropagation()}function rm(e){return(0,S.jsx)(ry,{children:e},e)}function rg(e){return!rf.includes(e)}function rv(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{fill:"none",height:"6",viewBox:"0 0 14 6",width:"14",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("path",{d:"M13.8284 0H0.17157C0.702003 0 1.21071 0.210714 1.58578 0.585787L5.58578 4.58579C6.36683 5.36684 7.63316 5.36683 8.41421 4.58579L12.4142 0.585786C12.7893 0.210714 13.298 0 13.8284 0Z",fill:"var(--background)"})}),t[0]=e):e=t[0],e}function ry(e){var t,n,r,o,a=(0,O.c)(9),i=e.children;a[0]!==i?(t=function(e){switch(e){case"Meta":return(0,S.jsx)(rb,{});case"Alt":case"Option":return"⌥";case"Control":case"Ctrl":return"Ctrl";case"Shift":return"⇧";case"Enter":return"⏎";case"Escape":case"Esc":return"Esc";case" ":case"Space":case"Spacebar":return"Space";case"ArrowUp":return"↑";case"ArrowDown":return"↓";case"ArrowLeft":return"←";case"ArrowRight":return"→";case"Tab":return"Tab";case"Backspace":return"⌫";case"Delete":return"⌦";default:if(1===i.length)return i.toUpperCase();return i}},a[0]=i,a[1]=t):t=a[1];var l=t;if(a[2]!==i||a[3]!==l){var s=l(i);n="string"==typeof s&&1===s.length,r=function(e){if("string"!=typeof e)return e;var t={Minus:"-",Equal:"=",BracketLeft:"[",BracketRight:"]",Backslash:"\\",Semicolon:";",Quote:"'",Comma:",",Period:".",Backquote:"`",Space:" ",Slash:"/",IntlBackslash:"\\"};return t[e]?t[e]:/^Key([A-Z])$/.test(e)?e.replace(/^Key/,""):/^Digit([0-9])$/.test(e)?e.replace(/^Digit/,""):/^Numpad([0-9])$/.test(e)?e.replace(/^Numpad/,""):"NumpadAdd"===e?"+":"NumpadSubtract"===e?"-":"NumpadMultiply"===e?"*":"NumpadDivide"===e?"/":"NumpadDecimal"===e?".":"NumpadEnter"===e?"Enter":e}(s),a[2]=i,a[3]=l,a[4]=n,a[5]=r}else n=a[4],r=a[5];return a[6]!==n||a[7]!==r?(o=(0,S.jsx)("kbd",{"data-symbol":n,children:r}),a[6]=n,a[7]=r,a[8]=o):o=a[8],o}function rb(){var e,t=(0,O.c)(1),n=r_(/^Mac/)||r_(/^iPhone/)||r_(/^iPad/)||r_(/^Mac/)&&navigator.maxTouchPoints>1?"⌘":"Ctrl";return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("span",{style:{minWidth:"1em",display:"inline-block"},children:n}),t[0]=e):e=t[0],e}function rx(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{height:"16",strokeLinejoin:"round",viewBox:"0 0 16 16",width:"16",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M12.4697 13.5303L13 14.0607L14.0607 13L13.5303 12.4697L9.06065 7.99999L13.5303 3.53032L14.0607 2.99999L13 1.93933L12.4697 2.46966L7.99999 6.93933L3.53032 2.46966L2.99999 1.93933L1.93933 2.99999L2.46966 3.53032L6.93933 7.99999L2.46966 12.4697L1.93933 13L2.99999 14.0607L3.53032 13.5303L7.99999 9.06065L12.4697 13.5303Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}var rw=eg(rd());function r_(e){return null!=window.navigator?e.test(window.navigator.platform):void 0}function rk(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function rj(e,t,n,r,o,a,i){try{var l=e[a](i),s=l.value}catch(e){n(e);return}l.done?t(s):Promise.resolve(s).then(r,o)}var rS=__webpack_require__("./dist/compiled/zod/index.cjs"),rO=rS.z.object({theme:rS.z.enum(["light","dark","system"]).optional(),disableDevIndicator:rS.z.boolean().optional(),devToolsPosition:rS.z.enum(["top-left","top-right","bottom-left","bottom-right"]).optional(),devToolsPanelPosition:rS.z.record(rS.z.string(),rS.z.enum(["top-left","top-right","bottom-left","bottom-right"])).optional(),devToolsPanelSize:rS.z.record(rS.z.string(),rS.z.object({width:rS.z.number(),height:rS.z.number()})).optional(),scale:rS.z.number().optional(),hideShortcut:rS.z.string().nullable().optional()});function rC(e){return e&&"undefined"!=typeof Symbol&&e.constructor===Symbol?"symbol":typeof e}var rP={},rE=null;function rT(){if(0!==Object.keys(rP).length){var e=JSON.stringify(rP);rP={},fetch("/__nextjs_devtools_config",{method:"POST",headers:{"Content-Type":"application/json"},body:e,keepalive:!0}).catch(function(t){console.warn("[Next.js DevTools] Failed to save config:",{data:e,error:t})})}}function rI(e){var t=rO.safeParse(e);t.success?(rP=function e(t,n){if(!n||(void 0===n?"undefined":rC(n))!=="object"||Array.isArray(n)||!t||(void 0===t?"undefined":rC(t))!=="object"||Array.isArray(t))return n;var r=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},t);for(var o in n){var a=n[o],i=t[o];void 0!==a&&(a&&(void 0===a?"undefined":rC(a))==="object"&&!Array.isArray(a)&&i&&(void 0===i?"undefined":rC(i))==="object"&&!Array.isArray(i)?r[o]=e(i,a):r[o]=a)}return r}(rP,e),rE&&clearTimeout(rE),rE=setTimeout(rT,120)):console.warn("[Next.js DevTools] Invalid config patch:",t.error.message)}function rN(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function rL(){var e,t,n=(e=["\n  .preferences-container {\n    width: 100%;\n  }\n\n  @media (min-width: 576px) {\n    .preferences-container {\n      width: 480px;\n    }\n  }\n\n  .preference-section:first-child {\n    padding-top: 0;\n  }\n\n  .preference-section {\n    padding: 12px 0;\n    border-bottom: 1px solid var(--color-gray-400);\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    gap: 24px;\n  }\n\n  .preference-section:last-child {\n    border-bottom: none;\n  }\n\n  .preference-header {\n    margin-bottom: 0;\n    flex: 1;\n  }\n\n  .preference-header label {\n    font-size: var(--size-14);\n    font-weight: 500;\n    color: var(--color-gray-1000);\n    margin: 0;\n  }\n\n  .preference-description {\n    color: var(--color-gray-900);\n    font-size: var(--size-14);\n    margin: 0;\n  }\n\n  .select-button,\n  .action-button {\n    display: flex;\n    align-items: center;\n    gap: 8px;\n    background: var(--color-background-100);\n    border: 1px solid var(--color-gray-400);\n    border-radius: var(--rounded-lg);\n    font-weight: 400;\n    font-size: var(--size-14);\n    color: var(--color-gray-1000);\n    padding: 6px 8px;\n    transition: border-color 150ms var(--timing-swift);\n\n    &:hover {\n      border-color: var(--color-gray-500);\n    }\n\n    svg {\n      width: 14px;\n      height: 14px;\n      overflow: visible;\n    }\n  }\n\n  .select-button {\n    &:focus-within {\n      outline: var(--focus-ring);\n      outline-offset: -1px;\n    }\n\n    select {\n      all: unset;\n    }\n\n    option {\n      color: var(--color-gray-1000);\n      background: var(--color-background-100);\n    }\n  }\n\n  .preference-section button:disabled {\n    opacity: 0.6;\n    cursor: not-allowed;\n  }\n\n  :global(.icon) {\n    width: 18px;\n    height: 18px;\n    color: #666;\n  }\n"],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return rL=function(){return n},n}function rA(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x,w,_,k,j,P,E,T,I,N,L,A,R,D,M,Z,F,U,H,V,B=(0,O.c)(61),$=e.theme,q=e.hide,W=e.hideShortcut,K=e.setHideShortcut,Y=e.scale,G=e.setPosition,X=e.setScale,Q=e.position,J=(r=(t=(0,C.useState)(!1),n=function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return rk(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return rk(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}())[0],o=n[1],{restartServer:function(e){var t,n=e.invalidateFileSystemCache;return(t=function(){var e,t,r,a,i,l;return function(e,t){var n,r,o,a={label:0,sent:function(){if(1&o[0])throw o[1];return o[1]},trys:[],ops:[]},i=Object.create(("function"==typeof Iterator?Iterator:Object).prototype);return i.next=l(0),i.throw=l(1),i.return=l(2),"function"==typeof Symbol&&(i[Symbol.iterator]=function(){return this}),i;function l(l){return function(s){var c=[l,s];if(n)throw TypeError("Generator is already executing.");for(;i&&(i=0,c[0]&&(a=0)),a;)try{if(n=1,r&&(o=2&c[0]?r.return:c[0]?r.throw||((o=r.return)&&o.call(r),0):r.next)&&!(o=o.call(r,c[1])).done)return o;switch(r=0,o&&(c=[2&c[0],o.value]),c[0]){case 0:case 1:o=c;break;case 4:return a.label++,{value:c[1],done:!1};case 5:a.label++,r=c[1],c=[0];continue;case 7:c=a.ops.pop(),a.trys.pop();continue;default:if(!(o=(o=a.trys).length>0&&o[o.length-1])&&(6===c[0]||2===c[0])){a=0;continue}if(3===c[0]&&(!o||c[1]>o[0]&&c[1]<o[3])){a.label=c[1];break}if(6===c[0]&&a.label<o[1]){a.label=o[1],o=c;break}if(o&&a.label<o[2]){a.label=o[2],a.ops.push(c);break}o[2]&&a.ops.pop(),a.trys.pop();continue}c=t.call(e,a)}catch(e){c=[6,e],r=0}finally{n=o=0}if(5&c[0])throw c[1];return{value:c[0]?c[1]:void 0,done:!0}}}}(this,function(s){switch(s.label){case 0:o(!0),e=n?"/__nextjs_restart_dev?invalidateFileSystemCache=1":"/__nextjs_restart_dev",t=!1,s.label=1;case 1:return s.trys.push([1,11,12,13]),[4,fetch("/__nextjs_server_status").then(function(e){return e.json()}).then(function(e){return e.executionId}).catch(function(e){return console.log("[Next.js DevTools] Failed to fetch server status while restarting dev server.",e),null})];case 2:if(!(r=s.sent()))return console.log("[Next.js DevTools] Failed to get the current server execution ID while restarting dev server."),[2];return[4,fetch(e,{method:"POST"})];case 3:if(!(a=s.sent()).ok)return console.log("[Next.js DevTools] Failed to fetch restart server endpoint. Status:",a.status),[2];i=0,s.label=4;case 4:if(!(i<10))return[3,10];return[4,new Promise(function(e){return setTimeout(e,1e3)})];case 5:s.sent(),s.label=6;case 6:return s.trys.push([6,8,,9]),[4,fetch("/__nextjs_server_status").then(function(e){return e.json()}).then(function(e){return e.executionId})];case 7:if(l=s.sent(),r!==l)return t=!0,window.location.reload(),[2];return[3,9];case 8:return s.sent(),[3,9];case 9:return i++,[3,4];case 10:return console.log("[Next.js DevTools] Failed to restart server. Exhausted all polling attempts."),[2];case 11:return console.log("[Next.js DevTools] Failed to restart server.",s.sent()),[2];case 12:return t||o(!1),[7];case 13:return[2]}})},function(){var e=this,n=arguments;return new Promise(function(r,o){var a=t.apply(e,n);function i(e){rj(a,r,o,i,l,"next",e)}function l(e){rj(a,r,o,i,l,"throw",e)}i(void 0)})})()},isPending:r}),ee=J.restartServer,et=J.isPending,en=dk().shadowRoot;B[0]!==en.host?(a=function(e){var t=en.host;if("system"===e.target.value){t.classList.remove("dark"),t.classList.remove("light"),rI({theme:"system"});return}"dark"===e.target.value?(t.classList.add("dark"),t.classList.remove("light"),rI({theme:"dark"})):(t.classList.remove("dark"),t.classList.add("light"),rI({theme:"light"}))},B[0]=en.host,B[1]=a):a=B[1];var er=a;B[2]!==G?(i=function(e){G(e.target.value),rI({devToolsPosition:e.target.value})},B[2]=G,B[3]=i):i=B[3];var eo=i;B[4]!==X?(l=function(e){var t=Number(e.target.value);X(t),rI({scale:t})},B[4]=X,B[5]=l):l=B[5];var ea=l;return B[6]===Symbol.for("react.memo_cache_sentinel")?(s=(0,S.jsxs)("div",{className:"preference-header",children:[(0,S.jsx)("label",{htmlFor:"theme",children:"Theme"}),(0,S.jsx)("p",{className:"preference-description",children:"Select your theme preference."})]}),B[6]=s):s=B[6],B[7]!==$?(c=(0,S.jsx)(rD,{theme:$}),B[7]=$,B[8]=c):c=B[8],B[9]===Symbol.for("react.memo_cache_sentinel")?(u=(0,S.jsx)("option",{value:"system",children:"System"}),d=(0,S.jsx)("option",{value:"light",children:"Light"}),f=(0,S.jsx)("option",{value:"dark",children:"Dark"}),B[9]=u,B[10]=d,B[11]=f):(u=B[9],d=B[10],f=B[11]),B[12]!==er||B[13]!==c||B[14]!==$?(p=(0,S.jsxs)("div",{className:"preference-section",children:[s,(0,S.jsxs)(rR,{id:"theme",name:"theme",prefix:c,value:$,onChange:er,children:[u,d,f]})]}),B[12]=er,B[13]=c,B[14]=$,B[15]=p):p=B[15],B[16]===Symbol.for("react.memo_cache_sentinel")?(h=(0,S.jsxs)("div",{className:"preference-header",children:[(0,S.jsx)("label",{htmlFor:"position",children:"Position"}),(0,S.jsx)("p",{className:"preference-description",children:"Adjust the placement of your dev tools."})]}),B[16]=h):h=B[16],B[17]===Symbol.for("react.memo_cache_sentinel")?(m=(0,S.jsx)("option",{value:"bottom-left",children:"Bottom Left"}),g=(0,S.jsx)("option",{value:"bottom-right",children:"Bottom Right"}),v=(0,S.jsx)("option",{value:"top-left",children:"Top Left"}),y=(0,S.jsx)("option",{value:"top-right",children:"Top Right"}),B[17]=m,B[18]=g,B[19]=v,B[20]=y):(m=B[17],g=B[18],v=B[19],y=B[20]),B[21]!==eo||B[22]!==Q?(b=(0,S.jsxs)("div",{className:"preference-section",children:[h,(0,S.jsxs)(rR,{id:"position",name:"position",value:Q,onChange:eo,children:[m,g,v,y]})]}),B[21]=eo,B[22]=Q,B[23]=b):b=B[23],B[24]===Symbol.for("react.memo_cache_sentinel")?(x=(0,S.jsxs)("div",{className:"preference-header",children:[(0,S.jsx)("label",{htmlFor:"size",children:"Size"}),(0,S.jsx)("p",{className:"preference-description",children:"Adjust the size of your dev tools."})]}),B[24]=x):x=B[24],B[25]===Symbol.for("react.memo_cache_sentinel")?(w=Object.entries(z).map(rz),B[25]=w):w=B[25],B[26]!==ea||B[27]!==Y?(_=(0,S.jsxs)("div",{className:"preference-section",children:[x,(0,S.jsx)(rR,{id:"size",name:"size",value:Y,onChange:ea,children:w})]}),B[26]=ea,B[27]=Y,B[28]=_):_=B[28],B[29]===Symbol.for("react.memo_cache_sentinel")?(k=(0,S.jsxs)("div",{className:"preference-header",children:[(0,S.jsx)("label",{id:"hide-dev-tools",children:"Hide Dev Tools for this session"}),(0,S.jsx)("p",{className:"preference-description",children:"Hide Dev Tools until you restart your dev server, or 1 day."})]}),B[29]=k):k=B[29],B[30]===Symbol.for("react.memo_cache_sentinel")?(j=(0,S.jsx)(rr,{}),P=(0,S.jsx)("span",{children:"Hide"}),B[30]=j,B[31]=P):(j=B[30],P=B[31]),B[32]!==q?(E=(0,S.jsxs)("div",{className:"preference-section",children:[k,(0,S.jsx)("div",{className:"preference-control",children:(0,S.jsxs)("button",{"aria-describedby":"hide-dev-tools",name:"hide-dev-tools","data-hide-dev-tools":!0,className:"action-button",onClick:q,children:[j,P]})})]}),B[32]=q,B[33]=E):E=B[33],B[34]===Symbol.for("react.memo_cache_sentinel")?(T=(0,S.jsxs)("div",{className:"preference-header",children:[(0,S.jsx)("label",{id:"hide-dev-tools",children:"Hide Dev Tools shortcut"}),(0,S.jsx)("p",{className:"preference-description",children:"Set a custom keyboard shortcut to toggle visibility."})]}),B[34]=T):T=B[34],B[35]!==W?(I=null!=(N=null==W?void 0:W.split("+"))?N:null,B[35]=W,B[36]=I):I=B[36],B[37]!==K||B[38]!==I?(L=(0,S.jsxs)("div",{className:"preference-section",children:[T,(0,S.jsx)("div",{className:"preference-control",children:(0,S.jsx)(rp,{value:I,onChange:K})})]}),B[37]=K,B[38]=I,B[39]=L):L=B[39],B[40]===Symbol.for("react.memo_cache_sentinel")?(A=(0,S.jsx)("label",{children:"Disable Dev Tools for this project"}),B[40]=A):A=B[40],B[41]===Symbol.for("react.memo_cache_sentinel")?(R=(0,S.jsx)("code",{className:"dev-tools-info-code",children:"devIndicators: false"}),B[41]=R):R=B[41],B[42]===Symbol.for("react.memo_cache_sentinel")?(D=(0,S.jsx)("div",{className:"preference-section",children:(0,S.jsxs)("div",{className:"preference-header",children:[A,(0,S.jsxs)("p",{className:"preference-description",children:["To disable this UI completely, set"," ",R," in your ",(0,S.jsx)("code",{className:"dev-tools-info-code",children:"next.config"})," file."]})]})}),B[42]=D):D=B[42],B[43]===Symbol.for("react.memo_cache_sentinel")?(M=(0,S.jsxs)("div",{className:"preference-header",children:[(0,S.jsx)("label",{id:"restart-dev-server",children:"Restart Dev Server"}),(0,S.jsx)("p",{className:"preference-description",children:"Restarts the development server without needing to leave the browser."})]}),B[43]=M):M=B[43],B[44]!==ee?(Z=function(){return ee({invalidateFileSystemCache:!1})},B[44]=ee,B[45]=Z):Z=B[45],B[46]===Symbol.for("react.memo_cache_sentinel")?(F=(0,S.jsx)("span",{children:"Restart"}),B[46]=F):F=B[46],B[47]!==et||B[48]!==Z?(U=(0,S.jsxs)("div",{className:"preference-section",children:[M,(0,S.jsx)("div",{className:"preference-control",children:(0,S.jsx)("button",{"aria-describedby":"restart-dev-server",title:"Restarts the development server without needing to leave the browser.",name:"restart-dev-server","data-restart-dev-server":!0,className:"action-button",onClick:Z,disabled:et,children:F})})]}),B[47]=et,B[48]=Z,B[49]=U):U=B[49],B[50]!==et||B[51]!==ee?(H=process.env.__NEXT_BUNDLER_HAS_PERSISTENT_CACHE?(0,S.jsxs)("div",{className:"preference-section",children:[(0,S.jsxs)("div",{className:"preference-header",children:[(0,S.jsx)("label",{id:"reset-bundler-cache",children:"Reset Bundler Cache"}),(0,S.jsx)("p",{className:"preference-description",children:"Clears the bundler cache and restarts the dev server. Helpful if you are seeing stale errors or changes are not appearing."})]}),(0,S.jsx)("div",{className:"preference-control",children:(0,S.jsx)("button",{"aria-describedby":"reset-bundler-cache",title:"Clears the bundler cache and restarts the dev server. Helpful if you are seeing stale errors or changes are not appearing.",name:"reset-bundler-cache","data-reset-bundler-cache":!0,className:"action-button",onClick:function(){return ee({invalidateFileSystemCache:!0})},disabled:et,children:(0,S.jsx)("span",{children:"Reset Cache"})})})]}):null,B[50]=et,B[51]=ee,B[52]=H):H=B[52],B[53]!==p||B[54]!==b||B[55]!==_||B[56]!==E||B[57]!==L||B[58]!==U||B[59]!==H?(V=(0,S.jsxs)("div",{className:"preferences-container",children:[p,b,_,E,L,D,U,H]}),B[53]=p,B[54]=b,B[55]=_,B[56]=E,B[57]=L,B[58]=U,B[59]=H,B[60]=V):V=B[60],V}function rz(e){var t,n=function(e){if(Array.isArray(e))return e}(t=e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return rN(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return rN(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}(),r=n[0],o=n[1];return(0,S.jsx)("option",{value:o,children:r},r)}function rR(e){var t,n,r,o,a,i,l,s,c=(0,O.c)(11);return(c[0]!==e?(a=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children","prefix"]),r=e.children,o=e.prefix,c[0]=e,c[1]=r,c[2]=o,c[3]=a):(r=c[1],o=c[2],a=c[3]),c[4]!==r||c[5]!==a)?(i=(0,S.jsx)("select",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},a),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),c[4]=r,c[5]=a,c[6]=i):i=c[6],c[7]===Symbol.for("react.memo_cache_sentinel")?(l=(0,S.jsx)(rZ,{}),c[7]=l):l=c[7],c[8]!==o||c[9]!==i?(s=(0,S.jsxs)("div",{className:"select-button",children:[o,i,l]}),c[8]=o,c[9]=i,c[10]=s):s=c[10],s}function rD(e){var t,n,r,o=(0,O.c)(3);switch(e.theme){case"system":return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)(ri,{}),o[0]=t):t=o[0],t;case"dark":return o[1]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsx)(ra,{}),o[1]=n):n=o[1],n;case"light":return o[2]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)(ro,{}),o[2]=r):r=o[2],r;default:return null}}var rM=eg(rL());function rZ(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"16",height:"16",viewBox:"0 0 16 16","aria-hidden":!0,children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M14.0607 5.49999L13.5303 6.03032L8.7071 10.8535C8.31658 11.2441 7.68341 11.2441 7.29289 10.8535L2.46966 6.03032L1.93933 5.49999L2.99999 4.43933L3.53032 4.96966L7.99999 9.43933L12.4697 4.96966L13 4.43933L14.0607 5.49999Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function rF(){var e,t,n=(e=["\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n        ","\n      "],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return rF=function(){return n},n}function rU(){return(0,S.jsx)("style",{children:eg(rF(),"\n  .nextjs-data-copy-button {\n    color: inherit;\n\n    svg {\n      width: var(--size-16);\n      height: var(--size-16);\n    }\n  }\n  .nextjs-data-copy-button:disabled {\n    background-color: var(--color-gray-100);\n    cursor: not-allowed;\n  }\n  .nextjs-data-copy-button--initial:hover:not(:disabled) {\n    cursor: pointer;\n  }\n  .nextjs-data-copy-button--error:not(:disabled),\n  .nextjs-data-copy-button--error:hover:not(:disabled) {\n    color: var(--color-ansi-red);\n  }\n  .nextjs-data-copy-button--success:not(:disabled) {\n    color: var(--color-ansi-green);\n  }\n",'\n  [data-nextjs-call-stack-frame-no-source] {\n    padding: 6px 8px;\n    margin-bottom: 4px;\n\n    border-radius: var(--rounded-lg);\n  }\n\n  [data-nextjs-call-stack-frame-no-source]:last-child {\n    margin-bottom: 0;\n  }\n\n  [data-nextjs-call-stack-frame-ignored="true"] {\n    opacity: 0.6;\n  }\n\n  [data-nextjs-call-stack-frame] {\n    user-select: text;\n    display: block;\n    box-sizing: border-box;\n\n    user-select: text;\n    -webkit-user-select: text;\n    -moz-user-select: text;\n    -ms-user-select: text;\n\n    padding: 6px 8px;\n\n    border-radius: var(--rounded-lg);\n  }\n\n  .call-stack-frame-method-name {\n    display: flex;\n    align-items: center;\n    gap: 4px;\n\n    margin-bottom: 4px;\n    font-family: var(--font-stack-monospace);\n\n    color: var(--color-gray-1000);\n    font-size: var(--size-14);\n    font-weight: 500;\n    line-height: var(--size-20);\n\n    svg {\n      width: var(--size-16px);\n      height: var(--size-16px);\n    }\n  }\n\n  .open-in-editor-button, .source-mapping-error-button {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    border-radius: var(--rounded-full);\n    padding: 4px;\n    color: var(--color-font);\n\n    svg {\n      width: var(--size-16);\n      height: var(--size-16);\n    }\n\n    &:focus-visible {\n      outline: var(--focus-ring);\n      outline-offset: -2px;\n    }\n\n    &:hover {\n      background: var(--color-gray-100);\n    }\n  }\n\n  .call-stack-frame-file-source {\n    color: var(--color-gray-900);\n    font-size: var(--size-14);\n    line-height: var(--size-20);\n  }\n',nL,"\n  [data-nextjs-environment-name-label] {\n    padding: 2px 6px;\n    margin: 0;\n    border-radius: var(--rounded-md-2);\n    background: var(--color-gray-100);\n    font-weight: 600;\n    font-size: var(--size-12);\n    color: var(--color-gray-900);\n    font-family: var(--font-stack-monospace);\n    line-height: var(--size-20);\n  }\n",n_,e6,nx,tZ,"\n  .error-overlay-bottom-stack-layer {\n    width: 100%;\n    height: var(--stack-layer-height);\n    position: relative;\n    border: 1px solid var(--color-gray-400);\n    border-radius: var(--rounded-xl);\n    background: var(--color-background-200);\n    transition:\n      translate 350ms var(--timing-swift),\n      box-shadow 350ms var(--timing-swift);\n  }\n\n  .error-overlay-bottom-stack-layer-1 {\n    width: calc(100% - var(--size-24));\n  }\n\n  .error-overlay-bottom-stack-layer-2 {\n    width: calc(100% - var(--size-48));\n    z-index: -1;\n  }\n\n  .error-overlay-bottom-stack {\n    width: 100%;\n    position: absolute;\n    bottom: -1px;\n    height: 0;\n    overflow: visible;\n  }\n\n  .error-overlay-bottom-stack-stack {\n    --stack-layer-height: 44px;\n    --stack-layer-height-half: calc(var(--stack-layer-height) / 2);\n    --stack-layer-trim: 13px;\n    --shadow: 0px 0.925px 0.925px 0px rgba(0, 0, 0, 0.02),\n      0px 3.7px 7.4px -3.7px rgba(0, 0, 0, 0.04),\n      0px 14.8px 22.2px -7.4px rgba(0, 0, 0, 0.06);\n\n    display: grid;\n    place-items: center center;\n    width: 100%;\n    position: fixed;\n    height: 0;\n    overflow: visible;\n    z-index: -1;\n    max-width: var(--next-dialog-max-width);\n\n    .error-overlay-bottom-stack-layer {\n      grid-area: 1 / 1;\n      /* Hide */\n      translate: 0 calc(var(--stack-layer-height) * -1);\n    }\n\n    &[data-stack-count='1'],\n    &[data-stack-count='2'] {\n      .error-overlay-bottom-stack-layer-1 {\n        translate: 0\n          calc(var(--stack-layer-height-half) * -1 - var(--stack-layer-trim));\n      }\n    }\n\n    &[data-stack-count='2'] {\n      .error-overlay-bottom-stack-layer-2 {\n        translate: 0 calc(var(--stack-layer-trim) * -1 * 2);\n      }\n    }\n\n    /* Only the bottom stack should have the shadow */\n    &[data-stack-count='1'] .error-overlay-bottom-stack-layer-1 {\n      box-shadow: var(--shadow);\n    }\n\n    &[data-stack-count='2'] {\n      .error-overlay-bottom-stack-layer-2 {\n        box-shadow: var(--shadow);\n      }\n    }\n  }\n","\n  .error-overlay-pagination {\n    -webkit-font-smoothing: antialiased;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    gap: 8px;\n    width: fit-content;\n  }\n\n  .error-overlay-pagination-count {\n    color: var(--color-gray-900);\n    text-align: center;\n    font-size: var(--size-14);\n    font-weight: 500;\n    line-height: var(--size-16);\n    font-variant-numeric: tabular-nums;\n  }\n\n  .error-overlay-pagination-button {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n\n    width: var(--size-24);\n    height: var(--size-24);\n    background: var(--color-gray-300);\n    flex-shrink: 0;\n\n    border: none;\n    border-radius: var(--rounded-full);\n\n    svg {\n      width: var(--size-16);\n      height: var(--size-16);\n    }\n\n    &:focus-visible {\n      outline: var(--focus-ring);\n    }\n\n    &:not(:disabled):active {\n      background: var(--color-gray-500);\n    }\n\n    &:disabled {\n      opacity: 0.5;\n      cursor: not-allowed;\n    }\n  }\n\n  .error-overlay-pagination-button-icon {\n    color: var(--color-gray-1000);\n  }\n",'\n  [data-nextjs-codeframe] {\n    --code-frame-padding: 12px;\n    --code-frame-line-height: var(--size-16);\n    background-color: var(--color-background-200);\n    color: var(--color-gray-1000);\n    text-overflow: ellipsis;\n    border: 1px solid var(--color-gray-400);\n    border-radius: 8px;\n    font-family: var(--font-stack-monospace);\n    font-size: var(--size-12);\n    line-height: var(--code-frame-line-height);\n    margin: 8px 0;\n\n    svg {\n      width: var(--size-16);\n      height: var(--size-16);\n    }\n  }\n\n  .code-frame-link,\n  .code-frame-pre {\n    padding: var(--code-frame-padding);\n  }\n\n  .code-frame-link svg {\n    flex-shrink: 0;\n  }\n\n  .code-frame-lines {\n    min-width: max-content;\n  }\n\n  .code-frame-link [data-text] {\n    text-align: left;\n    margin: auto 6px;\n  }\n\n  .code-frame-header {\n    width: 100%;\n    transition: background 100ms ease-out;\n    border-radius: 8px 8px 0 0;\n    border-bottom: 1px solid var(--color-gray-400);\n  }\n\n  [data-with-open-in-editor-link-source-file] {\n    padding: 4px;\n    margin: -4px 0 -4px auto;\n    border-radius: var(--rounded-full);\n    margin-left: auto;\n\n    &:focus-visible {\n      outline: var(--focus-ring);\n      outline-offset: -2px;\n    }\n\n    &:hover {\n      background: var(--color-gray-100);\n    }\n  }\n\n  [data-nextjs-codeframe]::selection,\n  [data-nextjs-codeframe] *::selection {\n    background-color: var(--color-ansi-selection);\n  }\n\n  [data-nextjs-codeframe] *:not(a) {\n    color: inherit;\n    background-color: transparent;\n    font-family: var(--font-stack-monospace);\n  }\n\n  [data-nextjs-codeframe-line][data-nextjs-codeframe-line--errored="true"] {\n    position: relative;\n    isolation: isolate;\n\n    > span { \n      position: relative;\n      z-index: 1;\n    }\n\n    &::after {\n      content: "";\n      width: calc(100% + var(--code-frame-padding) * 2);\n      height: var(--code-frame-line-height);\n      left: calc(-1 * var(--code-frame-padding));\n      background: var(--color-red-200);\n      box-shadow: 2px 0 0 0 var(--color-red-900) inset;\n      position: absolute;\n    }\n  }\n\n\n  [data-nextjs-codeframe] > * {\n    margin: 0;\n  }\n\n  .code-frame-link {\n    display: flex;\n    margin: 0;\n    outline: 0;\n  }\n  .code-frame-link [data-icon=\'right\'] {\n    margin-left: auto;\n  }\n\n  [data-nextjs-codeframe] div > pre {\n    overflow: hidden;\n    display: inline-block;\n  }\n\n  [data-nextjs-codeframe] svg {\n    color: var(--color-gray-900);\n  }\n',"\n  [data-nextjs-terminal]::selection,\n  [data-nextjs-terminal] *::selection {\n    background-color: var(--color-ansi-selection);\n  }\n\n  [data-nextjs-terminal] * {\n    color: inherit;\n    background-color: transparent;\n    font-family: var(--font-stack-monospace);\n  }\n\n  [data-nextjs-terminal] > div > p {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    cursor: pointer;\n    margin: 0;\n  }\n  [data-nextjs-terminal] > div > p:hover {\n    text-decoration: underline dotted;\n  }\n  [data-nextjs-terminal] div > pre {\n    overflow: hidden;\n    display: inline-block;\n  }\n","\n  [data-with-open-in-editor-link] svg {\n    width: auto;\n    height: var(--size-14);\n    margin-left: 8px;\n  }\n  [data-with-open-in-editor-link] {\n    cursor: pointer;\n  }\n  [data-with-open-in-editor-link]:hover {\n    text-decoration: underline dotted;\n  }\n  [data-with-open-in-editor-link-import-trace] {\n    margin-left: 16px;\n  }\n","","\n  .nextjs-error-with-static {\n    bottom: calc(16px * 4.5);\n  }\n  p.nextjs__container_errors__link {\n    font-size: var(--size-14);\n  }\n  p.nextjs__container_errors__notes {\n    color: var(--color-stack-notes);\n    font-size: var(--size-14);\n    line-height: 1.5;\n  }\n  .nextjs-container-errors-body > h2:not(:first-child) {\n    margin-top: calc(16px + 8px);\n  }\n  .nextjs-container-errors-body > h2 {\n    color: var(--color-title-color);\n    margin-bottom: 8px;\n    font-size: var(--size-20);\n  }\n  .nextjs-toast-errors-parent {\n    cursor: pointer;\n    transition: transform 0.2s ease;\n  }\n  .nextjs-toast-errors-parent:hover {\n    transform: scale(1.1);\n  }\n  .nextjs-toast-errors {\n    display: flex;\n    align-items: center;\n    justify-content: flex-start;\n  }\n  .nextjs-toast-errors > svg {\n    margin-right: 8px;\n  }\n  .nextjs-toast-hide-button {\n    margin-left: 24px;\n    border: none;\n    background: none;\n    color: var(--color-ansi-bright-white);\n    padding: 0;\n    transition: opacity 0.25s ease;\n    opacity: 0.7;\n  }\n  .nextjs-toast-hide-button:hover {\n    opacity: 1;\n  }\n  .nextjs__container_errors__error_title {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    margin-bottom: 14px;\n  }\n  .error-overlay-notes-container {\n    margin: 8px 2px;\n  }\n  .error-overlay-notes-container p {\n    white-space: pre-wrap;\n  }\n  .nextjs__blocking_page_load_error_description {\n    color: var(--color-stack-notes);\n  }\n  .nextjs__blocking_page_load_error_description_title {\n    color: var(--color-title-color);\n  }\n  .nextjs__blocking_page_load_error_fix_option {\n    background-color: var(--color-background-200);\n    padding: 14px;\n    border-radius: var(--rounded-md-2);\n    border: 1px solid var(--color-gray-alpha-400);\n  }\n",nG,"\n  .nextjs-container-build-error-version-status {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    gap: 4px;\n\n    height: var(--size-26);\n    padding: 6px 8px 6px 6px;\n    background: var(--color-background-100);\n    background-clip: padding-box;\n    border: 1px solid var(--color-gray-alpha-400);\n    box-shadow: var(--shadow-small);\n    border-radius: var(--rounded-full);\n\n    color: var(--color-gray-900);\n    font-size: var(--size-12);\n    font-weight: 500;\n    line-height: var(--size-16);\n  }\n\n  a.nextjs-container-build-error-version-status {\n    text-decoration: none;\n    color: var(--color-gray-900);\n\n    &:hover {\n      background: var(--color-gray-100);\n    }\n\n    &:focus {\n      outline: var(--focus-ring);\n    }\n  }\n\n  .version-staleness-indicator.fresh {\n    fill: var(--color-green-800);\n    stroke: var(--color-green-300);\n  }\n  .version-staleness-indicator.stale {\n    fill: var(--color-amber-800);\n    stroke: var(--color-amber-300);\n  }\n  .version-staleness-indicator.outdated {\n    fill: var(--color-red-800);\n    stroke: var(--color-red-300);\n  }\n  .version-staleness-indicator.unknown {\n    fill: var(--color-gray-800);\n    stroke: var(--color-gray-300);\n  }\n\n  .nextjs-container-build-error-version-status > .turbopack-text {\n    background: linear-gradient(\n      to right,\n      var(--color-turbopack-text-red) 0%,\n      var(--color-turbopack-text-blue) 100%\n    );\n    background-clip: text;\n    -webkit-background-clip: text;\n    -webkit-text-fill-color: transparent;\n  }\n","\n  .dev-tools-info-code {\n    background: var(--color-gray-400);\n    color: var(--color-gray-1000);\n    font-family: var(--font-stack-monospace);\n    padding: 2px 4px;\n    margin: 0;\n    font-size: var(--size-13);\n    white-space: break-spaces;\n    border-radius: var(--rounded-md-2);\n  }\n\n  .dev-tools-info-code-block-container {\n    padding: 6px;\n  }\n\n  .dev-tools-info-code-block {\n    position: relative;\n    background: var(--color-background-200);\n    border: 1px solid var(--color-gray-alpha-400);\n    border-radius: var(--rounded-md-2);\n    min-width: 326px;\n  }\n\n  .dev-tools-info-code-block-pre {\n    margin: 0;\n    font-family: var(--font-stack-monospace);\n    font-size: var(--size-12);\n  }\n\n  .dev-tools-info-copy-button {\n    position: absolute;\n\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    right: 8px;\n    top: 8px;\n    padding: 4px;\n    height: var(--size-24);\n    width: var(--size-24);\n    border-radius: var(--rounded-md-2);\n    border: 1px solid var(--color-gray-alpha-400);\n    background: var(--color-background-100);\n  }\n\n  .dev-tools-info-code-block-line {\n    display: block;\n    line-height: 1.5;\n    padding: 0 16px;\n  }\n\n  .dev-tools-info-code-block-line.dev-tools-info-highlight {\n    border-left: 2px solid var(--color-blue-900);\n    background: var(--color-blue-400);\n  }\n\n  .dev-tools-info-code-block-json-key {\n    color: var(--color-syntax-keyword);\n  }\n\n  .dev-tools-info-code-block-json-value {\n    color: var(--color-syntax-link);\n  }\n","",rM,'\n  .nextjs-scroll-fader {\n    --blur: 1px;\n    --stop: 25%;\n    --height: 150px;\n    --color-bg: var(--color-background-100);\n    position: absolute;\n    pointer-events: none;\n    user-select: none;\n    width: 100%;\n    height: var(--height);\n    left: 0;\n    backdrop-filter: blur(var(--blur));\n\n    &[data-side="top"] {\n      top: 0;\n      background: linear-gradient(to top, transparent, var(--color-bg));\n      mask-image: linear-gradient(to bottom, var(--color-bg) var(--stop), transparent);\n    }\n  }\n',rw)})}function rH(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function rV(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return rH(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return rH(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function rB(e,t){var n,r,o,a,i=(0,O.c)(10),l=void 0!==e&&e;i[0]!==t?(n=void 0===t?{}:t,i[0]=t,i[1]=n):n=i[1];var s=n,c=rV((0,C.useState)(l),2),u=c[0],d=c[1],f=rV((0,C.useState)(!1),2),p=f[0],h=f[1],m=s.enterDelay,g=s.exitDelay,v=void 0===m?1:m,y=void 0===g?0:g;return i[2]!==l||i[3]!==v||i[4]!==y?(r=function(){var e,t;return l?(d(!0),v<=0?h(!0):e=setTimeout(function(){h(!0)},v)):(h(!1),y<=0?d(!1):t=setTimeout(function(){d(!1)},y)),function(){clearTimeout(e),clearTimeout(t)}},o=[l,v,y],i[2]=l,i[3]=v,i[4]=y,i[5]=r,i[6]=o):(r=i[5],o=i[6]),(0,C.useEffect)(r,o),i[7]!==u||i[8]!==p?(a={mounted:u,rendered:p},i[7]=u,i[8]=p,i[9]=a):a=i[9],a}function r$(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function rq(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function rW(e){var t,n,r,o,a,i,l,s=(0,O.c)(18),c=e.state,u=e.dispatch,d=e.getSquashedHydrationErrorDetails,f=e.runtimeErrors,p=e.errorCount,h=!!process.env.TURBOPACK;s[0]===Symbol.for("react.memo_cache_sentinel")?(t={exitDelay:200},s[0]=t):t=s[0];var m=rB(c.isErrorOverlayOpen,t),g=m.mounted,v=m.rendered;s[1]!==p||s[2]!==v||s[3]!==c.versionInfo?(n={rendered:v,transitionDurationMs:200,isTurbopack:h,versionInfo:c.versionInfo,errorCount:p},s[1]=p,s[2]=v,s[3]=c.versionInfo,s[4]=n):n=s[4];var y=n;return null!==c.buildError?(s[5]!==y||s[6]!==c.buildError?(r=(0,S.jsx)(nC,rq(r$({},y),{message:c.buildError,rendered:!0})),s[5]=y,s[6]=c.buildError,s[7]=r):r=s[7],r):f.length?g?(s[10]!==u?(i=function(){u({type:Y})},s[10]=u,s[11]=i):i=s[11],s[12]!==y||s[13]!==d||s[14]!==f||s[15]!==c.debugInfo||s[16]!==i?(l=(0,S.jsx)(n4,rq(r$({},y),{debugInfo:c.debugInfo,getSquashedHydrationErrorDetails:d,runtimeErrors:f,onClose:i})),s[12]=y,s[13]=d,s[14]=f,s[15]=c.debugInfo,s[16]=i,s[17]=l):l=s[17],l):(s[9]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)(C.Suspense,{}),s[9]=a):a=s[9],a):(s[8]===Symbol.for("react.memo_cache_sentinel")?(o=(0,S.jsx)(C.Suspense,{}),s[8]=o):o=s[8],o)}function rK(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function rY(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function rG(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){rY(e,t,n[t])})}return e}function rX(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return rK(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return rK(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}var rQ=function(e){var t,n,r=(0,O.c)(4);return e.state.buildError?(r[0]!==e?(t=(0,S.jsx)(r0,rG({},e)),r[0]=e,r[1]=t):t=r[1],t):(r[2]!==e?(n=(0,S.jsx)(rJ,rG({},e)),r[2]=e,r[3]=n):n=r[3],n)},rJ=function(e){var t=e.children,n=e.state,r=e.isAppDir,o=n.errors,a=rX((0,C.useState)({}),2),i=a[0],l=a[1],s=rX((0,C.useMemo)(function(){for(var e=[],t=null,n=0;n<o.length;++n){var r=o[n],a=r.id;if(a in i){e.push(i[a]);continue}t=r;break}return[e,t]},[o,i]),2),c=s[0],u=s[1];return(0,C.useEffect)(function(){if(null!=u){var e,t,n=!0;return(e=u,t=r,nV(function(){var n,r,o;return nq(this,function(a){switch(a.label){case 0:var i,l;return n={id:e.id,runtime:!0,error:e.error,type:e.type},[2,n$(nB({},n),{frames:(l=(i=function(){return nV(function(){return nq(this,function(n){switch(n.label){case 0:return[4,eR(e.frames,nU(e.error),t)];case 1:return[2,n.sent()]}})})()})(),function(){return l})})];case 1:return r=[nB({},n)],o={},[4,eR(e.frames,nU(e.error),t)];case 2:return[2,n$.apply(void 0,r.concat([(o.frames=a.sent(),o)]))];case 3:return[2]}})})()).then(function(e){n&&l(function(t){var n,r;return n=rG({},t),r=null!=(r=rY({},e.id,e))?r:{},Object.getOwnPropertyDescriptors?Object.defineProperties(n,Object.getOwnPropertyDescriptors(r)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(r)).forEach(function(e){Object.defineProperty(n,e,Object.getOwnPropertyDescriptor(r,e))}),n})}),function(){n=!1}}},[u,r]),t({runtimeErrors:c,totalErrorCount:o.length})},r0=function(e){return(0,e.children)({runtimeErrors:[],totalErrorCount:1})};function r1(){var e,t,n=(0,O.c)(4),r=dk(),o=r.shadowRoot,a=r.state;return n[0]!==o||n[1]!==a.scale?(e=function(){(null==o?void 0:o.host)&&o.host.style.setProperty("--nextjs-dev-tools-scale",String(a.scale||1))},t=[o,a.scale],n[0]=o,n[1]=a.scale,n[2]=e,n[3]=t):(e=n[2],t=n[3]),(0,C.useLayoutEffect)(e,t),null}var r2=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-indicator/devtools-indicator.css"),r3={};function r4(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function r5(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function r6(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return r5(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return r5(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function r9(e){var t,n,r,o,a=(0,O.c)(3);return(a[0]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.08889 11.8384L2.62486 12.3024L1.69678 11.3744L2.16082 10.9103L6.07178 6.99937L2.16082 3.08841L1.69678 2.62437L2.62486 1.69629L3.08889 2.16033L6.99986 6.07129L10.9108 2.16033L11.3749 1.69629L12.3029 2.62437L11.8389 3.08841L7.92793 6.99937L11.8389 10.9103L12.3029 11.3744L11.3749 12.3024L10.9108 11.8384L6.99986 7.92744L3.08889 11.8384Z",fill:"currentColor"}),a[0]=r):r=a[0],a[1]!==e)?(o=(0,S.jsx)("svg",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({width:"12",height:"12",viewBox:"0 0 14 14",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),a[1]=e,a[2]=o):o=a[2],o}function r8(e){var t,n,r,o,a=(0,O.c)(3);return(a[0]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.98071 1.125L1.125 3.98071L1.125 8.01929L3.98071 10.875H8.01929L10.875 8.01929V3.98071L8.01929 1.125H3.98071ZM3.82538 0C3.62647 0 3.4357 0.0790176 3.29505 0.21967L0.21967 3.29505C0.0790176 3.4357 0 3.62647 0 3.82538V8.17462C0 8.37353 0.0790178 8.5643 0.21967 8.70495L3.29505 11.7803C3.4357 11.921 3.62647 12 3.82538 12H8.17462C8.37353 12 8.5643 11.921 8.70495 11.7803L11.7803 8.70495C11.921 8.5643 12 8.37353 12 8.17462V3.82538C12 3.62647 11.921 3.4357 11.7803 3.29505L8.70495 0.21967C8.5643 0.0790177 8.37353 0 8.17462 0H3.82538ZM6.5625 2.8125V3.375V6V6.5625H5.4375V6V3.375V2.8125H6.5625ZM6 9C6.41421 9 6.75 8.66421 6.75 8.25C6.75 7.83579 6.41421 7.5 6 7.5C5.58579 7.5 5.25 7.83579 5.25 8.25C5.25 8.66421 5.58579 9 6 9Z",fill:"currentColor"}),a[0]=r):r=a[0],a[1]!==e)?(o=(0,S.jsx)("svg",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({width:"12",height:"12",viewBox:"0 0 12 12",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),n=n={children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),a[1]=e,a[2]=o):o=a[2],o}r3.styleTagTransform=x(),r3.setAttributes=g(),r3.insert=h(),r3.domAPI=f(),r3.insertStyleElement=y(),u()(r2.A,r3),r2.A&&r2.A.locals&&r2.A.locals;var r7=(0,C.createContext)(null),oe=function(){return(0,C.useContext)(r7)};function ot(e){return oA+36/e.scale+9}function on(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function or(){var e,t,n=(e=["\n          [data-indicator-status] {\n            --padding-left: 8px;\n            display: flex;\n            gap: 6px;\n            align-items: center;\n            padding-left: 12px;\n            padding-right: 8px;\n            height: var(--size-32);\n            margin-right: 2px;\n            border-radius: var(--rounded-full);\n            transition: background var(--duration-short) ease;\n            color: white;\n            font-size: var(--size-13);\n            font-weight: 500;\n            white-space: nowrap;\n            border: none;\n            background: transparent;\n            cursor: pointer;\n            outline: none;\n          }\n\n          [data-indicator-status]:focus-visible {\n            outline: 2px solid var(--color-blue-800, #3b82f6);\n            outline-offset: 3px;\n          }\n\n          [data-status-dot] {\n            width: 8px;\n            height: 8px;\n            border-radius: 50%;\n            flex-shrink: 0;\n          }\n\n          [data-status-text-animation] {\n            display: inline-flex;\n            align-items: center;\n            position: relative;\n            overflow: hidden;\n            height: 100%;\n\n            > * {\n              white-space: nowrap;\n              line-height: 1;\n            }\n\n            [data-status-text-enter] {\n              animation: slotMachineEnter 150ms cubic-bezier(0, 0, 0.2, 1)\n                forwards;\n            }\n          }\n\n          [data-status-ellipsis] {\n            display: inline-flex;\n            margin-left: 2px;\n          }\n\n          [data-status-ellipsis] span {\n            animation: ellipsisFade 1.2s infinite;\n            margin: 0 1px;\n          }\n\n          [data-status-ellipsis] span:nth-child(2) {\n            animation-delay: 0.2s;\n          }\n\n          [data-status-ellipsis] span:nth-child(3) {\n            animation-delay: 0.4s;\n          }\n\n          @keyframes ellipsisFade {\n            0%,\n            60%,\n            100% {\n              opacity: 0.2;\n            }\n            30% {\n              opacity: 1;\n            }\n          }\n\n          @keyframes slotMachineEnter {\n            0% {\n              transform: translateY(0.8em);\n              opacity: 0;\n            }\n            50% {\n              opacity: 0.8;\n            }\n            100% {\n              transform: translateY(0);\n              opacity: 1;\n            }\n          }\n        "],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return or=function(){return n},n}var oo=((e={}).None="none",e.Rendering="rendering",e.Compiling="compiling",e.Prerendering="prerendering",e.CacheBypassing="cache-bypassing",e);function oa(e){var t,n,r,o,a,i,l,s,c=(0,O.c)(13),u=e.status,d=e.onClick;c[0]===Symbol.for("react.memo_cache_sentinel")?(on(n={},"none",""),on(n,"cache-bypassing","Cache disabled"),on(n,"prerendering","Prerendering"),on(n,"compiling","Compiling"),on(n,"rendering","Rendering"),t=n,c[0]=t):t=c[0];var f=t;c[1]===Symbol.for("react.memo_cache_sentinel")?(on(o={},"none",""),on(o,"cache-bypassing",""),on(o,"prerendering","#f5a623"),on(o,"compiling","#f5a623"),on(o,"rendering","#50e3c2"),r=o,c[1]=r):r=c[1];var p=r;if("none"===u)return null;c[2]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)("style",{children:eg(or())}),c[2]=a):a=c[2],c[3]!==u?(i=p[u]&&(0,S.jsx)("div",{"data-status-dot":!0,style:{backgroundColor:p[u]}}),c[3]=u,c[4]=i):i=c[4];var h="cache-bypassing"!==u,m=f[u];return c[5]!==u||c[6]!==h||c[7]!==m?(l=(0,S.jsx)(oi,{statusKey:u,showEllipsis:h,children:m},u),c[5]=u,c[6]=h,c[7]=m,c[8]=l):l=c[8],c[9]!==d||c[10]!==i||c[11]!==l?(s=(0,S.jsxs)(S.Fragment,{children:[a,(0,S.jsxs)("button",{"data-indicator-status":!0,"data-nextjs-dev-tools-button":!0,onClick:d,"aria-label":"Open Next.js Dev Tools",children:[i,l]})]}),c[9]=d,c[10]=i,c[11]=l,c[12]=s):s=c[12],s}function oi(e){var t,n,r=(0,O.c)(5),o=e.children,a=e.showEllipsis,i=void 0===a||a;return r[0]!==i?(t=i&&(0,S.jsxs)("span",{"data-status-ellipsis":!0,children:[(0,S.jsx)("span",{children:"."}),(0,S.jsx)("span",{children:"."}),(0,S.jsx)("span",{children:"."})]}),r[0]=i,r[1]=t):t=r[1],r[2]!==t||r[3]!==o?(n=(0,S.jsx)("div",{"data-status-text-animation":!0,children:(0,S.jsxs)("div",{"data-status-text-enter":!0,children:[o,t]})}),r[2]=t,r[3]=o,r[4]=n):n=r[4],n}function ol(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function os(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function oc(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function ou(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}function od(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return ol(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return ol(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function of(){var e,t,n=(e=["\n          [data-next-badge-root] {\n            --timing: cubic-bezier(0.23, 0.88, 0.26, 0.92);\n            --duration-long: 250ms;\n            --color-outer-border: #171717;\n            --color-inner-border: hsla(0, 0%, 100%, 0.14);\n            --color-hover-alpha-subtle: hsla(0, 0%, 100%, 0.13);\n            --color-hover-alpha-error: hsla(0, 0%, 100%, 0.2);\n            --color-hover-alpha-error-2: hsla(0, 0%, 100%, 0.25);\n            --mark-size: calc(var(--size) - var(--size-2) * 2);\n\n            --focus-color: var(--color-blue-800);\n            --focus-ring: 2px solid var(--focus-color);\n\n            &:has([data-next-badge][data-error='true']) {\n              --focus-color: #fff;\n            }\n          }\n\n          [data-disabled-icon] {\n            display: flex;\n            align-items: center;\n            justify-content: center;\n            padding-right: 4px;\n          }\n\n          [data-next-badge] {\n            width: var(--size);\n            height: var(--size);\n            display: flex;\n            align-items: center;\n            position: relative;\n            background: rgba(0, 0, 0, 0.8);\n            box-shadow:\n              0 0 0 1px var(--color-outer-border),\n              inset 0 0 0 1px var(--color-inner-border),\n              0px 16px 32px -8px rgba(0, 0, 0, 0.24);\n            backdrop-filter: blur(48px);\n            border-radius: var(--rounded-full);\n            user-select: none;\n            cursor: pointer;\n            scale: 1;\n            overflow: hidden;\n            will-change: scale, box-shadow, width, background;\n            transition:\n              scale var(--duration-short) var(--timing),\n              width var(--duration-long) var(--timing),\n              box-shadow var(--duration-long) var(--timing),\n              background var(--duration-short) ease;\n\n            &:active[data-error='false'] {\n              scale: 0.95;\n            }\n\n            &[data-animate='true']:not(:hover) {\n              scale: 1.02;\n            }\n\n            &[data-error='false']:has([data-next-mark]:focus-visible) {\n              outline: var(--focus-ring);\n              outline-offset: 3px;\n            }\n\n            &[data-error='true'] {\n              background: #ca2a30;\n              --color-inner-border: #e5484d;\n\n              [data-next-mark] {\n                background: var(--color-hover-alpha-error);\n                outline-offset: 0px;\n\n                &:focus-visible {\n                  outline: var(--focus-ring);\n                  outline-offset: -1px;\n                }\n\n                &:hover {\n                  background: var(--color-hover-alpha-error-2);\n                }\n              }\n            }\n\n            &[data-cache-bypassing='true']:not([data-error='true']) {\n              background: rgba(217, 119, 6, 0.95);\n              --color-inner-border: rgba(245, 158, 11, 0.9);\n\n              [data-issues-open] {\n                color: white;\n              }\n            }\n\n            &[data-error-expanded='false'][data-error='true'] ~ [data-dot] {\n              scale: 1;\n            }\n\n            > div {\n              display: flex;\n            }\n          }\n\n          [data-issues-collapse]:focus-visible {\n            outline: var(--focus-ring);\n          }\n\n          [data-issues]:has([data-issues-open]:focus-visible) {\n            outline: var(--focus-ring);\n            outline-offset: -1px;\n          }\n\n          [data-dot] {\n            content: '';\n            width: var(--size-8);\n            height: var(--size-8);\n            background: #fff;\n            box-shadow: 0 0 0 1px var(--color-outer-border);\n            border-radius: 50%;\n            position: absolute;\n            top: 2px;\n            right: 0px;\n            scale: 0;\n            pointer-events: none;\n            transition: scale 200ms var(--timing);\n            transition-delay: var(--duration-short);\n          }\n\n          [data-issues] {\n            --padding-left: 8px;\n            display: flex;\n            gap: 2px;\n            align-items: center;\n            padding-left: 8px;\n            padding-right: 8px;\n            height: var(--size-32);\n            margin-right: 2px;\n            border-radius: var(--rounded-full);\n            transition: background var(--duration-short) ease;\n\n            &:has([data-issues-open]:hover) {\n              background: var(--color-hover-alpha-error);\n            }\n\n            &:has([data-issues-collapse]) {\n              padding-right: calc(var(--padding-left) / 2);\n            }\n\n            [data-cross] {\n              translate: 0px -1px;\n            }\n          }\n\n          [data-issues-open] {\n            font-size: var(--size-13);\n            color: white;\n            width: fit-content;\n            height: 100%;\n            display: flex;\n            gap: 2px;\n            align-items: center;\n            margin: 0;\n            line-height: var(--size-36);\n            font-weight: 500;\n            z-index: 2;\n            white-space: nowrap;\n\n            &:focus-visible {\n              outline: 0;\n            }\n          }\n\n          [data-issues-collapse] {\n            width: var(--size-24);\n            height: var(--size-24);\n            border-radius: var(--rounded-full);\n            transition: background var(--duration-short) ease;\n\n            &:hover {\n              background: var(--color-hover-alpha-error);\n            }\n          }\n\n          [data-cross] {\n            color: #fff;\n            width: var(--size-12);\n            height: var(--size-12);\n          }\n\n          [data-next-mark] {\n            width: var(--mark-size);\n            height: var(--mark-size);\n            margin: 0 2px;\n            display: flex;\n            align-items: center;\n            border-radius: var(--rounded-full);\n            transition: background var(--duration-long) var(--timing);\n\n            &:focus-visible {\n              outline: 0;\n            }\n\n            &:hover {\n              background: var(--color-hover-alpha-subtle);\n            }\n\n            svg {\n              flex-shrink: 0;\n              width: var(--size-40);\n              height: var(--size-40);\n            }\n          }\n\n          [data-issues-count-animation] {\n            display: grid;\n            place-items: center center;\n            font-variant-numeric: tabular-nums;\n\n            &[data-animate='false'] {\n              [data-issues-count-exit],\n              [data-issues-count-enter] {\n                animation-duration: 0ms;\n              }\n            }\n\n            > * {\n              grid-area: 1 / 1;\n            }\n\n            [data-issues-count-exit] {\n              animation: fadeOut 300ms var(--timing) forwards;\n            }\n\n            [data-issues-count-enter] {\n              animation: fadeIn 300ms var(--timing) forwards;\n            }\n          }\n\n          [data-issues-count-plural] {\n            display: inline-block;\n            &[data-animate='true'] {\n              animation: fadeIn 300ms var(--timing) forwards;\n            }\n          }\n\n          .paused {\n            stroke-dashoffset: 0;\n          }\n\n          @keyframes fadeIn {\n            0% {\n              opacity: 0;\n              filter: blur(2px);\n              transform: translateY(8px);\n            }\n            100% {\n              opacity: 1;\n              filter: blur(0px);\n              transform: translateY(0);\n            }\n          }\n\n          @keyframes fadeOut {\n            0% {\n              opacity: 1;\n              filter: blur(0px);\n              transform: translateY(0);\n            }\n            100% {\n              opacity: 0;\n              transform: translateY(-12px);\n              filter: blur(2px);\n            }\n          }\n\n          @media (prefers-reduced-motion) {\n            [data-issues-count-exit],\n            [data-issues-count-enter],\n            [data-issues-count-plural] {\n              animation-duration: 0ms !important;\n            }\n          }\n        "],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return of=function(){return n},n}function op(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x,w,_,k,j,P,E,T,I,N,L,A,z,R,D=(0,O.c)(54);D[0]!==e?(w=ou(e,["onTriggerClick"]),_=e.onTriggerClick,D[0]=e,D[1]=w,D[2]=_):(w=D[1],_=D[2]);var M=dk(),Z=M.state,F=M.dispatch,U=dl().totalErrorCount,H=36/Z.scale,V=oe(),B=V.panel,$=V.triggerRef,q=V.setPanel,W="panel-selector"===B,G=U>0,X=od((0,C.useState)(G),2),Q=X[0],J=X[1],ee=od((0,C.useState)(G),2),et=ee[0],en=ee[1];et!==G&&(en(G),J(G));var er=od((0,C.useState)(!1),2),eo=er[0],ea=er[1],ei=(t=U,o=(0,O.c)(4),a=150,i=(0,C.useRef)(null),c=(l=(0,C.useState)(!1),s=function(e){if(Array.isArray(e))return e}(l)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(l,2)||function(e,t){if(e){if("string"==typeof e)return r4(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return r4(e,2)}}(l,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}())[0],u=s[1],o[0]!==a||o[1]!==t?(n=function(){if(t>0){var e=i.current?Date.now()-i.current:-1;if(i.current=Date.now(),!(e<=a)){u(!0);var n=window.setTimeout(function(){u(!1)},a);return function(){clearTimeout(n)}}}},r=[t,a],o[0]=a,o[1]=t,o[2]=n,o[3]=r):(n=o[2],r=o[3]),(0,C.useEffect)(n,r),c),el="filling"===Z.cacheIndicator,es="bypass"===Z.cacheIndicator,ec=Z.buildingIndicator||Z.renderingIndicator||el;D[3]===Symbol.for("react.memo_cache_sentinel")?(k={enterDelay:400,exitDelay:500},D[3]=k):k=D[3];var eu=rB(ec,k).rendered,ed=(0,C.useRef)(null),ef=(d=ed,h=(0,O.c)(3),g=(m=r6((0,C.useState)(0),2))[0],v=m[1],h[0]!==d?(f=function(){var e=d.current;if(e){var t=new ResizeObserver(function(e){v(r6(e,1)[0].contentRect.width)});return t.observe(e),function(){return t.disconnect()}}},p=[d],h[0]=d,h[1]=f,h[2]=p):(f=h[1],p=h[2]),(0,C.useEffect)(f,p),g);D[4]!==Z.buildingIndicator||D[5]!==Z.cacheIndicator||D[6]!==Z.renderingIndicator?(y=Z.buildingIndicator,b=Z.renderingIndicator,x=Z.cacheIndicator,j=y?"compiling":"filling"===x?"prerendering":b?"rendering":"none",D[4]=Z.buildingIndicator,D[5]=Z.cacheIndicator,D[6]=Z.renderingIndicator,D[7]=j):j=D[7];var ep=j,eh=eu?ep:oo.None,em=Q||es||eu||Z.disableDevIndicator,ev=0===ef?"auto":ef,ey="".concat(H,"px"),eb=Z.disableDevIndicator&&(!G||eo)?"none":"block";D[8]!==ey||D[9]!==eb?(P={"--size":ey,"--duration-short":"".concat(150,"ms"),display:eb},D[8]=ey,D[9]=eb,D[10]=P):P=D[10];var ex=P;D[11]===Symbol.for("react.memo_cache_sentinel")?(E=(0,S.jsx)("style",{children:eg(of())}),D[11]=E):E=D[11];var ew=G||es?oo.None:ep;return D[12]!==ev?(T={width:ev},D[12]=ev,D[13]=T):T=D[13],D[14]!==w||D[15]!==G||D[16]!==es||D[17]!==W||D[18]!==_||D[19]!==eu||D[20]!==Z.disableDevIndicator||D[21]!==$?(I=!Z.disableDevIndicator&&(0,S.jsx)("button",oc(os({id:"next-logo",ref:$,"data-next-mark":!0,onClick:_,disabled:Z.disableDevIndicator,"aria-haspopup":"menu","aria-expanded":W,"aria-controls":"nextjs-dev-tools-menu","aria-label":"".concat(W?"Close":"Open"," Next.js Dev Tools"),"data-nextjs-dev-tools-button":!0,style:{display:!eu||G||es?"flex":"none"}},w),{children:(0,S.jsx)(og,{})})),D[14]=w,D[15]=G,D[16]=es,D[17]=W,D[18]=_,D[19]=eu,D[20]=Z.disableDevIndicator,D[21]=$,D[22]=I):I=D[22],D[23]!==F||D[24]!==eh||D[25]!==G||D[26]!==es||D[27]!==Q||D[28]!==em||D[29]!==ei||D[30]!==_||D[31]!==q||D[32]!==eu||D[33]!==Z.buildError||D[34]!==Z.disableDevIndicator||D[35]!==Z.isErrorOverlayOpen||D[36]!==U||D[37]!==$?(N=em&&(0,S.jsxs)(S.Fragment,{children:[(Q||Z.disableDevIndicator)&&(0,S.jsxs)("div",{"data-issues":!0,children:[(0,S.jsxs)("button",{"data-issues-open":!0,"aria-label":"Open issues overlay",onClick:function(){Z.isErrorOverlayOpen?F({type:Y}):(F({type:K}),q(null))},children:[Z.disableDevIndicator&&(0,S.jsx)("div",{"data-disabled-icon":!0,children:(0,S.jsx)(r8,{})}),(0,S.jsx)(oh,{animate:ei,"data-issues-count-animation":!0,children:U},U)," ",(0,S.jsxs)("div",{children:["Issue",U>1&&(0,S.jsx)("span",{"aria-hidden":!0,"data-issues-count-plural":!0,"data-animate":ei&&2===U,children:"s"})]})]}),!Z.buildError&&(0,S.jsx)("button",{"data-issues-collapse":!0,"aria-label":"Collapse issues badge",onClick:function(){var e;Z.disableDevIndicator?ea(!0):J(!1),null==(e=$.current)||e.focus()},children:(0,S.jsx)(r9,{"data-cross":!0})})]}),es&&!G&&!Z.disableDevIndicator&&(0,S.jsx)(om,{onTriggerClick:_,triggerRef:$}),eu&&!G&&!es&&!Z.disableDevIndicator&&(0,S.jsx)(oa,{status:eh,onClick:_})]}),D[23]=F,D[24]=eh,D[25]=G,D[26]=es,D[27]=Q,D[28]=em,D[29]=ei,D[30]=_,D[31]=q,D[32]=eu,D[33]=Z.buildError,D[34]=Z.disableDevIndicator,D[35]=Z.isErrorOverlayOpen,D[36]=U,D[37]=$,D[38]=N):N=D[38],D[39]!==I||D[40]!==N?(L=(0,S.jsxs)("div",{ref:ed,children:[I,N]}),D[39]=I,D[40]=N,D[41]=L):L=D[41],D[42]!==G||D[43]!==es||D[44]!==em||D[45]!==ei||D[46]!==L||D[47]!==ew||D[48]!==T?(A=(0,S.jsx)("div",{"data-next-badge":!0,"data-error":G,"data-error-expanded":em,"data-status":ew,"data-cache-bypassing":es,"data-animate":ei,style:T,children:L}),D[42]=G,D[43]=es,D[44]=em,D[45]=ei,D[46]=L,D[47]=ew,D[48]=T,D[49]=A):A=D[49],D[50]===Symbol.for("react.memo_cache_sentinel")?(z=(0,S.jsx)("div",{"aria-hidden":!0,"data-dot":!0}),D[50]=z):z=D[50],D[51]!==A||D[52]!==ex?(R=(0,S.jsxs)("div",{"data-next-badge-root":!0,style:ex,children:[E,A,z]}),D[51]=A,D[52]=ex,D[53]=R):R=D[53],R}function oh(e){var t,n,r,o,a,i,l=(0,O.c)(13);l[0]!==e?(n=ou(e,["children","animate"]),t=e.children,r=e.animate,l[0]=e,l[1]=t,l[2]=n,l[3]=r):(t=l[1],n=l[2],r=l[3]);var s=void 0===r||r,c=t-1;return l[4]!==c?(o=(0,S.jsx)("div",{"aria-hidden":!0,"data-issues-count-exit":!0,children:c}),l[4]=c,l[5]=o):o=l[5],l[6]!==t?(a=(0,S.jsx)("div",{"data-issues-count":!0,"data-issues-count-enter":!0,children:t}),l[6]=t,l[7]=a):a=l[7],l[8]!==s||l[9]!==n||l[10]!==o||l[11]!==a?(i=(0,S.jsxs)("div",oc(os({},n),{"data-animate":s,children:[o,a]})),l[8]=s,l[9]=n,l[10]=o,l[11]=a,l[12]=i):i=l[12],i}function om(e){var t,n,r,o,a,i=(0,O.c)(10),l=e.onTriggerClick,s=e.triggerRef,c=od((0,C.useState)(!1),2),u=c[0],d=c[1];return u?null:(i[0]!==l?(t=(0,S.jsx)("button",{"data-issues-open":!0,"data-nextjs-dev-tools-button":!0,"aria-label":"Open Next.js Dev Tools",onClick:l,children:"Cache disabled"}),i[0]=l,i[1]=t):t=i[1],i[2]!==s?(n=function(){var e;d(!0),null==(e=s.current)||e.focus()},i[2]=s,i[3]=n):n=i[3],i[4]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsx)(r9,{"data-cross":!0}),i[4]=r):r=i[4],i[5]!==n?(o=(0,S.jsx)("button",{"data-issues-collapse":!0,"aria-label":"Collapse cache bypass badge",onClick:n,children:r}),i[5]=n,i[6]=o):o=i[6],i[7]!==t||i[8]!==o?(a=(0,S.jsxs)("div",{"data-issues":!0,"data-cache-bypass-badge":!0,children:[t,o]}),i[7]=t,i[8]=o,i[9]=a):a=i[9],a)}function og(){var e,t,n,r,o=(0,O.c)(4);return o[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsxs)("g",{transform:"translate(8.5, 13)",children:[(0,S.jsx)("path",{className:"paused",d:"M13.3 15.2 L2.34 1 V12.6",fill:"none",stroke:"url(#next_logo_paint0_linear_1357_10853)",strokeWidth:"1.86",mask:"url(#next_logo_mask0)",strokeDasharray:"29.6",strokeDashoffset:"29.6"}),(0,S.jsx)("path",{className:"paused",d:"M11.825 1.5 V13.1",strokeWidth:"1.86",stroke:"url(#next_logo_paint1_linear_1357_10853)",strokeDasharray:"11.6",strokeDashoffset:"11.6"})]}),o[0]=e):e=o[0],o[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsxs)("linearGradient",{id:"next_logo_paint0_linear_1357_10853",x1:"9.95555",y1:"11.1226",x2:"15.4778",y2:"17.9671",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{stopColor:"white"}),(0,S.jsx)("stop",{offset:"0.604072",stopColor:"white",stopOpacity:"0"}),(0,S.jsx)("stop",{offset:"1",stopColor:"white",stopOpacity:"0"})]}),o[1]=t):t=o[1],o[2]===Symbol.for("react.memo_cache_sentinel")?(n=(0,S.jsxs)("linearGradient",{id:"next_logo_paint1_linear_1357_10853",x1:"11.8222",y1:"1.40039",x2:"11.791",y2:"9.62542",gradientUnits:"userSpaceOnUse",children:[(0,S.jsx)("stop",{stopColor:"white"}),(0,S.jsx)("stop",{offset:"1",stopColor:"white",stopOpacity:"0"})]}),o[2]=n):n=o[2],o[3]===Symbol.for("react.memo_cache_sentinel")?(r=(0,S.jsxs)("svg",{width:"40",height:"40",viewBox:"0 0 40 40",fill:"none",children:[e,(0,S.jsxs)("defs",{children:[t,n,(0,S.jsxs)("mask",{id:"next_logo_mask0",children:[(0,S.jsx)("rect",{width:"100%",height:"100%",fill:"white"}),(0,S.jsx)("rect",{width:"5",height:"1.5",fill:"black"})]})]})]}),o[3]=r):r=o[3],r}var ov=C.forwardRef(function(e,t){var n,r,o,a,i,l,s,c,u,d=(0,O.c)(15);return(d[0]!==e?(l=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["onClick","children","className"]),i=e.onClick,o=e.children,a=e.className,d[0]=e,d[1]=o,d[2]=a,d[3]=i,d[4]=l):(o=d[1],a=d[2],i=d[3],l=d[4]),d[5]!==i?(s=function(e){return e.target.closest("a")||e.preventDefault(),null==i?void 0:i()},d[5]=i,d[6]=s):s=d[6],d[7]!==a?(c=e9("nextjs-toast",a),d[7]=a,d[8]=c):c=d[8],d[9]!==o||d[10]!==l||d[11]!==t||d[12]!==s||d[13]!==c)?(u=(0,S.jsx)("div",(n=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},l),r=r={ref:t,onClick:s,className:c,children:o},Object.getOwnPropertyDescriptors?Object.defineProperties(n,Object.getOwnPropertyDescriptors(r)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(r)).forEach(function(e){Object.defineProperty(n,e,Object.getOwnPropertyDescriptor(r,e))}),n)),d[9]=o,d[10]=l,d[11]=t,d[12]=s,d[13]=c,d[14]=u):u=d[14],u});function oy(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}var ob=(0,C.createContext)(null);function ox(e){var t=e.children,n=e.disabled,r=void 0!==n&&n,o=(0,C.useRef)(new Set),a=(0,C.useCallback)(function(e){o.current.add(e)},[]),i=(0,C.useCallback)(function(e){o.current.delete(e)},[]),l=(0,C.useMemo)(function(){return{register:a,unregister:i,handles:o.current,disabled:r}},[a,i,r]);return(0,S.jsx)(ob.Provider,{value:l,children:t})}function ow(){return(0,C.useContext)(ob)}function o_(e){var t,n,r,o,a,i,l,s,c,u,d,f=(0,O.c)(19);f[0]!==e?(o=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["children","ref"]),r=e.children,a=e.ref,f[0]=e,f[1]=r,f[2]=o,f[3]=a):(r=f[1],o=f[2],a=f[3]);var p=(0,C.useRef)(null),h=ow();f[4]!==a?(i=function(e){if(p.current=null!=e?e:null,"function"==typeof a)a(e);else{var t;a&&(void 0===a?"undefined":(t=a)&&"undefined"!=typeof Symbol&&t.constructor===Symbol?"symbol":typeof t)=="object"&&(a.current=e)}},f[4]=a,f[5]=i):i=f[5];var m=i;f[6]!==h?(l=function(){if(h&&p.current&&!h.disabled){var e=p.current;return h.register(e),function(){return h.unregister(e)}}},s=[h],f[6]=h,f[7]=l,f[8]=s):(l=f[7],s=f[8]),(0,C.useEffect)(l,s);var g=(null==h?void 0:h.disabled)?"default":"grab";return(f[9]!==o.style?(c=o.style||{},f[9]=o.style,f[10]=c):c=f[10],f[11]!==g||f[12]!==c?(u=oy({cursor:g},c),f[11]=g,f[12]=c,f[13]=u):u=f[13],f[14]!==r||f[15]!==o||f[16]!==m||f[17]!==u)?(d=(0,S.jsx)("div",(t=oy({ref:m},o),n=n={style:u,children:r},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),f[14]=r,f[15]=o,f[16]=m,f[17]=u,f[18]=d):d=f[18],d}function ok(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function oj(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function oS(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function oO(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}function oC(e){return function(e){if(Array.isArray(e))return ok(e)}(e)||function(e){if("undefined"!=typeof Symbol&&null!=e[Symbol.iterator]||null!=e["@@iterator"])return Array.from(e)}(e)||oP(e)||function(){throw TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function oP(e,t){if(e){if("string"==typeof e)return ok(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return ok(e,t)}}function oE(e){var t,n,r,o,a,i,l,s,c,u,d,f,p=(0,O.c)(18);p[0]!==e?(s=oO(e,["children","padding","position","setPosition","onDragStart","dragHandleSelector","disableDrag","avoidZone"]),r=e.children,l=e.padding,o=e.position,c=e.setPosition,i=e.onDragStart,a=e.dragHandleSelector,u=e.disableDrag,n=e.avoidZone,p[0]=e,p[1]=n,p[2]=r,p[3]=o,p[4]=a,p[5]=i,p[6]=l,p[7]=s,p[8]=c,p[9]=u):(n=p[1],r=p[2],o=p[3],a=p[4],i=p[5],l=p[6],s=p[7],c=p[8],u=p[9]);var h=function(e){var t=(0,C.useRef)(null),n=(0,C.useRef)({state:"idle"}),r=(0,C.useRef)(null),o=(0,C.useRef)({x:0,y:0}),a=(0,C.useRef)({x:0,y:0}),i=(0,C.useRef)(0),l=(0,C.useRef)([]),s=(0,C.useCallback)(function(){var e,o;"drag"===n.current.state&&(null==(o=t.current)||o.releasePointerCapture(n.current.pointerId)),n.current="drag"===n.current.state?{state:"drag-end"}:{state:"idle"},null!==r.current&&(r.current(),r.current=null),l.current=[],null==(e=t.current)||e.classList.remove("dev-tools-grabbing"),document.body.style.removeProperty("user-select"),document.body.style.removeProperty("-webkit-user-select")},[]);function c(e){t.current&&(a.current=e,t.current.style.translate="".concat(e.x,"px ").concat(e.y,"px"))}function u(n){var r=t.current;null!==r&&(r.style.transition="translate 491.22ms var(--timing-bounce)",r.addEventListener("transitionend",function t(o){if("translate"===o.propertyName){var i;null==(i=e.onAnimationEnd)||i.call(e,n),a.current={x:0,y:0},r.style.transition="",r.removeEventListener("transitionend",t)}}),c(n.translation))}function d(e){if("drag-end"===n.current.state){var r;e.preventDefault(),e.stopPropagation(),n.current={state:"idle"},null==(r=t.current)||r.removeEventListener("click",d)}}function f(r){if("press"===n.current.state){var s,u,d,f,p=r.clientX-o.current.x,h=r.clientY-o.current.y;Math.sqrt(p*p+h*h)>=e.threshold&&(n.current={state:"drag",pointerId:r.pointerId},null==(u=t.current)||u.setPointerCapture(r.pointerId),null==(d=t.current)||d.classList.add("dev-tools-grabbing"),document.body.style.userSelect="none",document.body.style.webkitUserSelect="none",null==(f=e.onDragStart)||f.call(e))}if("drag"===n.current.state){var m={x:r.clientX,y:r.clientY},g=m.x-o.current.x,v=m.y-o.current.y;o.current=m,c({x:a.current.x+g,y:a.current.y+v});var y=Date.now();y-i.current>=10&&(l.current=oC(l.current.slice(-5)).concat([{position:m,timestamp:y}])),i.current=y,null==(s=e.onDrag)||s.call(e,a.current)}}function p(){var t,n=function(e){if(e.length<2)return{x:0,y:0};var t=e[0],n=e[e.length-1],r=n.timestamp-t.timestamp;return 0===r?{x:0,y:0}:{x:1e3*((n.position.x-t.position.x)/r),y:1e3*((n.position.y-t.position.y)/r)}}(l.current);s(),null==(t=e.onDragEnd)||t.call(e,a.current,n)}return(0,C.useLayoutEffect)(function(){e.disabled&&s()},[s,e.disabled]),e.disabled?{ref:t,animate:u}:{ref:t,onPointerDown:function(a){var i;0!==a.button||function(n){if(!n||!t.current)return!0;if(e.handles&&e.handles.size>0){for(var r=n;r&&r!==t.current;){if(e.handles.has(r))return!0;r=r.parentElement}return!1}return!e.dragHandleSelector||null!==n.closest(e.dragHandleSelector)}(a.target)&&(o.current={x:a.clientX,y:a.clientY},n.current={state:"press"},window.addEventListener("pointermove",f),window.addEventListener("pointerup",p),null!==r.current&&(r.current(),r.current=null),r.current=function(){window.removeEventListener("pointermove",f),window.removeEventListener("pointerup",p)},null==(i=t.current)||i.addEventListener("click",d))},animate:u}}({disabled:void 0!==u&&u,handles:null==(t=ow())?void 0:t.handles,threshold:5,onDragStart:i,onDragEnd:function(e,t){var r,a,i,s,c,u,d,f,p,h,v,y,b,x,w,_,k,j;if(0===Math.sqrt(e.x*e.x+e.y*e.y)){null==(r=m.current)||r.style.removeProperty("translate");return}g((b=(a={x:e.x+oI(t.x),y:e.y+oI(t.y)}).x,x=a.y,_=Object.entries(w=(c=2*l,u=(null==(i=m.current)?void 0:i.offsetWidth)||0,d=(null==(s=m.current)?void 0:s.offsetHeight)||0,f=window.innerWidth-document.documentElement.clientWidth,h=(p=function(e){var t=e.includes("right"),r=e.includes("bottom"),o=t?window.innerWidth-f-c-u:0,a=r?window.innerHeight-c-d:0;if(n&&n.corner===e){var i=n.square+n.padding;r?a-=i:a+=i}return{x:o,y:a}})(o),{"top-left":(v=function(e){return{x:e.x-h.x,y:e.y-h.y}})(p("top-left")),"top-right":v(p("top-right")),"bottom-left":v(p("bottom-left")),"bottom-right":v(p("bottom-right"))})).map(function(e){var t,n=function(e){if(Array.isArray(e))return e}(t=e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||oP(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}(),r=n[0],o=n[1];return{key:r,distance:Math.sqrt(Math.pow(b-o.x,2)+Math.pow(x-o.y,2))}}),k=(y=Math).min.apply(y,oC(_.map(oT))),(j=_.find(function(e){return e.distance===k}))?{translation:w[j.key],corner:j.key}:{corner:o,translation:w[o]}))},onAnimationEnd:function(e){var t=e.corner;setTimeout(function(){var e;null==(e=m.current)||e.style.removeProperty("translate"),c(t)})},dragHandleSelector:a}),m=h.ref,g=h.animate,v=oO(h,["ref","animate"]);return p[10]!==s.style?(d=oj({touchAction:"none",userSelect:"none",WebkitUserSelect:"none"},s.style),p[10]=s.style,p[11]=d):d=p[11],p[12]!==r||p[13]!==v||p[14]!==s||p[15]!==m||p[16]!==d?(f=(0,S.jsx)("div",oS(oj(oS(oj({},s),{ref:m}),v),{style:d,children:r})),p[12]=r,p[13]=v,p[14]=s,p[15]=m,p[16]=d,p[17]=f):f=p[17],f}function oT(e){return e.distance}function oI(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:.999;return e/1e3*t/(1-t)}function oN(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function oL(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var oA=20;function oz(){var e,t,n,r,o,a,i,l,s=(0,O.c)(20),c=dk(),u=c.state,d=c.dispatch,f=oe(),p=f.panel,h=f.setPanel,m=f.setSelectedIndex,g=oR();s[0]!==u.devToolsPosition?(t=u.devToolsPosition.split("-",2),s[0]=u.devToolsPosition,s[1]=t):t=s[1];var v=function(e){if(Array.isArray(e))return e}(e=t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,2)||function(e,t){if(e){if("string"==typeof e)return oN(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return oN(e,2)}}(e,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}(),y=v[0],b=v[1];s[2]!==b||s[3]!==y?(oL(r={"--animate-out-duration-ms":"".concat(200,"ms"),"--animate-out-timing-function":nc,boxShadow:"none"},y,"".concat(oA,"px")),oL(r,b,"".concat(oA,"px")),n=r,s[2]=b,s[3]=y,s[4]=n):n=s[4];var x=n,w=null!==p;return s[5]!==d||s[6]!==g?(o=function(e){d({type:et,devToolsPosition:e}),rI({devToolsPosition:e}),g(e)},s[5]=d,s[6]=g,s[7]=o):o=s[7],s[8]!==p||s[9]!==h||s[10]!==m?(a=(0,S.jsx)(op,{onTriggerClick:function(){var e="panel-selector"===p?null:"panel-selector";if(h(e),!e)return void m(-1)}}),s[8]=p,s[9]=h,s[10]=m,s[11]=a):a=s[11],s[12]!==u.devToolsPosition||s[13]!==w||s[14]!==o||s[15]!==a?(i=(0,S.jsx)(oE,{disableDrag:w,padding:oA,position:u.devToolsPosition,setPosition:o,children:a}),s[12]=u.devToolsPosition,s[13]=w,s[14]=o,s[15]=a,s[16]=i):i=s[16],s[17]!==x||s[18]!==i?(l=(0,S.jsx)(ov,{id:"devtools-indicator","data-nextjs-toast":!0,style:x,children:i}),s[17]=x,s[18]=i,s[19]=l):l=s[19],l}var oR=function(){var e,t=(0,O.c)(3),n=dk(),r=n.state,o=n.dispatch;return t[0]!==o||t[1]!==r.devToolsPanelPosition?(e=function(e){o({type:en,devToolsPanelPosition:e,key:es});var t=Object.keys(r.devToolsPanelPosition).filter(oD),n=oL({},es,e);t.forEach(function(t){o({type:en,devToolsPanelPosition:e,key:t}),n[t]=e}),rI({devToolsPanelPosition:n})},t[0]=o,t[1]=r.devToolsPanelPosition,t[2]=e):e=t[2],e};function oD(e){return e.startsWith(ea)}function oM(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function oZ(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function oF(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){oZ(e,t,n[t])})}return e}function oU(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function oH(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return oM(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return oM(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}var oV=(0,C.createContext)({});function oB(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h=(0,O.c)(37);h[0]!==e?(a=function(e,t){if(null==e)return{};var n,r,o=function(e,t){if(null==e)return{};var n,r,o={},a=Object.keys(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],!(t.indexOf(n)>=0)&&Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}(e,["index","label","value","onClick","href"]),n=e.index,r=e.label,i=e.value,o=e.onClick,t=e.href,h[0]=e,h[1]=t,h[2]=n,h[3]=r,h[4]=o,h[5]=a,h[6]=i):(t=h[1],n=h[2],r=h[3],o=h[4],a=h[5],i=h[6]);var m="function"==typeof o||"string"==typeof t,g=(0,C.useContext)(oV),v=g.closeMenu,y=g.selectedIndex,b=g.setSelectedIndex,x=y===n;h[7]!==v||h[8]!==t||h[9]!==m||h[10]!==o?(l=function(){m&&(null==o||o(),null==v||v(),t&&window.open(t,"_blank","noopener, noreferrer"))},h[7]=v,h[8]=t,h[9]=m,h[10]=o,h[11]=l):l=h[11];var w=l;h[12]!==n||h[13]!==m||h[14]!==y||h[15]!==b?(s=function(){m&&void 0!==n&&y!==n&&b(n)},h[12]=n,h[13]=m,h[14]=y,h[15]=b,h[16]=s):s=h[16],h[17]!==b?(c=function(){return b(-1)},h[17]=b,h[18]=c):c=h[18],h[19]!==w?(u=function(e){("Enter"===e.key||" "===e.key)&&w()},h[19]=w,h[20]=u):u=h[20];var _=m?"menuitem":void 0,k=x?0:-1;return h[21]!==r?(d=(0,S.jsx)("span",{className:"dev-tools-indicator-label",children:r}),h[21]=r,h[22]=d):d=h[22],h[23]!==i?(f=(0,S.jsx)("span",{className:"dev-tools-indicator-value",children:i}),h[23]=i,h[24]=f):f=h[24],h[25]!==w||h[26]!==n||h[27]!==a||h[28]!==x||h[29]!==s||h[30]!==c||h[31]!==u||h[32]!==_||h[33]!==k||h[34]!==d||h[35]!==f?(p=(0,S.jsxs)("div",oU(oF({className:"dev-tools-indicator-item","data-index":n,"data-selected":x,onClick:w,onMouseMove:s,onMouseLeave:c,onKeyDown:u,role:_,tabIndex:k},a),{children:[d,f]})),h[25]=w,h[26]=n,h[27]=a,h[28]=x,h[29]=s,h[30]=c,h[31]=u,h[32]=_,h[33]=k,h[34]=d,h[35]=f,h[36]=p):p=h[36],p}var o$=function(e){var t,n=e.closeOnClickOutside,r=void 0===n||n,o=e.items,a=dk().state,i=oe(),l=i.setPanel,s=i.triggerRef,c=i.setSelectedIndex,u=i.selectedIndex,d=u7().mounted,f=oH(a.devToolsPosition.split("-",2),2),p=f[0],h=f[1],m=(0,C.useRef)(null);ns(m,s,r&&d,function(e){switch(e){case"escape":l(null),c(-1);return;case"outside":if(!r)return;l(null),c(-1);return;default:return null}});var g=(0,C.useEffectEvent)(function(){oY({index:-1===u?"first":u,menuRef:m,setSelectedIndex:c})});(0,C.useLayoutEffect)(function(){var e;null==(e=m.current)||e.focus(),g()},[]);var v=ot(a),y=oH(a.devToolsPosition.split("-",2),2),b=y[0],x=y[1],w=p===b&&h===x?v:oA,_=(oZ(t={},p,"".concat(w,"px")),oZ(t,h,"".concat(oA,"px")),oZ(t,"top"===p?"bottom":"top","auto"),oZ(t,"left"===h?"right":"left","auto"),t),k=o.filter(function(e){return!!e}),j=k.filter(function(e){return!e.footer}),O=k.filter(function(e){return e.footer});return(0,S.jsx)("div",{ref:m,onKeyDown:function(e){e.preventDefault();var t=k.filter(function(e){return e.onClick}).length;switch(e.key){case"ArrowDown":oY({index:u>=t-1?0:u+1,menuRef:m,setSelectedIndex:c});break;case"ArrowUp":oY({index:u<=0?t-1:u-1,menuRef:m,setSelectedIndex:c});break;case"Home":oY({index:"first",menuRef:m,setSelectedIndex:c});break;case"End":oY({index:"last",menuRef:m,setSelectedIndex:c});break;case"n":e.ctrlKey&&oY({index:u>=t-1?0:u+1,menuRef:m,setSelectedIndex:c});break;case"p":e.ctrlKey&&oY({index:u<=0?t-1:u-1,menuRef:m,setSelectedIndex:c})}},id:"nextjs-dev-tools-menu",role:"menu",dir:"ltr","aria-orientation":"vertical","aria-label":"Next.js Dev Tools Items",tabIndex:-1,style:oF({outline:0,WebkitFontSmoothing:"antialiased",display:"flex",flexDirection:"column",alignItems:"flex-start",background:"var(--color-background-100)",backgroundClip:"padding-box",boxShadow:"var(--shadow-menu)",borderRadius:"var(--rounded-xl)",position:"fixed",fontFamily:"var(--font-stack-sans)",zIndex:"var(--top-z-index)",overflow:"hidden",opacity:1,minWidth:"248px",transition:"opacity var(--animate-out-duration-ms) var(--animate-out-timing-function)",border:"1px solid var(--color-gray-alpha-400)"},_),children:(0,S.jsxs)(oV,{value:{selectedIndex:u,setSelectedIndex:c},children:[(0,S.jsx)("div",{style:{padding:"6px",width:"100%"},children:j.map(function(e,t){return(0,S.jsx)(oB,oF({title:e.title,label:e.label,value:e.value,onClick:e.onClick,index:e.onClick?oq(j,t):void 0},e.attributes),e.label)})}),(0,S.jsx)("div",{className:"dev-tools-indicator-footer",children:O.map(function(e,t){var n;return(0,S.jsx)(oB,oU(oF({title:e.title,label:e.label,value:e.value,onClick:e.onClick},e.attributes),{index:e.onClick?oq(O,t)+(n=j).filter(function(e){return e.onClick}).length:void 0}),e.label)})})]})})};function oq(e,t){for(var n=0,r=0;r<=t&&r<e.length;r++)if(e[r].onClick){if(r===t)return n;n++}return n}function oW(e){var t,n,r=(0,O.c)(4),o=e.children,a=o>0;return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("span",{className:"dev-tools-indicator-issue-count-indicator"}),r[0]=t):t=r[0],r[1]!==o||r[2]!==a?(n=(0,S.jsxs)("span",{className:"dev-tools-indicator-issue-count","data-has-issues":a,children:[t,o]}),r[1]=o,r[2]=a,r[3]=n):n=r[3],n}function oK(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",children:(0,S.jsx)("path",{fill:"#666",fillRule:"evenodd",clipRule:"evenodd",d:"M5.50011 1.93945L6.03044 2.46978L10.8537 7.293C11.2442 7.68353 11.2442 8.31669 10.8537 8.70722L6.03044 13.5304L5.50011 14.0608L4.43945 13.0001L4.96978 12.4698L9.43945 8.00011L4.96978 3.53044L4.43945 3.00011L5.50011 1.93945Z"})}),t[0]=e):e=t[0],e}function oY(e){var t,n=e.index,r=e.menuRef,o=e.setSelectedIndex;if("first"===n)return void setTimeout(function(){var e,t=null==(e=r.current)?void 0:e.querySelectorAll('[role="menuitem"]');t&&oY({index:Number(t[0].getAttribute("data-index")),menuRef:r,setSelectedIndex:o})});if("last"===n)return void setTimeout(function(){var e,t=null==(e=r.current)?void 0:e.querySelectorAll('[role="menuitem"]');t&&oY({index:t.length-1,menuRef:r,setSelectedIndex:o})});var a=null==(t=r.current)?void 0:t.querySelector('[data-index="'.concat(n,'"]'));a&&(o(n),null==a||a.focus())}function oG(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}var oX=(0,C.createContext)(null),oQ=function(e){var t=.95*window.innerWidth,n=.95*window.innerHeight;return{width:Math.min(t,Math.max(e.minWidth,e.width)),height:Math.min(n,Math.max(e.minHeight,e.height))}},oJ=function(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m=(0,O.c)(34),g=e.value,v=e.children,y=null!=(o=g.minWidth)?o:100,b=null!=(a=g.minHeight)?a:80,x=g.maxWidth,w=g.maxHeight,_=(t=(0,C.useState)(null),function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return oG(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return oG(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),k=_[0],j=_[1],P=null!=(i=g.storageKey)?i:el,E=g.resizeRef;m[0]!==k||m[1]!==b||m[2]!==y||m[3]!==E||m[4]!==P||m[5]!==g.devToolsPanelSize?(l=function(){if(E.current&&null===k){var e=g.devToolsPanelSize[P];if(e){var t,n,r=oQ((t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},e),n=n={minWidth:null!=y?y:100,minHeight:null!=b?b:80},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t)),o=r.height,a=r.width;return E.current.style.width="".concat(a,"px"),E.current.style.height="".concat(o,"px"),!0}}},m[0]=k,m[1]=b,m[2]=y,m[3]=E,m[4]=P,m[5]=g.devToolsPanelSize,m[6]=l):l=m[6];var T=l;m[7]!==T||m[8]!==b||m[9]!==y||m[10]!==E||m[11]!==g.initialSize?(s=function(){var e;if(!T()&&E.current&&(null==(e=g.initialSize)?void 0:e.height)&&g.initialSize.width){var t=oQ({height:g.initialSize.height,width:g.initialSize.width,minWidth:null!=y?y:100,minHeight:null!=b?b:80}),n=t.height,r=t.width;E.current.style.width="".concat(r,"px"),E.current.style.height="".concat(n,"px")}},m[7]=T,m[8]=b,m[9]=y,m[10]=E,m[11]=g.initialSize,m[12]=s):s=m[12];var I=(0,C.useEffectEvent)(s);m[13]!==I?(c=function(){I()},m[13]=I,m[14]=c):c=m[14],m[15]===Symbol.for("react.memo_cache_sentinel")?(u=[],m[15]=u):u=m[15],(0,C.useLayoutEffect)(c,u),m[16]!==T?(d=function(){return window.addEventListener("resize",T),function(){return window.removeEventListener("resize",T)}},m[16]=T,m[17]=d):d=m[17];var N=null==(n=g.initialSize)?void 0:n.height,L=null==(r=g.initialSize)?void 0:r.width;return m[18]!==T||m[19]!==N||m[20]!==L||m[21]!==g.resizeRef?(f=[T,N,L,g.resizeRef],m[18]=T,m[19]=N,m[20]=L,m[21]=g.resizeRef,m[22]=f):f=m[22],(0,C.useLayoutEffect)(d,f),m[23]!==k||m[24]!==w||m[25]!==x||m[26]!==b||m[27]!==y||m[28]!==P||m[29]!==g.resizeRef?(p={resizeRef:g.resizeRef,minWidth:y,minHeight:b,maxWidth:x,maxHeight:w,draggingDirection:k,setDraggingDirection:j,storageKey:P},m[23]=k,m[24]=w,m[25]=x,m[26]=b,m[27]=y,m[28]=P,m[29]=g.resizeRef,m[30]=p):p=m[30],m[31]!==v||m[32]!==p?(h=(0,S.jsx)(oX.Provider,{value:p,children:v}),m[31]=v,m[32]=p,m[33]=h):h=m[33],h},o0=function(){var e=(0,C.useContext)(oX);if(!e)throw Error("useResize must be used within a Resize provider");return e},o1=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/devtools-panel/resize/resize-handle.css"),o2={};function o3(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}o2.styleTagTransform=x(),o2.setAttributes=g(),o2.insert=h(),o2.domAPI=f(),o2.insertStyleElement=y(),u()(o1.A,o2),o1.A&&o1.A.locals&&o1.A.locals;var o4=function(e){var t,n,r,o,a,i,l,s,c,u=(0,O.c)(31),d=e.direction,f=e.position,p=o0(),h=p.resizeRef,m=p.minWidth,g=p.minHeight,v=p.maxWidth,y=p.maxHeight,b=p.storageKey,x=p.draggingDirection,w=p.setDraggingDirection;u[0]===Symbol.for("react.memo_cache_sentinel")?(n={top:0,right:0,bottom:0,left:0},u[0]=n):n=u[0];var _=(t=(0,C.useState)(n),function(e){if(Array.isArray(e))return e}(t)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(t,2)||function(e,t){if(e){if("string"==typeof e)return o3(e,2);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return o3(e,2)}}(t,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),k=_[0],j=_[1];u[1]!==h?(r=function(){if(h.current){var e=h.current,t=window.getComputedStyle(e);j({top:parseFloat(t.borderTopWidth)||0,right:parseFloat(t.borderRightWidth)||0,bottom:parseFloat(t.borderBottomWidth)||0,left:parseFloat(t.borderLeftWidth)||0})}},o=[h],u[1]=h,u[2]=r,u[3]=o):(r=u[2],o=u[3]),(0,C.useLayoutEffect)(r,o),u[4]!==d||u[5]!==y||u[6]!==v||u[7]!==g||u[8]!==m||u[9]!==h||u[10]!==w||u[11]!==b?(a=function(e){if(e.preventDefault(),h.current){w(d);var t=h.current,n=t.getBoundingClientRect(),r=e.clientX,o=e.clientY,a=function(e){var a=o5(d,e.clientX-r,e.clientY-o,n,m,g,v,y),i=a.newWidth,l=a.newHeight;void 0!==i&&(t.style.width="".concat(i,"px")),void 0!==l&&(t.style.height="".concat(l,"px"))},i=function(){if(w(null),document.removeEventListener("mousemove",a),document.removeEventListener("mouseup",i),h.current){var e,t,n,r=h.current.getBoundingClientRect(),o=r.width,l=r.height;rI({devToolsPanelSize:(e={},t=b,n={width:o,height:l},t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e)})}};document.addEventListener("mousemove",a),document.addEventListener("mouseup",i)}},u[4]=d,u[5]=y,u[6]=v,u[7]=g,u[8]=m,u[9]=h,u[10]=w,u[11]=b,u[12]=a):a=u[12];var P=a;if(!(!f.split("-").includes(d)&&(!d.includes("-")||d===o6(f))))return null;var E=k.left+k.right,T=k.top+k.bottom;u[13]!==d?(i=d.includes("-"),u[13]=d,u[14]=i):i=u[14];var I=i,N="resize-container ".concat(d," ").concat(x&&x!==d?"no-hover":"");return u[15]!==P||u[16]!==N?(l=(0,S.jsx)("div",{className:N,onMouseDown:P}),u[15]=P,u[16]=N,u[17]=l):l=u[17],u[18]!==k.bottom||u[19]!==k.left||u[20]!==k.right||u[21]!==k.top||u[22]!==d||u[23]!==x||u[24]!==I||u[25]!==E||u[26]!==T?(s=!I&&(0,S.jsx)("div",{className:"resize-line ".concat(d," ").concat(x===d?"dragging":""),style:{"--border-horizontal":"".concat(E,"px"),"--border-vertical":"".concat(T,"px"),"--border-top":"".concat(k.top,"px"),"--border-right":"".concat(k.right,"px"),"--border-bottom":"".concat(k.bottom,"px"),"--border-left":"".concat(k.left,"px")}}),u[18]=k.bottom,u[19]=k.left,u[20]=k.right,u[21]=k.top,u[22]=d,u[23]=x,u[24]=I,u[25]=E,u[26]=T,u[27]=s):s=u[27],u[28]!==l||u[29]!==s?(c=(0,S.jsxs)(S.Fragment,{children:[l,s]}),u[28]=l,u[29]=s,u[30]=c):c=u[30],c},o5=function(e,t,n,r,o,a,i,l){var s=null!=i?i:.95*window.innerWidth,c=null!=l?l:.95*window.innerHeight;switch(e){case"right":return{newWidth:Math.min(s,Math.max(o,r.width+t)),newHeight:r.height};case"left":return{newWidth:Math.min(s,Math.max(o,r.width-t)),newHeight:r.height};case"bottom":return{newWidth:r.width,newHeight:Math.min(c,Math.max(a,r.height+n))};case"top":return{newWidth:r.width,newHeight:Math.min(c,Math.max(a,r.height-n))};case"top-left":return{newWidth:Math.min(s,Math.max(o,r.width-t)),newHeight:Math.min(c,Math.max(a,r.height-n))};case"top-right":return{newWidth:Math.min(s,Math.max(o,r.width+t)),newHeight:Math.min(c,Math.max(a,r.height-n))};case"bottom-left":return{newWidth:Math.min(s,Math.max(o,r.width-t)),newHeight:Math.min(c,Math.max(a,r.height+n))};case"bottom-right":return{newWidth:Math.min(s,Math.max(o,r.width+t)),newHeight:Math.min(c,Math.max(a,r.height+n))};default:return null}};function o6(e){switch(e){case"top-left":return"bottom-right";case"top-right":return"bottom-left";case"bottom-left":return"top-right";case"bottom-right":return"top-left";default:return null}}var o9=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/panel/dynamic-panel.css"),o8={};function o7(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function ae(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function at(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){ae(e,t,n[t])})}return e}function an(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return o7(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return o7(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function ar(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"width";if("number"==typeof e)return e;var n=document.createElement("div");n.style.position="absolute",n.style.visibility="hidden","width"===t?n.style.width=e:n.style.height=e,document.body.appendChild(n);var r="width"===t?n.offsetWidth:n.offsetHeight;return document.body.removeChild(n),r}function ao(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g=e.header,v=e.children,y=e.draggable,b=void 0!==y&&y,x=e.sizeConfig,w=void 0===x?{kind:"resizable",minWidth:400,minHeight:350,maxWidth:1e3,maxHeight:1e3,initialSize:{height:400,width:500}}:x,_=e.closeOnClickOutside,k=void 0!==_&&_,j=e.sharePanelSizeGlobally,P=e.sharePanelPositionGlobally,E=e.containerProps,T=oe().setPanel,I=u7(),N=I.name,L=I.mounted,A=void 0===j||j?el:"".concat(ei,"_").concat(N),z=void 0===P||P?es:"".concat(ea,"_").concat(N),R=dk(),D=R.dispatch,M=R.state,Z=null!=(h=M.devToolsPanelPosition[z])?h:M.devToolsPosition,F=an(Z.split("-",2),2),U=F[0],H=F[1],V=(0,C.useRef)(null);ns(V,oe().triggerRef,L,function(e){switch(e){case"escape":return void T("panel-selector");case"outside":k&&T("panel-selector");return;default:return null}});var B=ot(M),$=an(M.devToolsPosition.split("-",2),2),q=$[0],W=$[1],K=U===q&&H===W?B:oA,Y=(ae(m={},U,"".concat(K,"px")),ae(m,H,"".concat(oA,"px")),ae(m,"top"===U?"bottom":"top","auto"),ae(m,"left"===H?"right":"left","auto"),m),G="resizable"===w.kind,X=(t=G?w.minWidth:void 0,n=G?w.minHeight:void 0,r=G?w.maxWidth:void 0,o=G?w.maxHeight:void 0,(s=(0,O.c)(11))[0]!==o||s[1]!==r||s[2]!==n||s[3]!==t?(a=function(){return{minWidth:t?ar(t,"width"):void 0,minHeight:n?ar(n,"height"):void 0,maxWidth:r?ar(r,"width"):void 0,maxHeight:o?ar(o,"height"):void 0}},s[0]=o,s[1]=r,s[2]=n,s[3]=t,s[4]=a):a=s[4],u=(c=an((0,C.useState)(a),2))[0],d=c[1],s[5]!==o||s[6]!==r||s[7]!==n||s[8]!==t?(i=function(){var e=function(){d({minWidth:t?ar(t,"width"):void 0,minHeight:n?ar(n,"height"):void 0,maxWidth:r?ar(r,"width"):void 0,maxHeight:o?ar(o,"height"):void 0})};return window.addEventListener("resize",e),function(){return window.removeEventListener("resize",e)}},l=[t,n,r,o],s[5]=o,s[6]=r,s[7]=n,s[8]=t,s[9]=i,s[10]=l):(i=s[9],l=s[10]),(0,C.useEffect)(i,l),u),Q=X.minWidth,J=X.minHeight,ee=X.maxWidth,et=X.maxHeight,er=N?"".concat(ei,"_").concat(N):el,eo=M.devToolsPanelSize[er];return(0,S.jsx)(oJ,{value:{resizeRef:V,initialSize:"resizable"===w.kind?w.initialSize:w,minWidth:Q,minHeight:J,maxWidth:ee,maxHeight:et,devToolsPosition:M.devToolsPosition,devToolsPanelSize:M.devToolsPanelSize,storageKey:A},children:(0,S.jsx)("div",{tabIndex:-1,ref:V,className:"dynamic-panel-container",style:at({"--panel-top":Y.top,"--panel-bottom":Y.bottom,"--panel-left":Y.left,"--panel-right":Y.right},G?{"--panel-min-width":Q?"".concat(Q,"px"):void 0,"--panel-min-height":J?"".concat(J,"px"):void 0,"--panel-max-width":ee?"".concat(ee,"px"):void 0,"--panel-max-height":et?"".concat(et,"px"):void 0}:{"--panel-height":"".concat(eo?eo.height:w.height,"px"),"--panel-width":"".concat(eo?eo.width:w.width,"px")}),children:(0,S.jsx)(ox,{disabled:!b,children:(0,S.jsx)(oE,{dragHandleSelector:".resize-container",avoidZone:{corner:M.devToolsPosition,square:25/M.scale,padding:oA},padding:oA,position:Z,setPosition:function(e){D({type:en,devToolsPanelPosition:e,key:z}),"resizable"===w.kind&&rI({devToolsPanelPosition:ae({},z,e)})},style:{overflow:"auto",width:"100%",height:"100%"},disableDrag:!b,children:(0,S.jsxs)(S.Fragment,{children:[(0,S.jsxs)("div",(f=at({},E),p=p={className:"panel-content-container ".concat((null==E?void 0:E.className)||""),style:at({},null==E?void 0:E.style),children:[(0,S.jsx)(o_,{children:g}),(0,S.jsx)("div",{"data-nextjs-scrollable-content":!0,className:"draggable-content",children:v})]},Object.getOwnPropertyDescriptors?Object.defineProperties(f,Object.getOwnPropertyDescriptors(p)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(p)).forEach(function(e){Object.defineProperty(f,e,Object.getOwnPropertyDescriptor(p,e))}),f)),G&&(0,S.jsxs)(S.Fragment,{children:[(!w.sides||w.sides.includes("vertical"))&&(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(o4,{position:Z,direction:"top"}),(0,S.jsx)(o4,{position:Z,direction:"bottom"})]}),(!w.sides||w.sides.includes("horizontal"))&&(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(o4,{position:Z,direction:"right"}),(0,S.jsx)(o4,{position:Z,direction:"left"})]}),(!w.sides||w.sides.includes("diagonal"))&&(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(o4,{position:Z,direction:"top-left"}),(0,S.jsx)(o4,{position:Z,direction:"top-right"}),(0,S.jsx)(o4,{position:Z,direction:"bottom-left"}),(0,S.jsx)(o4,{position:Z,direction:"bottom-right"})]})]})]})})})})})}o8.styleTagTransform=x(),o8.setAttributes=g(),o8.insert=h(),o8.domAPI=f(),o8.insertStyleElement=y(),u()(o9.A,o8),o9.A&&o9.A.locals&&o9.A.locals;var aa=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-explorer.css"),ai={};function al(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}ai.styleTagTransform=x(),ai.setAttributes=g(),ai.insert=h(),ai.domAPI=f(),ai.insertStyleElement=y(),u()(aa.A,ai),aa.A&&aa.A.locals&&aa.A.locals;var as=new Set,ac=function(e){return as.add(e),function(){return as.delete(e)}},au=function(){return af.getRoot()},ad=function(){return af.getRoot()},af=function(e){var t=e.getCharacters,n=void 0===t?function(e){return[e]}:t,r=e.compare,o=void 0===r?function(e,t){return e===t}:r,a={value:void 0,children:{}};function i(){var e=!0,t=!1,n=void 0;try{for(var r,o=as[Symbol.iterator]();!(e=(r=o.next()).done);e=!0)(0,r.value)()}catch(e){t=!0,n=e}finally{try{e||null==o.return||o.return()}finally{if(t)throw n}}}return{insert:function(e){var t=a,r=n(e),o=!0,l=!1,s=void 0;try{for(var c,u=r[Symbol.iterator]();!(o=(c=u.next()).done);o=!0){var d=c.value;t.children[d]||(t.children[d]={value:void 0,children:{}}),t=t.children[d]}}catch(e){l=!0,s=e}finally{try{o||null==u.return||u.return()}finally{if(l)throw s}}t.value=e,a=al({},a),i()},remove:function(e){var t=a,r=n(e),l=[],s=!0,c=!0,u=!1,d=void 0;try{for(var f,p=r[Symbol.iterator]();!(c=(f=p.next()).done);c=!0){var h=f.value;if(!t.children[h]){s=!1;break}l.push(t),t=t.children[h]}}catch(e){u=!0,d=e}finally{try{c||null==p.return||p.return()}finally{if(u)throw d}}if(s&&o(t.value,e)){t.value=void 0;for(var m=l.length-1;m>=0;m--){var g=l[m],v=r[m];0===Object.keys(g.children[v].children).length&&delete g.children[v]}a=al({},a),i()}},getRoot:function(){return a}}}({compare:function(e,t){return!!e&&!!t&&e.pagePath===t.pagePath&&e.type===t.type&&e.boundaryType===t.boundaryType},getCharacters:function(e){return e.pagePath.split("/")}}),ap=af.insert,ah=af.remove,am=af.getRoot,ag=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/overview/segment-boundary-trigger.css"),av={};av.styleTagTransform=x(),av.setAttributes=g(),av.insert=h(),av.domAPI=f(),av.insertStyleElement=y(),u()(ag.A,av),ag.A&&ag.A.locals&&ag.A.locals;let ay={};function ab(e,t){let n=C.useRef(ay);return n.current===ay&&(n.current=e(t)),n}let ax=[];function aw(e){C.useEffect(e,ax)}class a_{static create(){return new a_}currentId=0;start(e,t){this.clear(),this.currentId=setTimeout(()=>{this.currentId=0,t()},e)}isStarted(){return 0!==this.currentId}clear=()=>{0!==this.currentId&&(clearTimeout(this.currentId),this.currentId=0)};disposeEffect=()=>this.clear}function ak(){let e=ab(a_.create).current;return aw(e.disposeEffect),e}let aj=P[`useInsertionEffect${Math.random().toFixed(1)}`.slice(0,-3)],aS=aj&&aj!==C.useLayoutEffect?aj:e=>e();function aO(e){let t=ab(aC).current;return t.next=e,aS(t.effect),t.trampoline}function aC(){let e={next:void 0,callback:aP,trampoline:(...t)=>e.callback?.(...t),effect:()=>{e.callback=e.next}};return e}function aP(){}function aE({controlled:e,default:t,name:n,state:r="value"}){let{current:o}=C.useRef(void 0!==e),[a,i]=C.useState(t),l=C.useCallback(e=>{o||i(e)},[]);return[o?e:a,l]}let aT={...P},aI=0,aN=aT.useId;function aL(e,t){if(void 0!==aN){let n=aN();return e??(t?`${t}-${n}`:n)}return function(e,t="mui"){let[n,r]=C.useState(e),o=e||n;return C.useEffect(()=>{null==n&&(aI+=1,r(`${t}-${aI}`))},[n,t]),o}(e,t)}function aA(){let e=new Map;return{emit(t,n){e.get(t)?.forEach(e=>e(n))},on(t,n){e.has(t)||e.set(t,new Set),e.get(t).add(n)},off(t,n){e.get(t)?.delete(n)}}}let az="undefined"!=typeof document?C.useLayoutEffect:()=>{},aR=C.createContext(null),aD=C.createContext(null),aM=()=>P.useContext(aR)?.id||null;function aZ(e){let{children:t,id:n}=e,r=aM();return(0,S.jsx)(aR.Provider,{value:C.useMemo(()=>({id:n,parentId:r}),[n,r]),children:t})}function aF(e){let{children:t}=e,n=C.useRef([]),r=C.useCallback(e=>{n.current=[...n.current,e]},[]),o=C.useCallback(e=>{n.current=n.current.filter(t=>t!==e)},[]),[a]=C.useState(()=>aA());return(0,S.jsx)(aD.Provider,{value:C.useMemo(()=>({nodesRef:n,addNode:r,removeNode:o,events:a}),[r,o,a]),children:t})}function aU(e){let{open:t=!1,onOpenChange:n,elements:r}=e,o=aL(),a=C.useRef({}),[i]=C.useState(()=>aA()),l=null!=aM(),[s,c]=C.useState(r.reference),u=aO((e,t,r)=>{a.current.openEvent=e?t:void 0,i.emit("openchange",{open:e,event:t,reason:r,nested:l}),n?.(e,t,r)}),d=C.useMemo(()=>({setPositionReference:c}),[]),f=C.useMemo(()=>({reference:s||r.reference||null,floating:r.floating||null,domReference:r.reference}),[s,r.reference,r.floating]);return C.useMemo(()=>({dataRef:a,open:t,onOpenChange:u,elements:f,events:i,floatingId:o,refs:d}),[t,u,f,i,o,d])}function aH(){return"undefined"!=typeof window}function aV(e){return aq(e)?(e.nodeName||"").toLowerCase():"#document"}function aB(e){var t;return(null==e||null==(t=e.ownerDocument)?void 0:t.defaultView)||window}function a$(e){var t;return null==(t=(aq(e)?e.ownerDocument:e.document)||window.document)?void 0:t.documentElement}function aq(e){return!!aH()&&(e instanceof Node||e instanceof aB(e).Node)}function aW(e){return!!aH()&&(e instanceof Element||e instanceof aB(e).Element)}function aK(e){return!!aH()&&(e instanceof HTMLElement||e instanceof aB(e).HTMLElement)}function aY(e){return!!aH()&&"undefined"!=typeof ShadowRoot&&(e instanceof ShadowRoot||e instanceof aB(e).ShadowRoot)}let aG=new Set(["inline","contents"]);function aX(e){let{overflow:t,overflowX:n,overflowY:r,display:o}=a8(e);return/auto|scroll|overlay|hidden|clip/.test(t+r+n)&&!aG.has(o)}let aQ=new Set(["table","td","th"]),aJ=[":popover-open",":modal"];function a0(e){return aJ.some(t=>{try{return e.matches(t)}catch(e){return!1}})}let a1=["transform","translate","scale","rotate","perspective"],a2=["transform","translate","scale","rotate","perspective","filter"],a3=["paint","layout","strict","content"];function a4(e){let t=a5(),n=aW(e)?a8(e):e;return a1.some(e=>!!n[e]&&"none"!==n[e])||!!n.containerType&&"normal"!==n.containerType||!t&&!!n.backdropFilter&&"none"!==n.backdropFilter||!t&&!!n.filter&&"none"!==n.filter||a2.some(e=>(n.willChange||"").includes(e))||a3.some(e=>(n.contain||"").includes(e))}function a5(){return"undefined"!=typeof CSS&&!!CSS.supports&&CSS.supports("-webkit-backdrop-filter","none")}let a6=new Set(["html","body","#document"]);function a9(e){return a6.has(aV(e))}function a8(e){return aB(e).getComputedStyle(e)}function a7(e){return aW(e)?{scrollLeft:e.scrollLeft,scrollTop:e.scrollTop}:{scrollLeft:e.scrollX,scrollTop:e.scrollY}}function ie(e){if("html"===aV(e))return e;let t=e.assignedSlot||e.parentNode||aY(e)&&e.host||a$(e);return aY(t)?t.host:t}function it(e,t,n){var r;void 0===t&&(t=[]),void 0===n&&(n=!0);let o=function e(t){let n=ie(t);return a9(n)?t.ownerDocument?t.ownerDocument.body:t.body:aK(n)&&aX(n)?n:e(n)}(e),a=o===(null==(r=e.ownerDocument)?void 0:r.body),i=aB(o);if(a){let e=ir(i);return t.concat(i,i.visualViewport||[],aX(o)?o:[],e&&n?it(e):[])}return t.concat(o,it(o,[],n))}function ir(e){return e.parent&&Object.getPrototypeOf(e.parent)?e.frameElement:null}function io(e){let t=ab(ia,e).current;return t.next=e,az(t.effect),t}function ia(e){let t={current:e,next:e,effect:()=>{t.current=t.next}};return t}let ii="undefined"!=typeof navigator,il=function(){if(!ii)return{platform:"",maxTouchPoints:-1};let e=navigator.userAgentData;return e?.platform?{platform:e.platform,maxTouchPoints:navigator.maxTouchPoints}:{platform:navigator.platform??"",maxTouchPoints:navigator.maxTouchPoints??-1}}(),is=function(){if(!ii)return"";let e=navigator.userAgentData;return e?.platform?e.platform:navigator.platform??""}(),ic=function(){if(!ii)return"";let e=navigator.userAgentData;return e&&Array.isArray(e.brands)?e.brands.map(({brand:e,version:t})=>`${e}/${t}`).join(" "):navigator.userAgent}(),iu="undefined"!=typeof CSS&&!!CSS.supports&&CSS.supports("-webkit-backdrop-filter:none"),id="MacIntel"===il.platform&&il.maxTouchPoints>1||/iP(hone|ad|od)|iOS/.test(il.platform);ii&&/firefox/i.test(ic);let ip=ii&&/apple/i.test(navigator.vendor),ih=ii&&/android/i.test(is)||/android/i.test(ic),im=ii&&is.toLowerCase().startsWith("mac")&&!navigator.maxTouchPoints,ig=ic.includes("jsdom/");function iv(e){e.preventDefault(),e.stopPropagation()}function iy(e){return 0===e.mozInputSource&&!!e.isTrusted||(ih&&e.pointerType?"click"===e.type&&1===e.buttons:0===e.detail&&!e.pointerType)}function ib(e){return!ig&&(!ih&&0===e.width&&0===e.height||ih&&1===e.width&&1===e.height&&0===e.pressure&&0===e.detail&&"mouse"===e.pointerType||e.width<1&&e.height<1&&0===e.pressure&&0===e.detail&&"touch"===e.pointerType)}function ix(e,t){let n=["mouse","pen"];return t||n.push("",void 0),n.includes(e)}let iw="data-base-ui-focusable",i_="active",ik="selected",ij="ArrowLeft",iS="ArrowRight",iO="ArrowUp",iC="ArrowDown";function iP(e){let t=e.activeElement;for(;t?.shadowRoot?.activeElement!=null;)t=t.shadowRoot.activeElement;return t}function iE(e,t){if(!e||!t)return!1;let n=t.getRootNode?.();if(e.contains(t))return!0;if(n&&aY(n)){let n=t;for(;n;){if(e===n)return!0;n=n.parentNode||n.host}}return!1}function iT(e){return"composedPath"in e?e.composedPath()[0]:e.target}function iI(e,t){return null!=t&&("composedPath"in e?e.composedPath().includes(t):null!=e.target&&t.contains(e.target))}function iN(e){return e?.ownerDocument||document}function iL(e){return aK(e)&&e.matches("input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])")}function iA(e){return!!e&&"combobox"===e.getAttribute("role")&&iL(e)}function iz(e){return e?e.hasAttribute(iw)?e:e.querySelector(`[${iw}]`)||e:null}function iR(e){return`data-base-ui-${e}`}let iD=iR("safe-polygon");function iM(e,t,n){if(n&&!ix(n))return 0;if("number"==typeof e)return e;if("function"==typeof e){let n=e();return"number"==typeof n?n:n?.[t]}return e?.[t]}function iZ(e){return"function"==typeof e?e():e}function iF(e,t={}){let{open:n,onOpenChange:r,dataRef:o,events:a,elements:i}=e,{enabled:l=!0,delay:s=0,handleClose:c=null,mouseOnly:u=!1,restMs:d=0,move:f=!0}=t,p=C.useContext(aD),h=aM(),m=io(c),g=io(s),v=io(n),y=io(d),b=C.useRef(void 0),x=ak(),w=C.useRef(void 0),_=ak(),k=C.useRef(!0),j=C.useRef(!1),S=C.useRef(()=>{}),O=C.useRef(!1),P=aO(()=>{let e=o.current.openEvent?.type;return e?.includes("mouse")&&"mousedown"!==e});C.useEffect(()=>{if(l)return a.on("openchange",e),()=>{a.off("openchange",e)};function e({open:e}){e||(x.clear(),_.clear(),k.current=!0,O.current=!1)}},[l,a,x,_]),C.useEffect(()=>{if(!l||!m.current||!n)return;function e(e){P()&&r(!1,e,"hover")}let t=iN(i.floating).documentElement;return t.addEventListener("mouseleave",e),()=>{t.removeEventListener("mouseleave",e)}},[i.floating,n,r,l,m,P]);let E=C.useCallback((e,t=!0,n="hover")=>{let o=iM(g.current,"close",b.current);o&&!w.current?x.start(o,()=>r(!1,e,n)):t&&(x.clear(),r(!1,e,n))},[g,r,x]),T=aO(()=>{S.current(),w.current=void 0}),I=aO(()=>{if(j.current){let e=iN(i.floating).body;e.style.pointerEvents="",e.removeAttribute(iD),j.current=!1}}),N=aO(()=>!!o.current.openEvent&&["click","mousedown"].includes(o.current.openEvent.type));C.useEffect(()=>{if(l&&aW(i.domReference)){let r=i.domReference,o=i.floating;return n&&r.addEventListener("mouseleave",a),f&&r.addEventListener("mousemove",e,{once:!0}),r.addEventListener("mouseenter",e),r.addEventListener("mouseleave",t),o&&(o.addEventListener("mouseleave",a),o.addEventListener("mouseenter",s),o.addEventListener("mouseleave",c)),()=>{n&&r.removeEventListener("mouseleave",a),f&&r.removeEventListener("mousemove",e),r.removeEventListener("mouseenter",e),r.removeEventListener("mouseleave",t),o&&(o.removeEventListener("mouseleave",a),o.removeEventListener("mouseenter",s),o.removeEventListener("mouseleave",c))}}function e(e){if(x.clear(),k.current=!1,u&&!ix(b.current)||iZ(y.current)>0&&!iM(g.current,"open"))return;let t=iM(g.current,"open",b.current);t?x.start(t,()=>{v.current||r(!0,e,"hover")}):n||r(!0,e,"hover")}function t(e){if(N())return void I();S.current();let t=iN(i.floating);if(_.clear(),O.current=!1,m.current&&o.current.floatingContext){n||x.clear(),w.current=m.current({...o.current.floatingContext,tree:p,x:e.clientX,y:e.clientY,onClose(){I(),T(),N()||E(e,!0,"safe-polygon")}});let r=w.current;t.addEventListener("mousemove",r),S.current=()=>{t.removeEventListener("mousemove",r)};return}"touch"===b.current&&iE(i.floating,e.relatedTarget)||E(e)}function a(e){N()||o.current.floatingContext&&m.current?.({...o.current.floatingContext,tree:p,x:e.clientX,y:e.clientY,onClose(){I(),T(),N()||E(e)}})(e)}function s(){x.clear()}function c(e){N()||E(e,!1)}},[i,l,e,u,f,E,T,I,r,n,v,p,g,m,o,N,y,x,_]),az(()=>{if(l&&n&&m.current?.__options?.blockPointerEvents&&P()){j.current=!0;let e=i.floating;if(aW(i.domReference)&&e){let t=iN(i.floating).body;t.setAttribute(iD,"");let n=i.domReference,r=p?.nodesRef.current.find(e=>e.id===h)?.context?.elements.floating;return r&&(r.style.pointerEvents=""),t.style.pointerEvents="none",n.style.pointerEvents="auto",e.style.pointerEvents="auto",()=>{t.style.pointerEvents="",n.style.pointerEvents="",e.style.pointerEvents=""}}}},[l,n,h,i,p,m,P]),az(()=>{n||(b.current=void 0,O.current=!1,T(),I())},[n,T,I]),C.useEffect(()=>()=>{T(),x.clear(),_.clear(),I()},[l,i.domReference,T,I,x,_]);let L=C.useMemo(()=>{function e(e){b.current=e.pointerType}return{onPointerDown:e,onPointerEnter:e,onMouseMove(e){let{nativeEvent:t}=e;function o(){k.current||v.current||r(!0,t,"hover")}u&&!ix(b.current)||n||0===iZ(y.current)||O.current&&e.movementX**2+e.movementY**2<2||(_.clear(),"touch"===b.current?o():(O.current=!0,_.start(iZ(y.current),o)))}}},[u,r,n,v,y,_]);return C.useMemo(()=>l?{reference:L}:{},[l,L])}function iU(e,t,n=!0){return e.filter(e=>e.parentId===t&&(!n||e.context?.open)).flatMap(t=>[t,...iU(e,t.id,n)])}function iH(e,t){let n=[],r=e.find(e=>e.id===t)?.parentId;for(;r;){let t=e.find(e=>e.id===r);r=t?.parentId,t&&(n=n.concat(t))}return n}function iV(e,t){let[n,r]=e,o=!1,a=t.length;for(let e=0,i=a-1;e<a;i=e++){let[a,l]=t[e]||[0,0],[s,c]=t[i]||[0,0];l>=r!=c>=r&&n<=(s-a)*(r-l)/(c-l)+a&&(o=!o)}return o}function iB(e={}){let{buffer:t=.5,blockPointerEvents:n=!1,requireIntent:r=!0}=e,o=new a_,a=!1,i=null,l=null,s="undefined"!=typeof performance?performance.now():0,c=({x:e,y:n,placement:c,elements:u,onClose:d,nodeId:f,tree:p})=>function(h){var m,g;function v(){o.clear(),d()}if(o.clear(),!u.domReference||!u.floating||null==c||null==e||null==n)return;let{clientX:y,clientY:b}=h,x=[y,b],w=iT(h),_="mouseleave"===h.type,k=iE(u.floating,w),j=iE(u.domReference,w),S=u.domReference.getBoundingClientRect(),O=u.floating.getBoundingClientRect(),C=c.split("-")[0],P=e>O.right-O.width/2,E=n>O.bottom-O.height/2,T=(m=x,g=S,m[0]>=g.x&&m[0]<=g.x+g.width&&m[1]>=g.y&&m[1]<=g.y+g.height),I=O.width>S.width,N=O.height>S.height,L=(I?S:O).left,A=(I?S:O).right,z=(N?S:O).top,R=(N?S:O).bottom;if(k&&(a=!0,!_))return;if(j&&(a=!1),j&&!_){a=!0;return}if(_&&aW(h.relatedTarget)&&iE(u.floating,h.relatedTarget)||p&&iU(p.nodesRef.current,f).some(({context:e})=>e?.open))return;if("top"===C&&n>=S.bottom-1||"bottom"===C&&n<=S.top+1||"left"===C&&e>=S.right-1||"right"===C&&e<=S.left+1)return v();let D=[];switch(C){case"top":D=[[L,S.top+1],[L,O.bottom-1],[A,O.bottom-1],[A,S.top+1]];break;case"bottom":D=[[L,O.top+1],[L,S.bottom-1],[A,S.bottom-1],[A,O.top+1]];break;case"left":D=[[O.right-1,R],[O.right-1,z],[S.left+1,z],[S.left+1,R]];break;case"right":D=[[S.right-1,R],[S.right-1,z],[O.left+1,z],[O.left+1,R]]}if(!iV([y,b],D)){if(a&&!T)return v();if(!_&&r){let e=function(e,t){let n=performance.now(),r=n-s;if(null===i||null===l||0===r)return i=e,l=t,s=n,null;let o=e-i,a=t-l,c=Math.sqrt(o*o+a*a);return i=e,l=t,s=n,c/r}(h.clientX,h.clientY);if(null!==e&&e<.1)return v()}iV([y,b],function([e,n]){switch(C){case"top":{let r=[[O.left,P||I?O.bottom-t:O.top],[O.right,P?I?O.bottom-t:O.top:O.bottom-t]];return[[I?e+t/2:P?e+4*t:e-4*t,n+t+1],[I?e-t/2:P?e+4*t:e-4*t,n+t+1],...r]}case"bottom":{let r=[[O.left,P||I?O.top+t:O.bottom],[O.right,P?I?O.top+t:O.bottom:O.top+t]];return[[I?e+t/2:P?e+4*t:e-4*t,n-t],[I?e-t/2:P?e+4*t:e-4*t,n-t],...r]}case"left":return[[E||N?O.right-t:O.left,O.top],[E?N?O.right-t:O.left:O.right-t,O.bottom],[e+t+1,N?n+t/2:E?n+4*t:n-4*t],[e+t+1,N?n-t/2:E?n+4*t:n-4*t]];case"right":{let r=[[E||N?O.left+t:O.right,O.top],[E?N?O.left+t:O.right:O.left+t,O.bottom]];return[[e-t,N?n+t/2:E?n+4*t:n-4*t],[e-t,N?n-t/2:E?n+4*t:n-4*t],...r]}default:return[]}}([e,n]))?!a&&r&&o.start(40,v):v()}};return c.__options={blockPointerEvents:n},c}let i$=im&&ip;function iq(e,t={}){let{open:n,onOpenChange:r,events:o,dataRef:a,elements:i}=e,{enabled:l=!0,visibleOnly:s=!0}=t,c=C.useRef(!1),u=ak(),d=C.useRef(!0);C.useEffect(()=>{if(!l)return;let e=aB(i.domReference);function t(){!n&&aK(i.domReference)&&i.domReference===iP(iN(i.domReference))&&(c.current=!0)}function r(){d.current=!0}function o(){d.current=!1}return e.addEventListener("blur",t),i$&&(e.addEventListener("keydown",r,!0),e.addEventListener("pointerdown",o,!0)),()=>{e.removeEventListener("blur",t),i$&&(e.removeEventListener("keydown",r,!0),e.removeEventListener("pointerdown",o,!0))}},[i.domReference,n,l]),C.useEffect(()=>{if(l)return o.on("openchange",e),()=>{o.off("openchange",e)};function e({reason:e}){("reference-press"===e||"escape-key"===e)&&(c.current=!0)}},[o,l]);let f=C.useMemo(()=>({onMouseLeave(){c.current=!1},onFocus(e){if(c.current)return;let t=iT(e.nativeEvent);if(s&&aW(t)){if(i$&&!e.relatedTarget){if(!d.current&&!iL(t))return}else if(!function(e){if(!e||ig)return!0;try{return e.matches(":focus-visible")}catch(e){return!0}}(t))return}r(!0,e.nativeEvent,"focus")},onBlur(e){c.current=!1;let t=e.relatedTarget,n=e.nativeEvent,o=aW(t)&&t.hasAttribute(iR("focus-guard"))&&"outside"===t.getAttribute("data-type");u.start(0,()=>{let e=iP(i.domReference?i.domReference.ownerDocument:document);!t&&e===i.domReference||iE(a.current.floatingContext?.refs.floating.current,e)||iE(i.domReference,e)||o||r(!1,n,"focus")})}}),[a,i.domReference,r,s,u]);return C.useMemo(()=>l?{reference:f}:{},[l,f])}let iW=new class{callbacks=[];callbacksCount=0;nextId=1;startId=1;isScheduled=!1;tick=e=>{this.isScheduled=!1;let t=this.callbacks,n=this.callbacksCount;if(this.callbacks=[],this.callbacksCount=0,this.startId=this.nextId,n>0)for(let n=0;n<t.length;n+=1)t[n]?.(e)};request(e){let t=this.nextId;return this.nextId+=1,this.callbacks.push(e),this.callbacksCount+=1,this.isScheduled||(requestAnimationFrame(this.tick),this.isScheduled=!0),t}cancel(e){let t=e-this.startId;t<0||t>=this.callbacks.length||(this.callbacks[t]=null,this.callbacksCount-=1)}};class iK{static create(){return new iK}static request(e){return iW.request(e)}static cancel(e){return iW.cancel(e)}currentId=null;request(e){this.cancel(),this.currentId=iW.request(()=>{this.currentId=null,e()})}cancel=()=>{null!==this.currentId&&(iW.cancel(this.currentId),this.currentId=null)};disposeEffect=()=>this.cancel}function iY(){let e=ab(iK.create).current;return aw(e.disposeEffect),e}let iG={style:{transition:"none"}},iX={},iQ=[],iJ={fallbackAxisSide:"none"},i0={fallbackAxisSide:"end"},i1={intentional:"onClick",sloppy:"onPointerDown"};function i2(e){return{escapeKey:"boolean"==typeof e?e:e?.escapeKey??!1,outsidePress:"boolean"==typeof e?e:e?.outsidePress??!0}}function i3(e,t={}){let{open:n,onOpenChange:r,elements:o,dataRef:a}=e,{enabled:i=!0,escapeKey:l=!0,outsidePress:s=!0,outsidePressEvent:c="sloppy",referencePress:u=!1,referencePressEvent:d="sloppy",ancestorScroll:f=!1,bubbles:p,capture:h}=t,m=C.useContext(aD),g=aO("function"==typeof s?s:()=>!1),v="function"==typeof s?g:s,y=C.useRef(!1),{escapeKey:b,outsidePress:x}=i2(p),{escapeKey:w,outsidePress:_}=i2(h),k=C.useRef(null),j=ak(),S=ak(),O=C.useRef(!1),P=C.useRef(""),E=aO(e=>{P.current=e.pointerType}),T=aO(()=>{let e=P.current;return"string"==typeof c?c:c["pen"!==e&&e?e:"mouse"]}),I=aO(e=>{if(!n||!i||!l||"Escape"!==e.key||O.current)return;let t=a.current.floatingContext?.nodeId,o=m?iU(m.nodesRef.current,t):[];if(!b&&(e.stopPropagation(),o.length>0)){let e=!0;if(o.forEach(t=>{t.context?.open&&!t.context.dataRef.current.__escapeKeyBubbles&&(e=!1)}),!e)return}r(!1,"nativeEvent"in e?e.nativeEvent:e,"escape-key")}),N=aO(e=>{let t=T();return"intentional"===t&&"click"!==e.type||"sloppy"===t&&"click"===e.type}),L=aO(e=>{let t=()=>{I(e),iT(e)?.removeEventListener("keydown",t)};iT(e)?.addEventListener("keydown",t)}),A=aO(e=>{if(N(e))return;let t=a.current.insideReactTree;a.current.insideReactTree=!1;let n=y.current;if(y.current=!1,"intentional"===T()&&n||t||"function"==typeof v&&!v(e))return;let i=iT(e),l=`[${iR("inert")}]`,s=iN(o.floating).querySelectorAll(l),c=aW(i)?i:null;for(;c&&!a9(c);){let e=ie(c);if(a9(e)||!aW(e))break;c=e}if(s.length&&aW(i)&&!i.matches("html,body")&&!iE(i,o.floating)&&Array.from(s).every(e=>!iE(c,e)))return;if(aK(i)){let t=a9(i),n=a8(i),r=/auto|scroll/,o=t||r.test(n.overflowX),a=t||r.test(n.overflowY),l=o&&i.clientWidth>0&&i.scrollWidth>i.clientWidth,s=a&&i.clientHeight>0&&i.scrollHeight>i.clientHeight,c="rtl"===n.direction,u=s&&(c?e.offsetX<=i.offsetWidth-i.clientWidth:e.offsetX>i.clientWidth),d=l&&e.offsetY>i.clientHeight;if(u||d)return}let u=a.current.floatingContext?.nodeId,d=m&&iU(m.nodesRef.current,u).some(t=>iI(e,t.context?.elements.floating));if(iI(e,o.floating)||iI(e,o.domReference)||d)return;let f=m?iU(m.nodesRef.current,u):[];if(f.length>0){let e=!0;if(f.forEach(t=>{t.context?.open&&!t.context.dataRef.current.__outsidePressBubbles&&(e=!1)}),!e)return}r(!1,e,"outside-press")}),z=aO(e=>{if(!("sloppy"!==T()||!n||!i||iI(e,o.floating)||iI(e,o.domReference))){if("touch"===e.pointerType){k.current={startTime:Date.now(),startX:e.clientX,startY:e.clientY,dismissOnPointerUp:!1,dismissOnMouseDown:!0},j.start(1e3,()=>{k.current&&(k.current.dismissOnPointerUp=!1,k.current.dismissOnMouseDown=!1)});return}A(e)}}),R=aO(e=>{if(N(e)||(j.clear(),"mousedown"===e.type&&k.current&&!k.current.dismissOnMouseDown))return;let t=()=>{"pointerdown"===e.type?z(e):A(e),iT(e)?.removeEventListener(e.type,t)};iT(e)?.addEventListener(e.type,t)}),D=aO(e=>{if("sloppy"!==T()||"touch"!==e.pointerType||!k.current||iI(e,o.floating)||iI(e,o.domReference))return;let t=Math.abs(e.clientX-k.current.startX),n=Math.abs(e.clientY-k.current.startY),r=Math.sqrt(t*t+n*n);r>5&&(k.current.dismissOnPointerUp=!0),r>10&&(A(e),j.clear(),k.current=null)}),M=aO(e=>{"sloppy"!==T()||"touch"!==e.pointerType||!k.current||iI(e,o.floating)||iI(e,o.domReference)||(k.current.dismissOnPointerUp&&A(e),j.clear(),k.current=null)});C.useEffect(()=>{if(!n||!i)return;a.current.__escapeKeyBubbles=b,a.current.__outsidePressBubbles=x;let e=new a_;function t(e){r(!1,e,"ancestor-scroll")}function s(){e.clear(),O.current=!0}function c(){e.start(5*!!a5(),()=>{O.current=!1})}let u=iN(o.floating);u.addEventListener("pointerdown",E,!0),l&&(u.addEventListener("keydown",w?L:I,w),u.addEventListener("compositionstart",s),u.addEventListener("compositionend",c)),v&&(u.addEventListener("click",_?R:A,_),u.addEventListener("pointerdown",_?R:A,_),u.addEventListener("pointermove",D,_),u.addEventListener("pointerup",M,_),u.addEventListener("mousedown",R,_));let d=[];return f&&(aW(o.domReference)&&(d=it(o.domReference)),aW(o.floating)&&(d=d.concat(it(o.floating))),!aW(o.reference)&&o.reference&&o.reference.contextElement&&(d=d.concat(it(o.reference.contextElement)))),(d=d.filter(e=>e!==u.defaultView?.visualViewport)).forEach(e=>{e.addEventListener("scroll",t,{passive:!0})}),()=>{u.removeEventListener("pointerdown",E,!0),l&&(u.removeEventListener("keydown",w?L:I,w),u.removeEventListener("compositionstart",s),u.removeEventListener("compositionend",c)),v&&(u.removeEventListener("click",_?R:A,_),u.removeEventListener("pointerdown",_?R:A,_),u.removeEventListener("pointermove",D,_),u.removeEventListener("pointerup",M,_),u.removeEventListener("mousedown",R,_)),d.forEach(e=>{e.removeEventListener("scroll",t)}),e.clear()}},[a,o,l,v,c,n,r,f,i,b,x,I,w,L,A,_,R,z,D,M,E]),C.useEffect(()=>{a.current.insideReactTree=!1},[a,v]);let Z=C.useMemo(()=>({onKeyDown:I,...u&&{[i1[d]]:e=>{r(!1,e.nativeEvent,"reference-press")},..."intentional"!==d&&{onClick(e){r(!1,e.nativeEvent,"reference-press")}}}}),[I,r,u,d]),F=aO(e=>{let t=iT(e.nativeEvent);iE(o.floating,t)&&(y.current=!0)}),U=aO(()=>{a.current.insideReactTree=!0,S.start(0,()=>{a.current.insideReactTree=!1})}),H=C.useMemo(()=>({onKeyDown:I,onMouseDown:F,onMouseUp:F,onPointerDownCapture:U,onMouseDownCapture:U,onClickCapture:U}),[I,F,U]);return C.useMemo(()=>i?{reference:Z,floating:H}:{},[i,Z,H])}let i4=new Map([["select","listbox"],["combobox","listbox"],["label",!1]]),i5=["top","right","bottom","left"],i6=Math.min,i9=Math.max,i8=Math.round,i7=Math.floor,le=e=>({x:e,y:e}),lt={left:"right",right:"left",bottom:"top",top:"bottom"},ln={start:"end",end:"start"};function lr(e,t){return"function"==typeof e?e(t):e}function lo(e){return e.split("-")[0]}function la(e){return e.split("-")[1]}function li(e){return"x"===e?"y":"x"}function ll(e){return"y"===e?"height":"width"}let ls=new Set(["top","bottom"]);function lc(e){return ls.has(lo(e))?"y":"x"}function lu(e){return e.replace(/start|end/g,e=>ln[e])}let ld=["left","right"],lf=["right","left"],lp=["top","bottom"],lh=["bottom","top"];function lm(e){return e.replace(/left|right|bottom|top/g,e=>lt[e])}function lg(e){return"number"!=typeof e?{top:0,right:0,bottom:0,left:0,...e}:{top:e,right:e,bottom:e,left:e}}function lv(e){let{x:t,y:n,width:r,height:o}=e;return{width:r,height:o,top:n,left:t,right:t+r,bottom:n+o,x:t,y:n}}function ly(e,t,n){return Math.floor(e/t)!==n}function lb(e,t){return t<0||t>=e.current.length}function lx(e,t){return l_(e,{disabledIndices:t})}function lw(e,t){return l_(e,{decrement:!0,startingIndex:e.current.length,disabledIndices:t})}function l_(e,{startingIndex:t=-1,decrement:n=!1,disabledIndices:r,amount:o=1}={}){let a=t;do a+=n?-o:o;while(a>=0&&a<=e.current.length-1&&lk(e,a,r));return a}function lk(e,t,n){if("function"==typeof n)return n(t);if(n)return n.includes(t);let r=e.current[t];return null==r||r.hasAttribute("disabled")||"true"===r.getAttribute("aria-disabled")}let lj=0;function lS(e,t={}){let{preventScroll:n=!1,cancelPrevious:r=!0,sync:o=!1}=t;r&&cancelAnimationFrame(lj);let a=()=>e?.focus({preventScroll:n});o?a():lj=requestAnimationFrame(a)}function lO(e,t,n){switch(e){case"vertical":return t;case"horizontal":return n;default:return t||n}}function lC(e,t){return lO(t,e===iO||e===iC,e===ij||e===iS)}function lP(e,t,n){return lO(t,e===iC,n?e===ij:e===iS)||"Enter"===e||" "===e||""===e}function lE(e=[]){let t=e.map(e=>e?.reference),n=e.map(e=>e?.floating),r=e.map(e=>e?.item),o=C.useCallback(t=>lT(t,e,"reference"),t),a=C.useCallback(t=>lT(t,e,"floating"),n),i=C.useCallback(t=>lT(t,e,"item"),r);return C.useMemo(()=>({getReferenceProps:o,getFloatingProps:a,getItemProps:i}),[o,a,i])}function lT(e,t,n){let r=new Map,o="item"===n,a={};for(let t in"floating"===n&&(a.tabIndex=-1,a[iw]=""),e)o&&e&&(t===i_||t===ik)||(a[t]=e[t]);for(let i=0;i<t.length;i+=1){let l,s=t[i]?.[n];(l="function"==typeof s?e?s(e):null:s)&&lI(a,l,o,r)}return lI(a,e,o,r),a}function lI(e,t,n,r){for(let o in t){let a=t[o];n&&(o===i_||o===ik)||(o.startsWith("on")?(r.has(o)||r.set(o,[]),"function"==typeof a&&(r.get(o)?.push(a),e[o]=(...e)=>r.get(o)?.map(t=>t(...e)).find(e=>void 0!==e))):e[o]=a)}}let lN=C.createContext(void 0);function lL(e){let t=C.useContext(lN);if(void 0===t&&!e)throw Error("Base UI: MenuRootContext is missing. Menu parts must be placed within <Menu.Root>.");return t}let lA=C.createContext(null);function lz(e,t=!1,n=!1){let[r,o]=C.useState(e&&t?"idle":void 0),[a,i]=C.useState(e);return e&&!a&&(i(!0),o("starting")),e||!a||"ending"===r||n||o("ending"),e||a||"ending"!==r||o(void 0),az(()=>{if(!e&&a&&"ending"!==r&&n){let e=iK.request(()=>{o("ending")});return()=>{iK.cancel(e)}}},[e,a,r,n]),az(()=>{if(!e||t)return;let n=iK.request(()=>{ex.flushSync(()=>{o(void 0)})});return()=>{iK.cancel(n)}},[t,e]),az(()=>{if(!e||!t)return;e&&a&&"idle"!==r&&o("starting");let n=iK.request(()=>{o("idle")});return()=>{iK.cancel(n)}},[t,e,a,o,r]),C.useMemo(()=>({mounted:a,setMounted:i,transitionStatus:r}),[a,r])}function lR(e){let{enabled:t=!0,open:n,ref:r,onComplete:o}=e,a=io(n),i=aO(o),l=function(e,t=!1){let n=iY();return aO((r,o=null)=>{let a;if(n.cancel(),null!=e){if("current"in e){if(null==e.current)return;a=e.current}else a=e;"function"!=typeof a.getAnimations||globalThis.BASE_UI_ANIMATIONS_DISABLED?r():n.request(()=>{function e(){a&&Promise.allSettled(a.getAnimations().map(e=>e.finished)).then(()=>{null!=o&&o.aborted||ex.flushSync(r)})}t?n.request(e):e()})}})}(r,n);C.useEffect(()=>{t&&l(()=>{n===a.current&&i()})},[t,n,i,l,a])}let lD=C.createContext(void 0);function lM(e=!0){let t=C.useContext(lD);if(void 0===t&&!e)throw Error("Base UI: DirectionContext is missing.");return t?.direction??"ltr"}function lZ(e){return e?.ownerDocument||document}let lF=()=>{},lU={},lH={},lV="";class lB{lockCount=0;restore=null;timeoutLock=a_.create();timeoutUnlock=a_.create();acquire(e){return this.lockCount+=1,1===this.lockCount&&null===this.restore&&this.timeoutLock.start(0,()=>this.lock(e)),this.release}release=()=>{this.lockCount-=1,0===this.lockCount&&this.restore&&this.timeoutUnlock.start(0,this.unlock)};unlock=()=>{0===this.lockCount&&this.restore&&(this.restore?.(),this.restore=null)};lock(e){let t,n;if(0===this.lockCount||null!==this.restore)return;let r=lZ(e).documentElement,o=aB(r).getComputedStyle(r).overflowY;if("hidden"===o||"clip"===o){this.restore=lF;return}let a=id||!function(e){if("undefined"==typeof document)return!1;let t=lZ(e);return aB(t).innerWidth-t.documentElement.clientWidth>0}(e);this.restore=a?(n=(t=lZ(e).documentElement).style.overflow,t.style.overflow="hidden",()=>{t.style.overflow=n}):function(e){let t=lZ(e),n=t.documentElement,r=t.body,o=aB(n),a=0,i=0,l=iK.create();if(iu&&(o.visualViewport?.scale??1)!==1)return()=>{};function s(){let e=o.getComputedStyle(n),t=o.getComputedStyle(r);a=n.scrollTop,i=n.scrollLeft,lU={scrollbarGutter:n.style.scrollbarGutter,overflowY:n.style.overflowY,overflowX:n.style.overflowX},lV=n.style.scrollBehavior,lH={position:r.style.position,height:r.style.height,width:r.style.width,boxSizing:r.style.boxSizing,overflowY:r.style.overflowY,overflowX:r.style.overflowX,scrollBehavior:r.style.scrollBehavior};let l="undefined"!=typeof CSS&&CSS.supports?.("scrollbar-gutter","stable"),s=n.scrollHeight>n.clientHeight,c=n.scrollWidth>n.clientWidth,u="scroll"===e.overflowY||"scroll"===t.overflowY,d="scroll"===e.overflowX||"scroll"===t.overflowX,f=Math.max(0,o.innerWidth-n.clientWidth),p=Math.max(0,o.innerHeight-n.clientHeight),h=parseFloat(t.marginTop)+parseFloat(t.marginBottom),m=parseFloat(t.marginLeft)+parseFloat(t.marginRight);Object.assign(n.style,{scrollbarGutter:"stable",overflowY:!l&&(s||u)?"scroll":"hidden",overflowX:!l&&(c||d)?"scroll":"hidden"}),Object.assign(r.style,{position:"relative",height:h||p?`calc(100dvh - ${h+p}px)`:"100dvh",width:m||f?`calc(100vw - ${m+f}px)`:"100vw",boxSizing:"border-box",overflow:"hidden",scrollBehavior:"unset"}),r.scrollTop=a,r.scrollLeft=i,n.setAttribute("data-base-ui-scroll-locked",""),n.style.scrollBehavior="unset"}function c(){Object.assign(n.style,lU),Object.assign(r.style,lH),n.scrollTop=a,n.scrollLeft=i,n.removeAttribute("data-base-ui-scroll-locked"),n.style.scrollBehavior=lV}function u(){c(),l.request(s)}return s(),o.addEventListener("resize",u),()=>{l.cancel(),c(),o.removeEventListener("resize",u)}}(e)}}let l$=new lB;function lq(e){if(e)return({"focus-out":"focus-out","escape-key":"escape-key","outside-press":"outside-press","list-navigation":"list-navigation",click:"trigger-press",hover:"trigger-hover",focus:"trigger-focus","reference-press":"trigger-press","safe-polygon":"trigger-hover","ancestor-scroll":void 0})[e]}let lW=C.createContext(void 0);function lK(e=!0){let t=C.useContext(lW);if(void 0===t&&!e)throw Error("Base UI: ContextMenuRootContext is missing. ContextMenu parts must be placed within <ContextMenu.Root>.");return t}let lY=C.createContext(!1);function lG(e,t){return e&&!t?e:!e&&t?t:e||t?{...e,...t}:void 0}let lX={};function lQ(e,t,n,r,o){let a={...l1(e,lX)};return t&&(a=lJ(a,t)),n&&(a=lJ(a,n)),r&&(a=lJ(a,r)),o&&(a=lJ(a,o)),a}function lJ(e,t){return l0(t)?t(e):function(e,t){if(!t)return e;for(let n in t){let r=t[n];switch(n){case"style":e[n]=lG(e.style,r);break;case"className":e[n]=l3(e.className,r);break;default:!function(e,t){let n=e.charCodeAt(0),r=e.charCodeAt(1),o=e.charCodeAt(2);return 111===n&&110===r&&o>=65&&o<=90&&("function"==typeof t||void 0===t)}(n,r)?e[n]=r:e[n]=function(e,t){return t?e?n=>{var r;if(null!=(r=n)&&"object"==typeof r&&"nativeEvent"in r){l2(n);let r=t(n);return n.baseUIHandlerPrevented||e?.(n),r}let o=t(n);return e?.(n),o}:t:e}(e[n],r)}}return e}(e,t)}function l0(e){return"function"==typeof e}function l1(e,t){return l0(e)?e(t):e??lX}function l2(e){return e.preventBaseUIHandler=()=>{e.baseUIHandlerPrevented=!0},e}function l3(e,t){return t?e?t+" "+e:t:e}let l4=[],l5={current:!1},l6=function(e){let t,n,{children:r,open:o,onOpenChange:a,onOpenChangeComplete:i,defaultOpen:l=!1,disabled:s=!1,modal:c,loop:u=!0,orientation:d="vertical",actionsRef:f,openOnHover:p,delay:h=100,closeDelay:m=0,closeParentOnEsc:g=!0}=e,[v,y]=C.useState(null),[b,x]=C.useState(null),[w,_]=C.useState(),[k,j]=C.useState(!0),[O,P]=C.useState(null),[E,T]=C.useState(null),[I,N]=C.useState(!0),[L,A]=C.useState(!1),z=C.useRef(null),R=C.useRef(null),D=C.useRef(null),M=C.useRef([]),Z=C.useRef([]),F=ak(),U=lK(!0),H=C.useContext(lY);{let e=lL(!0),n=function(e){let t=C.useContext(lA);if(null===t&&!e)throw Error("Base UI: MenubarContext is missing. Menubar parts must be placed within <Menubar>.");return t}(!0);t=H&&e?{type:"menu",context:e}:n?{type:"menubar",context:n}:U?{type:"context-menu",context:U}:{type:void 0}}let V=aL();void 0!==t.type&&(V=t.context.rootId);let B=(void 0===t.type||"context-menu"===t.type)&&(c??!0),$="menu"===t.type?t.context.allowMouseEnter:L,q="menu"===t.type?t.context.setAllowMouseEnter:A,W=p??("menu"===t.type||"menubar"===t.type&&t.context.hasSubmenuOpen),[K,Y]=aE({controlled:o,default:l,name:"MenuRoot",state:"open"}),G=C.useRef("context-menu"!==t.type),X=ak();C.useEffect(()=>{if(K||(z.current=null),"context-menu"===t.type){if(!K){X.clear(),G.current=!1;return}X.start(500,()=>{G.current=!0})}},[X,K,t.type]);let Q=C.useCallback(e=>{D.current=e,x(e)},[]),{mounted:J,setMounted:ee,transitionStatus:et}=lz(K),{openMethod:en,triggerProps:er,reset:eo}=function(e){var t;let n,r,[o,a]=C.useState(null),i=aO((t,n)=>{e||a(n)}),l=aO(()=>{a(null)}),{onClick:s,onPointerDown:c}=(t=i,n=C.useRef(""),r=C.useCallback(e=>{e.defaultPrevented||(n.current=e.pointerType,t(e,e.pointerType))},[t]),{onClick:C.useCallback(e=>{0===e.detail?t(e,"keyboard"):("pointerType"in e&&t(e,e.pointerType),t(e,n.current),n.current="")},[t]),onPointerDown:r});return C.useMemo(()=>({openMethod:o,reset:l,triggerProps:{onClick:s,onPointerDown:c}}),[o,l,s,c])}(K);!function(e){let{enabled:t=!0,mounted:n,open:r,referenceElement:o=null}=e;az(()=>{if(t&&iu&&n&&!r){let e=lZ(o),t=e.body.style.userSelect,n=e.body.style.webkitUserSelect;return e.body.style.userSelect="none",e.body.style.webkitUserSelect="none",()=>{e.body.style.userSelect=t,e.body.style.webkitUserSelect=n}}},[t,n,r,o]),az(()=>{if(t)return l$.acquire(o)},[t,o])}({enabled:K&&B&&"trigger-hover"!==E&&"touch"!==en,mounted:J,open:K,referenceElement:b}),K||k||j(!0);let ea=aO(()=>{ee(!1),N(!0),q(!1),i?.(!1),eo()});lR({enabled:!f,open:K,ref:R,onComplete(){K||ea()}});let ei=C.useRef(!0),el=ak(),es=aO((e,n,r)=>{if(K===e||!1===e&&n?.type==="click"&&"touch"===n.pointerType&&!ei.current)return;if(!e&&null!==O){let e=M.current[O];queueMicrotask(()=>{e?.setAttribute("tabindex","-1")})}e&&"trigger-focus"===r?(ei.current=!1,el.start(300,()=>{ei.current=!0})):(ei.current=!0,el.clear());let o=("trigger-press"===r||"item-press"===r)&&0===n.detail&&n?.isTrusted,i=!e&&("escape-key"===r||null==r);function l(){a?.(e,n,r),Y(e),T(r??null),z.current=n??null}"trigger-hover"===r?(N(!0),F.start(500,()=>{N(!1)}),ex.flushSync(l)):l(),"menubar"===t.type&&("trigger-focus"===r||"focus-out"===r||"trigger-hover"===r||"list-navigation"===r||"sibling-open"===r)?_("group"):o||i?_(o?"click":"dismiss"):_(void 0)});C.useImperativeHandle(f,()=>({unmount:ea}),[ea]),"context-menu"===t.type&&(n=t.context),C.useImperativeHandle(n?.positionerRef,()=>b,[b]),C.useImperativeHandle(n?.actionsRef,()=>({setOpen:es}),[es]),C.useEffect(()=>{K||F.clear()},[F,K]);let ec=aU({elements:{reference:v,floating:b},open:K,onOpenChange(e,t,n){es(e,t,lq(n))}}),eu=iF(ec,{enabled:k&&W&&!s&&"context-menu"!==t.type&&("menubar"!==t.type||t.context.hasSubmenuOpen&&!K),handleClose:iB({blockPointerEvents:!0}),mouseOnly:!0,move:"menu"===t.type,restMs:void 0===t.type||"menu"===t.type&&$?h:void 0,delay:"menu"===t.type?{open:$?h:1e10,close:m}:{close:m}}),ed=iq(ec,{enabled:!s&&!K&&"menubar"===t.type&&t.context.hasSubmenuOpen&&!U}),ef=function(e,t={}){let{open:n,onOpenChange:r,dataRef:o}=e,{enabled:a=!0,event:i="click",toggle:l=!0,ignoreMouse:s=!1,stickIfOpen:c=!0}=t,u=C.useRef(void 0),d=iY(),f=C.useMemo(()=>({onPointerDown(e){u.current=e.pointerType},onMouseDown(e){let t=u.current,a=e.nativeEvent;if(0!==e.button||"click"===i||ix(t,!0)&&s)return;let f=o.current.openEvent,p=f?.type,h=!(n&&l&&(!f||!c||"click"===p||"mousedown"===p));d.request(()=>{r(h,a,"click")})},onClick(e){let t=u.current;if("mousedown"===i&&t){u.current=void 0;return}if(ix(t,!0)&&s)return;let a=o.current.openEvent,d=a?.type;r(!(n&&l&&(!a||!c||"click"===d||"mousedown"===d||"keydown"===d||"keyup"===d)),e.nativeEvent,"click")},onKeyDown(){u.current=void 0}}),[o,i,s,r,n,c,l,d]);return C.useMemo(()=>a?{reference:f}:iX,[a,f])}(ec,{enabled:!s&&"context-menu"!==t.type,event:K&&"menubar"===t.type?"click":"mousedown",toggle:!W||"menu"!==t.type,ignoreMouse:W&&"menu"===t.type,stickIfOpen:void 0===t.type&&I}),ep=i3(ec,{enabled:!s,bubbles:g&&"menu"===t.type,outsidePress:()=>"context-menu"!==t.type||z.current?.type==="contextmenu"||G.current}),eh=function(e,t={}){let{open:n,elements:r,floatingId:o}=e,{enabled:a=!0,role:i="dialog"}=t,l=aL(),s=r.domReference?.id||l,c=C.useMemo(()=>iz(r.floating)?.id||o,[r.floating,o]),u=i4.get(i)??i,d=null!=aM(),f=C.useMemo(()=>"tooltip"===u||"label"===i?{[`aria-${"label"===i?"labelledby":"describedby"}`]:n?c:void 0}:{"aria-expanded":n?"true":"false","aria-haspopup":"alertdialog"===u?"dialog":u,"aria-controls":n?c:void 0,..."listbox"===u&&{role:"combobox"},..."menu"===u&&{id:s},..."menu"===u&&d&&{role:"menuitem"},..."select"===i&&{"aria-autocomplete":"none"},..."combobox"===i&&{"aria-autocomplete":"list"}},[u,c,d,n,s,i]),p=C.useMemo(()=>{let e={id:c,...u&&{role:u}};return"tooltip"===u||"label"===i?e:{...e,..."menu"===u&&{"aria-labelledby":s}}},[u,c,s,i]),h=C.useCallback(({active:e,selected:t})=>{let n={role:"option",...e&&{id:`${c}-fui-option`}};switch(i){case"select":case"combobox":return{...n,"aria-selected":t}}return{}},[c,i]);return C.useMemo(()=>a?{reference:f,floating:p,item:h}:{},[a,f,p,h])}(ec,{role:"menu"}),em=lM(),eg=function(e,t){let{open:n,onOpenChange:r,elements:o,floatingId:a}=e,{listRef:i,activeIndex:l,onNavigate:s=()=>{},enabled:c=!0,selectedIndex:u=null,allowEscape:d=!1,loop:f=!1,nested:p=!1,rtl:h=!1,virtual:m=!1,focusItemOnOpen:g="auto",focusItemOnHover:v=!0,openOnArrowKeyDown:y=!0,disabledIndices:b,orientation:x="vertical",parentOrientation:w,cols:_=1,scrollItemIntoView:k=!0,virtualItemRef:j,itemSizes:S,dense:O=!1}=t,P=io(iz(o.floating)),E=aM(),T=C.useContext(aD);az(()=>{e.dataRef.current.orientation=x},[e,x]);let I=iA(o.domReference),N=C.useRef(g),L=C.useRef(u??-1),A=C.useRef(null),z=C.useRef(!0),R=aO(()=>{s(-1===L.current?null:L.current)}),D=C.useRef(R),M=C.useRef(!!o.floating),Z=C.useRef(n),F=C.useRef(!1),U=C.useRef(!1),H=io(b),V=io(n),B=io(k),$=io(u),[q,W]=C.useState(),K=aO(()=>{function e(e){m?(e.id?.endsWith("-fui-option")&&(e.id=`${a}-${Math.random().toString(16).slice(2,10)}`),W(e.id),T?.events.emit("virtualfocus",e),j&&(j.current=e)):lS(e,{sync:F.current,preventScroll:!0})}let t=i.current[L.current],n=U.current;t&&e(t),(F.current?e=>e():requestAnimationFrame)(()=>{let r=i.current[L.current]||t;if(!r)return;t||e(r);let o=B.current;o&&G&&(n||!z.current)&&r.scrollIntoView?.("boolean"==typeof o?{block:"nearest",inline:"nearest"}:o)})});az(()=>{c&&(n&&o.floating?N.current&&null!=u&&(U.current=!0,L.current=u,R()):M.current&&(L.current=-1,D.current()))},[c,n,o.floating,u,R]),az(()=>{if(c&&n&&o.floating)if(null==l){if(F.current=!1,null!=$.current)return;if(M.current&&(L.current=-1,K()),(!Z.current||!M.current)&&N.current&&(null!=A.current||!0===N.current&&null==A.current)){let e=0,t=()=>{null==i.current[0]?(e<2&&(e?requestAnimationFrame:queueMicrotask)(t),e+=1):(L.current=null==A.current||lP(A.current,x,h)||p?lx(i,H.current):lw(i,H.current),A.current=null,R())};t()}}else lb(i,l)||(L.current=l,K(),U.current=!1)},[c,n,o.floating,l,$,p,i,x,h,R,K,H]),az(()=>{if(!c||o.floating||!T||m||!M.current)return;let e=T.nodesRef.current,t=e.find(e=>e.id===E)?.context?.elements.floating,n=iP(iN(o.floating)),r=e.some(e=>e.context&&iE(e.context.elements.floating,n));t&&!r&&z.current&&t.focus({preventScroll:!0})},[c,o.floating,T,E,m]),az(()=>{D.current=R,Z.current=n,M.current=!!o.floating}),az(()=>{n||(A.current=null,N.current=g)},[n,g]);let Y=null!=l,G=C.useMemo(()=>{function e(e){if(!V.current)return;let t=i.current.indexOf(e);-1!==t&&L.current!==t&&(L.current=t,R())}return{onFocus({currentTarget:t}){F.current=!0,e(t)},onClick:({currentTarget:e})=>e.focus({preventScroll:!0}),onMouseMove({currentTarget:t}){F.current=!0,U.current=!1,v&&e(t)},onPointerLeave({pointerType:e}){!z.current||"touch"===e||(F.current=!0,v&&(L.current=-1,R(),m||P.current?.focus({preventScroll:!0})))}}},[V,P,v,i,R,m]),X=C.useCallback(()=>w??T?.nodesRef.current.find(e=>e.id===E)?.context?.dataRef?.current.orientation,[E,T,w]),Q=aO(e=>{var t,a,l,s,c,u,g,v;if(z.current=!1,F.current=!0,229===e.which||!V.current&&e.currentTarget===P.current)return;if(p&&(t=e.key,a=x,l=h,s=_,"both"===a||"horizontal"===a&&s&&s>1?"Escape"===t:lO(a,l?t===iS:t===ij,t===iO))){lC(e.key,X())||iv(e),r(!1,e.nativeEvent,"list-navigation"),aK(o.domReference)&&(m?T?.events.emit("virtualfocus",o.domReference):o.domReference.focus());return}let y=L.current,w=lx(i,b),k=lw(i,b);if(I||("Home"===e.key&&(iv(e),L.current=w,R()),"End"===e.key&&(iv(e),L.current=k,R())),_>1){let t,n,r=S||Array.from({length:i.current.length},()=>({width:1,height:1})),o=(c=r,u=_,g=O,t=[],n=0,c.forEach(({width:e,height:r},o)=>{let a=!1;for(g&&(n=0);!a;){let i=[];for(let t=0;t<e;t+=1)for(let e=0;e<r;e+=1)i.push(n+t+e*u);n%u+e<=u&&i.every(e=>null==t[e])?(i.forEach(e=>{t[e]=o}),a=!0):n+=1}}),[...t]),a=o.findIndex(e=>null!=e&&!lk(i,e,b)),l=o.reduce((e,t,n)=>null==t||lk(i,t,b)?e:n,-1),s=o[function(e,{event:t,orientation:n,loop:r,rtl:o,cols:a,disabledIndices:i,minIndex:l,maxIndex:s,prevIndex:c,stopEvent:u=!1}){let d=c;if(t.key===iO){if(u&&iv(t),-1===c)d=s;else if(d=l_(e,{startingIndex:d,amount:a,decrement:!0,disabledIndices:i}),r&&(c-a<l||d<0)){let e=c%a,t=s%a,n=s-(t-e);d=t===e?s:t>e?n:n-a}lb(e,d)&&(d=c)}if(t.key===iC&&(u&&iv(t),-1===c?d=l:(d=l_(e,{startingIndex:c,amount:a,disabledIndices:i}),r&&c+a>s&&(d=l_(e,{startingIndex:c%a-a,amount:a,disabledIndices:i}))),lb(e,d)&&(d=c)),"both"===n){let n=i7(c/a);t.key===(o?ij:iS)&&(u&&iv(t),c%a!=a-1?(d=l_(e,{startingIndex:c,disabledIndices:i}),r&&ly(d,a,n)&&(d=l_(e,{startingIndex:c-c%a-1,disabledIndices:i}))):r&&(d=l_(e,{startingIndex:c-c%a-1,disabledIndices:i})),ly(d,a,n)&&(d=c)),t.key===(o?iS:ij)&&(u&&iv(t),c%a!=0?(d=l_(e,{startingIndex:c,decrement:!0,disabledIndices:i}),r&&ly(d,a,n)&&(d=l_(e,{startingIndex:c+(a-c%a),decrement:!0,disabledIndices:i}))):r&&(d=l_(e,{startingIndex:c+(a-c%a),decrement:!0,disabledIndices:i})),ly(d,a,n)&&(d=c));let l=i7(s/a)===n;lb(e,d)&&(d=r&&l?t.key===(o?iS:ij)?s:l_(e,{startingIndex:c-c%a-1,disabledIndices:i}):c)}return d}({current:o.map(e=>null!=e?i.current[e]:null)},{event:e,orientation:x,loop:f,rtl:h,cols:_,disabledIndices:(v=[...("function"!=typeof b?b:null)||i.current.map((e,t)=>lk(i,t,b)?t:void 0),void 0],o.flatMap((e,t)=>v.includes(e)?[t]:[])),minIndex:a,maxIndex:l,prevIndex:function(e,t,n,r,o){if(-1===e)return -1;let a=n.indexOf(e),i=t[e];switch(o){case"tl":return a;case"tr":if(!i)return a;return a+i.width-1;case"bl":if(!i)return a;return a+(i.height-1)*r;case"br":return n.lastIndexOf(e);default:return -1}}(L.current>k?w:L.current,r,o,_,e.key===iC?"bl":e.key===(h?ij:iS)?"tr":"tl"),stopEvent:!0})];if(null!=s&&(L.current=s,R()),"both"===x)return}if(lC(e.key,x)){if(iv(e),n&&!m&&iP(e.currentTarget.ownerDocument)===e.currentTarget){L.current=lP(e.key,x,h)?w:k,R();return}lP(e.key,x,h)?f?L.current=y>=k?d&&y!==i.current.length?-1:w:l_(i,{startingIndex:y,disabledIndices:b}):L.current=Math.min(k,l_(i,{startingIndex:y,disabledIndices:b})):f?L.current=y<=w?d&&-1!==y?i.current.length:k:l_(i,{startingIndex:y,decrement:!0,disabledIndices:b}):L.current=Math.max(w,l_(i,{startingIndex:y,decrement:!0,disabledIndices:b})),lb(i,L.current)&&(L.current=-1),R()}}),J=C.useMemo(()=>m&&n&&Y&&{"aria-activedescendant":q},[m,n,Y,q]),ee=C.useMemo(()=>({"aria-orientation":"both"===x?void 0:x,...!I?J:{},onKeyDown(e){if("Tab"===e.key&&e.shiftKey&&n&&!m){iv(e),r(!1,e.nativeEvent,"list-navigation"),aK(o.domReference)&&o.domReference.focus();return}Q(e)},onPointerMove(){z.current=!0}}),[J,Q,x,I,r,n,m,o.domReference]),et=C.useMemo(()=>{function e(e){"auto"===g&&iy(e.nativeEvent)&&(N.current=!0)}function t(e){N.current=g,"auto"===g&&ib(e.nativeEvent)&&(N.current=!0)}return{...J,onKeyDown(e){var t,o;z.current=!1;let a=e.key.startsWith("Arrow"),l=(t=e.key,o=X(),lO(o,h?t===ij:t===iS,t===iC)),s=lC(e.key,x),c=(p?l:s)||"Enter"===e.key||""===e.key.trim();if(m&&n)return Q(e);if(n||y||!a){if(c){let t=lC(e.key,X());A.current=p&&t?null:e.key}if(p){l&&(iv(e),n?(L.current=lx(i,H.current),R()):r(!0,e.nativeEvent,"list-navigation"));return}s&&(null!=u&&(L.current=u),iv(e),!n&&y?r(!0,e.nativeEvent,"list-navigation"):Q(e),n&&R())}},onFocus(){n&&!m&&(L.current=-1,R())},onPointerDown:t,onPointerEnter:t,onMouseDown:e,onClick:e}},[J,Q,H,g,i,p,R,r,n,y,x,X,h,u,m]);return C.useMemo(()=>c?{reference:et,floating:ee,item:G}:{},[c,et,ee,G])}(ec,{enabled:!s,listRef:M,activeIndex:O,nested:void 0!==t.type,loop:u,orientation:d,parentOrientation:"menubar"===t.type?t.context.orientation:void 0,rtl:"rtl"===em,disabledIndices:l4,onNavigate:P,openOnArrowKeyDown:"context-menu"!==t.type}),ev=C.useRef(!1),ey=function(e,t){let{open:n,dataRef:r}=e,{listRef:o,activeIndex:a,onMatch:i,onTypingChange:l,enabled:s=!0,findMatch:c=null,resetMs:u=750,ignoreKeys:d=[],selectedIndex:f=null}=t,p=ak(),h=C.useRef(""),m=C.useRef(f??a??-1),g=C.useRef(null),v=aO(i),y=aO(l),b=io(c),x=io(d);az(()=>{n&&(p.clear(),g.current=null,h.current="")},[n,p]),az(()=>{n&&""===h.current&&(m.current=f??a??-1)},[n,f,a]);let w=aO(e=>{e?r.current.typing||(r.current.typing=e,y(e)):r.current.typing&&(r.current.typing=e,y(e))}),_=aO(e=>{function t(e,t,n){let r=b.current?b.current(t,n):t.find(e=>e?.toLocaleLowerCase().indexOf(n.toLocaleLowerCase())===0);return r?e.indexOf(r):-1}let r=o.current;if(h.current.length>0&&" "!==h.current[0]&&(-1===t(r,r,h.current)?w(!1):" "===e.key&&iv(e)),null==r||x.current.includes(e.key)||1!==e.key.length||e.ctrlKey||e.metaKey||e.altKey)return;n&&" "!==e.key&&(iv(e),w(!0)),r.every(e=>!e||e[0]?.toLocaleLowerCase()!==e[1]?.toLocaleLowerCase())&&h.current===e.key&&(h.current="",m.current=g.current),h.current+=e.key,p.start(u,()=>{h.current="",m.current=g.current,w(!1)});let a=m.current,i=t(r,[...r.slice((a||0)+1),...r.slice(0,(a||0)+1)],h.current);-1!==i?(v(i),g.current=i):" "!==e.key&&(h.current="",w(!1))}),k=C.useMemo(()=>({onKeyDown:_}),[_]),j=C.useMemo(()=>({onKeyDown:_,onKeyUp(e){" "===e.key&&w(!1)}}),[_,w]);return C.useMemo(()=>s?{reference:k,floating:j}:{},[s,k,j])}(ec,{listRef:Z,activeIndex:O,resetMs:500,onMatch:e=>{K&&e!==O&&P(e)},onTypingChange:C.useCallback(e=>{ev.current=e},[])}),{getReferenceProps:eb,getFloatingProps:ew,getItemProps:e_}=lE([eu,ef,ep,ed,eh,eg,ey]),ek=function(e){let{enabled:t=!0,mouseDownAction:n,open:r}=e,o=C.useRef(!1);return C.useMemo(()=>t?{onMouseDown:e=>{("open"===n&&!r||"close"===n&&r)&&(o.current=!0,lZ(e.currentTarget).addEventListener("click",()=>{o.current=!1},{once:!0}))},onClick:e=>{o.current&&(o.current=!1,e.preventBaseUIHandler())}}:iX,[t,n,r])}({open:K,enabled:"menubar"===t.type,mouseDownAction:"open"}),ej=C.useMemo(()=>{let e=lQ(eb(),{onMouseEnter(){j(!0)},onMouseMove(){q(!0)}},er,ek);return delete e.role,e},[eb,ek,q,er]),eS=C.useMemo(()=>ew({onMouseEnter(){W&&"menu"!==t.type||j(!1)},onMouseMove(){q(!0)},onClick(){W&&j(!1)}}),[ew,W,t.type,q]),eO=C.useMemo(()=>e_(),[e_]),eC=C.useMemo(()=>({activeIndex:O,setActiveIndex:P,allowMouseUpTriggerRef:t.type?t.context.allowMouseUpTriggerRef:l5,floatingRootContext:ec,itemProps:eO,popupProps:eS,triggerProps:ej,itemDomElements:M,itemLabels:Z,mounted:J,open:K,popupRef:R,positionerRef:D,setOpen:es,setPositionerElement:Q,triggerElement:v,setTriggerElement:y,transitionStatus:et,lastOpenChangeReason:E,instantType:w,onOpenChangeComplete:i,setHoverEnabled:j,typingRef:ev,modal:B,disabled:s,parent:t,rootId:V,allowMouseEnter:$,setAllowMouseEnter:q}),[O,ec,eO,eS,ej,M,Z,J,K,D,es,et,v,Q,E,w,i,B,s,t,V,$,q]),eP=(0,S.jsx)(lN.Provider,{value:eC,children:r});return void 0===t.type||"context-menu"===t.type?(0,S.jsx)(aF,{children:eP}):eP};function l9(e,t,n,r){var o,a,i,l,s;let c=ab(l8).current;return o=c,a=e,i=t,l=n,s=r,(o.refs[0]!==a||o.refs[1]!==i||o.refs[2]!==l||o.refs[3]!==s)&&l7(c,[e,t,n,r]),c.callback}function l8(){return{callback:null,cleanup:null,refs:[]}}function l7(e,t){if(e.refs=t,t.every(e=>null==e)){e.callback=null;return}e.callback=n=>{if(e.cleanup&&(e.cleanup(),e.cleanup=null),null!=n){let r=Array(t.length).fill(null);for(let e=0;e<t.length;e+=1){let o=t[e];if(null!=o)switch(typeof o){case"function":{let t=o(n);"function"==typeof t&&(r[e]=t);break}case"object":o.current=n}}e.cleanup=()=>{for(let e=0;e<t.length;e+=1){let n=t[e];if(null!=n)switch(typeof n){case"function":{let t=r[e];"function"==typeof t?t():n(null);break}case"object":n.current=null}}}}}}let se=((t={}).startingStyle="data-starting-style",t.endingStyle="data-ending-style",t),st={[se.startingStyle]:""},sn={[se.endingStyle]:""},sr={transitionStatus:e=>"starting"===e?st:"ending"===e?sn:null},so=((n={}).open="data-open",n.closed="data-closed",n[n.startingStyle=se.startingStyle]="startingStyle",n[n.endingStyle=se.endingStyle]="endingStyle",n.anchorHidden="data-anchor-hidden",n),sa=((r={}).popupOpen="data-popup-open",r.pressed="data-pressed",r),si={[sa.popupOpen]:""},sl={[sa.popupOpen]:"",[sa.pressed]:""},ss={[so.open]:""},sc={[so.closed]:""},su={[so.anchorHidden]:""},sd={open:e=>e?si:null},sf={open:e=>e?sl:null},sp={open:e=>e?ss:sc,anchorHidden:e=>e?su:null},sh=parseInt(C.version,10);function sm(e,t,n={}){let r=t.render,o=function(e,t={}){var n,r,o,a,i;let l,{className:s,render:c}=e,{state:u=iX,ref:d,props:f,disableStyleHooks:p,customStyleHookMapping:h,enabled:m=!0}=t,g=m?(n=s,r=u,"function"==typeof n?n(r):n):void 0;!0!==p&&(l=C.useMemo(()=>m?function(e,t){let n={};for(let r in e){let o=e[r];if(t?.hasOwnProperty(r)){let e=t[r](o);null!=e&&Object.assign(n,e);continue}!0===o?n[`data-${r.toLowerCase()}`]="":o&&(n[`data-${r.toLowerCase()}`]=o.toString())}return n}(u,h):iX,[u,h,m]));let v=m?lG(l,Array.isArray(f)?function(e){if(0===e.length)return lX;if(1===e.length)return l1(e[0],lX);let t={...l1(e[0],lX)};for(let n=1;n<e.length;n+=1)t=lJ(t,e[n]);return t}(f):f)??iX:iX;if("undefined"!=typeof document)if(m)if(Array.isArray(d)){let e;o=[v.ref,sg(c),...d],a=e=ab(l8).current,i=o,(a.refs.length!==i.length||a.refs.some((e,t)=>e!==i[t]))&&l7(e,o),v.ref=e.callback}else v.ref=l9(v.ref,sg(c),d);else l9(null,null);return m?(void 0!==g&&(v.className=l3(v.className,g)),v):iX}(t,n);return!1===n.enabled?null:function(e,t,n,r){if(t){if("function"==typeof t)return t(n,r);let e=lQ(n,t.props);return e.ref=n.ref,C.cloneElement(t,e)}if(e&&"string"==typeof e){var o,a;return o=e,a=n,"button"===o?(0,S.jsx)("button",{type:"button",...a}):"img"===o?(0,S.jsx)("img",{alt:"",...a}):C.createElement(o,a)}throw Error("Base UI: Render element or function are not defined.")}(e,r,o,n.state??iX)}function sg(e){return e&&"function"!=typeof e?sh>=19?e.props.ref:e.ref:null}let sv=C.createContext(void 0);function sy(e=!1){let t=C.useContext(sv);if(void 0===t&&!e)throw Error("Base UI: CompositeRootContext is missing. Composite parts must be placed within <Composite.Root>.");return t}function sb(e={}){let{disabled:t=!1,focusableWhenDisabled:n,tabIndex:r=0,native:o=!0}=e,a=C.useRef(null),i=void 0!==sy(!0),l=aO(()=>{let e=a.current;return!!(e?.tagName==="A"&&e?.href)}),{props:s}=function(e){let{focusableWhenDisabled:t,disabled:n,composite:r=!1,tabIndex:o=0,isNativeButton:a}=e,i=r&&!1!==t,l=r&&!1===t;return{props:C.useMemo(()=>{let e={onKeyDown(e){n&&t&&"Tab"!==e.key&&e.preventDefault()}};return r||(e.tabIndex=o,!a&&n&&(e.tabIndex=t?o:-1)),(a&&(t||i)||!a&&n)&&(e["aria-disabled"]=n),a&&(!t||l)&&(e.disabled=n),e},[r,n,t,i,l,a,o])}}({focusableWhenDisabled:n,disabled:t,composite:i,tabIndex:r,isNativeButton:o});return az(()=>{let e=a.current;e instanceof HTMLButtonElement&&i&&t&&void 0===s.disabled&&e.disabled&&(e.disabled=!1)},[t,s.disabled,i]),{getButtonProps:C.useCallback((e={})=>{let{onClick:n,onMouseDown:r,onKeyUp:a,onKeyDown:i,onPointerDown:c,...u}=e;return lQ({type:o?"button":void 0,onClick(e){t?e.preventDefault():n?.(e)},onMouseDown(e){t||r?.(e)},onKeyDown(e){if(t||(l2(e),i?.(e)),e.baseUIHandlerPrevented)return;let r=e.target===e.currentTarget&&!o&&!l()&&!t,a="Enter"===e.key,s=" "===e.key;r&&((s||a)&&e.preventDefault(),a&&n?.(e))},onKeyUp(e){t||(l2(e),a?.(e)),!e.baseUIHandlerPrevented&&(e.target!==e.currentTarget||o||t||" "!==e.key||n?.(e))},onPointerDown(e){t?e.preventDefault():c?.(e)}},o?void 0:{role:"button"},s,u)},[t,s,o,l]),buttonRef:a}}let sx=C.createContext({register:()=>{},unregister:()=>{},subscribeMapChange:()=>()=>{},elementsRef:{current:[]},nextIndexRef:{current:0}}),sw=((o={})[o.None=0]="None",o[o.GuessFromOrder=1]="GuessFromOrder",o);function s_(e={}){let{label:t,metadata:n,textRef:r,indexGuessBehavior:o}=e,{register:a,unregister:i,subscribeMapChange:l,elementsRef:s,labelsRef:c,nextIndexRef:u}=C.useContext(sx),d=C.useRef(-1),[f,p]=C.useState(o===sw.GuessFromOrder?()=>{if(-1===d.current){let e=u.current;u.current+=1,d.current=e}return d.current}:-1),h=C.useRef(null),m=C.useCallback(e=>{if(h.current=e,-1!==f&&null!==e&&(s.current[f]=e,c)){let n=void 0!==t;c.current[f]=n?t:r?.current?.textContent??e.textContent}},[f,s,c,t,r]);return az(()=>{let e=h.current;if(e)return a(e,n),()=>{i(e)}},[a,i,n]),az(()=>l(e=>{let t=h.current?e.get(h.current)?.index:null;null!=t&&p(t)}),[l,p]),C.useMemo(()=>({ref:m,index:f}),[f,m])}function sk(e){let{render:t,className:n,state:r=iX,props:o=iQ,refs:a=iQ,metadata:i,customStyleHookMapping:l,tag:s="div",...c}=e,{compositeProps:u,compositeRef:d}=function(e={}){let{highlightItemOnHover:t,highlightedIndex:n,onHighlightedIndexChange:r}=sy(),{ref:o,index:a}=s_(e),i=n===a,l=C.useRef(null),s=l9(o,l);return{compositeProps:C.useMemo(()=>({tabIndex:i?0:-1,onFocus(){r(a)},onMouseMove(){let e=l.current;if(!t||!e)return;let n=e.hasAttribute("disabled")||"true"===e.ariaDisabled;i||n||e.focus()}}),[i,r,a,t]),compositeRef:s,index:a}}({metadata:i});return sm(s,e,{state:r,ref:[...a,d],props:[u,...o,c],customStyleHookMapping:l})}let sj=C.forwardRef(function(e,t){let{render:n,className:r,disabled:o=!1,nativeButton:a=!0,...i}=e,{triggerProps:l,disabled:s,setTriggerElement:c,open:u,allowMouseUpTriggerRef:d,positionerRef:f,parent:p,lastOpenChangeReason:h,rootId:m}=lL(),g=o||s,v=C.useRef(null),y=ak(),{getButtonProps:b,buttonRef:x}=sb({disabled:g,native:a}),w=l9(x,c),{events:_}=C.useContext(aD);C.useEffect(()=>{u||void 0!==p.type||(d.current=!1)},[d,u,p.type]);let k=aO(e=>{if(!v.current)return;y.clear(),d.current=!1;let t=e.target;if(iE(v.current,t)||iE(f.current,t)||t===v.current||null!=t&&function e(t){return aK(t)&&t.hasAttribute("data-rootownerid")?t.getAttribute("data-rootownerid")??void 0:a9(t)?void 0:e(ie(t))}(t)===m)return;let n=function(e){let t=e.getBoundingClientRect(),n=window.getComputedStyle(e,"::before"),r=window.getComputedStyle(e,"::after");if("none"===n.content&&"none"===r.content)return t;let o=parseFloat(n.width)||0,a=parseFloat(n.height)||0,i=parseFloat(r.width)||0,l=parseFloat(r.height)||0,s=Math.max(t.width,o,i),c=Math.max(t.height,a,l),u=s-t.width,d=c-t.height;return{left:t.left-u/2,right:t.right+u/2,top:t.top-d/2,bottom:t.bottom+d/2}}(v.current);e.clientX>=n.left-2&&e.clientX<=n.right+2&&e.clientY>=n.top-2&&e.clientY<=n.bottom+2||_.emit("close",{domEvent:e,reason:"cancel-open"})});C.useEffect(()=>{u&&"trigger-hover"===h&&lZ(v.current).addEventListener("mouseup",k,{once:!0})},[u,k,h]);let j="menubar"===p.type,O=C.useCallback(e=>lQ(j?{role:"menuitem"}:{},{"aria-haspopup":"menu",ref:w,onMouseDown:e=>{u||(y.start(200,()=>{d.current=!0}),lZ(e.currentTarget).addEventListener("mouseup",k,{once:!0}))}},e,b),[b,w,u,d,y,k,j]),P=C.useMemo(()=>({disabled:g,open:u}),[g,u]),E=[v,t,x],T=[l,i,O],I=sm("button",e,{enabled:!j,customStyleHookMapping:sf,state:P,ref:E,props:T});return j?(0,S.jsx)(sk,{tag:"button",render:n,className:r,state:P,refs:E,props:T,customStyleHookMapping:sf}):I}),sS={clip:"rect(0 0 0 0)",overflow:"hidden",whiteSpace:"nowrap",position:"fixed",top:0,left:0,border:0,padding:0,width:1,height:1,margin:-1},sO=C.forwardRef(function(e,t){let[n,r]=C.useState();return az(()=>{ip&&r("button")},[]),(0,S.jsx)("span",{...e,ref:t,tabIndex:0,role:n,"aria-hidden":!n||void 0,style:sS,"data-base-ui-focus-guard":""})});var sC='input:not([inert]),select:not([inert]),textarea:not([inert]),a[href]:not([inert]),button:not([inert]),[tabindex]:not(slot):not([inert]),audio[controls]:not([inert]),video[controls]:not([inert]),[contenteditable]:not([contenteditable="false"]):not([inert]),details>summary:first-of-type:not([inert]),details:not([inert])',sP="undefined"==typeof Element,sE=sP?function(){}:Element.prototype.matches||Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector,sT=!sP&&Element.prototype.getRootNode?function(e){var t;return null==e||null==(t=e.getRootNode)?void 0:t.call(e)}:function(e){return null==e?void 0:e.ownerDocument},sI=function e(t,n){void 0===n&&(n=!0);var r,o=null==t||null==(r=t.getAttribute)?void 0:r.call(t,"inert");return""===o||"true"===o||n&&t&&e(t.parentNode)},sN=function(e){var t,n=null==e||null==(t=e.getAttribute)?void 0:t.call(e,"contenteditable");return""===n||"true"===n},sL=function(e,t,n){if(sI(e))return[];var r=Array.prototype.slice.apply(e.querySelectorAll(sC));return t&&sE.call(e,sC)&&r.unshift(e),r=r.filter(n)},sA=function e(t,n,r){for(var o=[],a=Array.from(t);a.length;){var i=a.shift();if(!sI(i,!1))if("SLOT"===i.tagName){var l=i.assignedElements(),s=e(l.length?l:i.children,!0,r);r.flatten?o.push.apply(o,s):o.push({scopeParent:i,candidates:s})}else{sE.call(i,sC)&&r.filter(i)&&(n||!t.includes(i))&&o.push(i);var c=i.shadowRoot||"function"==typeof r.getShadowRoot&&r.getShadowRoot(i),u=!sI(c,!1)&&(!r.shadowRootFilter||r.shadowRootFilter(i));if(c&&u){var d=e(!0===c?i.children:c.children,!0,r);r.flatten?o.push.apply(o,d):o.push({scopeParent:i,candidates:d})}else a.unshift.apply(a,i.children)}}return o},sz=function(e){return!isNaN(parseInt(e.getAttribute("tabindex"),10))},sR=function(e){if(!e)throw Error("No node provided");return e.tabIndex<0&&(/^(AUDIO|VIDEO|DETAILS)$/.test(e.tagName)||sN(e))&&!sz(e)?0:e.tabIndex},sD=function(e,t){var n=sR(e);return n<0&&t&&!sz(e)?0:n},sM=function(e,t){return e.tabIndex===t.tabIndex?e.documentOrder-t.documentOrder:e.tabIndex-t.tabIndex},sZ=function(e){return"INPUT"===e.tagName},sF=function(e,t){for(var n=0;n<e.length;n++)if(e[n].checked&&e[n].form===t)return e[n]},sU=function(e){if(!e.name)return!0;var t,n=e.form||sT(e),r=function(e){return n.querySelectorAll('input[type="radio"][name="'+e+'"]')};if("undefined"!=typeof window&&void 0!==window.CSS&&"function"==typeof window.CSS.escape)t=r(window.CSS.escape(e.name));else try{t=r(e.name)}catch(e){return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s",e.message),!1}var o=sF(t,e.form);return!o||o===e},sH=function(e){var t;return sZ(t=e)&&"radio"===t.type&&!sU(e)},sV=function(e){var t,n,r,o,a,i,l,s=e&&sT(e),c=null==(t=s)?void 0:t.host,u=!1;if(s&&s!==e)for(u=!!(null!=(n=c)&&null!=(r=n.ownerDocument)&&r.contains(c)||null!=e&&null!=(o=e.ownerDocument)&&o.contains(e));!u&&c;)u=!!(null!=(i=c=null==(a=s=sT(c))?void 0:a.host)&&null!=(l=i.ownerDocument)&&l.contains(c));return u},sB=function(e){var t=e.getBoundingClientRect(),n=t.width,r=t.height;return 0===n&&0===r},s$=function(e,t){var n=t.displayCheck,r=t.getShadowRoot;if("hidden"===getComputedStyle(e).visibility)return!0;var o=sE.call(e,"details>summary:first-of-type")?e.parentElement:e;if(sE.call(o,"details:not([open]) *"))return!0;if(n&&"full"!==n&&"legacy-full"!==n){if("non-zero-area"===n)return sB(e)}else{if("function"==typeof r){for(var a=e;e;){var i=e.parentElement,l=sT(e);if(i&&!i.shadowRoot&&!0===r(i))return sB(e);e=e.assignedSlot?e.assignedSlot:i||l===e.ownerDocument?i:l.host}e=a}if(sV(e))return!e.getClientRects().length;if("legacy-full"!==n)return!0}return!1},sq=function(e){if(/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(e.tagName))for(var t=e.parentElement;t;){if("FIELDSET"===t.tagName&&t.disabled){for(var n=0;n<t.children.length;n++){var r=t.children.item(n);if("LEGEND"===r.tagName)return!!sE.call(t,"fieldset[disabled] *")||!r.contains(e)}return!0}t=t.parentElement}return!1},sW=function(e,t){var n,r;return!(t.disabled||sI(t)||sZ(n=t)&&"hidden"===n.type||s$(t,e)||"DETAILS"===(r=t).tagName&&Array.prototype.slice.apply(r.children).some(function(e){return"SUMMARY"===e.tagName})||sq(t))},sK=function(e,t){return!(sH(t)||0>sR(t))&&!!sW(e,t)},sY=function(e){var t=parseInt(e.getAttribute("tabindex"),10);return!!isNaN(t)||!!(t>=0)},sG=function e(t){var n=[],r=[];return t.forEach(function(t,o){var a=!!t.scopeParent,i=a?t.scopeParent:t,l=sD(i,a),s=a?e(t.candidates):i;0===l?a?n.push.apply(n,s):n.push(i):r.push({documentOrder:o,tabIndex:l,item:t,isScope:a,content:s})}),r.sort(sM).reduce(function(e,t){return t.isScope?e.push.apply(e,t.content):e.push(t.content),e},[]).concat(n)},sX=function(e,t){return sG((t=t||{}).getShadowRoot?sA([e],t.includeContainer,{filter:sK.bind(null,t),flatten:!1,getShadowRoot:t.getShadowRoot,shadowRootFilter:sY}):sL(e,t.includeContainer,sK.bind(null,t)))},sQ=function(e,t){return(t=t||{}).getShadowRoot?sA([e],t.includeContainer,{filter:sW.bind(null,t),flatten:!0,getShadowRoot:t.getShadowRoot}):sL(e,t.includeContainer,sW.bind(null,t))},sJ=function(e,t){if(t=t||{},!e)throw Error("No node provided");return!1!==sE.call(e,sC)&&sK(t,e)};let s0=()=>({getShadowRoot:!0,displayCheck:"function"==typeof ResizeObserver&&ResizeObserver.toString().includes("[native code]")?"full":"none"});function s1(e,t){let n=sX(e,s0()),r=n.length;if(0===r)return;let o=iP(iN(e)),a=n.indexOf(o);return n[-1===a?1===t?0:r-1:a+t]}function s2(e){return s1(iN(e).body,1)||e}function s3(e){return s1(iN(e).body,-1)||e}function s4(e,t){let n=t||e.currentTarget,r=e.relatedTarget;return!r||!iE(n,r)}function s5(e){sX(e,s0()).forEach(e=>{e.dataset.tabindex=e.getAttribute("tabindex")||"",e.setAttribute("tabindex","-1")})}function s6(e){e.querySelectorAll("[data-tabindex]").forEach(e=>{let t=e.dataset.tabindex;delete e.dataset.tabindex,t?e.setAttribute("tabindex",t):e.removeAttribute("tabindex")})}let s9=C.createContext(null),s8=iR("portal");function s7(e={}){let{id:t,root:n}=e,r=aL(),o=C.useContext(s9),[a,i]=C.useState(null),l=C.useRef(null);return az(()=>()=>{a?.remove(),queueMicrotask(()=>{l.current=null})},[a]),az(()=>{if(!r||l.current)return;let e=t?document.getElementById(t):null;if(!e)return;let n=document.createElement("div");n.id=r,n.setAttribute(s8,""),e.appendChild(n),l.current=n,i(n)},[t,r]),az(()=>{if(null===n||!r||l.current)return;let e=n||o?.portalNode;e&&!aq(e)&&(e=e.current),e=e||document.body;let a=null;t&&((a=document.createElement("div")).id=t,e.appendChild(a));let s=document.createElement("div");s.id=r,s.setAttribute(s8,""),(e=a||e).appendChild(s),l.current=s,i(s)},[t,n,r,o]),a}function ce(e){let{children:t,id:n,root:r,preserveTabOrder:o=!0}=e,a=s7({id:n,root:r}),[i,l]=C.useState(null),s=C.useRef(null),c=C.useRef(null),u=C.useRef(null),d=C.useRef(null),f=i?.modal,p=i?.open,h=!!i&&!i.modal&&i.open&&o&&!!(r||a);return C.useEffect(()=>{if(a&&o&&!f)return a.addEventListener("focusin",e,!0),a.addEventListener("focusout",e,!0),()=>{a.removeEventListener("focusin",e,!0),a.removeEventListener("focusout",e,!0)};function e(e){if(a&&s4(e)){let t="focusin"===e.type;(t?s6:s5)(a)}}},[a,o,f]),C.useEffect(()=>{!a||p||s6(a)},[p,a]),(0,S.jsxs)(s9.Provider,{value:C.useMemo(()=>({preserveTabOrder:o,beforeOutsideRef:s,afterOutsideRef:c,beforeInsideRef:u,afterInsideRef:d,portalNode:a,setFocusManagerState:l}),[o,a]),children:[h&&a&&(0,S.jsx)(sO,{"data-type":"outside",ref:s,onFocus:e=>{if(s4(e,a))u.current?.focus();else{let e=s3(i?i.domReference:null);e?.focus()}}}),h&&a&&(0,S.jsx)("span",{"aria-owns":a.id,style:sS}),a&&ex.createPortal(t,a),h&&a&&(0,S.jsx)(sO,{"data-type":"outside",ref:c,onFocus:e=>{if(s4(e,a))d.current?.focus();else{let t=s2(i?i.domReference:null);t?.focus(),i?.closeOnFocusOut&&i?.onOpenChange(!1,e.nativeEvent,"focus-out")}}})]})}let ct=C.createContext(void 0);function cn(e){let{children:t,keepMounted:n=!1,container:r}=e,{mounted:o}=lL();return o||n?(0,S.jsx)(ct.Provider,{value:n,children:(0,S.jsx)(ce,{root:r,children:t})}):null}let cr=C.createContext(void 0);function co(e,t,n){let r,{reference:o,floating:a}=e,i=lc(t),l=li(lc(t)),s=ll(l),c=lo(t),u="y"===i,d=o.x+o.width/2-a.width/2,f=o.y+o.height/2-a.height/2,p=o[s]/2-a[s]/2;switch(c){case"top":r={x:d,y:o.y-a.height};break;case"bottom":r={x:d,y:o.y+o.height};break;case"right":r={x:o.x+o.width,y:f};break;case"left":r={x:o.x-a.width,y:f};break;default:r={x:o.x,y:o.y}}switch(la(t)){case"start":r[l]-=p*(n&&u?-1:1);break;case"end":r[l]+=p*(n&&u?-1:1)}return r}let ca=async(e,t,n)=>{let{placement:r="bottom",strategy:o="absolute",middleware:a=[],platform:i}=n,l=a.filter(Boolean),s=await (null==i.isRTL?void 0:i.isRTL(t)),c=await i.getElementRects({reference:e,floating:t,strategy:o}),{x:u,y:d}=co(c,r,s),f=r,p={},h=0;for(let n=0;n<l.length;n++){let{name:a,fn:m}=l[n],{x:g,y:v,data:y,reset:b}=await m({x:u,y:d,initialPlacement:r,placement:f,strategy:o,middlewareData:p,rects:c,platform:i,elements:{reference:e,floating:t}});u=null!=g?g:u,d=null!=v?v:d,p={...p,[a]:{...p[a],...y}},b&&h<=50&&(h++,"object"==typeof b&&(b.placement&&(f=b.placement),b.rects&&(c=!0===b.rects?await i.getElementRects({reference:e,floating:t,strategy:o}):b.rects),{x:u,y:d}=co(c,f,s)),n=-1)}return{x:u,y:d,placement:f,strategy:o,middlewareData:p}};async function ci(e,t){var n;void 0===t&&(t={});let{x:r,y:o,platform:a,rects:i,elements:l,strategy:s}=e,{boundary:c="clippingAncestors",rootBoundary:u="viewport",elementContext:d="floating",altBoundary:f=!1,padding:p=0}=lr(t,e),h=lg(p),m=l[f?"floating"===d?"reference":"floating":d],g=lv(await a.getClippingRect({element:null==(n=await (null==a.isElement?void 0:a.isElement(m)))||n?m:m.contextElement||await (null==a.getDocumentElement?void 0:a.getDocumentElement(l.floating)),boundary:c,rootBoundary:u,strategy:s})),v="floating"===d?{x:r,y:o,width:i.floating.width,height:i.floating.height}:i.reference,y=await (null==a.getOffsetParent?void 0:a.getOffsetParent(l.floating)),b=await (null==a.isElement?void 0:a.isElement(y))&&await (null==a.getScale?void 0:a.getScale(y))||{x:1,y:1},x=lv(a.convertOffsetParentRelativeRectToViewportRelativeRect?await a.convertOffsetParentRelativeRectToViewportRelativeRect({elements:l,rect:v,offsetParent:y,strategy:s}):v);return{top:(g.top-x.top+h.top)/b.y,bottom:(x.bottom-g.bottom+h.bottom)/b.y,left:(g.left-x.left+h.left)/b.x,right:(x.right-g.right+h.right)/b.x}}function cl(e,t){return{top:e.top-t.height,right:e.right-t.width,bottom:e.bottom-t.height,left:e.left-t.width}}function cs(e){return i5.some(t=>e[t]>=0)}let cc=new Set(["left","top"]);async function cu(e,t){let{placement:n,platform:r,elements:o}=e,a=await (null==r.isRTL?void 0:r.isRTL(o.floating)),i=lo(n),l=la(n),s="y"===lc(n),c=cc.has(i)?-1:1,u=a&&s?-1:1,d=lr(t,e),{mainAxis:f,crossAxis:p,alignmentAxis:h}="number"==typeof d?{mainAxis:d,crossAxis:0,alignmentAxis:null}:{mainAxis:d.mainAxis||0,crossAxis:d.crossAxis||0,alignmentAxis:d.alignmentAxis};return l&&"number"==typeof h&&(p="end"===l?-1*h:h),s?{x:p*u,y:f*c}:{x:f*c,y:p*u}}function cd(e){let t=a8(e),n=parseFloat(t.width)||0,r=parseFloat(t.height)||0,o=aK(e),a=o?e.offsetWidth:n,i=o?e.offsetHeight:r,l=i8(n)!==a||i8(r)!==i;return l&&(n=a,r=i),{width:n,height:r,$:l}}function cf(e){return aW(e)?e:e.contextElement}function cp(e){let t=cf(e);if(!aK(t))return le(1);let n=t.getBoundingClientRect(),{width:r,height:o,$:a}=cd(t),i=(a?i8(n.width):n.width)/r,l=(a?i8(n.height):n.height)/o;return i&&Number.isFinite(i)||(i=1),l&&Number.isFinite(l)||(l=1),{x:i,y:l}}let ch=le(0);function cm(e){let t=aB(e);return a5()&&t.visualViewport?{x:t.visualViewport.offsetLeft,y:t.visualViewport.offsetTop}:ch}function cg(e,t,n,r){var o,a,i;void 0===t&&(t=!1),void 0===n&&(n=!1);let l=e.getBoundingClientRect(),s=cf(e),c=le(1);t&&(r?aW(r)&&(c=cp(r)):c=cp(e));let u=(o=s,void 0===(a=n)&&(a=!1),(i=r)&&(!a||i===aB(o))&&a)?cm(s):le(0),d=(l.left+u.x)/c.x,f=(l.top+u.y)/c.y,p=l.width/c.x,h=l.height/c.y;if(s){let e=aB(s),t=r&&aW(r)?aB(r):r,n=e,o=ir(n);for(;o&&r&&t!==n;){let e=cp(o),t=o.getBoundingClientRect(),r=a8(o),a=t.left+(o.clientLeft+parseFloat(r.paddingLeft))*e.x,i=t.top+(o.clientTop+parseFloat(r.paddingTop))*e.y;d*=e.x,f*=e.y,p*=e.x,h*=e.y,d+=a,f+=i,o=ir(n=aB(o))}}return lv({width:p,height:h,x:d,y:f})}function cv(e,t){let n=a7(e).scrollLeft;return t?t.left+n:cg(a$(e)).left+n}function cy(e,t,n){void 0===n&&(n=!1);let r=e.getBoundingClientRect(),o=r.left+t.scrollLeft-(n?0:cv(e,r));return{x:o,y:r.top+t.scrollTop}}let cb=new Set(["absolute","fixed"]);function cx(e,t,n){var r,o;let a;if("viewport"===t)a=function(e,t){let n=aB(e),r=a$(e),o=n.visualViewport,a=r.clientWidth,i=r.clientHeight,l=0,s=0;if(o){a=o.width,i=o.height;let e=a5();(!e||e&&"fixed"===t)&&(l=o.offsetLeft,s=o.offsetTop)}return{width:a,height:i,x:l,y:s}}(e,n);else if("document"===t){let t,n,o,i,l,s,c;r=a$(e),t=a$(r),n=a7(r),o=r.ownerDocument.body,i=i9(t.scrollWidth,t.clientWidth,o.scrollWidth,o.clientWidth),l=i9(t.scrollHeight,t.clientHeight,o.scrollHeight,o.clientHeight),s=-n.scrollLeft+cv(r),c=-n.scrollTop,"rtl"===a8(o).direction&&(s+=i9(t.clientWidth,o.clientWidth)-i),a={width:i,height:l,x:s,y:c}}else if(aW(t)){let e,r,i,l,s,c,u;r=(e=cg(o=t,!0,"fixed"===n)).top+o.clientTop,i=e.left+o.clientLeft,l=aK(o)?cp(o):le(1),s=o.clientWidth*l.x,c=o.clientHeight*l.y,u=i*l.x,a={width:s,height:c,x:u,y:r*l.y}}else{let n=cm(e);a={x:t.x-n.x,y:t.y-n.y,width:t.width,height:t.height}}return lv(a)}function cw(e){return"static"===a8(e).position}function c_(e,t){if(!aK(e)||"fixed"===a8(e).position)return null;if(t)return t(e);let n=e.offsetParent;return a$(e)===n&&(n=n.ownerDocument.body),n}function ck(e,t){var n;let r=aB(e);if(a0(e))return r;if(!aK(e)){let t=ie(e);for(;t&&!a9(t);){if(aW(t)&&!cw(t))return t;t=ie(t)}return r}let o=c_(e,t);for(;o&&(n=o,aQ.has(aV(n)))&&cw(o);)o=c_(o,t);return o&&a9(o)&&cw(o)&&!a4(o)?r:o||function(e){let t=ie(e);for(;aK(t)&&!a9(t);){if(a4(t))return t;if(a0(t))break;t=ie(t)}return null}(e)||r}let cj=async function(e){let t=this.getOffsetParent||ck,n=this.getDimensions,r=await n(e.floating);return{reference:function(e,t,n){let r=aK(t),o=a$(t),a="fixed"===n,i=cg(e,!0,a,t),l={scrollLeft:0,scrollTop:0},s=le(0);if(r||!r&&!a)if(("body"!==aV(t)||aX(o))&&(l=a7(t)),r){let e=cg(t,!0,a,t);s.x=e.x+t.clientLeft,s.y=e.y+t.clientTop}else o&&(s.x=cv(o));a&&!r&&o&&(s.x=cv(o));let c=!o||r||a?le(0):cy(o,l),u=i.left+l.scrollLeft-s.x-c.x;return{x:u,y:i.top+l.scrollTop-s.y-c.y,width:i.width,height:i.height}}(e.reference,await t(e.floating),e.strategy),floating:{x:0,y:0,width:r.width,height:r.height}}},cS={convertOffsetParentRelativeRectToViewportRelativeRect:function(e){let{elements:t,rect:n,offsetParent:r,strategy:o}=e,a="fixed"===o,i=a$(r),l=!!t&&a0(t.floating);if(r===i||l&&a)return n;let s={scrollLeft:0,scrollTop:0},c=le(1),u=le(0),d=aK(r);if((d||!d&&!a)&&(("body"!==aV(r)||aX(i))&&(s=a7(r)),aK(r))){let e=cg(r);c=cp(r),u.x=e.x+r.clientLeft,u.y=e.y+r.clientTop}let f=!i||d||a?le(0):cy(i,s,!0);return{width:n.width*c.x,height:n.height*c.y,x:n.x*c.x-s.scrollLeft*c.x+u.x+f.x,y:n.y*c.y-s.scrollTop*c.y+u.y+f.y}},getDocumentElement:a$,getClippingRect:function(e){let{element:t,boundary:n,rootBoundary:r,strategy:o}=e,a=[..."clippingAncestors"===n?a0(t)?[]:function(e,t){let n=t.get(e);if(n)return n;let r=it(e,[],!1).filter(e=>aW(e)&&"body"!==aV(e)),o=null,a="fixed"===a8(e).position,i=a?ie(e):e;for(;aW(i)&&!a9(i);){let t=a8(i),n=a4(i);n||"fixed"!==t.position||(o=null),(a?!n&&!o:!n&&"static"===t.position&&!!o&&cb.has(o.position)||aX(i)&&!n&&function e(t,n){let r=ie(t);return!(r===n||!aW(r)||a9(r))&&("fixed"===a8(r).position||e(r,n))}(e,i))?r=r.filter(e=>e!==i):o=t,i=ie(i)}return t.set(e,r),r}(t,this._c):[].concat(n),r],i=a[0],l=a.reduce((e,n)=>{let r=cx(t,n,o);return e.top=i9(r.top,e.top),e.right=i6(r.right,e.right),e.bottom=i6(r.bottom,e.bottom),e.left=i9(r.left,e.left),e},cx(t,i,o));return{width:l.right-l.left,height:l.bottom-l.top,x:l.left,y:l.top}},getOffsetParent:ck,getElementRects:cj,getClientRects:function(e){return Array.from(e.getClientRects())},getDimensions:function(e){let{width:t,height:n}=cd(e);return{width:t,height:n}},getScale:cp,isElement:aW,isRTL:function(e){return"rtl"===a8(e).direction}};function cO(e,t){return e.x===t.x&&e.y===t.y&&e.width===t.width&&e.height===t.height}function cC(e,t,n,r){let o;void 0===r&&(r={});let{ancestorScroll:a=!0,ancestorResize:i=!0,elementResize:l="function"==typeof ResizeObserver,layoutShift:s="function"==typeof IntersectionObserver,animationFrame:c=!1}=r,u=cf(e),d=a||i?[...u?it(u):[],...it(t)]:[];d.forEach(e=>{a&&e.addEventListener("scroll",n,{passive:!0}),i&&e.addEventListener("resize",n)});let f=u&&s?function(e,t){let n,r=null,o=a$(e);function a(){var e;clearTimeout(n),null==(e=r)||e.disconnect(),r=null}return!function i(l,s){void 0===l&&(l=!1),void 0===s&&(s=1),a();let c=e.getBoundingClientRect(),{left:u,top:d,width:f,height:p}=c;if(l||t(),!f||!p)return;let h=i7(d),m=i7(o.clientWidth-(u+f)),g=i7(o.clientHeight-(d+p)),v={rootMargin:-h+"px "+-m+"px "+-g+"px "+-i7(u)+"px",threshold:i9(0,i6(1,s))||1},y=!0;function b(t){let r=t[0].intersectionRatio;if(r!==s){if(!y)return i();r?i(!1,r):n=setTimeout(()=>{i(!1,1e-7)},1e3)}1!==r||cO(c,e.getBoundingClientRect())||i(),y=!1}try{r=new IntersectionObserver(b,{...v,root:o.ownerDocument})}catch(e){r=new IntersectionObserver(b,v)}r.observe(e)}(!0),a}(u,n):null,p=-1,h=null;l&&(h=new ResizeObserver(e=>{let[r]=e;r&&r.target===u&&h&&(h.unobserve(t),cancelAnimationFrame(p),p=requestAnimationFrame(()=>{var e;null==(e=h)||e.observe(t)})),n()}),u&&!c&&h.observe(u),h.observe(t));let m=c?cg(e):null;return c&&function t(){let r=cg(e);m&&!cO(m,r)&&n(),m=r,o=requestAnimationFrame(t)}(),n(),()=>{var e;d.forEach(e=>{a&&e.removeEventListener("scroll",n),i&&e.removeEventListener("resize",n)}),null==f||f(),null==(e=h)||e.disconnect(),h=null,c&&cancelAnimationFrame(o)}}var cP="undefined"!=typeof document,cE=cP?C.useLayoutEffect:function(){};function cT(e,t){let n,r,o;if(e===t)return!0;if(typeof e!=typeof t)return!1;if("function"==typeof e&&e.toString()===t.toString())return!0;if(e&&t&&"object"==typeof e){if(Array.isArray(e)){if((n=e.length)!==t.length)return!1;for(r=n;0!=r--;)if(!cT(e[r],t[r]))return!1;return!0}if((n=(o=Object.keys(e)).length)!==Object.keys(t).length)return!1;for(r=n;0!=r--;)if(!({}).hasOwnProperty.call(t,o[r]))return!1;for(r=n;0!=r--;){let n=o[r];if(("_owner"!==n||!e.$$typeof)&&!cT(e[n],t[n]))return!1}return!0}return e!=e&&t!=t}function cI(e){return"undefined"==typeof window?1:(e.ownerDocument.defaultView||window).devicePixelRatio||1}function cN(e,t){let n=cI(e);return Math.round(t*n)/n}function cL(e){let t=C.useRef(e);return cE(()=>{t.current=e}),t}function cA(e,t,n){let r="inline-start"===e||"inline-end"===e;return({top:"top",right:r?n?"inline-start":"inline-end":"right",bottom:"bottom",left:r?n?"inline-end":"inline-start":"left"})[t]}function cz(e,t,n){let{rects:r,placement:o}=e;return{side:cA(t,lo(o),n),align:la(o)||"center",anchor:{width:r.reference.width,height:r.reference.height},positioner:{width:r.floating.width,height:r.floating.height}}}function cR(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v;let y,{anchor:b,positionMethod:x="absolute",side:w="bottom",sideOffset:_=0,align:k="center",alignOffset:j=0,collisionBoundary:S,collisionPadding:O=5,sticky:P=!1,arrowPadding:E=5,trackAnchor:T=!0,keepMounted:I=!1,floatingRootContext:N,mounted:L,collisionAvoidance:A,shiftCrossAxis:z=!1,nodeId:R,adaptiveOrigin:D}=e,M=A.side||"flip",Z=A.align||"flip",F=A.fallbackAxisSide||"end",U="function"==typeof b?b:void 0,H=aO(U),V=U?H:b,B=io(b),$="rtl"===lM(),q={top:"top",right:"right",bottom:"bottom",left:"left","inline-end":$?"left":"right","inline-start":$?"right":"left"}[w],W="center"===k?q:`${q}-${k}`,K={boundary:"clipping-ancestors"===S?"clippingAncestors":S,padding:O},Y=C.useRef(null),G=io(_),X=io(j),Q="function"!=typeof _?_:0,J=[(t=e=>{let t=cz(e,w,$),n="function"==typeof G.current?G.current(t):G.current,r="function"==typeof X.current?X.current(t):X.current;return{mainAxis:n,crossAxis:r,alignmentAxis:r}},n=[Q,"function"!=typeof j?j:0,$,w],{...(void 0===(r=t)&&(r=0),{name:"offset",options:r,async fn(e){var t,n;let{x:o,y:a,placement:i,middlewareData:l}=e,s=await cu(e,r);return i===(null==(t=l.offset)?void 0:t.placement)&&null!=(n=l.arrow)&&n.alignmentOffset?{}:{x:o+s.x,y:a+s.y,data:{...s,placement:i}}}}),options:[t,n]})],ee="none"===Z&&"shift"!==M,et=!ee&&(P||z||"shift"===M),en="none"===M?null:{...{name:"flip",options:i=o={...K,mainAxis:!z&&"flip"===M,crossAxis:"flip"===Z&&"alignment",fallbackAxisSideDirection:F},async fn(e){var t,n,r,o,a,l,s,c,u,d,f,p,h;let m,g,v,{placement:y,middlewareData:b,rects:x,initialPlacement:w,platform:_,elements:k}=e,{mainAxis:j=!0,crossAxis:S=!0,fallbackPlacements:O,fallbackStrategy:C="bestFit",fallbackAxisSideDirection:P="none",flipAlignment:E=!0,...T}=lr(i,e);if(null!=(t=b.arrow)&&t.alignmentOffset)return{};let I=lo(y),N=lc(w),L=lo(w)===w,A=await (null==_.isRTL?void 0:_.isRTL(k.floating)),z=O||(L||!E?[lm(w)]:(m=lm(l=w),[lu(l),m,lu(m)])),R="none"!==P;!O&&R&&z.push(...(s=w,c=E,u=P,d=A,g=la(s),v=function(e,t,n){switch(e){case"top":case"bottom":if(n)return t?lf:ld;return t?ld:lf;case"left":case"right":return t?lp:lh;default:return[]}}(lo(s),"start"===u,d),g&&(v=v.map(e=>e+"-"+g),c&&(v=v.concat(v.map(lu)))),v));let D=[w,...z],M=await ci(e,T),Z=[],F=(null==(n=b.flip)?void 0:n.overflows)||[];if(j&&Z.push(M[I]),S){let e,t,n,r,o=(f=y,p=x,void 0===(h=A)&&(h=!1),e=la(f),t=li(lc(f)),n=ll(t),r="x"===t?e===(h?"end":"start")?"right":"left":"start"===e?"bottom":"top",p.reference[n]>p.floating[n]&&(r=lm(r)),[r,lm(r)]);Z.push(M[o[0]],M[o[1]])}if(F=[...F,{placement:y,overflows:Z}],!Z.every(e=>e<=0)){let e=((null==(r=b.flip)?void 0:r.index)||0)+1,t=D[e];if(t&&("alignment"!==S||N===lc(t)||F.every(e=>lc(e.placement)!==N||e.overflows[0]>0)))return{data:{index:e,overflows:F},reset:{placement:t}};let n=null==(o=F.filter(e=>e.overflows[0]<=0).sort((e,t)=>e.overflows[1]-t.overflows[1])[0])?void 0:o.placement;if(!n)switch(C){case"bestFit":{let e=null==(a=F.filter(e=>{if(R){let t=lc(e.placement);return t===N||"y"===t}return!0}).map(e=>[e.placement,e.overflows.filter(e=>e>0).reduce((e,t)=>e+t,0)]).sort((e,t)=>e[1]-t[1])[0])?void 0:a[0];e&&(n=e);break}case"initialPlacement":n=w}if(y!==n)return{reset:{placement:n}}}return{}}},options:[o,a]},er=ee?null:(l=e=>{var t,n,r;let o=lZ(e.elements.floating).documentElement;return{...K,rootBoundary:z?{x:0,y:0,width:o.clientWidth,height:o.clientHeight}:void 0,mainAxis:"none"!==Z,crossAxis:et,limiter:P||z?void 0:{...(void 0===(r=t=()=>{if(!Y.current)return{};let{height:e}=Y.current.getBoundingClientRect();return{offset:e/2+("number"==typeof O?O:0)}})&&(r={}),{options:r,fn(e){let{x:t,y:n,placement:o,rects:a,middlewareData:i}=e,{offset:l=0,mainAxis:s=!0,crossAxis:c=!0}=lr(r,e),u={x:t,y:n},d=lc(o),f=li(d),p=u[f],h=u[d],m=lr(l,e),g="number"==typeof m?{mainAxis:m,crossAxis:0}:{mainAxis:0,crossAxis:0,...m};if(s){let e="y"===f?"height":"width",t=a.reference[f]-a.floating[e]+g.mainAxis,n=a.reference[f]+a.reference[e]-g.mainAxis;p<t?p=t:p>n&&(p=n)}if(c){var v,y;let e="y"===f?"width":"height",t=cc.has(lo(o)),n=a.reference[d]-a.floating[e]+(t&&(null==(v=i.offset)?void 0:v[d])||0)+(t?0:g.crossAxis),r=a.reference[d]+a.reference[e]+(t?0:(null==(y=i.offset)?void 0:y[d])||0)-(t?g.crossAxis:0);h<n?h=n:h>r&&(h=r)}return{[f]:p,[d]:h}}}),options:[t,n]}}},s=[K,P,z,O,Z],{...(void 0===(c=l)&&(c={}),{name:"shift",options:c,async fn(e){let{x:t,y:n,placement:r}=e,{mainAxis:o=!0,crossAxis:a=!1,limiter:i={fn:e=>{let{x:t,y:n}=e;return{x:t,y:n}}},...l}=lr(c,e),s={x:t,y:n},u=await ci(e,l),d=lc(lo(r)),f=li(d),p=s[f],h=s[d];if(o){let e="y"===f?"top":"left",t="y"===f?"bottom":"right",n=p+u[e],r=p-u[t];p=i9(n,i6(p,r))}if(a){let e="y"===d?"top":"left",t="y"===d?"bottom":"right",n=h+u[e],r=h-u[t];h=i9(n,i6(h,r))}let m=i.fn({...e,[f]:p,[d]:h});return{...m,data:{x:m.x-t,y:m.y-n,enabled:{[f]:o,[d]:a}}}}}),options:[l,s]});"shift"===M||"shift"===Z||"center"===k?J.push(er,en):J.push(en,er),J.push({...{name:"size",options:f=u={...K,apply({elements:{floating:e},rects:{reference:t},availableWidth:n,availableHeight:r}){Object.entries({"--available-width":`${n}px`,"--available-height":`${r}px`,"--anchor-width":`${t.width}px`,"--anchor-height":`${t.height}px`}).forEach(([t,n])=>{e.style.setProperty(t,n)})}},async fn(e){var t,n;let r,o,{placement:a,rects:i,platform:l,elements:s}=e,{apply:c=()=>{},...u}=lr(f,e),d=await ci(e,u),p=lo(a),h=la(a),m="y"===lc(a),{width:g,height:v}=i.floating;"top"===p||"bottom"===p?(r=p,o=h===(await (null==l.isRTL?void 0:l.isRTL(s.floating))?"start":"end")?"left":"right"):(o=p,r="end"===h?"top":"bottom");let y=v-d.top-d.bottom,b=g-d.left-d.right,x=i6(v-d[r],y),w=i6(g-d[o],b),_=!e.middlewareData.shift,k=x,j=w;if(null!=(t=e.middlewareData.shift)&&t.enabled.x&&(j=b),null!=(n=e.middlewareData.shift)&&n.enabled.y&&(k=y),_&&!h){let e=i9(d.left,0),t=i9(d.right,0),n=i9(d.top,0),r=i9(d.bottom,0);m?j=g-2*(0!==e||0!==t?e+t:i9(d.left,d.right)):k=v-2*(0!==n||0!==r?n+r:i9(d.top,d.bottom))}await c({...e,availableWidth:j,availableHeight:k});let S=await l.getDimensions(s.floating);return g!==S.width||v!==S.height?{reset:{rects:!0}}:{}}},options:[u,d]},(p=()=>({element:Y.current||document.createElement("div"),padding:E,offsetParent:"floating"}),h=[E],{...{name:"arrow",options:y=p,async fn(e){let{x:t,y:n,placement:r,rects:o,platform:a,elements:i,middlewareData:l}=e,{element:s,padding:c=0,offsetParent:u="real"}=lr(y,e)||{};if(null==s)return{};let d=lg(c),f={x:t,y:n},p=li(lc(r)),h=ll(p),m=await a.getDimensions(s),g="y"===p,v=g?"clientHeight":"clientWidth",b=o.reference[h]+o.reference[p]-f[p]-o.floating[h],x=f[p]-o.reference[p],w="real"===u?await a.getOffsetParent?.(s):i.floating,_=i.floating[v]||o.floating[h];_&&await a.isElement?.(w)||(_=i.floating[v]||o.floating[h]);let k=_/2-m[h]/2-1,j=Math.min(d[g?"top":"left"],k),S=Math.min(d[g?"bottom":"right"],k),O=_-m[h]-S,C=_/2-m[h]/2+(b/2-x/2),P=i9(j,i6(C,O)),E=!l.arrow&&null!=la(r)&&C!==P&&o.reference[h]/2-(C<j?j:S)-m[h]/2<0,T=E?C<j?C-j:C-O:0;return{[p]:f[p]+T,data:{[p]:P,centerOffset:C-P-T,...E&&{alignmentOffset:T}},reset:E}}},options:[p,h]}),{...(void 0===(v=m)&&(v={}),{name:"hide",options:v,async fn(e){let{rects:t}=e,{strategy:n="referenceHidden",...r}=lr(v,e);switch(n){case"referenceHidden":{let n=cl(await ci(e,{...r,elementContext:"reference"}),t.reference);return{data:{referenceHiddenOffsets:n,referenceHidden:cs(n)}}}case"escaped":{let n=cl(await ci(e,{...r,altBoundary:!0}),t.floating);return{data:{escapedOffsets:n,escaped:cs(n)}}}default:return{}}}}),options:[m,g]},{name:"transformOrigin",fn(e){let{elements:t,middlewareData:n,placement:r,rects:o,y:a}=e,i=lo(r),l=lc(i),s=Y.current,c=n.arrow?.x||0,u=n.arrow?.y||0,d=s?.clientWidth||0,f=s?.clientHeight||0,p=c+d/2,h=u+f/2,m=Math.abs(n.shift?.y||0),g=o.reference.height/2,v=m>("function"==typeof _?_(cz(e,w,$)):_),y={top:`${p}px calc(100% + ${_}px)`,bottom:`${p}px ${-_}px`,left:`calc(100% + ${_}px) ${h}px`,right:`${-_}px ${h}px`}[i],b=`${p}px ${o.reference.y+g-a}px`;return t.floating.style.setProperty("--transform-origin",et&&"y"===l&&v?b:y),{}}},D);let eo=N;!L&&N&&(eo={...N,elements:{reference:null,floating:null,domReference:null}});let ea=C.useMemo(()=>({elementResize:T&&"undefined"!=typeof ResizeObserver,layoutShift:T&&"undefined"!=typeof IntersectionObserver}),[T]),{refs:ei,elements:el,x:es,y:ec,middlewareData:eu,update:ed,placement:ef,context:ep,isPositioned:eh,floatingStyles:em}=function(e={}){let{nodeId:t}=e,n=aU({...e,elements:{reference:null,floating:null,...e.elements}}),r=e.rootContext||n,o=r.elements,[a,i]=C.useState(null),[l,s]=C.useState(null),c=o?.domReference||a,u=C.useRef(null),d=C.useContext(aD);az(()=>{c&&(u.current=c)},[c]);let f=function(e){void 0===e&&(e={});let{placement:t="bottom",strategy:n="absolute",middleware:r=[],platform:o,elements:{reference:a,floating:i}={},transform:l=!0,whileElementsMounted:s,open:c}=e,[u,d]=C.useState({x:0,y:0,strategy:n,placement:t,middlewareData:{},isPositioned:!1}),[f,p]=C.useState(r);cT(f,r)||p(r);let[h,m]=C.useState(null),[g,v]=C.useState(null),y=C.useCallback(e=>{e!==_.current&&(_.current=e,m(e))},[]),b=C.useCallback(e=>{e!==k.current&&(k.current=e,v(e))},[]),x=a||h,w=i||g,_=C.useRef(null),k=C.useRef(null),j=C.useRef(u),S=null!=s,O=cL(s),P=cL(o),E=cL(c),T=C.useCallback(()=>{var e,r,o;let a,i,l;if(!_.current||!k.current)return;let s={placement:t,strategy:n,middleware:f};P.current&&(s.platform=P.current),(e=_.current,r=k.current,o=s,a=new Map,l={...(i={platform:cS,...o}).platform,_c:a},ca(e,r,{...i,platform:l})).then(e=>{let t={...e,isPositioned:!1!==E.current};I.current&&!cT(j.current,t)&&(j.current=t,ex.flushSync(()=>{d(t)}))})},[f,t,n,P,E]);cE(()=>{!1===c&&j.current.isPositioned&&(j.current.isPositioned=!1,d(e=>({...e,isPositioned:!1})))},[c]);let I=C.useRef(!1);cE(()=>(I.current=!0,()=>{I.current=!1}),[]),cE(()=>{if(x&&(_.current=x),w&&(k.current=w),x&&w){if(O.current)return O.current(x,w,T);T()}},[x,w,T,O,S]);let N=C.useMemo(()=>({reference:_,floating:k,setReference:y,setFloating:b}),[y,b]),L=C.useMemo(()=>({reference:x,floating:w}),[x,w]),A=C.useMemo(()=>{let e={position:n,left:0,top:0};if(!L.floating)return e;let t=cN(L.floating,u.x),r=cN(L.floating,u.y);return l?{...e,transform:"translate("+t+"px, "+r+"px)",...cI(L.floating)>=1.5&&{willChange:"transform"}}:{position:n,left:t,top:r}},[n,l,L.floating,u.x,u.y]);return C.useMemo(()=>({...u,update:T,refs:N,elements:L,floatingStyles:A}),[u,T,N,L,A])}({...e,elements:{...o,...l&&{reference:l}}}),p=C.useCallback(e=>{let t=aW(e)?{getBoundingClientRect:()=>e.getBoundingClientRect(),getClientRects:()=>e.getClientRects(),contextElement:e}:e;s(t),f.refs.setReference(t)},[f.refs]),h=C.useCallback(e=>{(aW(e)||null===e)&&(u.current=e,i(e)),(aW(f.refs.reference.current)||null===f.refs.reference.current||null!==e&&!aW(e))&&f.refs.setReference(e)},[f.refs]),m=C.useMemo(()=>({...f.refs,setReference:h,setPositionReference:p,domReference:u}),[f.refs,h,p]),g=C.useMemo(()=>({...f.elements,domReference:c}),[f.elements,c]),v=C.useMemo(()=>({...f,...r,refs:m,elements:g,nodeId:t}),[f,m,g,t,r]);return az(()=>{r.dataRef.current.floatingContext=v;let e=d?.nodesRef.current.find(e=>e.id===t);e&&(e.context=v)}),C.useMemo(()=>({...f,context:v,refs:m,elements:g}),[f,m,g,v])}({rootContext:eo,placement:W,middleware:J,strategy:x,whileElementsMounted:I?void 0:(...e)=>cC(...e,ea),nodeId:R}),{sideX:eg,sideY:ev}=eu.adaptiveOrigin||{},ey=C.useMemo(()=>D?{position:x,[eg]:`${es}px`,[ev]:`${ec}px`}:em,[D,eg,ev,x,es,ec,em]),eb=C.useRef(null);az(()=>{if(!L)return;let e=B.current,t="function"==typeof e?e():e,n=(cD(t)?t.current:t)||null;n!==eb.current&&(ei.setPositionReference(n),eb.current=n)},[L,ei,V,B]),C.useEffect(()=>{if(!L)return;let e=B.current;"function"!=typeof e&&cD(e)&&e.current!==eb.current&&(ei.setPositionReference(e.current),eb.current=e.current)},[L,ei,V,B]),C.useEffect(()=>{if(I&&L&&el.domReference&&el.floating)return cC(el.domReference,el.floating,ed,ea)},[I,L,el,ed,ea]);let ew=cA(w,lo(ef),$),e_=la(ef)||"center",ek=!!eu.hide?.referenceHidden,ej=C.useMemo(()=>({position:"absolute",top:eu.arrow?.y,left:eu.arrow?.x}),[eu.arrow]),eS=eu.arrow?.centerOffset!==0;return C.useMemo(()=>({positionerStyles:ey,arrowStyles:ej,arrowRef:Y,arrowUncentered:eS,side:ew,align:e_,anchorHidden:ek,refs:ei,context:ep,isPositioned:eh,update:ed}),[ey,ej,Y,eS,ew,e_,ek,ei,ep,eh,ed])}function cD(e){return null!=e&&"current"in e}function cM(e){let{children:t,elementsRef:n,labelsRef:r,onMapChange:o}=e,a=C.useRef(0),i=ab(cF).current,l=ab(cZ).current,[s,c]=C.useState(0),u=C.useRef(s),d=aO((e,t)=>{l.set(e,t??null),u.current+=1,c(u.current)}),f=aO(e=>{l.delete(e),u.current+=1,c(u.current)}),p=C.useMemo(()=>{let e=new Map;return Array.from(l.keys()).sort(cU).forEach((t,n)=>{let r=l.get(t)??{};e.set(t,{...r,index:n})}),e},[l,s]);az(()=>{u.current===s&&(n.current.length!==p.size&&(n.current.length=p.size),r&&r.current.length!==p.size&&(r.current.length=p.size)),o?.(p)},[o,p,n,r,s,u]);let h=aO(e=>(i.add(e),()=>{i.delete(e)}));az(()=>{i.forEach(e=>e(p))},[i,p]);let m=C.useMemo(()=>({register:d,unregister:f,subscribeMapChange:h,elementsRef:n,labelsRef:r,nextIndexRef:a}),[d,f,h,n,r,a]);return(0,S.jsx)(sx.Provider,{value:m,children:t})}function cZ(){return new Map}function cF(){return new Set}function cU(e,t){let n=e.compareDocumentPosition(t);return n&Node.DOCUMENT_POSITION_FOLLOWING||n&Node.DOCUMENT_POSITION_CONTAINED_BY?-1:n&Node.DOCUMENT_POSITION_PRECEDING||n&Node.DOCUMENT_POSITION_CONTAINS?1:0}let cH=C.forwardRef(function(e,t){let n,{cutout:r,...o}=e;if(r){let e=r?.getBoundingClientRect();n=`polygon(
      0% 0%,
      100% 0%,
      100% 100%,
      0% 100%,
      0% 0%,
      ${e.left}px ${e.top}px,
      ${e.left}px ${e.bottom}px,
      ${e.right}px ${e.bottom}px,
      ${e.right}px ${e.top}px,
      ${e.left}px ${e.top}px
    )`}return(0,S.jsx)("div",{ref:t,role:"presentation","data-base-ui-inert":"",...o,style:{position:"fixed",inset:0,userSelect:"none",WebkitUserSelect:"none",clipPath:n}})}),cV=C.forwardRef(function(e,t){var n;let r,o,a,i,{anchor:l,positionMethod:s="absolute",className:c,render:u,side:d,align:f,sideOffset:p=0,alignOffset:h=0,collisionBoundary:m="clipping-ancestors",collisionPadding:g=5,arrowPadding:v=5,sticky:y=!1,trackAnchor:b=!0,collisionAvoidance:x=iJ,...w}=e,{open:_,setOpen:k,floatingRootContext:j,setPositionerElement:O,itemDomElements:P,itemLabels:E,mounted:T,modal:I,lastOpenChangeReason:N,parent:L,setHoverEnabled:A,triggerElement:z}=lL(),R=function(){let e=C.useContext(ct);if(void 0===e)throw Error("Base UI: <Menu.Portal> is missing.");return e}(),D=(r=aL(),o=C.useContext(aD),i=a=aM(),az(()=>{if(!r)return;let e={id:r,parentId:i};return o?.addNode(e),()=>{o?.removeNode(e)}},[o,r,i]),r),M=aM(),Z=lK(!0),F=l,U=p,H=h,V=f;"context-menu"===L.type&&(F=L.context?.anchor??l,V=e.align??"start",H=e.alignOffset??2,U=e.sideOffset??-5);let B=d,$=V;"menu"===L.type?(B=B??"inline-end",$=$??"start"):"menubar"===L.type&&(B=B??"bottom",$=$??"start");let q="context-menu"===L.type,W=cR({anchor:F,floatingRootContext:j,positionMethod:Z?"fixed":s,mounted:T,side:B,sideOffset:U,align:$,alignOffset:H,arrowPadding:q?0:v,collisionBoundary:m,collisionPadding:g,sticky:y,nodeId:D,keepMounted:R,trackAnchor:b,collisionAvoidance:x,shiftCrossAxis:q}),{events:K}=C.useContext(aD),Y=C.useMemo(()=>{let e={};return _||(e.pointerEvents="none"),{role:"presentation",hidden:!T,style:{...W.positionerStyles,...e}}},[_,T,W.positionerStyles]);C.useEffect(()=>{function e(e){e.open?(e.parentNodeId===D&&A(!1),e.nodeId!==D&&e.parentNodeId===M&&k(!1,void 0,"sibling-open")):e.parentNodeId===D&&A(!0)}return K.on("openchange",e),()=>{K.off("openchange",e)}},[K,D,M,k,A]),C.useEffect(()=>{K.emit("openchange",{open:_,nodeId:D,parentNodeId:M})},[K,_,D,M]);let G=C.useMemo(()=>({open:_,side:W.side,align:W.align,anchorHidden:W.anchorHidden,nested:"menu"===L.type}),[_,W.side,W.align,W.anchorHidden,L.type]),X=C.useMemo(()=>({side:W.side,align:W.align,arrowRef:W.arrowRef,arrowUncentered:W.arrowUncentered,arrowStyles:W.arrowStyles,floatingContext:W.context}),[W.side,W.align,W.arrowRef,W.arrowUncentered,W.arrowStyles,W.context]),Q=sm("div",e,{state:G,customStyleHookMapping:sp,ref:[t,O],props:{...Y,...w}}),J=T&&"menu"!==L.type&&("menubar"!==L.type&&I&&"trigger-hover"!==N||"menubar"===L.type&&L.context.modal),ee=null;return"menubar"===L.type?ee=L.context.contentElement:void 0===L.type&&(ee=z),(0,S.jsxs)(cr.Provider,{value:X,children:[J&&(0,S.jsx)(cH,{ref:"context-menu"===L.type||"nested-context-menu"===L.type?L.context.internalBackdropRef:null,inert:(n=!_,sh>=19?n:n?"true":void 0),cutout:ee}),(0,S.jsx)(aZ,{id:D,children:(0,S.jsx)(cM,{elementsRef:P,labelsRef:E,children:Q})})]})}),cB={inert:new WeakMap,"aria-hidden":new WeakMap,none:new WeakMap};function c$(e){return"inert"===e?cB.inert:"aria-hidden"===e?cB["aria-hidden"]:cB.none}let cq=new WeakSet,cW={},cK=0,cY=e=>e&&(e.host||cY(e.parentNode)),cG=[];function cX(){cG=cG.filter(e=>e.isConnected)}function cQ(){return cX(),cG[cG.length-1]}function cJ(e,t){if(!t.current.includes("floating")&&!e.getAttribute("role")?.includes("dialog"))return;let n=s0(),r=sQ(e,n).filter(e=>{let t=e.getAttribute("data-tabindex")||"";return sJ(e,n)||e.hasAttribute("data-tabindex")&&!t.startsWith("-")}),o=e.getAttribute("tabindex");t.current.includes("floating")||0===r.length?"0"!==o&&e.setAttribute("tabindex","0"):("-1"!==o||e.hasAttribute("data-tabindex")&&"-1"!==e.getAttribute("data-tabindex"))&&(e.setAttribute("tabindex","-1"),e.setAttribute("data-tabindex","-1"))}function c0(e){let{context:t,children:n,disabled:r=!1,order:o=["content"],initialFocus:a=0,returnFocus:i=!0,restoreFocus:l=!1,modal:s=!0,closeOnFocusOut:c=!0,getInsideElements:u=()=>[]}=e,{open:d,onOpenChange:f,events:p,dataRef:h,elements:{domReference:m,floating:g}}=t,v=aO(()=>h.current.floatingContext?.nodeId),y=aO(u),b="number"==typeof a&&a<0,x=iA(m)&&b,w=io(o),_=io(a),k=io(i),j=C.useContext(aD),O=C.useContext(s9),P=C.useRef(null),E=C.useRef(null),T=C.useRef(!1),I=C.useRef(!1),N=C.useRef(-1),L=ak(),A=null!=O,z=iz(g),R=aO((e=z)=>e?sX(e,s0()):[]),D=aO(e=>{let t=R(e);return w.current.map(()=>t).filter(Boolean).flat()});C.useEffect(()=>{if(r||!s)return;function e(e){"Tab"===e.key&&iE(z,iP(iN(z)))&&0===R().length&&!x&&iv(e)}let t=iN(z);return t.addEventListener("keydown",e),()=>{t.removeEventListener("keydown",e)}},[r,m,z,s,w,x,R,D]),C.useEffect(()=>{if(!r&&g)return g.addEventListener("focusin",e),()=>{g.removeEventListener("focusin",e)};function e(e){let t=iT(e),n=R().indexOf(t);-1!==n&&(N.current=n)}},[r,g,R]),C.useEffect(()=>{if(r||!c)return;function e(){I.current=!0}function t(e){let t=e.relatedTarget,n=e.currentTarget,r=iT(e);queueMicrotask(()=>{let o=v(),a=!(iE(m,t)||iE(g,t)||iE(t,g)||iE(O?.portalNode,t)||t?.hasAttribute(iR("focus-guard"))||j&&(iU(j.nodesRef.current,o).find(e=>iE(e.context?.elements.floating,t)||iE(e.context?.elements.domReference,t))||iH(j.nodesRef.current,o).find(e=>[e.context?.elements.floating,iz(e.context?.elements.floating)].includes(t)||e.context?.elements.domReference===t)));if(n===m&&z&&cJ(z,w),l&&n!==m&&!r?.isConnected&&iP(iN(z))===iN(z).body){aK(z)&&z.focus();let e=N.current,t=R(),n=t[e]||t[t.length-1]||z;aK(n)&&n.focus()}if(h.current.insideReactTree){h.current.insideReactTree=!1;return}if(I.current){I.current=!1;return}(x||!s)&&t&&a&&t!==cQ()&&(T.current=!0,f(!1,e,"focus-out"))})}let n=!!(!j&&O);function o(){h.current.insideReactTree=!0,L.start(0,()=>{h.current.insideReactTree=!1})}if(g&&aK(m))return m.addEventListener("focusout",t),m.addEventListener("pointerdown",e),g.addEventListener("focusout",t),n&&g.addEventListener("focusout",o,!0),()=>{m.removeEventListener("focusout",t),m.removeEventListener("pointerdown",e),g.removeEventListener("focusout",t),n&&g.removeEventListener("focusout",o,!0)}},[r,m,g,z,s,j,O,f,c,l,R,x,v,w,h,L]);let M=C.useRef(null),Z=C.useRef(null),F=l9(M,O?.beforeInsideRef),U=l9(Z,O?.afterInsideRef);C.useEffect(()=>{if(r||!g)return;let e=Array.from(O?.portalNode?.querySelectorAll(`[${iR("portal")}]`)||[]),t=j?iH(j.nodesRef.current,v()):[],n=function(e,t=!1,n=!1){var r,o,a;let i,l,s,c,u,d,f,p,h=iN(e[0]).body;return r=e.concat(Array.from(h.querySelectorAll("[aria-live]"))),o=h,a=t,i="data-base-ui-inert",l=n?"inert":a?"aria-hidden":null,s=o,c=r.map(e=>{if(s.contains(e))return e;let t=cY(e);return s.contains(t)?t:null}).filter(e=>null!=e),u=new Set,d=new Set(c),f=[],cW[i]||(cW[i]=new WeakMap),p=cW[i],c.forEach(function e(t){!(!t||u.has(t))&&(u.add(t),t.parentNode&&e(t.parentNode))}),function e(t){!t||d.has(t)||[].forEach.call(t.children,t=>{if("script"!==aV(t))if(u.has(t))e(t);else{let e=l?t.getAttribute(l):null,n=null!==e&&"false"!==e,r=c$(l),o=(r.get(t)||0)+1,a=(p.get(t)||0)+1;r.set(t,o),p.set(t,a),f.push(t),1===o&&n&&cq.add(t),1===a&&t.setAttribute(i,""),!n&&l&&t.setAttribute(l,"inert"===l?"":"true")}})}(o),u.clear(),cK+=1,()=>{f.forEach(e=>{let t=c$(l),n=(t.get(e)||0)-1,r=(p.get(e)||0)-1;t.set(e,n),p.set(e,r),n||(!cq.has(e)&&l&&e.removeAttribute(l),cq.delete(e)),r||e.removeAttribute(i)}),(cK-=1)||(cB.inert=new WeakMap,cB["aria-hidden"]=new WeakMap,cB.none=new WeakMap,cq=new WeakSet,cW={})}}([g,t.find(e=>iA(e.context?.elements.domReference||null))?.context?.elements.domReference,...e,...y(),P.current,E.current,M.current,Z.current,O?.beforeOutsideRef.current,O?.afterOutsideRef.current,x?m:null].filter(e=>null!=e),s||x);return()=>{n()}},[r,m,g,s,w,O,x,j,v,y]),az(()=>{if(r||!aK(z))return;let e=iP(iN(z));queueMicrotask(()=>{let t=D(z),n=_.current,r=("number"==typeof n?t[n]:n.current)||z,o=iE(z,e);b||o||!d||lS(r,{preventScroll:r===z})})},[r,d,z,b,D,_]),az(()=>{var e;if(r||!z)return;let t=iN(z);function n({reason:e,event:t,nested:n}){if(["hover","safe-polygon"].includes(e)&&"mouseleave"===t.type&&(T.current=!0),"outside-press"===e)if(n)T.current=!1;else if(iy(t)||ib(t))T.current=!1;else{let e=!1;document.createElement("div").focus({get preventScroll(){return e=!0,!1}}),e?T.current=!1:T.current=!0}}e=iP(t),cX(),e&&"body"!==aV(e)&&(cG.push(e),cG.length>20&&(cG=cG.slice(-20))),p.on("openchange",n);let o=t.createElement("span");return o.setAttribute("tabindex","-1"),o.setAttribute("aria-hidden","true"),Object.assign(o.style,sS),A&&m&&m.insertAdjacentElement("afterend",o),()=>{p.off("openchange",n);let e=iP(t),r=iE(g,e)||j&&iU(j.nodesRef.current,v(),!1).some(t=>iE(t.context?.elements.floating,e)),a=function(){if("boolean"==typeof k.current){let e=m||cQ();return e&&e.isConnected?e:o}return k.current.current||o}();queueMicrotask(()=>{var n;let i,l=(n=a,i=s0(),sJ(n,i)?n:sX(n,i)[0]||n);k.current&&!T.current&&aK(l)&&(l===e||e===t.body||r)&&l.focus({preventScroll:!0}),o.remove()})}},[r,g,z,k,h,p,j,A,m,v]),C.useEffect(()=>{queueMicrotask(()=>{T.current=!1})},[r]),C.useEffect(()=>{if(r||!d)return;function e(e){let t=iT(e);t?.closest("[data-base-ui-click-trigger]")&&(I.current=!0)}let t=iN(z);return t.addEventListener("pointerdown",e,!0),()=>{t.removeEventListener("pointerdown",e,!0)}},[r,d,z]),az(()=>{if(!r&&O)return O.setFocusManagerState({modal:s,closeOnFocusOut:c,open:d,onOpenChange:f,domReference:m}),()=>{O.setFocusManagerState(null)}},[r,O,s,d,f,c,m]),az(()=>{if(!r&&z)return cJ(z,w),()=>{queueMicrotask(cX)}},[r,z,w]);let H=!r&&(!s||!x)&&(A||s);return(0,S.jsxs)(C.Fragment,{children:[H&&(0,S.jsx)(sO,{"data-type":"inside",ref:F,onFocus:e=>{if(s){let e=D();lS(e[e.length-1])}else if(O?.preserveTabOrder&&O.portalNode)if(T.current=!1,s4(e,O.portalNode)){let e=s2(m);e?.focus()}else O.beforeOutsideRef.current?.focus()}}),n,H&&(0,S.jsx)(sO,{"data-type":"inside",ref:U,onFocus:e=>{if(s)lS(D()[0]);else if(O?.preserveTabOrder&&O.portalNode)if(c&&(T.current=!0),s4(e,O.portalNode)){let e=s3(m);e?.focus()}else O.afterOutsideRef.current?.focus()}})]})}let c1={...sp,...sr},c2=C.forwardRef(function(e,t){let{render:n,className:r,finalFocus:o,...a}=e,{open:i,setOpen:l,popupRef:s,transitionStatus:c,popupProps:u,mounted:d,instantType:f,onOpenChangeComplete:p,parent:h,lastOpenChangeReason:m,rootId:g}=lL(),{side:v,align:y,floatingContext:b}=function(){let e=C.useContext(cr);if(void 0===e)throw Error("Base UI: MenuPositionerContext is missing. MenuPositioner parts must be placed within <Menu.Positioner>.");return e}();lR({open:i,ref:s,onComplete(){i&&p?.(!0)}});let{events:x}=C.useContext(aD);C.useEffect(()=>{function e(e){l(!1,e.domEvent,e.reason)}return x.on("close",e),()=>{x.off("close",e)}},[x,l]);let w=sm("div",e,{state:C.useMemo(()=>({transitionStatus:c,side:v,align:y,open:i,nested:"menu"===h.type,instant:f}),[c,v,y,i,h.type,f]),ref:[t,s],customStyleHookMapping:c1,props:[u,"starting"===c?iG:iX,a,{"data-rootownerid":g}]}),_=void 0===h.type||"context-menu"===h.type;return"menubar"===h.type&&"outside-press"!==m&&(_=!0),(0,S.jsx)(c0,{context:b,modal:!1,disabled:!d,returnFocus:o||_,initialFocus:"menu"===h.type?-1:0,restoreFocus:!0,children:w})}),c3=C.createContext(void 0),c4=C.forwardRef(function(e,t){let{render:n,className:r,...o}=e,[a,i]=C.useState(void 0),l=C.useMemo(()=>({setLabelId:i}),[i]),s=sm("div",e,{ref:t,props:{role:"group","aria-labelledby":a,...o}});return(0,S.jsx)(c3.Provider,{value:l,children:s})});function c5(e){return aL(e,"base-ui")}let c6=C.forwardRef(function(e,t){let{className:n,render:r,id:o,...a}=e,i=c5(o),{setLabelId:l}=function(){let e=C.useContext(c3);if(void 0===e)throw Error("Base UI: MenuGroupRootContext is missing. Menu group parts must be used within <Menu.Group>.");return e}();return az(()=>(l(i),()=>{l(void 0)}),[l,i]),sm("div",e,{ref:t,props:{id:i,role:"presentation",...a}})}),c9={type:"regular-item"},c8=C.memo(C.forwardRef(function(e,t){let{className:n,closeOnClick:r=!0,disabled:o=!1,highlighted:a,id:i,menuEvents:l,itemProps:s,render:c,allowMouseUpTriggerRef:u,typingRef:d,nativeButton:f,...p}=e,{getItemProps:h,itemRef:m}=function(e){let{closeOnClick:t,disabled:n=!1,highlighted:r,id:o,menuEvents:a,allowMouseUpTriggerRef:i,typingRef:l,nativeButton:s,itemMetadata:c}=e,u=C.useRef(null),{getButtonProps:d,buttonRef:f}=sb({disabled:n,focusableWhenDisabled:!0,native:s}),p=C.useCallback(e=>lQ({id:o,role:"menuitem",tabIndex:r?0:-1,onMouseEnter(){"submenu-trigger"===c.type&&c.setActive()},onKeyUp:e=>{" "===e.key&&l.current&&e.preventBaseUIHandler()},onClick:e=>{t&&a.emit("close",{domEvent:e,reason:"item-press"})},onMouseUp:()=>{u.current&&i.current&&"regular-item"===c.type&&u.current.click()}},e,d),[o,r,d,l,t,a,i,c]),h=l9(u,f);return C.useMemo(()=>({getItemProps:p,itemRef:h}),[p,h])}({closeOnClick:r,disabled:o,highlighted:a,id:i,menuEvents:l,allowMouseUpTriggerRef:u,typingRef:d,nativeButton:f,itemMetadata:c9});return sm("div",e,{state:C.useMemo(()=>({disabled:o,highlighted:a}),[o,a]),ref:[m,t],props:[s,p,h]})})),c7=C.forwardRef(function(e,t){let{id:n,label:r,nativeButton:o=!1,...a}=e,i=C.useRef(null),l=s_({label:r}),s=l9(t,l.ref,i),{itemProps:c,activeIndex:u,allowMouseUpTriggerRef:d,typingRef:f}=lL(),p=c5(n),h=l.index===u,{events:m}=C.useContext(aD);return(0,S.jsx)(c8,{...a,id:p,ref:s,highlighted:h,menuEvents:m,itemProps:c,allowMouseUpTriggerRef:d,typingRef:f,nativeButton:o})});var ue="__next_builtin__";function ut(e){return e.replace(new RegExp("^".concat(ue)),"").replace(new RegExp("".concat("@boundary","$")),"")}var un="boundary:";function ur(e){return e.startsWith(un)}function uo(e){return e.replace(un,"")}function ua(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function ui(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function ul(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function us(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return ua(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return ua(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}var uc=function(){for(var e=arguments.length,t=Array(e),n=0;n<e;n++)t[n]=arguments[n];return function(e){t.forEach(function(t){"function"==typeof t?t(e):t&&(t.current=e)})}};function uu(e){var t,n=e.nodeState,r=e.boundaries,o=n.pagePath,a=n.boundaryType,i=n.setBoundaryType,l=us((0,C.useState)(!1),2),s=l[0],c=l[1],u=dk().shadowRoot,d=(0,C.useRef)(null),f=(0,C.useRef)(null);ns(f,d,s,function(){c(!1)},null==(t=d.current)?void 0:t.ownerDocument);var p=(Object.values(r).find(function(e){return null!==e})||"").split(".").pop()||"js",h=(0,C.useMemo)(function(){return Object.fromEntries(Object.entries(r).map(function(e){var t=us(e,2),n=t[0],r=ut((t[1]||"").split("/").pop()||"".concat(n,".").concat(p));return[n,r]}))},[r,p]),m=(o||"").split("/").pop()||"",g=ut(a?"page.".concat(p):m||"page.".concat(p)),v=[{label:h.loading,value:"loading",icon:(0,S.jsx)(ud,{}),disabled:!r.loading},{label:h.error,value:"error",icon:(0,S.jsx)(uf,{}),disabled:!r.error},{label:h["not-found"],value:"not-found",icon:(0,S.jsx)(up,{}),disabled:!r["not-found"]}],y={label:a?"Reset":g,value:"reset",icon:(0,S.jsx)(uh,{}),disabled:null===a},b=(0,C.useCallback)(function(e){var t=new URLSearchParams({file:e.filePath,isAppRelativePath:"1"});fetch("".concat(process.env.__NEXT_ROUTER_BASEPATH||"","/__nextjs_launch-editor?").concat(t.toString())).catch(console.warn)},[]),x=(0,C.useCallback)(function(e){switch(e){case"not-found":case"loading":case"error":i(e);break;case"reset":i(null);break;case"open-editor":o&&b({filePath:o})}},[i,o,b]),w=(0,C.useMemo)(function(){return"layout"!==n.type&&"template"!==n.type&&Object.values(r).some(function(e){return null!==e})},[n.type,r]);return(0,S.jsxs)(l6,{delay:0,modal:!1,open:s,onOpenChange:c,children:[(0,S.jsx)(sj,{className:"segment-boundary-trigger","data-nextjs-dev-overlay-segment-boundary-trigger-button":!0,render:function(e){var t=uc(e.ref,d);return(0,S.jsx)(ug,ul(ui({},e),{ref:t}))},disabled:!w}),(0,S.jsx)(cn,{container:u,children:(0,S.jsx)(cV,{className:"segment-boundary-dropdown-positioner",side:"bottom",align:"center",sideOffset:6,arrowPadding:8,ref:f,children:(0,S.jsxs)(c2,{className:"segment-boundary-dropdown",children:[(0,S.jsxs)(c4,{children:[(0,S.jsx)(c6,{className:"segment-boundary-group-label",children:"Toggle Overrides"}),v.map(function(e){return(0,S.jsxs)(c7,{className:"segment-boundary-dropdown-item",onClick:function(){return x(e.value)},disabled:e.disabled,children:[e.icon,e.label]},e.value)})]}),(0,S.jsx)(c4,{children:(0,S.jsxs)(c7,{className:"segment-boundary-dropdown-item",onClick:function(){return x(y.value)},disabled:y.disabled,children:[y.icon,y.label]},y.value)})]})})})]})}function ud(){var e,t,n=(0,O.c)(2);return n[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("g",{clipPath:"url(#clip0_2759_1866)",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 3.5C13.5899 3.5 16.5 6.41015 16.5 10C16.5 13.5899 13.5899 16.5 10 16.5C6.41015 16.5 3.5 13.5899 3.5 10C3.5 6.41015 6.41015 3.5 10 3.5ZM2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10ZM10.75 9.62402V6H9.25V9.875C9.25 10.1898 9.39858 10.486 9.65039 10.6748L11.5498 12.0996L12.1504 12.5498L13.0498 11.3496L12.4502 10.9004L10.75 9.62402Z",fill:"currentColor"})}),n[0]=e):e=n[0],n[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsxs)("svg",{width:"20px",height:"20px",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e,(0,S.jsx)("defs",{children:(0,S.jsx)("clipPath",{id:"clip0_2759_1866",children:(0,S.jsx)("rect",{width:"16",height:"16",fill:"white",transform:"translate(2 2)"})})})]}),n[1]=t):t=n[1],t}function uf(){var e,t,n=(0,O.c)(2);return n[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("g",{clipPath:"url(#clip0_2759_1881)",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M3.5 7.30762V12.6924L7.30762 16.5H12.6924L16.5 12.6924V7.30762L12.6924 3.5H7.30762L3.5 7.30762ZM18 12.8994L17.9951 12.998C17.9724 13.2271 17.8712 13.4423 17.707 13.6064L13.6064 17.707L13.5332 17.7734C13.3806 17.8985 13.1944 17.9757 12.998 17.9951L12.8994 18H7.10059L7.00195 17.9951C6.80562 17.9757 6.6194 17.8985 6.4668 17.7734L6.39355 17.707L2.29297 13.6064C2.12883 13.4423 2.02756 13.2271 2.00488 12.998L2 12.8994V7.10059C2 6.83539 2.10546 6.58109 2.29297 6.39355L6.39355 2.29297C6.55771 2.12883 6.77294 2.02756 7.00195 2.00488L7.10059 2H12.8994L12.998 2.00488C13.2271 2.02756 13.4423 2.12883 13.6064 2.29297L17.707 6.39355C17.8945 6.58109 18 6.83539 18 7.10059V12.8994ZM9.25 5.75H10.75L10.75 10.75H9.25L9.25 5.75ZM10 14C10.5523 14 11 13.5523 11 13C11 12.4477 10.5523 12 10 12C9.44772 12 9 12.4477 9 13C9 13.5523 9.44772 14 10 14Z",fill:"currentColor"})}),n[0]=e):e=n[0],n[1]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsxs)("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e,(0,S.jsx)("defs",{children:(0,S.jsx)("clipPath",{id:"clip0_2759_1881",children:(0,S.jsx)("rect",{width:"16",height:"16",fill:"white",transform:"translate(2 2)"})})})]}),n[1]=t):t=n[1],t}function up(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"20px",height:"20px",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10.5586 2.5C11.1341 2.50004 11.6588 2.8294 11.9091 3.34766L17.8076 15.5654C18.1278 16.2292 17.6442 16.9997 16.9072 17H3.09274C2.35574 16.9997 1.8721 16.2292 2.19235 15.5654L8.09079 3.34766C8.34109 2.8294 8.86583 2.50004 9.44137 2.5H10.5586ZM3.89059 15.5H16.1093L10.5586 4H9.44137L3.89059 15.5ZM9.24997 6.75H10.75L10.75 10.75H9.24997L9.24997 6.75ZM9.99997 14C10.5523 14 11 13.5523 11 13C11 12.4477 10.5523 12 9.99997 12C9.44768 12 8.99997 12.4477 8.99997 13C8.99997 13.5523 9.44768 14 9.99997 14Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function uh(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("path",{d:"M9.96484 3C13.8463 3.00018 17 6.13012 17 10C17 13.8699 13.8463 16.9998 9.96484 17C7.62404 17 5.54877 15.8617 4.27051 14.1123L3.82812 13.5068L5.03906 12.6221L5.48145 13.2275C6.48815 14.6053 8.12092 15.5 9.96484 15.5C13.0259 15.4998 15.5 13.0335 15.5 10C15.5 6.96654 13.0259 4.50018 9.96484 4.5C7.42905 4.5 5.29544 6.19429 4.63867 8.5H8V10H2.75C2.33579 10 2 9.66421 2 9.25V4H3.5V7.2373C4.57781 4.74376 7.06749 3 9.96484 3Z",fill:"currentColor"})}),t[0]=e):e=t[0],e}function um(e){var t,n,r=(0,O.c)(3);return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M8.7071 2.39644C8.31658 2.00592 7.68341 2.00592 7.29289 2.39644L4.46966 5.21966L3.93933 5.74999L4.99999 6.81065L5.53032 6.28032L7.99999 3.81065L10.4697 6.28032L11 6.81065L12.0607 5.74999L11.5303 5.21966L8.7071 2.39644ZM5.53032 9.71966L4.99999 9.18933L3.93933 10.25L4.46966 10.7803L7.29289 13.6035C7.68341 13.9941 8.31658 13.9941 8.7071 13.6035L11.5303 10.7803L12.0607 10.25L11 9.18933L10.4697 9.71966L7.99999 12.1893L5.53032 9.71966Z",fill:"currentColor"}),r[0]=t):t=r[0],r[1]!==e?(n=(0,S.jsx)("svg",ul(ui({strokeLinejoin:"round",viewBox:"0 0 16 16"},e),{children:t})),r[1]=e,r[2]=n):n=r[2],n}function ug(e){var t,n,r=(0,O.c)(3);return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("span",{className:"segment-boundary-trigger-text",children:(0,S.jsx)(um,{className:"plus-icon"})}),r[0]=t):t=r[0],r[1]!==e?(n=(0,S.jsx)("button",ul(ui({},e),{children:t})),r[1]=e,r[2]=n):n=r[2],n}let uv=C.createContext(void 0);function uy(){let e=C.useContext(uv);if(void 0===e)throw Error("Base UI: TooltipRootContext is missing. Tooltip parts must be placed within <Tooltip.Root>.");return e}let ub=C.forwardRef(function(e,t){let{className:n,render:r,...o}=e,{open:a,setTriggerElement:i,triggerProps:l}=uy();return sm("button",e,{state:C.useMemo(()=>({open:a}),[a]),ref:[t,i],props:[l,o],customStyleHookMapping:sd})}),ux=C.createContext(void 0);function uw(){let e=C.useContext(ux);if(void 0===e)throw Error("Base UI: TooltipPositionerContext is missing. TooltipPositioner parts must be placed within <Tooltip.Positioner>.");return e}let u_=C.forwardRef(function(e,t){let{className:n,render:r,...o}=e,{open:a,arrowRef:i,side:l,align:s,arrowUncentered:c,arrowStyles:u}=uw();return sm("div",e,{state:C.useMemo(()=>({open:a,side:l,align:s,uncentered:c}),[a,l,s,c]),ref:[t,i],props:[{style:u,"aria-hidden":!0},o],customStyleHookMapping:sp})}),uk={...sp,...sr},uj=C.forwardRef(function(e,t){let{className:n,render:r,...o}=e,{open:a,instantType:i,transitionStatus:l,popupProps:s,popupRef:c,onOpenChangeComplete:u}=uy(),{side:d,align:f}=uw();return lR({open:a,ref:c,onComplete(){a&&u?.(!0)}}),sm("div",e,{state:C.useMemo(()=>({open:a,side:d,align:f,instant:i,transitionStatus:l}),[a,d,f,i,l]),ref:[t,c],props:[s,"starting"===l?iG:iX,o],customStyleHookMapping:uk})}),uS=C.createContext(void 0),uO=C.forwardRef(function(e,t){let{render:n,className:r,anchor:o,positionMethod:a="absolute",side:i="top",align:l="center",sideOffset:s=0,alignOffset:c=0,collisionBoundary:u="clipping-ancestors",collisionPadding:d=5,arrowPadding:f=5,sticky:p=!1,trackAnchor:h=!0,collisionAvoidance:m=i0,...g}=e,{open:v,setPositionerElement:y,mounted:b,floatingRootContext:x,trackCursorAxis:w,hoverable:_}=uy(),k=cR({anchor:o,positionMethod:a,floatingRootContext:x,mounted:b,side:i,sideOffset:s,align:l,alignOffset:c,collisionBoundary:u,collisionPadding:d,sticky:p,arrowPadding:f,trackAnchor:h,keepMounted:function(){let e=C.useContext(uS);if(void 0===e)throw Error("Base UI: <Tooltip.Portal> is missing.");return e}(),collisionAvoidance:m}),j=C.useMemo(()=>{let e={};return v&&"both"!==w&&_||(e.pointerEvents="none"),{role:"presentation",hidden:!b,style:{...k.positionerStyles,...e}}},[v,w,_,b,k.positionerStyles]),O=C.useMemo(()=>({props:j,...k}),[j,k]),P=C.useMemo(()=>({open:v,side:O.side,align:O.align,anchorHidden:O.anchorHidden}),[v,O.side,O.align,O.anchorHidden]),E=C.useMemo(()=>({...P,arrowRef:O.arrowRef,arrowStyles:O.arrowStyles,arrowUncentered:O.arrowUncentered}),[P,O.arrowRef,O.arrowStyles,O.arrowUncentered]),T=sm("div",e,{state:P,props:[O.props,g],ref:[t,y],customStyleHookMapping:sp});return(0,S.jsx)(ux.Provider,{value:E,children:T})});function uC(e){let t=s7({root:e.root});return t&&ex.createPortal(e.children,t)}function uP(e){let{children:t,keepMounted:n=!1,container:r}=e,{mounted:o}=uy();return o||n?(0,S.jsx)(uS.Provider,{value:n,children:(0,S.jsx)(uC,{root:r,children:t})}):null}let uE=C.createContext({hasProvider:!1,timeoutMs:0,delayRef:{current:0},initialDelayRef:{current:0},timeout:new a_,currentIdRef:{current:null},currentContextRef:{current:null}});function uT(e){let{children:t,delay:n,timeoutMs:r=0}=e,o=C.useRef(n),a=C.useRef(n),i=C.useRef(null),l=C.useRef(null),s=ak();return(0,S.jsx)(uE.Provider,{value:C.useMemo(()=>({hasProvider:!0,delayRef:o,initialDelayRef:a,currentIdRef:i,timeoutMs:r,currentContextRef:l,timeout:s}),[r,s]),children:t})}let uI=C.createContext(void 0),uN=function(e){let{delay:t,closeDelay:n,timeout:r=400}=e,o=C.useMemo(()=>({delay:t,closeDelay:n}),[t,n]),a=C.useMemo(()=>({open:t,close:n}),[t,n]);return(0,S.jsx)(uI.Provider,{value:o,children:(0,S.jsx)(uT,{delay:a,timeoutMs:r,children:e.children})})};function uL(e){return null!=e&&null!=e.clientX}function uA(e){let{disabled:t=!1,defaultOpen:n=!1,onOpenChange:r,open:o,delay:a,closeDelay:i,hoverable:l=!0,trackCursorAxis:s="none",actionsRef:c,onOpenChangeComplete:u}=e,d=a??600,f=i??0,[p,h]=C.useState(null),[m,g]=C.useState(null),[v,y]=C.useState(),b=C.useRef(null),[x,w]=aE({controlled:o,default:n,name:"Tooltip",state:"open"}),_=!t&&x;function k(e,t,n){let o="trigger-hover"===n,a=e&&"trigger-focus"===n,i=!e&&("trigger-press"===n||"escape-key"===n);function l(){r?.(e,t,n),w(e)}o?ex.flushSync(l):l(),a||i?y(a?"focus":"dismiss"):"trigger-hover"===n&&y(void 0)}let j=aO(k);x&&t&&k(!1,void 0,"disabled");let{mounted:O,setMounted:P,transitionStatus:E}=lz(_),T=aO(()=>{P(!1),u?.(!1)});lR({enabled:!c,open:_,ref:b,onComplete(){_||T()}}),C.useImperativeHandle(c,()=>({unmount:T}),[T]);let I=aU({elements:{reference:p,floating:m},open:_,onOpenChange(e,t,n){j(e,t,lq(n))}}),N=C.useContext(uI),{delayRef:L,isInstantPhase:A,hasProvider:z}=function(e,t={}){let{open:n,onOpenChange:r,floatingId:o}=e,{enabled:a=!0}=t,{currentIdRef:i,delayRef:l,timeoutMs:s,initialDelayRef:c,currentContextRef:u,hasProvider:d,timeout:f}=C.useContext(uE),[p,h]=C.useState(!1);return az(()=>{function e(){h(!1),u.current?.setIsInstantPhase(!1),i.current=null,u.current=null,l.current=c.current}if(a&&i.current&&!n&&i.current===o){if(h(!1),s)return f.start(s,e),()=>{f.clear()};e()}},[a,n,o,i,l,s,c,u,f]),az(()=>{if(!a||!n)return;let e=u.current,t=i.current;u.current={onOpenChange:r,setIsInstantPhase:h},i.current=o,l.current={open:0,close:iM(c.current,"close")},null!==t&&t!==o?(f.clear(),h(!0),e?.setIsInstantPhase(!0),e?.onOpenChange(!1)):(h(!1),e?.setIsInstantPhase(!1))},[a,n,o,r,i,l,s,c,u,f]),az(()=>()=>{u.current=null},[u]),C.useMemo(()=>({hasProvider:d,delayRef:l,isInstantPhase:p}),[d,l,p])}(I),R=A?"delay":v,D=iF(I,{enabled:!t,mouseOnly:!0,move:!1,handleClose:l&&"both"!==s?iB():null,restMs(){let e=N?.delay,t="object"==typeof L.current?L.current.open:void 0,n=d;return z&&(n=0!==t?a??e??d:0),n},delay(){let e="object"==typeof L.current?L.current.close:void 0,t=f;return null==i&&z&&(t=e),{close:t}}}),M=iq(I,{enabled:!t}),Z=i3(I,{enabled:!t,referencePress:!0}),{getReferenceProps:F,getFloatingProps:U}=lE([D,M,Z,function(e,t={}){let{open:n,dataRef:r,elements:{floating:o,domReference:a},refs:i}=e,{enabled:l=!0,axis:s="both",x:c=null,y:u=null}=t,d=C.useRef(!1),f=C.useRef(null),[p,h]=C.useState(),[m,g]=C.useState([]),v=aO((e,t)=>{if(!d.current&&(!r.current.openEvent||uL(r.current.openEvent))){var n,o;let l,c,u;i.setPositionReference((n=a,o={x:e,y:t,axis:s,dataRef:r,pointerType:p},l=null,c=null,u=!1,{contextElement:n||void 0,getBoundingClientRect(){let e=n?.getBoundingClientRect()||{width:0,height:0,x:0,y:0},t="x"===o.axis||"both"===o.axis,r="y"===o.axis||"both"===o.axis,a=["mouseenter","mousemove"].includes(o.dataRef.current.openEvent?.type||"")&&"touch"!==o.pointerType,i=e.width,s=e.height,d=e.x,f=e.y;return null==l&&o.x&&t&&(l=e.x-o.x),null==c&&o.y&&r&&(c=e.y-o.y),d-=l||0,f-=c||0,i=0,s=0,!u||a?(i="y"===o.axis?e.width:0,s="x"===o.axis?e.height:0,d=t&&null!=o.x?o.x:d,f=r&&null!=o.y?o.y:f):u&&!a&&(s="x"===o.axis?e.height:s,i="y"===o.axis?e.width:i),u=!0,{width:i,height:s,x:d,y:f,top:f,right:d+i,bottom:f+s,left:d}}}))}}),y=aO(e=>{null==c&&null==u&&(n?f.current||g([]):v(e.clientX,e.clientY))}),b=ix(p)?o:n,x=C.useCallback(()=>{if(!b||!l||null!=c||null!=u)return;let e=aB(o);function t(n){iE(o,iT(n))?(e.removeEventListener("mousemove",t),f.current=null):v(n.clientX,n.clientY)}if(!r.current.openEvent||uL(r.current.openEvent)){e.addEventListener("mousemove",t);let n=()=>{e.removeEventListener("mousemove",t),f.current=null};return f.current=n,n}i.setPositionReference(a)},[b,l,c,u,o,r,i,a,v]);C.useEffect(()=>x(),[x,m]),C.useEffect(()=>{l&&!o&&(d.current=!1)},[l,o]),C.useEffect(()=>{!l&&n&&(d.current=!0)},[l,n]),az(()=>{l&&(null!=c||null!=u)&&(d.current=!1,v(c,u))},[l,c,u,v]);let w=C.useMemo(()=>{function e(e){h(e.pointerType)}return{onPointerDown:e,onPointerEnter:e,onMouseMove:y,onMouseEnter:y}},[y]);return C.useMemo(()=>l?{reference:w}:{},[l,w])}(I,{enabled:!t&&"none"!==s,axis:"none"===s?void 0:s})]),H=C.useMemo(()=>({open:_,setOpen:j,mounted:O,setMounted:P,setTriggerElement:h,positionerElement:m,setPositionerElement:g,popupRef:b,triggerProps:F(),popupProps:U(),floatingRootContext:I,instantType:R,transitionStatus:E,onOpenChangeComplete:u}),[_,j,O,P,h,m,g,b,F,U,I,R,E,u]),V=C.useMemo(()=>({...H,delay:d,closeDelay:f,trackCursorAxis:s,hoverable:l}),[H,d,f,s,l]);return(0,S.jsx)(uv.Provider,{value:V,children:e.children})}var uz=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/components/tooltip/tooltip.css"),uR={};uR.styleTagTransform=x(),uR.setAttributes=g(),uR.insert=h(),uR.domAPI=f(),uR.insertStyleElement=y(),u()(uz.A,uR),uz.A&&uz.A.locals&&uz.A.locals;var uD=(0,C.forwardRef)(function(e,t){var n,r,o,a,i,l,s,c,u,d,f,p,h=(0,O.c)(35),m=e.className,g=e.children,v=e.title,y=e.direction,b=e.arrowSize,x=e.offset,w=void 0===y?"top":y,_=void 0===b?6:b,k=dk().shadowRoot;if(!v)return g;h[0]!==g?(n=function(e){var t,n;return(0,S.jsx)("span",(t=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}({},e),n=n={children:g},Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(n)).forEach(function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(n,e))}),t))},h[0]=g,h[1]=n):n=h[1],h[2]!==t||h[3]!==n?(r=(0,S.jsx)(ub,{ref:t,render:n}),h[2]=t,h[3]=n,h[4]=r):r=h[4];var j=(void 0===x?8:x)+_,C="".concat(_,"px"),P="".concat(_,"px");h[5]!==C||h[6]!==P?(o={"--anchor-width":C,"--anchor-height":P},h[5]=C,h[6]=P,h[7]=o):o=h[7];var E=o;h[8]!==m?(a=e9("tooltip",m),h[8]=m,h[9]=a):a=h[9];var T="".concat(_,"px");h[10]!==T?(i={"--arrow-size":T},h[10]=T,h[11]=i):i=h[11];var I=i,N="tooltip-arrow--".concat(w);h[12]!==N?(l=e9("tooltip-arrow",N),h[12]=N,h[13]=l):l=h[13];var L="".concat(_,"px");h[14]!==L?(s={"--arrow-size":L},h[14]=L,h[15]=s):s=h[15];var A=s;return h[16]!==l||h[17]!==A?(c=(0,S.jsx)(u_,{className:l,style:A}),h[16]=l,h[17]=A,h[18]=c):c=h[18],h[19]!==a||h[20]!==I||h[21]!==c||h[22]!==v?(u=(0,S.jsxs)(uj,{className:a,style:I,children:[v,c]}),h[19]=a,h[20]=I,h[21]=c,h[22]=v,h[23]=u):u=h[23],h[24]!==w||h[25]!==E||h[26]!==u||h[27]!==j?(d=(0,S.jsx)(uO,{side:w,sideOffset:j,className:"tooltip-positioner",style:E,children:u}),h[24]=w,h[25]=E,h[26]=u,h[27]=j,h[28]=d):d=h[28],h[29]!==k||h[30]!==d?(f=(0,S.jsx)(uP,{container:k,children:d}),h[29]=k,h[30]=d,h[31]=f):f=h[31],h[32]!==f||h[33]!==r?(p=(0,S.jsx)(uN,{children:(0,S.jsxs)(uA,{delay:400,children:[r,f]})}),h[32]=f,h[33]=r,h[34]=p):p=h[34],p});function uM(e){var t,n,r=(0,O.c)(3),o=e.possibleExtension,a=e.missingGlobalError?"No global-error.".concat(o," found: Add one to ensure users see a helpful message when an unexpected error occurs."):null;return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)(uK,{}),r[0]=t):t=r[0],r[1]!==a?(n=(0,S.jsx)("span",{className:"segment-explorer-suggestions",children:(0,S.jsx)(uD,{className:"segment-explorer-suggestions-tooltip",title:a,children:t})}),r[1]=a,r[2]=n):n=r[2],n}function uZ(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function uF(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}var uU=function(e){var t,n;return!!(null==(t=e.value)?void 0:t.type)&&!!(null==(n=e.value)?void 0:n.pagePath)};function uH(e){var t,n,r=(0,O.c)(3),o=e.page;return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)(uY,{}),r[0]=t):t=r[0],r[1]!==o?(n=(0,S.jsxs)("div",{className:"segment-explorer-page-route-bar",children:[t,(0,S.jsx)("span",{className:"segment-explorer-page-route-bar-path",children:o})]}),r[1]=o,r[2]=n):n=r[2],n}function uV(e){var t,n,r,o=(0,O.c)(9),a=e.activeBoundariesCount,i=e.onGlobalReset,l=a>0,s="segment-explorer-footer-button ".concat(l?"":"segment-explorer-footer-button--disabled"),c=l?i:void 0,u=!l;return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("span",{className:"segment-explorer-footer-text",children:"Clear Segment Overrides"}),o[0]=t):t=o[0],o[1]!==a||o[2]!==l?(n=l&&(0,S.jsx)("span",{className:"segment-explorer-footer-badge",children:a}),o[1]=a,o[2]=l,o[3]=n):n=o[3],o[4]!==s||o[5]!==c||o[6]!==u||o[7]!==n?(r=(0,S.jsx)("div",{className:"segment-explorer-footer",children:(0,S.jsxs)("button",{className:s,onClick:c,disabled:u,type:"button",children:[t,n]})}),o[4]=s,o[5]=c,o[6]=u,o[7]=n,o[8]=r):r=o[8],r}function uB(e){var t,n,r,o,a,i=(0,O.c)(15),l=e.type,s=e.isBuiltin,c=e.isOverridden,u=e.filePath,d=e.fileName,f="segment-explorer-file-label--".concat(l),p=s&&"segment-explorer-file-label--builtin",h=c&&"segment-explorer-file-label--overridden";return i[0]!==f||i[1]!==p||i[2]!==h?(t=e9("segment-explorer-file-label",f,p,h),i[0]=f,i[1]=p,i[2]=h,i[3]=t):t=i[3],i[4]!==u?(n=function(){var e;e=new URLSearchParams({file:{filePath:u}.filePath,isAppRelativePath:"1"}),fetch("".concat(process.env.__NEXT_ROUTER_BASEPATH||"","/__nextjs_launch-editor?").concat(e.toString()))},i[4]=u,i[5]=n):n=i[5],i[6]!==d?(r=(0,S.jsx)("span",{className:"segment-explorer-file-label-text",children:d}),i[6]=d,i[7]=r):r=i[7],i[8]!==s?(o=s?(0,S.jsx)(uK,{}):(0,S.jsx)(uG,{className:"code-icon"}),i[8]=s,i[9]=o):o=i[9],i[10]!==t||i[11]!==n||i[12]!==r||i[13]!==o?(a=(0,S.jsxs)("span",{className:t,onClick:n,children:[r,o]}),i[10]=t,i[11]=n,i[12]=r,i[13]=o,i[14]=a):a=i[14],a}function u$(e){var t,n,r,o,a,i,l,s,c=(0,O.c)(17),u=e.page,d=(0,C.useSyncExternalStore)(ac,au,ad);c[0]!==d?(t=function e(t){var n,r=0;return(null==(n=t.value)?void 0:n.setBoundaryType)&&null!==t.value.boundaryType&&!ur(t.value.type)&&r++,Object.values(t.children).forEach(function(t){t&&(r+=e(t))}),r}(d),c[0]=d,c[1]=t):t=c[1];var f=t;c[2]!==d?(n=function(){!function e(t){var n;(null==(n=t.value)?void 0:n.setBoundaryType)&&t.value.setBoundaryType(null),Object.values(t.children).forEach(function(t){t&&e(t)})}(d)},c[2]=d,c[3]=n):n=c[3];var p=n;return c[4]===Symbol.for("react.memo_cache_sentinel")?(r={display:"flex",flexDirection:"column",height:"100%"},c[4]=r):r=c[4],c[5]!==u?(o=(0,S.jsx)(uH,{page:u}),c[5]=u,c[6]=o):o=c[6],c[7]===Symbol.for("react.memo_cache_sentinel")?(a={flex:"1 1 auto",overflow:"auto"},c[7]=a):a=c[7],c[8]!==d?(i=(0,S.jsx)("div",{className:"segment-explorer-content","data-nextjs-devtool-segment-explorer":!0,style:a,children:(0,S.jsx)(uW,{node:d,level:0,segment:""})}),c[8]=d,c[9]=i):i=c[9],c[10]!==f||c[11]!==p?(l=(0,S.jsx)(uV,{activeBoundariesCount:f,onGlobalReset:p}),c[10]=f,c[11]=p,c[12]=l):l=c[12],c[13]!==o||c[14]!==i||c[15]!==l?(s=(0,S.jsxs)("div",{"data-nextjs-devtools-panel-segments-explorer":!0,style:r,children:[o,i,l]}),c[13]=o,c[14]=i,c[15]=l,c[16]=s):s=c[16],s}var uq="global-error";function uW(e){var t=e.segment,n=e.node,r=e.level,o=(0,C.useMemo)(function(){return Object.keys(n.children)},[n.children]),a=(0,C.useMemo)(function(){var e=[];return o.forEach(function(t){var r=n.children[t];if(r&&r.value){var o=uo(r.value.type),a=o===uq;(a&&!r.value.pagePath.startsWith(ue)||!a&&ur(r.value.type))&&e.push(o)}}),0===r&&!e.includes(uq)},[n.children,o,r]),i=o.sort(function(e,t){var r=e.includes("."),o=t.includes(".");if(r&&!o)return -1;if(!r&&o)return 1;if(r&&o){var a,i,l,s,c,u,d,f,p=null==(i=n.children[e])||null==(a=i.value)?void 0:a.type,h=null==(s=n.children[t])||null==(l=s.value)?void 0:l.type,m=function(e){return e?"layout"===e?1:"template"===e?2:"page"===e?3:ur(e)?4:5:5},g=m(p),v=m(h);if(g!==v)return g-v;var y=(null==(u=n.children[e])||null==(c=u.value)?void 0:c.pagePath)||"",b=(null==(f=n.children[t])||null==(d=f.value)?void 0:d.pagePath)||"";return y.localeCompare(b)}return e.localeCompare(t)}),l=0!==r||t?t:"app",s=[],c=[],u=!0,d=!1,f=void 0;try{for(var p,h=i[Symbol.iterator]();!(u=(p=h.next()).done);u=!0){var m=p.value,g=n.children[m];if(g){if(uU(g)){c.push(m);continue}s.push(m)}}}catch(e){d=!0,f=e}finally{try{u||null==h.return||h.return()}finally{if(d)throw f}}for(var v=ut(c[0]||"").split(".").pop()||"js",y=null,b=i.length-1;b>=0;b--){var x=n.children[i[b]];if(x&&x.value){var w=ur(x.value.type);if(!y&&!w){y=x;break}}}var _=null,k=!0,j=!1,O=void 0;try{for(var P,E=i[Symbol.iterator]();!(k=(P=E.next()).done);k=!0){var T=P.value,I=n.children[T];if(I&&I.value&&ur(I.value.type)){_=I;break}}}catch(e){j=!0,O=e}finally{try{k||null==E.return||E.return()}finally{if(j)throw O}}y=y||_;var N=c.length>0,L={"not-found":null,loading:null,error:null,"global-error":null};return c.forEach(function(e){var t=n.children[e];if(t&&t.value&&ur(t.value.type)){var r=uo(t.value.type);r in L&&(L[r]=t.value.pagePath||null)}}),(0,S.jsxs)(S.Fragment,{children:[N&&(0,S.jsx)("div",{className:"segment-explorer-item","data-nextjs-devtool-segment-explorer-segment":t+"-"+r,children:(0,S.jsx)("div",{className:"segment-explorer-item-row",style:uZ({},{paddingLeft:"".concat((r+1)*8,"px")}),children:(0,S.jsx)("div",{className:"segment-explorer-item-row-main",children:(0,S.jsxs)("div",{className:"segment-explorer-filename",children:[l&&(0,S.jsxs)("span",{className:"segment-explorer-filename--path",children:[l,(0,S.jsx)("small",{children:"/"})]}),a&&(0,S.jsx)(uM,{possibleExtension:v,missingGlobalError:a}),c.length>0&&(0,S.jsx)("span",{className:"segment-explorer-files",children:c.map(function(e){var t=n.children[e];if(!t||!t.value||ur(t.value.type))return null;var r=t.value.pagePath,o=r.split("/").pop()||"",a=r.startsWith(ue),i=ut(o),l=a?"The default Next.js ".concat(t.value.type," is being shown. You can customize this page by adding your own ").concat(i," file to the app/ directory."):null,s=null!==t.value.boundaryType;return(0,S.jsx)(uD,{className:"segment-explorer-file-label-tooltip--"+(a?"lg":"sm"),direction:a?"right":"top",title:l,offset:12,children:(0,S.jsx)(uB,{type:t.value.type,isBuiltin:a,isOverridden:s,filePath:r,fileName:i})},e)})}),y&&y.value&&(0,S.jsx)(uu,{nodeState:y.value,boundaries:L})]})})})}),s.map(function(e){var o=n.children[e];if(!o)return null;var a=N?e:t+" / "+e;return(0,S.jsx)(uW,{segment:a,node:o,level:N?r+1:r},e)})]})}function uK(e){var t,n,r,o=(0,O.c)(4);return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{d:"M14 8C14 11.3137 11.3137 14 8 14C4.68629 14 2 11.3137 2 8C2 4.68629 4.68629 2 8 2C11.3137 2 14 4.68629 14 8Z",fill:"var(--color-gray-400)"}),n=(0,S.jsx)("path",{d:"M7.75 7C8.30228 7.00001 8.75 7.44772 8.75 8V11.25H7.25V8.5H6.25V7H7.75ZM8 4C8.55228 4 9 4.44772 9 5C9 5.55228 8.55228 6 8 6C7.44772 6 7 5.55228 7 5C7 4.44772 7.44772 4 8 4Z",fill:"var(--color-gray-900)"}),o[0]=t,o[1]=n):(t=o[0],n=o[1]),o[2]!==e?(r=(0,S.jsxs)("svg",uF(uZ({width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),{children:[t,n]})),o[2]=e,o[3]=r):r=o[3],r}function uY(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"20",height:"20",viewBox:"0 0 20 20",fill:"var(--color-gray-600)",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("path",{d:"M4.5 11.25C4.5 11.3881 4.61193 11.5 4.75 11.5H14.4395L11.9395 9L13 7.93945L16.7803 11.7197L16.832 11.7764C17.0723 12.0709 17.0549 12.5057 16.7803 12.7803L13 16.5605L11.9395 15.5L14.4395 13H4.75C3.7835 13 3 12.2165 3 11.25V4.25H4.5V11.25Z"})}),t[0]=e):e=t[0],e}function uG(e){var t,n,r=(0,O.c)(3);return r[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M7.22763 14.1819L10.2276 2.18193L10.4095 1.45432L8.95432 1.09052L8.77242 1.81812L5.77242 13.8181L5.59051 14.5457L7.04573 14.9095L7.22763 14.1819ZM3.75002 12.0607L3.21969 11.5304L0.39647 8.70713C0.00594559 8.31661 0.00594559 7.68344 0.39647 7.29292L3.21969 4.46969L3.75002 3.93936L4.81068 5.00002L4.28035 5.53035L1.81068 8.00003L4.28035 10.4697L4.81068 11L3.75002 12.0607ZM12.25 12.0607L12.7804 11.5304L15.6036 8.70713C15.9941 8.31661 15.9941 7.68344 15.6036 7.29292L12.7804 4.46969L12.25 3.93936L11.1894 5.00002L11.7197 5.53035L14.1894 8.00003L11.7197 10.4697L11.1894 11L12.25 12.0607Z",fill:"currentColor"}),r[0]=t):t=r[0],r[1]!==e?(n=(0,S.jsx)("svg",uF(uZ({width:"12",height:"12",strokeLinejoin:"round",viewBox:"0 0 16 16",fill:"currentColor"},e),{children:t})),r[1]=e,r[2]=n):n=r[2],n}function uX(){var e,t,n=(e=["\n        .dev-tools-info-close-button:focus-visible {\n          outline: var(--focus-ring);\n        }\n      "],t||(t=e.slice(0)),Object.freeze(Object.defineProperties(e,{raw:{value:Object.freeze(t)}})));return uX=function(){return n},n}function uQ(e){var t,n,r,o,a,i,l,s,c,u,d,f=(0,O.c)(18),p=e.title,h=e.children,m=e.ref,g=oe().setPanel,v=(0,C.useRef)(null);return f[0]===Symbol.for("react.memo_cache_sentinel")?(t=function(){var e;null==(e=v.current)||e.focus()},n=[],f[0]=t,f[1]=n):(t=f[0],n=f[1]),(0,C.useLayoutEffect)(t,n),f[2]===Symbol.for("react.memo_cache_sentinel")?(r={width:"100%",display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 20px",userSelect:"none",WebkitUserSelect:"none",borderBottom:"1px solid var(--color-gray-alpha-400)"},f[2]=r):r=f[2],f[3]===Symbol.for("react.memo_cache_sentinel")?(o={margin:0,fontSize:"14px",color:"var(--color-text-primary)",fontWeight:"normal"},f[3]=o):o=f[3],f[4]!==p?(a=(0,S.jsx)("h3",{style:o,children:p}),f[4]=p,f[5]=a):a=f[5],f[6]!==g?(i=function(){g("panel-selector")},f[6]=g,f[7]=i):i=f[7],f[8]===Symbol.for("react.memo_cache_sentinel")?(l={background:"none",border:"none",cursor:"pointer",padding:"4px",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:"4px",color:"var(--color-gray-900)"},s=(0,S.jsx)(uJ,{}),f[8]=l,f[9]=s):(l=f[8],s=f[9]),f[10]!==i?(c=(0,S.jsx)("button",{ref:v,id:"_next-devtools-panel-close",className:"dev-tools-info-close-button",onClick:i,"aria-label":"Close devtools panel",style:l,children:s}),f[10]=i,f[11]=c):c=f[11],f[12]===Symbol.for("react.memo_cache_sentinel")?(u=(0,S.jsx)("style",{children:eg(uX())}),f[12]=u):u=f[12],f[13]!==h||f[14]!==m||f[15]!==a||f[16]!==c?(d=(0,S.jsxs)("div",{style:r,ref:m,children:[a,h,c,u]}),f[13]=h,f[14]=m,f[15]=a,f[16]=c,f[17]=d):d=f[17],d}function uJ(e){var t,n,r,o=(0,O.c)(4),a=e.size,i=void 0===a?22:a;return o[0]===Symbol.for("react.memo_cache_sentinel")?(t=(0,S.jsx)("path",{d:"M18 6 6 18"}),n=(0,S.jsx)("path",{d:"m6 6 12 12"}),o[0]=t,o[1]=n):(t=o[0],n=o[1]),o[2]!==i?(r=(0,S.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:i,height:i,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[t,n]}),o[2]=i,o[3]=r):r=o[3],r}function u0(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 20 20",fill:"none",children:(0,S.jsx)("path",{fill:"currentColor",fillRule:"evenodd",d:"m9.7 3.736.045-.236h.51l.044.236a2.024 2.024 0 0 0 1.334 1.536c.19.066.375.143.554.23.618.301 1.398.29 2.03-.143l.199-.136.36.361-.135.199a2.024 2.024 0 0 0-.143 2.03c.087.179.164.364.23.554.224.65.783 1.192 1.536 1.334l.236.044v.51l-.236.044a2.024 2.024 0 0 0-1.536 1.334 4.95 4.95 0 0 1-.23.554 2.024 2.024 0 0 0 .143 2.03l.136.199-.361.36-.199-.135a2.024 2.024 0 0 0-2.03-.143c-.179.087-.364.164-.554.23a2.024 2.024 0 0 0-1.334 1.536l-.044.236h-.51l-.044-.236a2.024 2.024 0 0 0-1.334-1.536 4.952 4.952 0 0 1-.554-.23 2.024 2.024 0 0 0-2.03.143l-.199.136-.36-.361.135-.199a2.024 2.024 0 0 0 .143-2.03 4.958 4.958 0 0 1-.23-.554 2.024 2.024 0 0 0-1.536-1.334l-.236-.044v-.51l.236-.044a2.024 2.024 0 0 0 1.536-1.334 4.96 4.96 0 0 1 .23-.554 2.024 2.024 0 0 0-.143-2.03l-.136-.199.361-.36.199.135a2.024 2.024 0 0 0 2.03.143c.179-.087.364-.164.554-.23a2.024 2.024 0 0 0 1.334-1.536ZM8.5 2h3l.274 1.46c.034.185.17.333.348.394.248.086.49.186.722.3.17.082.37.074.526-.033l1.226-.839 2.122 2.122-.84 1.226a.524.524 0 0 0-.032.526c.114.233.214.474.3.722.061.177.21.314.394.348L18 8.5v3l-1.46.274a.524.524 0 0 0-.394.348 6.47 6.47 0 0 1-.3.722.524.524 0 0 0 .033.526l.839 1.226-2.122 2.122-1.226-.84a.524.524 0 0 0-.526-.032 6.477 6.477 0 0 1-.722.3.524.524 0 0 0-.348.394L11.5 18h-3l-.274-1.46a.524.524 0 0 0-.348-.394 6.477 6.477 0 0 1-.722-.3.524.524 0 0 0-.526.033l-1.226.839-2.122-2.122.84-1.226a.524.524 0 0 0 .032-.526 6.453 6.453 0 0 1-.3-.722.524.524 0 0 0-.394-.348L2 11.5v-3l1.46-.274a.524.524 0 0 0 .394-.348c.086-.248.186-.49.3-.722a.524.524 0 0 0-.033-.526l-.839-1.226 2.122-2.122 1.226.84a.524.524 0 0 0 .526.032 6.46 6.46 0 0 1 .722-.3.524.524 0 0 0 .348-.394L8.5 2Zm3 8a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Zm1.5 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z",clipRule:"evenodd"})}),t[0]=e):e=t[0],e}function u1(){var e,t=(0,O.c)(1);return t[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)("svg",{width:"20px",height:"20px",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,S.jsx)("circle",{cx:"10",cy:"10",r:"7",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeDasharray:"32 12",opacity:"0.8",children:(0,S.jsx)("animateTransform",{attributeName:"transform",type:"rotate",from:"0 10 10",to:"360 10 10",dur:"1s",repeatCount:"indefinite"})})}),t[0]=e):e=t[0],e}var u2=__webpack_require__("../../node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.6.0_@swc+helpers@0.5.15__webpack@5.98.0_@swc+core@1.11.24_@sw_3t67rhipccjkm2dfoeigtkqyke/node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[3].use[1]!./src/next-devtools/dev-overlay/menu/panel-router.css"),u3={};u3.styleTagTransform=x(),u3.setAttributes=g(),u3.insert=h(),u3.domAPI=f(),u3.insertStyleElement=y(),u()(u2.A,u3),u2.A&&u2.A.locals&&u2.A.locals;var u4=function(){var e,t,n,r,o,a,i,l,s,c,u=(0,O.c)(27),d=oe(),f=d.setPanel,p=d.setSelectedIndex,h=dk(),m=h.state,g=h.dispatch,v=dl().totalErrorCount,y="app"===m.routerType;return u[0]!==g||u[1]!==f||u[2]!==p||u[3]!==m.isErrorOverlayOpen||u[4]!==v?(e=v>0&&{title:"".concat(v," ").concat(1===v?"issue":"issues"," found. Click to view details in the dev overlay."),label:"Issues",value:(0,S.jsx)(oW,{children:v}),onClick:function(){if(m.isErrorOverlayOpen){g({type:Y}),f(null);return}f(null),p(-1),v>0&&g({type:K})}},u[0]=g,u[1]=f,u[2]=p,u[3]=m.isErrorOverlayOpen,u[4]=v,u[5]=e):e=u[5],u[6]!==f||u[7]!==m.staticIndicator?(t="disabled"===m.staticIndicator?void 0:"pending"===m.staticIndicator?{title:"Loading...",label:"Route",value:(0,S.jsx)(u1,{})}:{title:"Current route is ".concat(m.staticIndicator,"."),label:"Route",value:"static"===m.staticIndicator?"Static":"Dynamic",onClick:function(){return f("route-type")},attributes:{"data-nextjs-route-type":m.staticIndicator}},u[6]=f,u[7]=m.staticIndicator,u[8]=t):t=u[8],u[9]!==f?(n=process.env.TURBOPACK?{title:"Turbopack is enabled.",label:"Turbopack",value:"Enabled"}:{title:"Learn about Turbopack and how to enable it in your application.",label:"Try Turbopack",value:(0,S.jsx)(oK,{}),onClick:function(){return f("turbo-info")}},u[9]=f,u[10]=n):n=u[10],u[11]===Symbol.for("react.memo_cache_sentinel")?(r=!!process.env.__NEXT_CACHE_COMPONENTS&&{title:"Cache Components is enabled.",label:"Cache Components",value:"Enabled"},u[11]=r):r=u[11],u[12]!==y||u[13]!==f?(o=y&&{label:"Route Info",value:(0,S.jsx)(oK,{}),onClick:function(){return f("segment-explorer")},attributes:{"data-segment-explorer":!0}},u[12]=y,u[13]=f,u[14]=o):o=u[14],u[15]===Symbol.for("react.memo_cache_sentinel")?(a=(0,S.jsx)(u0,{}),u[15]=a):a=u[15],u[16]!==f?(i=function(){return f("preferences")},u[16]=f,u[17]=i):i=u[17],u[18]===Symbol.for("react.memo_cache_sentinel")?(l={"data-preferences":!0},u[18]=l):l=u[18],u[19]!==i?(s={label:"Preferences",value:a,onClick:i,footer:!0,attributes:l},u[19]=i,u[20]=s):s=u[20],u[21]!==e||u[22]!==t||u[23]!==n||u[24]!==o||u[25]!==s?(c=(0,S.jsx)(o$,{items:[e,t,n,r,o,s]}),u[21]=e,u[22]=t,u[23]=n,u[24]=o,u[25]=s,u[26]=c):c=u[26],c},u5=function(){var e,t=(0,O.c)(4),n=dk(),r=n.state,o=n.dispatch,a=n.shadowRoot;return t[0]!==o||t[1]!==a||t[2]!==r.disableDevIndicator?(e=function(){o({type:W,disabled:!r.disableDevIndicator});var e=a.getElementById("panel-route"),t=a.getElementById("data-devtools-indicator");if(e&&e.firstElementChild){var n=e.firstElementChild,i="none"===n.style.display;n.style.display=i?"":"none"}if(t){var l="none"===t.style.display;t.style.display=l?"":"none"}},t[0]=o,t[1]=a,t[2]=r.disableDevIndicator,t[3]=e):e=t[3],e},u6=function(){var e,t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x,w=(0,O.c)(30),_=dk().state,k=oe().triggerRef,j=u5(),P="app"===_.routerType;w[0]!==_.hideShortcut||w[1]!==j?(s=_.hideShortcut?(e={},t=_.hideShortcut,n=j,t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e):{},w[0]=_.hideShortcut,w[1]=j,w[2]=s):s=w[2],r=s,o=k,(l=(0,O.c)(4))[0]!==o||l[1]!==r?(a=function(){var e=function(e){if(!((n=nl((t=o).current))&&("true"===n.contentEditable||"INPUT"===n.tagName||"TEXTAREA"===n.tagName||"SELECT"===n.tagName||"true"===n.dataset["shortcut-recorder"])&&!n.hasAttribute("readonly"))){var t,n,a=[];e.metaKey&&a.push("Meta"),e.ctrlKey&&a.push("Control"),e.altKey&&a.push("Alt"),e.shiftKey&&a.push("Shift"),"Meta"!==e.key&&"Control"!==e.key&&"Alt"!==e.key&&"Shift"!==e.key&&a.push(e.code);var i=a.join("+");r[i]&&(e.preventDefault(),r[i]())}};return window.addEventListener("keydown",e),function(){return window.removeEventListener("keydown",e)}},i=[o,r],l[0]=o,l[1]=r,l[2]=a,l[3]=i):(a=l[2],i=l[3]),(0,C.useEffect)(a,i),w[3]===Symbol.for("react.memo_cache_sentinel")?(c=(0,S.jsx)(dt,{name:"panel-selector",children:(0,S.jsx)(u4,{})}),w[3]=c):c=w[3];var E=500/_.scale;w[4]!==E?(u={kind:"fixed",height:E,width:512},w[4]=E,w[5]=u):u=w[5],w[6]===Symbol.for("react.memo_cache_sentinel")?(d=(0,S.jsx)(uQ,{title:"Preferences"}),f=(0,S.jsx)(u8,{}),w[6]=d,w[7]=f):(d=w[6],f=w[7]),w[8]!==u?(p=(0,S.jsx)(dt,{name:"preferences",children:(0,S.jsx)(ao,{sharePanelSizeGlobally:!1,sizeConfig:u,closeOnClickOutside:!0,header:d,children:f})}),w[8]=u,w[9]=p):p=w[9],w[10]!==_.routerType||w[11]!==_.scale||w[12]!==_.staticIndicator?(h="disabled"!==_.staticIndicator&&"pending"!==_.staticIndicator&&(0,S.jsx)(dt,{name:"route-type",children:(0,S.jsx)(ao,{sharePanelSizeGlobally:!1,sizeConfig:{kind:"fixed",height:"static"===_.staticIndicator?300/_.scale:325/_.scale,width:400/_.scale},closeOnClickOutside:!0,header:(0,S.jsx)(uQ,{title:"".concat("static"===_.staticIndicator?"Static":"Dynamic"," Route")}),children:(0,S.jsxs)("div",{className:"panel-content",children:[(0,S.jsx)(rn,{routerType:_.routerType,isStaticRoute:"static"===_.staticIndicator}),(0,S.jsx)(u9,{href:rt[_.routerType][_.staticIndicator]})]})},_.staticIndicator)}),w[10]=_.routerType,w[11]=_.scale,w[12]=_.staticIndicator,w[13]=h):h=w[13],w[14]!==P||w[15]!==_.page||w[16]!==_.scale?(m=P&&(0,S.jsx)(dt,{name:"segment-explorer",children:(0,S.jsx)(ao,{sharePanelSizeGlobally:!1,sharePanelPositionGlobally:!1,draggable:!0,sizeConfig:{kind:"resizable",maxHeight:"90vh",maxWidth:"90vw",minHeight:200/_.scale,minWidth:250/_.scale,initialSize:{height:375/_.scale,width:400/_.scale}},header:(0,S.jsx)(uQ,{title:"Route Info"}),children:(0,S.jsx)(u$,{page:_.page})})}),w[14]=P,w[15]=_.page,w[16]=_.scale,w[17]=m):m=w[17];var T=470/_.scale,I=400/_.scale;return w[18]!==I||w[19]!==T?(g={kind:"fixed",height:T,width:I},w[18]=I,w[19]=T,w[20]=g):g=w[20],w[21]===Symbol.for("react.memo_cache_sentinel")?(v=(0,S.jsx)(uQ,{title:"Try Turbopack"}),w[21]=v):v=w[21],w[22]===Symbol.for("react.memo_cache_sentinel")?(y=(0,S.jsxs)("div",{className:"panel-content",children:[(0,S.jsx)(n5,{}),(0,S.jsx)(u9,{href:"https://nextjs.org/docs/app/api-reference/turbopack"})]}),w[22]=y):y=w[22],w[23]!==g?(b=(0,S.jsx)(dt,{name:"turbo-info",children:(0,S.jsx)(ao,{sharePanelSizeGlobally:!1,sizeConfig:g,closeOnClickOutside:!0,header:v,children:y})}),w[23]=g,w[24]=b):b=w[24],w[25]!==b||w[26]!==p||w[27]!==h||w[28]!==m?(x=(0,S.jsxs)(S.Fragment,{children:[c,p,h,m,b]}),w[25]=b,w[26]=p,w[27]=h,w[28]=m,w[29]=x):x=w[29],x},u9=function(e){var t,n=(0,O.c)(2),r=e.href;return n[0]!==r?(t=(0,S.jsx)("div",{className:"dev-tools-info-button-container",children:(0,S.jsx)("a",{className:"dev-tools-info-learn-more-button",href:r,target:"_blank",rel:"noreferrer noopener",children:"Learn More"})}),n[0]=r,n[1]=t):t=n[1],t},u8=function(){var e,t,n,r,o=(0,O.c)(17),a=dk(),i=a.dispatch,l=a.state,s=oe(),c=s.setPanel,u=s.setSelectedIndex,d=oR();return o[0]!==i?(e=function(e){i({type:er,scale:e})},o[0]=i,o[1]=e):e=o[1],o[2]!==i||o[3]!==d?(t=function(e){i({type:et,devToolsPosition:e}),d(e)},o[2]=i,o[3]=d,o[4]=t):t=o[4],o[5]!==i||o[6]!==c||o[7]!==u?(n=function(){i({type:W,disabled:!0}),u(-1),c(null),fetch("/__nextjs_disable_dev_indicator",{method:"POST"})},o[5]=i,o[6]=c,o[7]=u,o[8]=n):n=o[8],o[9]!==l.devToolsPosition||o[10]!==l.hideShortcut||o[11]!==l.scale||o[12]!==l.theme||o[13]!==e||o[14]!==t||o[15]!==n?(r=(0,S.jsx)("div",{className:"user-preferences-wrapper",children:(0,S.jsx)(rA,{theme:l.theme,position:l.devToolsPosition,scale:l.scale,setScale:e,setPosition:t,hideShortcut:l.hideShortcut,setHideShortcut:dn,hide:n})}),o[9]=l.devToolsPosition,o[10]=l.hideShortcut,o[11]=l.scale,o[12]=l.theme,o[13]=e,o[14]=t,o[15]=n,o[16]=r):r=o[16],r},u7=function(){return(0,C.useContext)(de)},de=(0,C.createContext)(null);function dt(e){var t,n,r,o,a,i=(0,O.c)(12),l=e.children,s=e.name,c=oe().panel;i[0]===Symbol.for("react.memo_cache_sentinel")?(t={enterDelay:0,exitDelay:200},i[0]=t):t=i[0];var u=rB(s===c,t),d=u.mounted,f=u.rendered;if(!d)return null;i[1]!==d||i[2]!==s?(n={name:s,mounted:d},i[1]=d,i[2]=s,i[3]=n):n=i[3];var p=+!!f;i[4]!==p?(r={"--panel-opacity":p,"--panel-transition":"opacity ".concat(200,"ms ").concat(nc)},i[4]=p,i[5]=r):r=i[5];var h=r;return i[6]!==l||i[7]!==h?(o=(0,S.jsx)("div",{id:"panel-route",className:"panel-route",style:h,children:l}),i[6]=l,i[7]=h,i[8]=o):o=i[8],i[9]!==n||i[10]!==o?(a=(0,S.jsx)(de,{value:n,children:o}),i[9]=n,i[10]=o,i[11]=a):a=i[11],a}function dn(e){rI({hideShortcut:e})}function dr(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function da(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),!t||a.length!==t);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(e,t)||function(e,t){if(e){if("string"==typeof e)return dr(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return dr(e,t)}}(e,t)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}var di=(0,C.createContext)(null),dl=function(){return(0,C.useContext)(di)};function ds(){var e,t,n,r,o=(0,O.c)(11),a=da((0,C.useState)(null),2),i=a[0],l=a[1],s=da((0,C.useState)(-1),2),c=s[0],u=s[1],d=dk(),f=d.state,p=d.dispatch,h=d.getSquashedHydrationErrorDetails,m=(0,C.useRef)(null);return o[0]===Symbol.for("react.memo_cache_sentinel")?(e=(0,S.jsx)(r1,{}),t=(0,S.jsx)(rU,{}),o[0]=e,o[1]=t):(e=o[0],t=o[1]),o[2]!==p||o[3]!==h||o[4]!==i||o[5]!==c||o[6]!==f?(n=function(e){var t=e.runtimeErrors,n=e.totalErrorCount;return(0,S.jsx)(S.Fragment,{children:f.showIndicator?(0,S.jsx)(S.Fragment,{children:(0,S.jsx)(di,{value:{runtimeErrors:t,totalErrorCount:n},children:(0,S.jsxs)(r7,{value:{panel:i,setPanel:l,triggerRef:m,selectedIndex:c,setSelectedIndex:u},children:[(0,S.jsx)(rW,{state:f,dispatch:p,getSquashedHydrationErrorDetails:h,runtimeErrors:t,errorCount:n}),(0,S.jsx)(u6,{}),(0,S.jsx)(oz,{})]})})}):null})},o[2]=p,o[3]=h,o[4]=i,o[5]=c,o[6]=f,o[7]=n):n=o[7],o[8]!==f||o[9]!==n?(r=(0,S.jsxs)(ew,{children:[e,t,(0,S.jsx)(rQ,{state:f,isAppDir:!0,children:n})]}),o[8]=f,o[9]=n,o[10]=r):r=o[10],r}function dc(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function du(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){var r,o,a;r=e,o=t,a=n[t],o in r?Object.defineProperty(r,o,{value:a,enumerable:!0,configurable:!0,writable:!0}):r[o]=a})}return e}function dd(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):(function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n})(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}function df(e){return function(e){if(Array.isArray(e))return dc(e)}(e)||function(e){if("undefined"!=typeof Symbol&&null!=e[Symbol.iterator]||null!=e["@@iterator"])return Array.from(e)}(e)||dp(e)||function(){throw TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function dp(e,t){if(e){if("string"==typeof e)return dc(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if("Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n)return Array.from(n);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return dc(e,t)}}var dh=null,dm=[],dg=null;function dv(){return dg?dd(du({},dg),{errors:dg.errors.map(function(e){return dd(du({},e),{error:e.error?{name:e.error.name,message:e.error.message,stack:e.error.stack}:null})})}):null}function dy(){return dg?{segmentTrie:am(),routerType:dg.routerType}:null}function db(e){return function(){for(var t=arguments.length,n=Array(t),r=0;r<t;r++)n[r]=arguments[r];dh?e.apply(void 0,[dh].concat(df(n))):dm.push(function(t){e.apply(void 0,[t].concat(df(n)))})}}var dx={onBuildOk:db(function(e){e({type:M})}),onBuildError:db(function(e,t){e({type:Z,message:t})}),onBeforeRefresh:db(function(e){e({type:F})}),onRefresh:db(function(e){e({type:U})}),onVersionInfo:db(function(e,t){e({type:H,versionInfo:t})}),onCacheIndicator:db(function(e,t){e({type:R,cacheIndicator:t})}),onStaticIndicator:db(function(e,t){e({type:D,staticIndicator:t})}),onDebugInfo:db(function(e,t){e({type:$,debugInfo:t})}),onDevIndicator:db(function(e,t){e({type:q,devIndicator:t})}),onDevToolsConfig:db(function(e,t){e({type:eo,devToolsConfig:t})}),onUnhandledError:db(function(e,t){e({type:V,reason:t})}),onUnhandledRejection:db(function(e,t){e({type:B,reason:t})}),openErrorOverlay:db(function(e){e({type:K})}),closeErrorOverlay:db(function(e){e({type:Y})}),toggleErrorOverlay:db(function(e){e({type:G})}),buildingIndicatorHide:db(function(e){e({type:Q})}),buildingIndicatorShow:db(function(e){e({type:X})}),renderingIndicatorHide:db(function(e){e({type:ee})}),renderingIndicatorShow:db(function(e){e({type:J})}),segmentExplorerNodeAdd:db(function(e,t){ap(t)}),segmentExplorerNodeRemove:db(function(e,t){ah(t)}),segmentExplorerUpdateRouteState:db(function(e,t){e({type:ec,page:t})})};function dw(e){var t,n,r,o,a,i,l,s,c,u,d,f,p,h,m,g,v,y,b,x,w,_,k=(0,O.c)(22),j=e.enableCacheIndicator,P=e.getOwnerStack,z=e.getSquashedHydrationErrorDetails,ea=e.isRecoverableError,ei=e.routerType,el=e.shadowRoot,es=(t=ei,n=P,r=ea,o=j,(u=(0,O.c)(8))[0]!==n||u[1]!==r?(l=function(e,t,o){var a,i=n(o),l=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:process.env.__NEXT_DIST_DIR;return e?(e=e.split("\n").map(function(e){return e.includes("(eval ")&&(e=e.replace(/eval code/g,"eval").replace(/\(eval at [^()]* \(/,"(file://").replace(/\),.*$/g,")")),e}).join("\n"),(0,E.parse)(e).map(function(e){try{var n=new URL(e.file),r=T.exec(n.pathname);if(r){var o,a=null==t||null==(o=t.replace(/\\/g,"/"))?void 0:o.replace(/\/$/,"");a&&(e.file="file://"+a.concat(r.pop())+n.search)}}catch(e){}return{file:e.file,line1:e.lineNumber,column1:e.column,methodName:e.methodName,arguments:e.arguments}})):[]}((o.stack||"")+(i||"")),s={id:t,error:o,frames:l,type:r(o)?"recoverable":(a=o)&&"NEXT_CONSOLE_ERROR"===a[I]?"console":"runtime"},c=e.filter(function(e){return""+e.error!=""+s.error||e.error.stack!==s.error.stack&&ed(e.error.stack)!==ed(s.error.stack)||n(e.error)!==n(s.error)});return c.length===e.length?(c.push(s),c):e},u[0]=n,u[1]=r,u[2]=l):l=u[2],d=l,(u[3]!==d?(s=function(e,t){switch(t.type){case $:return A(L({},e),{debugInfo:t.debugInfo});case R:return A(L({},e),{cacheIndicator:t.cacheIndicator});case D:return A(L({},e),{staticIndicator:t.staticIndicator});case M:return A(L({},e),{buildError:null});case Z:return A(L({},e),{buildError:t.message});case F:return A(L({},e),{refreshState:{type:"pending",errors:[]}});case U:return A(L({},e),{buildError:null,errors:"pending"===e.refreshState.type?e.refreshState.errors:[],refreshState:{type:"idle"}});case V:case B:switch(e.refreshState.type){case"idle":return A(L({},e),{nextId:e.nextId+1,errors:d(e.errors,e.nextId,t.reason)});case"pending":return A(L({},e),{nextId:e.nextId+1,refreshState:A(L({},e.refreshState),{errors:d(e.errors,e.nextId,t.reason)})});default:return e}case H:return A(L({},e),{versionInfo:t.versionInfo});case W:return A(L({},e),{disableDevIndicator:t.disabled});case q:return A(L({},e),{showIndicator:!0,disableDevIndicator:ef||!!t.devIndicator.disabledUntil});case K:return A(L({},e),{isErrorOverlayOpen:!0});case Y:return A(L({},e),{isErrorOverlayOpen:!1});case G:return A(L({},e),{isErrorOverlayOpen:!e.isErrorOverlayOpen});case X:return A(L({},e),{buildingIndicator:!0});case Q:return A(L({},e),{buildingIndicator:!1});case J:return A(L({},e),{renderingIndicator:!0});case ee:return A(L({},e),{renderingIndicator:!1});case et:return A(L({},e),{devToolsPosition:t.devToolsPosition});case en:return A(L({},e),{devToolsPanelPosition:A(L({},e.devToolsPanelPosition),N({},t.key,t.devToolsPanelPosition))});case er:return A(L({},e),{scale:t.scale});case ec:return A(L({},e),{page:t.page});case eo:var n=t.devToolsConfig,r=n.theme,o=n.disableDevIndicator,a=n.devToolsPosition,i=n.devToolsPanelPosition,l=n.devToolsPanelSize,s=n.scale,c=n.hideShortcut;return A(L({},e),{theme:null!=r?r:e.theme,disableDevIndicator:null!=o?o:e.disableDevIndicator,devToolsPosition:null!=a?a:e.devToolsPosition,devToolsPanelPosition:null!=i?i:e.devToolsPanelPosition,scale:null!=s?s:e.scale,devToolsPanelSize:null!=l?l:e.devToolsPanelSize,hideShortcut:void 0!==c?c:e.hideShortcut});default:return e}},u[3]=d,u[4]=s):s=u[4],u[5]!==o||u[6]!==t)?(a=t,i=o,c=A(L({},eh),{isErrorOverlayOpen:"pages"===a,routerType:a,cacheIndicator:i?"ready":"disabled"}),u[5]=o,u[6]=t,u[7]=c):c=u[7],f=(0,C.useReducer)(s,c),function(e){if(Array.isArray(e))return e}(f)||function(e,t){var n,r,o=null==e?null:"undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(null!=o){var a=[],i=!0,l=!1;try{for(o=o.call(e);!(i=(n=o.next()).done)&&(a.push(n.value),2!==a.length);i=!0);}catch(e){l=!0,r=e}finally{try{i||null==o.return||o.return()}finally{if(l)throw r}}return a}}(f,2)||dp(f,2)||function(){throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()),eu=es[0],ep=es[1];return k[0]!==ei||k[1]!==eu?(p=function(){dg=dd(du({},eu),{routerType:ei})},h=[eu,ei],k[0]=ei,k[1]=eu,k[2]=p,k[3]=h):(p=k[2],h=k[3]),(0,C.useEffect)(p,h),k[4]!==el.host||k[5]!==eu.theme?(m=function(){var e=el.host;"dark"===eu.theme?(e.classList.add("dark"),e.classList.remove("light")):"light"===eu.theme?(e.classList.add("light"),e.classList.remove("dark")):(e.classList.remove("dark"),e.classList.remove("light"))},k[4]=el.host,k[5]=eu.theme,k[6]=m):m=k[6],k[7]!==el||k[8]!==eu.theme?(g=[el,eu.theme],k[7]=el,k[8]=eu.theme,k[9]=g):g=k[9],(0,C.useLayoutEffect)(m,g),k[10]!==ep?(v=function(){dh=ep;var e=setTimeout(function(){!function(e){try{var t=!0,n=!1,r=void 0;try{for(var o,a=dm[Symbol.iterator]();!(t=(o=a.next()).done);t=!0)(0,o.value)(e)}catch(e){n=!0,r=e}finally{try{t||null==a.return||a.return()}finally{if(n)throw r}}}finally{dm.length=0}}(ep)});return function(){dh=null,clearTimeout(e)}},k[10]=ep,k[11]=v):v=k[11],k[12]===Symbol.for("react.memo_cache_sentinel")?(y=[],k[12]=y):y=k[12],(0,C.useInsertionEffect)(v,y),k[13]===Symbol.for("react.memo_cache_sentinel")?(b=(0,S.jsx)(ey,{}),k[13]=b):b=k[13],k[14]!==ep||k[15]!==z||k[16]!==el||k[17]!==eu?(x={dispatch:ep,getSquashedHydrationErrorDetails:z,shadowRoot:el,state:eu},k[14]=ep,k[15]=z,k[16]=el,k[17]=eu,k[18]=x):x=k[18],k[19]===Symbol.for("react.memo_cache_sentinel")?(w=(0,S.jsx)(ds,{}),k[19]=w):w=k[19],k[20]!==x?(_=(0,S.jsxs)(S.Fragment,{children:[b,(0,S.jsx)(d_,{value:x,children:w})]}),k[20]=x,k[21]=_):_=k[21],_}var d_=(0,C.createContext)(null),dk=function(){return(0,C.useContext)(d_)},dj=!1,dS=!1;function dO(){return null}function dC(e,t,n){if(dj)throw Error("Next DevTools: Pages Dev Overlay is already mounted. This is a bug in Next.js");if(!dS){var r=document.createElement("script");r.style.display="block",r.style.position="absolute",r.setAttribute("data-nextjs-dev-overlay","true");var o=document.createElement("nextjs-portal");r.appendChild(o),document.body.appendChild(r);var a=(0,em.createRoot)(o,{identifierPrefix:"ndt-",onDefaultTransitionIndicator:function(){return function(){}}}),i=o.attachShadow({mode:"open"});(0,C.startTransition)(function(){a.render((0,S.jsx)(dw,{enableCacheIndicator:n,getOwnerStack:e,getSquashedHydrationErrorDetails:dO,isRecoverableError:t,routerType:"app",shadowRoot:i}))}),dS=!0}}function dP(e,t,n){if(dS)throw Error("Next DevTools: App Dev Overlay is already mounted. This is a bug in Next.js");if(!dj){var r=document.createElement("nextjs-portal");r.style.position="absolute",new MutationObserver(function(e){var t=!0,n=!1,o=void 0;try{for(var a,i=e[Symbol.iterator]();!(t=(a=i.next()).done);t=!0){var l=a.value;if("childList"===l.type){var s=!0,c=!1,u=void 0;try{for(var d,f=l.removedNodes[Symbol.iterator]();!(s=(d=f.next()).done);s=!0)d.value===r&&document.body.appendChild(r)}catch(e){c=!0,u=e}finally{try{s||null==f.return||f.return()}finally{if(c)throw u}}}}}catch(e){n=!0,o=e}finally{try{t||null==i.return||i.return()}finally{if(n)throw o}}}).observe(document.body,{childList:!0}),document.body.appendChild(r);var o=(0,em.createRoot)(r,{identifierPrefix:"ndt-"}),a=r.attachShadow({mode:"open"});(0,C.startTransition)(function(){o.render((0,S.jsx)(dw,{enableCacheIndicator:!1,getOwnerStack:e,getSquashedHydrationErrorDetails:t,isRecoverableError:n,routerType:"pages",shadowRoot:a}))}),dj=!0}}})(),exports.DevOverlayContext=__webpack_exports__.DevOverlayContext,exports.dispatcher=__webpack_exports__.dispatcher,exports.getSegmentTrieData=__webpack_exports__.getSegmentTrieData,exports.getSerializedOverlayState=__webpack_exports__.getSerializedOverlayState,exports.renderAppDevOverlay=__webpack_exports__.renderAppDevOverlay,exports.renderPagesDevOverlay=__webpack_exports__.renderPagesDevOverlay,exports.useDevOverlayContext=__webpack_exports__.useDevOverlayContext,__webpack_exports__)-1===["DevOverlayContext","dispatcher","getSegmentTrieData","getSerializedOverlayState","renderAppDevOverlay","renderPagesDevOverlay","useDevOverlayContext"].indexOf(__webpack_i__)&&(exports[__webpack_i__]=__webpack_exports__[__webpack_i__]);Object.defineProperty(exports,"__esModule",{value:!0});
//# sourceMappingURL=index.js.map
})();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/safe-stable-stringify/index.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

(function() {
    "use strict";
    var e = {
        879: function(e, t) {
            const { hasOwnProperty: n } = Object.prototype;
            const r = configure();
            r.configure = configure;
            r.stringify = r;
            r.default = r;
            t.stringify = r;
            t.configure = configure;
            e.exports = r;
            const i = /[\u0000-\u001f\u0022\u005c\ud800-\udfff]/;
            function strEscape(e) {
                if (e.length < 5e3 && !i.test(e)) {
                    return `"${e}"`;
                }
                return JSON.stringify(e);
            }
            function sort(e, t) {
                if (e.length > 200 || t) {
                    return e.sort(t);
                }
                for(let t = 1; t < e.length; t++){
                    const n = e[t];
                    let r = t;
                    while(r !== 0 && e[r - 1] > n){
                        e[r] = e[r - 1];
                        r--;
                    }
                    e[r] = n;
                }
                return e;
            }
            const f = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Object.getPrototypeOf(new Int8Array)), Symbol.toStringTag).get;
            function isTypedArrayWithEntries(e) {
                return f.call(e) !== undefined && e.length !== 0;
            }
            function stringifyTypedArray(e, t, n) {
                if (e.length < n) {
                    n = e.length;
                }
                const r = t === "," ? "" : " ";
                let i = `"0":${r}${e[0]}`;
                for(let f = 1; f < n; f++){
                    i += `${t}"${f}":${r}${e[f]}`;
                }
                return i;
            }
            function getCircularValueOption(e) {
                if (n.call(e, "circularValue")) {
                    const t = e.circularValue;
                    if (typeof t === "string") {
                        return `"${t}"`;
                    }
                    if (t == null) {
                        return t;
                    }
                    if (t === Error || t === TypeError) {
                        return {
                            toString () {
                                throw new TypeError("Converting circular structure to JSON");
                            }
                        };
                    }
                    throw new TypeError('The "circularValue" argument must be of type string or the value null or undefined');
                }
                return '"[Circular]"';
            }
            function getDeterministicOption(e) {
                let t;
                if (n.call(e, "deterministic")) {
                    t = e.deterministic;
                    if (typeof t !== "boolean" && typeof t !== "function") {
                        throw new TypeError('The "deterministic" argument must be of type boolean or comparator function');
                    }
                }
                return t === undefined ? true : t;
            }
            function getBooleanOption(e, t) {
                let r;
                if (n.call(e, t)) {
                    r = e[t];
                    if (typeof r !== "boolean") {
                        throw new TypeError(`The "${t}" argument must be of type boolean`);
                    }
                }
                return r === undefined ? true : r;
            }
            function getPositiveIntegerOption(e, t) {
                let r;
                if (n.call(e, t)) {
                    r = e[t];
                    if (typeof r !== "number") {
                        throw new TypeError(`The "${t}" argument must be of type number`);
                    }
                    if (!Number.isInteger(r)) {
                        throw new TypeError(`The "${t}" argument must be an integer`);
                    }
                    if (r < 1) {
                        throw new RangeError(`The "${t}" argument must be >= 1`);
                    }
                }
                return r === undefined ? Infinity : r;
            }
            function getItemCount(e) {
                if (e === 1) {
                    return "1 item";
                }
                return `${e} items`;
            }
            function getUniqueReplacerSet(e) {
                const t = new Set;
                for (const n of e){
                    if (typeof n === "string" || typeof n === "number") {
                        t.add(String(n));
                    }
                }
                return t;
            }
            function getStrictOption(e) {
                if (n.call(e, "strict")) {
                    const t = e.strict;
                    if (typeof t !== "boolean") {
                        throw new TypeError('The "strict" argument must be of type boolean');
                    }
                    if (t) {
                        return (e)=>{
                            let t = `Object can not safely be stringified. Received type ${typeof e}`;
                            if (typeof e !== "function") t += ` (${e.toString()})`;
                            throw new Error(t);
                        };
                    }
                }
            }
            function configure(e) {
                e = {
                    ...e
                };
                const t = getStrictOption(e);
                if (t) {
                    if (e.bigint === undefined) {
                        e.bigint = false;
                    }
                    if (!("circularValue" in e)) {
                        e.circularValue = Error;
                    }
                }
                const n = getCircularValueOption(e);
                const r = getBooleanOption(e, "bigint");
                const i = getDeterministicOption(e);
                const f = typeof i === "function" ? i : undefined;
                const u = getPositiveIntegerOption(e, "maximumDepth");
                const o = getPositiveIntegerOption(e, "maximumBreadth");
                function stringifyFnReplacer(e, s, l, c, a, g) {
                    let p = s[e];
                    if (typeof p === "object" && p !== null && typeof p.toJSON === "function") {
                        p = p.toJSON(e);
                    }
                    p = c.call(s, e, p);
                    switch(typeof p){
                        case "string":
                            return strEscape(p);
                        case "object":
                            {
                                if (p === null) {
                                    return "null";
                                }
                                if (l.indexOf(p) !== -1) {
                                    return n;
                                }
                                let e = "";
                                let t = ",";
                                const r = g;
                                if (Array.isArray(p)) {
                                    if (p.length === 0) {
                                        return "[]";
                                    }
                                    if (u < l.length + 1) {
                                        return '"[Array]"';
                                    }
                                    l.push(p);
                                    if (a !== "") {
                                        g += a;
                                        e += `\n${g}`;
                                        t = `,\n${g}`;
                                    }
                                    const n = Math.min(p.length, o);
                                    let i = 0;
                                    for(; i < n - 1; i++){
                                        const n = stringifyFnReplacer(String(i), p, l, c, a, g);
                                        e += n !== undefined ? n : "null";
                                        e += t;
                                    }
                                    const f = stringifyFnReplacer(String(i), p, l, c, a, g);
                                    e += f !== undefined ? f : "null";
                                    if (p.length - 1 > o) {
                                        const n = p.length - o - 1;
                                        e += `${t}"... ${getItemCount(n)} not stringified"`;
                                    }
                                    if (a !== "") {
                                        e += `\n${r}`;
                                    }
                                    l.pop();
                                    return `[${e}]`;
                                }
                                let s = Object.keys(p);
                                const y = s.length;
                                if (y === 0) {
                                    return "{}";
                                }
                                if (u < l.length + 1) {
                                    return '"[Object]"';
                                }
                                let d = "";
                                let h = "";
                                if (a !== "") {
                                    g += a;
                                    t = `,\n${g}`;
                                    d = " ";
                                }
                                const $ = Math.min(y, o);
                                if (i && !isTypedArrayWithEntries(p)) {
                                    s = sort(s, f);
                                }
                                l.push(p);
                                for(let n = 0; n < $; n++){
                                    const r = s[n];
                                    const i = stringifyFnReplacer(r, p, l, c, a, g);
                                    if (i !== undefined) {
                                        e += `${h}${strEscape(r)}:${d}${i}`;
                                        h = t;
                                    }
                                }
                                if (y > o) {
                                    const n = y - o;
                                    e += `${h}"...":${d}"${getItemCount(n)} not stringified"`;
                                    h = t;
                                }
                                if (a !== "" && h.length > 1) {
                                    e = `\n${g}${e}\n${r}`;
                                }
                                l.pop();
                                return `{${e}}`;
                            }
                        case "number":
                            return isFinite(p) ? String(p) : t ? t(p) : "null";
                        case "boolean":
                            return p === true ? "true" : "false";
                        case "undefined":
                            return undefined;
                        case "bigint":
                            if (r) {
                                return String(p);
                            }
                        default:
                            return t ? t(p) : undefined;
                    }
                }
                function stringifyArrayReplacer(e, i, f, s, l, c) {
                    if (typeof i === "object" && i !== null && typeof i.toJSON === "function") {
                        i = i.toJSON(e);
                    }
                    switch(typeof i){
                        case "string":
                            return strEscape(i);
                        case "object":
                            {
                                if (i === null) {
                                    return "null";
                                }
                                if (f.indexOf(i) !== -1) {
                                    return n;
                                }
                                const e = c;
                                let t = "";
                                let r = ",";
                                if (Array.isArray(i)) {
                                    if (i.length === 0) {
                                        return "[]";
                                    }
                                    if (u < f.length + 1) {
                                        return '"[Array]"';
                                    }
                                    f.push(i);
                                    if (l !== "") {
                                        c += l;
                                        t += `\n${c}`;
                                        r = `,\n${c}`;
                                    }
                                    const n = Math.min(i.length, o);
                                    let a = 0;
                                    for(; a < n - 1; a++){
                                        const e = stringifyArrayReplacer(String(a), i[a], f, s, l, c);
                                        t += e !== undefined ? e : "null";
                                        t += r;
                                    }
                                    const g = stringifyArrayReplacer(String(a), i[a], f, s, l, c);
                                    t += g !== undefined ? g : "null";
                                    if (i.length - 1 > o) {
                                        const e = i.length - o - 1;
                                        t += `${r}"... ${getItemCount(e)} not stringified"`;
                                    }
                                    if (l !== "") {
                                        t += `\n${e}`;
                                    }
                                    f.pop();
                                    return `[${t}]`;
                                }
                                f.push(i);
                                let a = "";
                                if (l !== "") {
                                    c += l;
                                    r = `,\n${c}`;
                                    a = " ";
                                }
                                let g = "";
                                for (const e of s){
                                    const n = stringifyArrayReplacer(e, i[e], f, s, l, c);
                                    if (n !== undefined) {
                                        t += `${g}${strEscape(e)}:${a}${n}`;
                                        g = r;
                                    }
                                }
                                if (l !== "" && g.length > 1) {
                                    t = `\n${c}${t}\n${e}`;
                                }
                                f.pop();
                                return `{${t}}`;
                            }
                        case "number":
                            return isFinite(i) ? String(i) : t ? t(i) : "null";
                        case "boolean":
                            return i === true ? "true" : "false";
                        case "undefined":
                            return undefined;
                        case "bigint":
                            if (r) {
                                return String(i);
                            }
                        default:
                            return t ? t(i) : undefined;
                    }
                }
                function stringifyIndent(e, s, l, c, a) {
                    switch(typeof s){
                        case "string":
                            return strEscape(s);
                        case "object":
                            {
                                if (s === null) {
                                    return "null";
                                }
                                if (typeof s.toJSON === "function") {
                                    s = s.toJSON(e);
                                    if (typeof s !== "object") {
                                        return stringifyIndent(e, s, l, c, a);
                                    }
                                    if (s === null) {
                                        return "null";
                                    }
                                }
                                if (l.indexOf(s) !== -1) {
                                    return n;
                                }
                                const t = a;
                                if (Array.isArray(s)) {
                                    if (s.length === 0) {
                                        return "[]";
                                    }
                                    if (u < l.length + 1) {
                                        return '"[Array]"';
                                    }
                                    l.push(s);
                                    a += c;
                                    let e = `\n${a}`;
                                    const n = `,\n${a}`;
                                    const r = Math.min(s.length, o);
                                    let i = 0;
                                    for(; i < r - 1; i++){
                                        const t = stringifyIndent(String(i), s[i], l, c, a);
                                        e += t !== undefined ? t : "null";
                                        e += n;
                                    }
                                    const f = stringifyIndent(String(i), s[i], l, c, a);
                                    e += f !== undefined ? f : "null";
                                    if (s.length - 1 > o) {
                                        const t = s.length - o - 1;
                                        e += `${n}"... ${getItemCount(t)} not stringified"`;
                                    }
                                    e += `\n${t}`;
                                    l.pop();
                                    return `[${e}]`;
                                }
                                let r = Object.keys(s);
                                const g = r.length;
                                if (g === 0) {
                                    return "{}";
                                }
                                if (u < l.length + 1) {
                                    return '"[Object]"';
                                }
                                a += c;
                                const p = `,\n${a}`;
                                let y = "";
                                let d = "";
                                let h = Math.min(g, o);
                                if (isTypedArrayWithEntries(s)) {
                                    y += stringifyTypedArray(s, p, o);
                                    r = r.slice(s.length);
                                    h -= s.length;
                                    d = p;
                                }
                                if (i) {
                                    r = sort(r, f);
                                }
                                l.push(s);
                                for(let e = 0; e < h; e++){
                                    const t = r[e];
                                    const n = stringifyIndent(t, s[t], l, c, a);
                                    if (n !== undefined) {
                                        y += `${d}${strEscape(t)}: ${n}`;
                                        d = p;
                                    }
                                }
                                if (g > o) {
                                    const e = g - o;
                                    y += `${d}"...": "${getItemCount(e)} not stringified"`;
                                    d = p;
                                }
                                if (d !== "") {
                                    y = `\n${a}${y}\n${t}`;
                                }
                                l.pop();
                                return `{${y}}`;
                            }
                        case "number":
                            return isFinite(s) ? String(s) : t ? t(s) : "null";
                        case "boolean":
                            return s === true ? "true" : "false";
                        case "undefined":
                            return undefined;
                        case "bigint":
                            if (r) {
                                return String(s);
                            }
                        default:
                            return t ? t(s) : undefined;
                    }
                }
                function stringifySimple(e, s, l) {
                    switch(typeof s){
                        case "string":
                            return strEscape(s);
                        case "object":
                            {
                                if (s === null) {
                                    return "null";
                                }
                                if (typeof s.toJSON === "function") {
                                    s = s.toJSON(e);
                                    if (typeof s !== "object") {
                                        return stringifySimple(e, s, l);
                                    }
                                    if (s === null) {
                                        return "null";
                                    }
                                }
                                if (l.indexOf(s) !== -1) {
                                    return n;
                                }
                                let t = "";
                                const r = s.length !== undefined;
                                if (r && Array.isArray(s)) {
                                    if (s.length === 0) {
                                        return "[]";
                                    }
                                    if (u < l.length + 1) {
                                        return '"[Array]"';
                                    }
                                    l.push(s);
                                    const e = Math.min(s.length, o);
                                    let n = 0;
                                    for(; n < e - 1; n++){
                                        const e = stringifySimple(String(n), s[n], l);
                                        t += e !== undefined ? e : "null";
                                        t += ",";
                                    }
                                    const r = stringifySimple(String(n), s[n], l);
                                    t += r !== undefined ? r : "null";
                                    if (s.length - 1 > o) {
                                        const e = s.length - o - 1;
                                        t += `,"... ${getItemCount(e)} not stringified"`;
                                    }
                                    l.pop();
                                    return `[${t}]`;
                                }
                                let c = Object.keys(s);
                                const a = c.length;
                                if (a === 0) {
                                    return "{}";
                                }
                                if (u < l.length + 1) {
                                    return '"[Object]"';
                                }
                                let g = "";
                                let p = Math.min(a, o);
                                if (r && isTypedArrayWithEntries(s)) {
                                    t += stringifyTypedArray(s, ",", o);
                                    c = c.slice(s.length);
                                    p -= s.length;
                                    g = ",";
                                }
                                if (i) {
                                    c = sort(c, f);
                                }
                                l.push(s);
                                for(let e = 0; e < p; e++){
                                    const n = c[e];
                                    const r = stringifySimple(n, s[n], l);
                                    if (r !== undefined) {
                                        t += `${g}${strEscape(n)}:${r}`;
                                        g = ",";
                                    }
                                }
                                if (a > o) {
                                    const e = a - o;
                                    t += `${g}"...":"${getItemCount(e)} not stringified"`;
                                }
                                l.pop();
                                return `{${t}}`;
                            }
                        case "number":
                            return isFinite(s) ? String(s) : t ? t(s) : "null";
                        case "boolean":
                            return s === true ? "true" : "false";
                        case "undefined":
                            return undefined;
                        case "bigint":
                            if (r) {
                                return String(s);
                            }
                        default:
                            return t ? t(s) : undefined;
                    }
                }
                function stringify(e, t, n) {
                    if (arguments.length > 1) {
                        let r = "";
                        if (typeof n === "number") {
                            r = " ".repeat(Math.min(n, 10));
                        } else if (typeof n === "string") {
                            r = n.slice(0, 10);
                        }
                        if (t != null) {
                            if (typeof t === "function") {
                                return stringifyFnReplacer("", {
                                    "": e
                                }, [], t, r, "");
                            }
                            if (Array.isArray(t)) {
                                return stringifyArrayReplacer("", e, [], getUniqueReplacerSet(t), r, "");
                            }
                        }
                        if (r.length !== 0) {
                            return stringifyIndent("", e, [], r, "");
                        }
                    }
                    return stringifySimple("", e, []);
                }
                return stringify;
            }
        }
    };
    var t = {};
    function __nccwpck_require__(n) {
        var r = t[n];
        if (r !== undefined) {
            return r.exports;
        }
        var i = t[n] = {
            exports: {}
        };
        var f = true;
        try {
            e[n](i, i.exports, __nccwpck_require__);
            f = false;
        } finally{
            if (f) delete t[n];
        }
        return i.exports;
    }
    if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = ("TURBOPACK compile-time value", "/ROOT/spam-cloud-25-11-25/node_modules/next/dist/compiled/safe-stable-stringify") + "/";
    var n = __nccwpck_require__(879);
    module.exports = n;
})();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/strip-ansi/index.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

(()=>{
    "use strict";
    var e = {
        511: (e)=>{
            e.exports = ({ onlyFirst: e = false } = {})=>{
                const r = [
                    "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)",
                    "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))"
                ].join("|");
                return new RegExp(r, e ? undefined : "g");
            };
        },
        532: (e, r, _)=>{
            const t = _(511);
            e.exports = (e)=>typeof e === "string" ? e.replace(t(), "") : e;
        }
    };
    var r = {};
    function __nccwpck_require__(_) {
        var t = r[_];
        if (t !== undefined) {
            return t.exports;
        }
        var a = r[_] = {
            exports: {}
        };
        var n = true;
        try {
            e[_](a, a.exports, __nccwpck_require__);
            n = false;
        } finally{
            if (n) delete r[_];
        }
        return a.exports;
    }
    if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = ("TURBOPACK compile-time value", "/ROOT/spam-cloud-25-11-25/node_modules/next/dist/compiled/strip-ansi") + "/";
    var _ = __nccwpck_require__(532);
    module.exports = _;
})();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/stacktrace-parser/stack-trace-parser.cjs.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

(()=>{
    "use strict";
    if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = ("TURBOPACK compile-time value", "/ROOT/spam-cloud-25-11-25/node_modules/next/dist/compiled/stacktrace-parser") + "/";
    var e = {};
    (()=>{
        var r = e;
        Object.defineProperty(r, "__esModule", {
            value: true
        });
        var n = "<unknown>";
        function parse(e) {
            var r = e.split("\n");
            return r.reduce(function(e, r) {
                var n = parseChrome(r) || parseWinjs(r) || parseGecko(r) || parseNode(r) || parseJSC(r);
                if (n) {
                    e.push(n);
                }
                return e;
            }, []);
        }
        var a = /^\s*at (.*?) ?\(((?:file|https?|blob|chrome-extension|native|eval|webpack|webpack-internal|rsc|about|turbopack|<anonymous>|\/|[a-z]:\\|\\\\).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i;
        var u = /\((\S*)(?::(\d+))(?::(\d+))\)/;
        function parseChrome(e) {
            var r = a.exec(e);
            if (!r) {
                return null;
            }
            var l = r[2] && r[2].indexOf("native") === 0;
            var t = r[2] && r[2].indexOf("eval") === 0;
            var i = u.exec(r[2]);
            if (t && i != null) {
                r[2] = i[1];
                r[3] = i[2];
                r[4] = i[3];
            }
            return {
                file: !l ? r[2] : null,
                methodName: r[1] || n,
                arguments: l ? [
                    r[2]
                ] : [],
                lineNumber: r[3] ? +r[3] : null,
                column: r[4] ? +r[4] : null
            };
        }
        var l = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|webpack-internal|rsc|about|turbopack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i;
        function parseWinjs(e) {
            var r = l.exec(e);
            if (!r) {
                return null;
            }
            return {
                file: r[2],
                methodName: r[1] || n,
                arguments: [],
                lineNumber: +r[3],
                column: r[4] ? +r[4] : null
            };
        }
        var t = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|webpack-internal|rsc|about|turbopack|resource|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i;
        var i = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
        function parseGecko(e) {
            var r = t.exec(e);
            if (!r) {
                return null;
            }
            var a = r[3] && r[3].indexOf(" > eval") > -1;
            var u = i.exec(r[3]);
            if (a && u != null) {
                r[3] = u[1];
                r[4] = u[2];
                r[5] = null;
            }
            return {
                file: r[3],
                methodName: r[1] || n,
                arguments: r[2] ? r[2].split(",") : [],
                lineNumber: r[4] ? +r[4] : null,
                column: r[5] ? +r[5] : null
            };
        }
        var o = /^\s*(?:([^@]*)(?:\((.*?)\))?@)?(\S.*?):(\d+)(?::(\d+))?\s*$/i;
        function parseJSC(e) {
            var r = o.exec(e);
            if (!r) {
                return null;
            }
            return {
                file: r[3],
                methodName: r[1] || n,
                arguments: [],
                lineNumber: +r[4],
                column: r[5] ? +r[5] : null
            };
        }
        var s = /^\s*at (?:((?:\[object object\])?[^\\/]+(?: \[as \S+\])?) )?\(?(.*?):(\d+)(?::(\d+))?\)?\s*$/i;
        function parseNode(e) {
            var r = s.exec(e);
            if (!r) {
                return null;
            }
            return {
                file: r[2],
                methodName: r[1] || n,
                arguments: [],
                lineNumber: +r[3],
                column: r[4] ? +r[4] : null
            };
        }
        r.parse = parse;
    })();
    module.exports = e;
})();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/picomatch/index.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
(()=>{
    "use strict";
    var t = {
        170: (t, e, u)=>{
            const n = u(510);
            const isWindows = ()=>{
                if (typeof navigator !== "undefined" && navigator.platform) {
                    const t = navigator.platform.toLowerCase();
                    return t === "win32" || t === "windows";
                }
                if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"] !== "undefined" && __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].platform) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].platform === "win32";
                }
                return false;
            };
            function picomatch(t, e, u = false) {
                if (e && (e.windows === null || e.windows === undefined)) {
                    e = {
                        ...e,
                        windows: isWindows()
                    };
                }
                return n(t, e, u);
            }
            Object.assign(picomatch, n);
            t.exports = picomatch;
        },
        154: (t)=>{
            const e = "\\\\/";
            const u = `[^${e}]`;
            const n = "\\.";
            const o = "\\+";
            const s = "\\?";
            const r = "\\/";
            const a = "(?=.)";
            const i = "[^/]";
            const c = `(?:${r}|$)`;
            const p = `(?:^|${r})`;
            const l = `${n}{1,2}${c}`;
            const f = `(?!${n})`;
            const A = `(?!${p}${l})`;
            const _ = `(?!${n}{0,1}${c})`;
            const R = `(?!${l})`;
            const E = `[^.${r}]`;
            const h = `${i}*?`;
            const g = "/";
            const b = {
                DOT_LITERAL: n,
                PLUS_LITERAL: o,
                QMARK_LITERAL: s,
                SLASH_LITERAL: r,
                ONE_CHAR: a,
                QMARK: i,
                END_ANCHOR: c,
                DOTS_SLASH: l,
                NO_DOT: f,
                NO_DOTS: A,
                NO_DOT_SLASH: _,
                NO_DOTS_SLASH: R,
                QMARK_NO_DOT: E,
                STAR: h,
                START_ANCHOR: p,
                SEP: g
            };
            const C = {
                ...b,
                SLASH_LITERAL: `[${e}]`,
                QMARK: u,
                STAR: `${u}*?`,
                DOTS_SLASH: `${n}{1,2}(?:[${e}]|$)`,
                NO_DOT: `(?!${n})`,
                NO_DOTS: `(?!(?:^|[${e}])${n}{1,2}(?:[${e}]|$))`,
                NO_DOT_SLASH: `(?!${n}{0,1}(?:[${e}]|$))`,
                NO_DOTS_SLASH: `(?!${n}{1,2}(?:[${e}]|$))`,
                QMARK_NO_DOT: `[^.${e}]`,
                START_ANCHOR: `(?:^|[${e}])`,
                END_ANCHOR: `(?:[${e}]|$)`,
                SEP: "\\"
            };
            const y = {
                alnum: "a-zA-Z0-9",
                alpha: "a-zA-Z",
                ascii: "\\x00-\\x7F",
                blank: " \\t",
                cntrl: "\\x00-\\x1F\\x7F",
                digit: "0-9",
                graph: "\\x21-\\x7E",
                lower: "a-z",
                print: "\\x20-\\x7E ",
                punct: "\\-!\"#$%&'()\\*+,./:;<=>?@[\\]^_`{|}~",
                space: " \\t\\r\\n\\v\\f",
                upper: "A-Z",
                word: "A-Za-z0-9_",
                xdigit: "A-Fa-f0-9"
            };
            t.exports = {
                MAX_LENGTH: 1024 * 64,
                POSIX_REGEX_SOURCE: y,
                REGEX_BACKSLASH: /\\(?![*+?^${}(|)[\]])/g,
                REGEX_NON_SPECIAL_CHARS: /^[^@![\].,$*+?^{}()|\\/]+/,
                REGEX_SPECIAL_CHARS: /[-*+?.^${}(|)[\]]/,
                REGEX_SPECIAL_CHARS_BACKREF: /(\\?)((\W)(\3*))/g,
                REGEX_SPECIAL_CHARS_GLOBAL: /([-*+?.^${}(|)[\]])/g,
                REGEX_REMOVE_BACKSLASH: /(?:\[.*?[^\\]\]|\\(?=.))/g,
                REPLACEMENTS: {
                    "***": "*",
                    "**/**": "**",
                    "**/**/**": "**"
                },
                CHAR_0: 48,
                CHAR_9: 57,
                CHAR_UPPERCASE_A: 65,
                CHAR_LOWERCASE_A: 97,
                CHAR_UPPERCASE_Z: 90,
                CHAR_LOWERCASE_Z: 122,
                CHAR_LEFT_PARENTHESES: 40,
                CHAR_RIGHT_PARENTHESES: 41,
                CHAR_ASTERISK: 42,
                CHAR_AMPERSAND: 38,
                CHAR_AT: 64,
                CHAR_BACKWARD_SLASH: 92,
                CHAR_CARRIAGE_RETURN: 13,
                CHAR_CIRCUMFLEX_ACCENT: 94,
                CHAR_COLON: 58,
                CHAR_COMMA: 44,
                CHAR_DOT: 46,
                CHAR_DOUBLE_QUOTE: 34,
                CHAR_EQUAL: 61,
                CHAR_EXCLAMATION_MARK: 33,
                CHAR_FORM_FEED: 12,
                CHAR_FORWARD_SLASH: 47,
                CHAR_GRAVE_ACCENT: 96,
                CHAR_HASH: 35,
                CHAR_HYPHEN_MINUS: 45,
                CHAR_LEFT_ANGLE_BRACKET: 60,
                CHAR_LEFT_CURLY_BRACE: 123,
                CHAR_LEFT_SQUARE_BRACKET: 91,
                CHAR_LINE_FEED: 10,
                CHAR_NO_BREAK_SPACE: 160,
                CHAR_PERCENT: 37,
                CHAR_PLUS: 43,
                CHAR_QUESTION_MARK: 63,
                CHAR_RIGHT_ANGLE_BRACKET: 62,
                CHAR_RIGHT_CURLY_BRACE: 125,
                CHAR_RIGHT_SQUARE_BRACKET: 93,
                CHAR_SEMICOLON: 59,
                CHAR_SINGLE_QUOTE: 39,
                CHAR_SPACE: 32,
                CHAR_TAB: 9,
                CHAR_UNDERSCORE: 95,
                CHAR_VERTICAL_LINE: 124,
                CHAR_ZERO_WIDTH_NOBREAK_SPACE: 65279,
                extglobChars (t) {
                    return {
                        "!": {
                            type: "negate",
                            open: "(?:(?!(?:",
                            close: `))${t.STAR})`
                        },
                        "?": {
                            type: "qmark",
                            open: "(?:",
                            close: ")?"
                        },
                        "+": {
                            type: "plus",
                            open: "(?:",
                            close: ")+"
                        },
                        "*": {
                            type: "star",
                            open: "(?:",
                            close: ")*"
                        },
                        "@": {
                            type: "at",
                            open: "(?:",
                            close: ")"
                        }
                    };
                },
                globChars (t) {
                    return t === true ? C : b;
                }
            };
        },
        697: (t, e, u)=>{
            const n = u(154);
            const o = u(96);
            const { MAX_LENGTH: s, POSIX_REGEX_SOURCE: r, REGEX_NON_SPECIAL_CHARS: a, REGEX_SPECIAL_CHARS_BACKREF: i, REPLACEMENTS: c } = n;
            const expandRange = (t, e)=>{
                if (typeof e.expandRange === "function") {
                    return e.expandRange(...t, e);
                }
                t.sort();
                const u = `[${t.join("-")}]`;
                try {
                    new RegExp(u);
                } catch (e) {
                    return t.map((t)=>o.escapeRegex(t)).join("..");
                }
                return u;
            };
            const syntaxError = (t, e)=>`Missing ${t}: "${e}" - use "\\\\${e}" to match literal characters`;
            const parse = (t, e)=>{
                if (typeof t !== "string") {
                    throw new TypeError("Expected a string");
                }
                t = c[t] || t;
                const u = {
                    ...e
                };
                const p = typeof u.maxLength === "number" ? Math.min(s, u.maxLength) : s;
                let l = t.length;
                if (l > p) {
                    throw new SyntaxError(`Input length: ${l}, exceeds maximum allowed length: ${p}`);
                }
                const f = {
                    type: "bos",
                    value: "",
                    output: u.prepend || ""
                };
                const A = [
                    f
                ];
                const _ = u.capture ? "" : "?:";
                const R = n.globChars(u.windows);
                const E = n.extglobChars(R);
                const { DOT_LITERAL: h, PLUS_LITERAL: g, SLASH_LITERAL: b, ONE_CHAR: C, DOTS_SLASH: y, NO_DOT: $, NO_DOT_SLASH: x, NO_DOTS_SLASH: S, QMARK: H, QMARK_NO_DOT: v, STAR: d, START_ANCHOR: L } = R;
                const globstar = (t)=>`(${_}(?:(?!${L}${t.dot ? y : h}).)*?)`;
                const T = u.dot ? "" : $;
                const O = u.dot ? H : v;
                let k = u.bash === true ? globstar(u) : d;
                if (u.capture) {
                    k = `(${k})`;
                }
                if (typeof u.noext === "boolean") {
                    u.noextglob = u.noext;
                }
                const m = {
                    input: t,
                    index: -1,
                    start: 0,
                    dot: u.dot === true,
                    consumed: "",
                    output: "",
                    prefix: "",
                    backtrack: false,
                    negated: false,
                    brackets: 0,
                    braces: 0,
                    parens: 0,
                    quotes: 0,
                    globstar: false,
                    tokens: A
                };
                t = o.removePrefix(t, m);
                l = t.length;
                const w = [];
                const N = [];
                const I = [];
                let B = f;
                let G;
                const eos = ()=>m.index === l - 1;
                const D = m.peek = (e = 1)=>t[m.index + e];
                const M = m.advance = ()=>t[++m.index] || "";
                const remaining = ()=>t.slice(m.index + 1);
                const consume = (t = "", e = 0)=>{
                    m.consumed += t;
                    m.index += e;
                };
                const append = (t)=>{
                    m.output += t.output != null ? t.output : t.value;
                    consume(t.value);
                };
                const negate = ()=>{
                    let t = 1;
                    while(D() === "!" && (D(2) !== "(" || D(3) === "?")){
                        M();
                        m.start++;
                        t++;
                    }
                    if (t % 2 === 0) {
                        return false;
                    }
                    m.negated = true;
                    m.start++;
                    return true;
                };
                const increment = (t)=>{
                    m[t]++;
                    I.push(t);
                };
                const decrement = (t)=>{
                    m[t]--;
                    I.pop();
                };
                const push = (t)=>{
                    if (B.type === "globstar") {
                        const e = m.braces > 0 && (t.type === "comma" || t.type === "brace");
                        const u = t.extglob === true || w.length && (t.type === "pipe" || t.type === "paren");
                        if (t.type !== "slash" && t.type !== "paren" && !e && !u) {
                            m.output = m.output.slice(0, -B.output.length);
                            B.type = "star";
                            B.value = "*";
                            B.output = k;
                            m.output += B.output;
                        }
                    }
                    if (w.length && t.type !== "paren") {
                        w[w.length - 1].inner += t.value;
                    }
                    if (t.value || t.output) append(t);
                    if (B && B.type === "text" && t.type === "text") {
                        B.output = (B.output || B.value) + t.value;
                        B.value += t.value;
                        return;
                    }
                    t.prev = B;
                    A.push(t);
                    B = t;
                };
                const extglobOpen = (t, e)=>{
                    const n = {
                        ...E[e],
                        conditions: 1,
                        inner: ""
                    };
                    n.prev = B;
                    n.parens = m.parens;
                    n.output = m.output;
                    const o = (u.capture ? "(" : "") + n.open;
                    increment("parens");
                    push({
                        type: t,
                        value: e,
                        output: m.output ? "" : C
                    });
                    push({
                        type: "paren",
                        extglob: true,
                        value: M(),
                        output: o
                    });
                    w.push(n);
                };
                const extglobClose = (t)=>{
                    let n = t.close + (u.capture ? ")" : "");
                    let o;
                    if (t.type === "negate") {
                        let s = k;
                        if (t.inner && t.inner.length > 1 && t.inner.includes("/")) {
                            s = globstar(u);
                        }
                        if (s !== k || eos() || /^\)+$/.test(remaining())) {
                            n = t.close = `)$))${s}`;
                        }
                        if (t.inner.includes("*") && (o = remaining()) && /^\.[^\\/.]+$/.test(o)) {
                            const u = parse(o, {
                                ...e,
                                fastpaths: false
                            }).output;
                            n = t.close = `)${u})${s})`;
                        }
                        if (t.prev.type === "bos") {
                            m.negatedExtglob = true;
                        }
                    }
                    push({
                        type: "paren",
                        extglob: true,
                        value: G,
                        output: n
                    });
                    decrement("parens");
                };
                if (u.fastpaths !== false && !/(^[*!]|[/()[\]{}"])/.test(t)) {
                    let n = false;
                    let s = t.replace(i, (t, e, u, o, s, r)=>{
                        if (o === "\\") {
                            n = true;
                            return t;
                        }
                        if (o === "?") {
                            if (e) {
                                return e + o + (s ? H.repeat(s.length) : "");
                            }
                            if (r === 0) {
                                return O + (s ? H.repeat(s.length) : "");
                            }
                            return H.repeat(u.length);
                        }
                        if (o === ".") {
                            return h.repeat(u.length);
                        }
                        if (o === "*") {
                            if (e) {
                                return e + o + (s ? k : "");
                            }
                            return k;
                        }
                        return e ? t : `\\${t}`;
                    });
                    if (n === true) {
                        if (u.unescape === true) {
                            s = s.replace(/\\/g, "");
                        } else {
                            s = s.replace(/\\+/g, (t)=>t.length % 2 === 0 ? "\\\\" : t ? "\\" : "");
                        }
                    }
                    if (s === t && u.contains === true) {
                        m.output = t;
                        return m;
                    }
                    m.output = o.wrapOutput(s, m, e);
                    return m;
                }
                while(!eos()){
                    G = M();
                    if (G === "\0") {
                        continue;
                    }
                    if (G === "\\") {
                        const t = D();
                        if (t === "/" && u.bash !== true) {
                            continue;
                        }
                        if (t === "." || t === ";") {
                            continue;
                        }
                        if (!t) {
                            G += "\\";
                            push({
                                type: "text",
                                value: G
                            });
                            continue;
                        }
                        const e = /^\\+/.exec(remaining());
                        let n = 0;
                        if (e && e[0].length > 2) {
                            n = e[0].length;
                            m.index += n;
                            if (n % 2 !== 0) {
                                G += "\\";
                            }
                        }
                        if (u.unescape === true) {
                            G = M();
                        } else {
                            G += M();
                        }
                        if (m.brackets === 0) {
                            push({
                                type: "text",
                                value: G
                            });
                            continue;
                        }
                    }
                    if (m.brackets > 0 && (G !== "]" || B.value === "[" || B.value === "[^")) {
                        if (u.posix !== false && G === ":") {
                            const t = B.value.slice(1);
                            if (t.includes("[")) {
                                B.posix = true;
                                if (t.includes(":")) {
                                    const t = B.value.lastIndexOf("[");
                                    const e = B.value.slice(0, t);
                                    const u = B.value.slice(t + 2);
                                    const n = r[u];
                                    if (n) {
                                        B.value = e + n;
                                        m.backtrack = true;
                                        M();
                                        if (!f.output && A.indexOf(B) === 1) {
                                            f.output = C;
                                        }
                                        continue;
                                    }
                                }
                            }
                        }
                        if (G === "[" && D() !== ":" || G === "-" && D() === "]") {
                            G = `\\${G}`;
                        }
                        if (G === "]" && (B.value === "[" || B.value === "[^")) {
                            G = `\\${G}`;
                        }
                        if (u.posix === true && G === "!" && B.value === "[") {
                            G = "^";
                        }
                        B.value += G;
                        append({
                            value: G
                        });
                        continue;
                    }
                    if (m.quotes === 1 && G !== '"') {
                        G = o.escapeRegex(G);
                        B.value += G;
                        append({
                            value: G
                        });
                        continue;
                    }
                    if (G === '"') {
                        m.quotes = m.quotes === 1 ? 0 : 1;
                        if (u.keepQuotes === true) {
                            push({
                                type: "text",
                                value: G
                            });
                        }
                        continue;
                    }
                    if (G === "(") {
                        increment("parens");
                        push({
                            type: "paren",
                            value: G
                        });
                        continue;
                    }
                    if (G === ")") {
                        if (m.parens === 0 && u.strictBrackets === true) {
                            throw new SyntaxError(syntaxError("opening", "("));
                        }
                        const t = w[w.length - 1];
                        if (t && m.parens === t.parens + 1) {
                            extglobClose(w.pop());
                            continue;
                        }
                        push({
                            type: "paren",
                            value: G,
                            output: m.parens ? ")" : "\\)"
                        });
                        decrement("parens");
                        continue;
                    }
                    if (G === "[") {
                        if (u.nobracket === true || !remaining().includes("]")) {
                            if (u.nobracket !== true && u.strictBrackets === true) {
                                throw new SyntaxError(syntaxError("closing", "]"));
                            }
                            G = `\\${G}`;
                        } else {
                            increment("brackets");
                        }
                        push({
                            type: "bracket",
                            value: G
                        });
                        continue;
                    }
                    if (G === "]") {
                        if (u.nobracket === true || B && B.type === "bracket" && B.value.length === 1) {
                            push({
                                type: "text",
                                value: G,
                                output: `\\${G}`
                            });
                            continue;
                        }
                        if (m.brackets === 0) {
                            if (u.strictBrackets === true) {
                                throw new SyntaxError(syntaxError("opening", "["));
                            }
                            push({
                                type: "text",
                                value: G,
                                output: `\\${G}`
                            });
                            continue;
                        }
                        decrement("brackets");
                        const t = B.value.slice(1);
                        if (B.posix !== true && t[0] === "^" && !t.includes("/")) {
                            G = `/${G}`;
                        }
                        B.value += G;
                        append({
                            value: G
                        });
                        if (u.literalBrackets === false || o.hasRegexChars(t)) {
                            continue;
                        }
                        const e = o.escapeRegex(B.value);
                        m.output = m.output.slice(0, -B.value.length);
                        if (u.literalBrackets === true) {
                            m.output += e;
                            B.value = e;
                            continue;
                        }
                        B.value = `(${_}${e}|${B.value})`;
                        m.output += B.value;
                        continue;
                    }
                    if (G === "{" && u.nobrace !== true) {
                        increment("braces");
                        const t = {
                            type: "brace",
                            value: G,
                            output: "(",
                            outputIndex: m.output.length,
                            tokensIndex: m.tokens.length
                        };
                        N.push(t);
                        push(t);
                        continue;
                    }
                    if (G === "}") {
                        const t = N[N.length - 1];
                        if (u.nobrace === true || !t) {
                            push({
                                type: "text",
                                value: G,
                                output: G
                            });
                            continue;
                        }
                        let e = ")";
                        if (t.dots === true) {
                            const t = A.slice();
                            const n = [];
                            for(let e = t.length - 1; e >= 0; e--){
                                A.pop();
                                if (t[e].type === "brace") {
                                    break;
                                }
                                if (t[e].type !== "dots") {
                                    n.unshift(t[e].value);
                                }
                            }
                            e = expandRange(n, u);
                            m.backtrack = true;
                        }
                        if (t.comma !== true && t.dots !== true) {
                            const u = m.output.slice(0, t.outputIndex);
                            const n = m.tokens.slice(t.tokensIndex);
                            t.value = t.output = "\\{";
                            G = e = "\\}";
                            m.output = u;
                            for (const t of n){
                                m.output += t.output || t.value;
                            }
                        }
                        push({
                            type: "brace",
                            value: G,
                            output: e
                        });
                        decrement("braces");
                        N.pop();
                        continue;
                    }
                    if (G === "|") {
                        if (w.length > 0) {
                            w[w.length - 1].conditions++;
                        }
                        push({
                            type: "text",
                            value: G
                        });
                        continue;
                    }
                    if (G === ",") {
                        let t = G;
                        const e = N[N.length - 1];
                        if (e && I[I.length - 1] === "braces") {
                            e.comma = true;
                            t = "|";
                        }
                        push({
                            type: "comma",
                            value: G,
                            output: t
                        });
                        continue;
                    }
                    if (G === "/") {
                        if (B.type === "dot" && m.index === m.start + 1) {
                            m.start = m.index + 1;
                            m.consumed = "";
                            m.output = "";
                            A.pop();
                            B = f;
                            continue;
                        }
                        push({
                            type: "slash",
                            value: G,
                            output: b
                        });
                        continue;
                    }
                    if (G === ".") {
                        if (m.braces > 0 && B.type === "dot") {
                            if (B.value === ".") B.output = h;
                            const t = N[N.length - 1];
                            B.type = "dots";
                            B.output += G;
                            B.value += G;
                            t.dots = true;
                            continue;
                        }
                        if (m.braces + m.parens === 0 && B.type !== "bos" && B.type !== "slash") {
                            push({
                                type: "text",
                                value: G,
                                output: h
                            });
                            continue;
                        }
                        push({
                            type: "dot",
                            value: G,
                            output: h
                        });
                        continue;
                    }
                    if (G === "?") {
                        const t = B && B.value === "(";
                        if (!t && u.noextglob !== true && D() === "(" && D(2) !== "?") {
                            extglobOpen("qmark", G);
                            continue;
                        }
                        if (B && B.type === "paren") {
                            const t = D();
                            let e = G;
                            if (B.value === "(" && !/[!=<:]/.test(t) || t === "<" && !/<([!=]|\w+>)/.test(remaining())) {
                                e = `\\${G}`;
                            }
                            push({
                                type: "text",
                                value: G,
                                output: e
                            });
                            continue;
                        }
                        if (u.dot !== true && (B.type === "slash" || B.type === "bos")) {
                            push({
                                type: "qmark",
                                value: G,
                                output: v
                            });
                            continue;
                        }
                        push({
                            type: "qmark",
                            value: G,
                            output: H
                        });
                        continue;
                    }
                    if (G === "!") {
                        if (u.noextglob !== true && D() === "(") {
                            if (D(2) !== "?" || !/[!=<:]/.test(D(3))) {
                                extglobOpen("negate", G);
                                continue;
                            }
                        }
                        if (u.nonegate !== true && m.index === 0) {
                            negate();
                            continue;
                        }
                    }
                    if (G === "+") {
                        if (u.noextglob !== true && D() === "(" && D(2) !== "?") {
                            extglobOpen("plus", G);
                            continue;
                        }
                        if (B && B.value === "(" || u.regex === false) {
                            push({
                                type: "plus",
                                value: G,
                                output: g
                            });
                            continue;
                        }
                        if (B && (B.type === "bracket" || B.type === "paren" || B.type === "brace") || m.parens > 0) {
                            push({
                                type: "plus",
                                value: G
                            });
                            continue;
                        }
                        push({
                            type: "plus",
                            value: g
                        });
                        continue;
                    }
                    if (G === "@") {
                        if (u.noextglob !== true && D() === "(" && D(2) !== "?") {
                            push({
                                type: "at",
                                extglob: true,
                                value: G,
                                output: ""
                            });
                            continue;
                        }
                        push({
                            type: "text",
                            value: G
                        });
                        continue;
                    }
                    if (G !== "*") {
                        if (G === "$" || G === "^") {
                            G = `\\${G}`;
                        }
                        const t = a.exec(remaining());
                        if (t) {
                            G += t[0];
                            m.index += t[0].length;
                        }
                        push({
                            type: "text",
                            value: G
                        });
                        continue;
                    }
                    if (B && (B.type === "globstar" || B.star === true)) {
                        B.type = "star";
                        B.star = true;
                        B.value += G;
                        B.output = k;
                        m.backtrack = true;
                        m.globstar = true;
                        consume(G);
                        continue;
                    }
                    let e = remaining();
                    if (u.noextglob !== true && /^\([^?]/.test(e)) {
                        extglobOpen("star", G);
                        continue;
                    }
                    if (B.type === "star") {
                        if (u.noglobstar === true) {
                            consume(G);
                            continue;
                        }
                        const n = B.prev;
                        const o = n.prev;
                        const s = n.type === "slash" || n.type === "bos";
                        const r = o && (o.type === "star" || o.type === "globstar");
                        if (u.bash === true && (!s || e[0] && e[0] !== "/")) {
                            push({
                                type: "star",
                                value: G,
                                output: ""
                            });
                            continue;
                        }
                        const a = m.braces > 0 && (n.type === "comma" || n.type === "brace");
                        const i = w.length && (n.type === "pipe" || n.type === "paren");
                        if (!s && n.type !== "paren" && !a && !i) {
                            push({
                                type: "star",
                                value: G,
                                output: ""
                            });
                            continue;
                        }
                        while(e.slice(0, 3) === "/**"){
                            const u = t[m.index + 4];
                            if (u && u !== "/") {
                                break;
                            }
                            e = e.slice(3);
                            consume("/**", 3);
                        }
                        if (n.type === "bos" && eos()) {
                            B.type = "globstar";
                            B.value += G;
                            B.output = globstar(u);
                            m.output = B.output;
                            m.globstar = true;
                            consume(G);
                            continue;
                        }
                        if (n.type === "slash" && n.prev.type !== "bos" && !r && eos()) {
                            m.output = m.output.slice(0, -(n.output + B.output).length);
                            n.output = `(?:${n.output}`;
                            B.type = "globstar";
                            B.output = globstar(u) + (u.strictSlashes ? ")" : "|$)");
                            B.value += G;
                            m.globstar = true;
                            m.output += n.output + B.output;
                            consume(G);
                            continue;
                        }
                        if (n.type === "slash" && n.prev.type !== "bos" && e[0] === "/") {
                            const t = e[1] !== void 0 ? "|$" : "";
                            m.output = m.output.slice(0, -(n.output + B.output).length);
                            n.output = `(?:${n.output}`;
                            B.type = "globstar";
                            B.output = `${globstar(u)}${b}|${b}${t})`;
                            B.value += G;
                            m.output += n.output + B.output;
                            m.globstar = true;
                            consume(G + M());
                            push({
                                type: "slash",
                                value: "/",
                                output: ""
                            });
                            continue;
                        }
                        if (n.type === "bos" && e[0] === "/") {
                            B.type = "globstar";
                            B.value += G;
                            B.output = `(?:^|${b}|${globstar(u)}${b})`;
                            m.output = B.output;
                            m.globstar = true;
                            consume(G + M());
                            push({
                                type: "slash",
                                value: "/",
                                output: ""
                            });
                            continue;
                        }
                        m.output = m.output.slice(0, -B.output.length);
                        B.type = "globstar";
                        B.output = globstar(u);
                        B.value += G;
                        m.output += B.output;
                        m.globstar = true;
                        consume(G);
                        continue;
                    }
                    const n = {
                        type: "star",
                        value: G,
                        output: k
                    };
                    if (u.bash === true) {
                        n.output = ".*?";
                        if (B.type === "bos" || B.type === "slash") {
                            n.output = T + n.output;
                        }
                        push(n);
                        continue;
                    }
                    if (B && (B.type === "bracket" || B.type === "paren") && u.regex === true) {
                        n.output = G;
                        push(n);
                        continue;
                    }
                    if (m.index === m.start || B.type === "slash" || B.type === "dot") {
                        if (B.type === "dot") {
                            m.output += x;
                            B.output += x;
                        } else if (u.dot === true) {
                            m.output += S;
                            B.output += S;
                        } else {
                            m.output += T;
                            B.output += T;
                        }
                        if (D() !== "*") {
                            m.output += C;
                            B.output += C;
                        }
                    }
                    push(n);
                }
                while(m.brackets > 0){
                    if (u.strictBrackets === true) throw new SyntaxError(syntaxError("closing", "]"));
                    m.output = o.escapeLast(m.output, "[");
                    decrement("brackets");
                }
                while(m.parens > 0){
                    if (u.strictBrackets === true) throw new SyntaxError(syntaxError("closing", ")"));
                    m.output = o.escapeLast(m.output, "(");
                    decrement("parens");
                }
                while(m.braces > 0){
                    if (u.strictBrackets === true) throw new SyntaxError(syntaxError("closing", "}"));
                    m.output = o.escapeLast(m.output, "{");
                    decrement("braces");
                }
                if (u.strictSlashes !== true && (B.type === "star" || B.type === "bracket")) {
                    push({
                        type: "maybe_slash",
                        value: "",
                        output: `${b}?`
                    });
                }
                if (m.backtrack === true) {
                    m.output = "";
                    for (const t of m.tokens){
                        m.output += t.output != null ? t.output : t.value;
                        if (t.suffix) {
                            m.output += t.suffix;
                        }
                    }
                }
                return m;
            };
            parse.fastpaths = (t, e)=>{
                const u = {
                    ...e
                };
                const r = typeof u.maxLength === "number" ? Math.min(s, u.maxLength) : s;
                const a = t.length;
                if (a > r) {
                    throw new SyntaxError(`Input length: ${a}, exceeds maximum allowed length: ${r}`);
                }
                t = c[t] || t;
                const { DOT_LITERAL: i, SLASH_LITERAL: p, ONE_CHAR: l, DOTS_SLASH: f, NO_DOT: A, NO_DOTS: _, NO_DOTS_SLASH: R, STAR: E, START_ANCHOR: h } = n.globChars(u.windows);
                const g = u.dot ? _ : A;
                const b = u.dot ? R : A;
                const C = u.capture ? "" : "?:";
                const y = {
                    negated: false,
                    prefix: ""
                };
                let $ = u.bash === true ? ".*?" : E;
                if (u.capture) {
                    $ = `(${$})`;
                }
                const globstar = (t)=>{
                    if (t.noglobstar === true) return $;
                    return `(${C}(?:(?!${h}${t.dot ? f : i}).)*?)`;
                };
                const create = (t)=>{
                    switch(t){
                        case "*":
                            return `${g}${l}${$}`;
                        case ".*":
                            return `${i}${l}${$}`;
                        case "*.*":
                            return `${g}${$}${i}${l}${$}`;
                        case "*/*":
                            return `${g}${$}${p}${l}${b}${$}`;
                        case "**":
                            return g + globstar(u);
                        case "**/*":
                            return `(?:${g}${globstar(u)}${p})?${b}${l}${$}`;
                        case "**/*.*":
                            return `(?:${g}${globstar(u)}${p})?${b}${$}${i}${l}${$}`;
                        case "**/.*":
                            return `(?:${g}${globstar(u)}${p})?${i}${l}${$}`;
                        default:
                            {
                                const e = /^(.*?)\.(\w+)$/.exec(t);
                                if (!e) return;
                                const u = create(e[1]);
                                if (!u) return;
                                return u + i + e[2];
                            }
                    }
                };
                const x = o.removePrefix(t, y);
                let S = create(x);
                if (S && u.strictSlashes !== true) {
                    S += `${p}?`;
                }
                return S;
            };
            t.exports = parse;
        },
        510: (t, e, u)=>{
            const n = u(716);
            const o = u(697);
            const s = u(96);
            const r = u(154);
            const isObject = (t)=>t && typeof t === "object" && !Array.isArray(t);
            const picomatch = (t, e, u = false)=>{
                if (Array.isArray(t)) {
                    const n = t.map((t)=>picomatch(t, e, u));
                    const arrayMatcher = (t)=>{
                        for (const e of n){
                            const u = e(t);
                            if (u) return u;
                        }
                        return false;
                    };
                    return arrayMatcher;
                }
                const n = isObject(t) && t.tokens && t.input;
                if (t === "" || typeof t !== "string" && !n) {
                    throw new TypeError("Expected pattern to be a non-empty string");
                }
                const o = e || {};
                const s = o.windows;
                const r = n ? picomatch.compileRe(t, e) : picomatch.makeRe(t, e, false, true);
                const a = r.state;
                delete r.state;
                let isIgnored = ()=>false;
                if (o.ignore) {
                    const t = {
                        ...e,
                        ignore: null,
                        onMatch: null,
                        onResult: null
                    };
                    isIgnored = picomatch(o.ignore, t, u);
                }
                const matcher = (u, n = false)=>{
                    const { isMatch: i, match: c, output: p } = picomatch.test(u, r, e, {
                        glob: t,
                        posix: s
                    });
                    const l = {
                        glob: t,
                        state: a,
                        regex: r,
                        posix: s,
                        input: u,
                        output: p,
                        match: c,
                        isMatch: i
                    };
                    if (typeof o.onResult === "function") {
                        o.onResult(l);
                    }
                    if (i === false) {
                        l.isMatch = false;
                        return n ? l : false;
                    }
                    if (isIgnored(u)) {
                        if (typeof o.onIgnore === "function") {
                            o.onIgnore(l);
                        }
                        l.isMatch = false;
                        return n ? l : false;
                    }
                    if (typeof o.onMatch === "function") {
                        o.onMatch(l);
                    }
                    return n ? l : true;
                };
                if (u) {
                    matcher.state = a;
                }
                return matcher;
            };
            picomatch.test = (t, e, u, { glob: n, posix: o } = {})=>{
                if (typeof t !== "string") {
                    throw new TypeError("Expected input to be a string");
                }
                if (t === "") {
                    return {
                        isMatch: false,
                        output: ""
                    };
                }
                const r = u || {};
                const a = r.format || (o ? s.toPosixSlashes : null);
                let i = t === n;
                let c = i && a ? a(t) : t;
                if (i === false) {
                    c = a ? a(t) : t;
                    i = c === n;
                }
                if (i === false || r.capture === true) {
                    if (r.matchBase === true || r.basename === true) {
                        i = picomatch.matchBase(t, e, u, o);
                    } else {
                        i = e.exec(c);
                    }
                }
                return {
                    isMatch: Boolean(i),
                    match: i,
                    output: c
                };
            };
            picomatch.matchBase = (t, e, u)=>{
                const n = e instanceof RegExp ? e : picomatch.makeRe(e, u);
                return n.test(s.basename(t));
            };
            picomatch.isMatch = (t, e, u)=>picomatch(e, u)(t);
            picomatch.parse = (t, e)=>{
                if (Array.isArray(t)) return t.map((t)=>picomatch.parse(t, e));
                return o(t, {
                    ...e,
                    fastpaths: false
                });
            };
            picomatch.scan = (t, e)=>n(t, e);
            picomatch.compileRe = (t, e, u = false, n = false)=>{
                if (u === true) {
                    return t.output;
                }
                const o = e || {};
                const s = o.contains ? "" : "^";
                const r = o.contains ? "" : "$";
                let a = `${s}(?:${t.output})${r}`;
                if (t && t.negated === true) {
                    a = `^(?!${a}).*$`;
                }
                const i = picomatch.toRegex(a, e);
                if (n === true) {
                    i.state = t;
                }
                return i;
            };
            picomatch.makeRe = (t, e = {}, u = false, n = false)=>{
                if (!t || typeof t !== "string") {
                    throw new TypeError("Expected a non-empty string");
                }
                let s = {
                    negated: false,
                    fastpaths: true
                };
                if (e.fastpaths !== false && (t[0] === "." || t[0] === "*")) {
                    s.output = o.fastpaths(t, e);
                }
                if (!s.output) {
                    s = o(t, e);
                }
                return picomatch.compileRe(s, e, u, n);
            };
            picomatch.toRegex = (t, e)=>{
                try {
                    const u = e || {};
                    return new RegExp(t, u.flags || (u.nocase ? "i" : ""));
                } catch (t) {
                    if (e && e.debug === true) throw t;
                    return /$^/;
                }
            };
            picomatch.constants = r;
            t.exports = picomatch;
        },
        716: (t, e, u)=>{
            const n = u(96);
            const { CHAR_ASTERISK: o, CHAR_AT: s, CHAR_BACKWARD_SLASH: r, CHAR_COMMA: a, CHAR_DOT: i, CHAR_EXCLAMATION_MARK: c, CHAR_FORWARD_SLASH: p, CHAR_LEFT_CURLY_BRACE: l, CHAR_LEFT_PARENTHESES: f, CHAR_LEFT_SQUARE_BRACKET: A, CHAR_PLUS: _, CHAR_QUESTION_MARK: R, CHAR_RIGHT_CURLY_BRACE: E, CHAR_RIGHT_PARENTHESES: h, CHAR_RIGHT_SQUARE_BRACKET: g } = u(154);
            const isPathSeparator = (t)=>t === p || t === r;
            const depth = (t)=>{
                if (t.isPrefix !== true) {
                    t.depth = t.isGlobstar ? Infinity : 1;
                }
            };
            const scan = (t, e)=>{
                const u = e || {};
                const b = t.length - 1;
                const C = u.parts === true || u.scanToEnd === true;
                const y = [];
                const $ = [];
                const x = [];
                let S = t;
                let H = -1;
                let v = 0;
                let d = 0;
                let L = false;
                let T = false;
                let O = false;
                let k = false;
                let m = false;
                let w = false;
                let N = false;
                let I = false;
                let B = false;
                let G = false;
                let D = 0;
                let M;
                let P;
                let K = {
                    value: "",
                    depth: 0,
                    isGlob: false
                };
                const eos = ()=>H >= b;
                const peek = ()=>S.charCodeAt(H + 1);
                const advance = ()=>{
                    M = P;
                    return S.charCodeAt(++H);
                };
                while(H < b){
                    P = advance();
                    let t;
                    if (P === r) {
                        N = K.backslashes = true;
                        P = advance();
                        if (P === l) {
                            w = true;
                        }
                        continue;
                    }
                    if (w === true || P === l) {
                        D++;
                        while(eos() !== true && (P = advance())){
                            if (P === r) {
                                N = K.backslashes = true;
                                advance();
                                continue;
                            }
                            if (P === l) {
                                D++;
                                continue;
                            }
                            if (w !== true && P === i && (P = advance()) === i) {
                                L = K.isBrace = true;
                                O = K.isGlob = true;
                                G = true;
                                if (C === true) {
                                    continue;
                                }
                                break;
                            }
                            if (w !== true && P === a) {
                                L = K.isBrace = true;
                                O = K.isGlob = true;
                                G = true;
                                if (C === true) {
                                    continue;
                                }
                                break;
                            }
                            if (P === E) {
                                D--;
                                if (D === 0) {
                                    w = false;
                                    L = K.isBrace = true;
                                    G = true;
                                    break;
                                }
                            }
                        }
                        if (C === true) {
                            continue;
                        }
                        break;
                    }
                    if (P === p) {
                        y.push(H);
                        $.push(K);
                        K = {
                            value: "",
                            depth: 0,
                            isGlob: false
                        };
                        if (G === true) continue;
                        if (M === i && H === v + 1) {
                            v += 2;
                            continue;
                        }
                        d = H + 1;
                        continue;
                    }
                    if (u.noext !== true) {
                        const t = P === _ || P === s || P === o || P === R || P === c;
                        if (t === true && peek() === f) {
                            O = K.isGlob = true;
                            k = K.isExtglob = true;
                            G = true;
                            if (P === c && H === v) {
                                B = true;
                            }
                            if (C === true) {
                                while(eos() !== true && (P = advance())){
                                    if (P === r) {
                                        N = K.backslashes = true;
                                        P = advance();
                                        continue;
                                    }
                                    if (P === h) {
                                        O = K.isGlob = true;
                                        G = true;
                                        break;
                                    }
                                }
                                continue;
                            }
                            break;
                        }
                    }
                    if (P === o) {
                        if (M === o) m = K.isGlobstar = true;
                        O = K.isGlob = true;
                        G = true;
                        if (C === true) {
                            continue;
                        }
                        break;
                    }
                    if (P === R) {
                        O = K.isGlob = true;
                        G = true;
                        if (C === true) {
                            continue;
                        }
                        break;
                    }
                    if (P === A) {
                        while(eos() !== true && (t = advance())){
                            if (t === r) {
                                N = K.backslashes = true;
                                advance();
                                continue;
                            }
                            if (t === g) {
                                T = K.isBracket = true;
                                O = K.isGlob = true;
                                G = true;
                                break;
                            }
                        }
                        if (C === true) {
                            continue;
                        }
                        break;
                    }
                    if (u.nonegate !== true && P === c && H === v) {
                        I = K.negated = true;
                        v++;
                        continue;
                    }
                    if (u.noparen !== true && P === f) {
                        O = K.isGlob = true;
                        if (C === true) {
                            while(eos() !== true && (P = advance())){
                                if (P === f) {
                                    N = K.backslashes = true;
                                    P = advance();
                                    continue;
                                }
                                if (P === h) {
                                    G = true;
                                    break;
                                }
                            }
                            continue;
                        }
                        break;
                    }
                    if (O === true) {
                        G = true;
                        if (C === true) {
                            continue;
                        }
                        break;
                    }
                }
                if (u.noext === true) {
                    k = false;
                    O = false;
                }
                let U = S;
                let X = "";
                let F = "";
                if (v > 0) {
                    X = S.slice(0, v);
                    S = S.slice(v);
                    d -= v;
                }
                if (U && O === true && d > 0) {
                    U = S.slice(0, d);
                    F = S.slice(d);
                } else if (O === true) {
                    U = "";
                    F = S;
                } else {
                    U = S;
                }
                if (U && U !== "" && U !== "/" && U !== S) {
                    if (isPathSeparator(U.charCodeAt(U.length - 1))) {
                        U = U.slice(0, -1);
                    }
                }
                if (u.unescape === true) {
                    if (F) F = n.removeBackslashes(F);
                    if (U && N === true) {
                        U = n.removeBackslashes(U);
                    }
                }
                const Q = {
                    prefix: X,
                    input: t,
                    start: v,
                    base: U,
                    glob: F,
                    isBrace: L,
                    isBracket: T,
                    isGlob: O,
                    isExtglob: k,
                    isGlobstar: m,
                    negated: I,
                    negatedExtglob: B
                };
                if (u.tokens === true) {
                    Q.maxDepth = 0;
                    if (!isPathSeparator(P)) {
                        $.push(K);
                    }
                    Q.tokens = $;
                }
                if (u.parts === true || u.tokens === true) {
                    let e;
                    for(let n = 0; n < y.length; n++){
                        const o = e ? e + 1 : v;
                        const s = y[n];
                        const r = t.slice(o, s);
                        if (u.tokens) {
                            if (n === 0 && v !== 0) {
                                $[n].isPrefix = true;
                                $[n].value = X;
                            } else {
                                $[n].value = r;
                            }
                            depth($[n]);
                            Q.maxDepth += $[n].depth;
                        }
                        if (n !== 0 || r !== "") {
                            x.push(r);
                        }
                        e = s;
                    }
                    if (e && e + 1 < t.length) {
                        const n = t.slice(e + 1);
                        x.push(n);
                        if (u.tokens) {
                            $[$.length - 1].value = n;
                            depth($[$.length - 1]);
                            Q.maxDepth += $[$.length - 1].depth;
                        }
                    }
                    Q.slashes = y;
                    Q.parts = x;
                }
                return Q;
            };
            t.exports = scan;
        },
        96: (t, e, u)=>{
            const { REGEX_BACKSLASH: n, REGEX_REMOVE_BACKSLASH: o, REGEX_SPECIAL_CHARS: s, REGEX_SPECIAL_CHARS_GLOBAL: r } = u(154);
            e.isObject = (t)=>t !== null && typeof t === "object" && !Array.isArray(t);
            e.hasRegexChars = (t)=>s.test(t);
            e.isRegexChar = (t)=>t.length === 1 && e.hasRegexChars(t);
            e.escapeRegex = (t)=>t.replace(r, "\\$1");
            e.toPosixSlashes = (t)=>t.replace(n, "/");
            e.removeBackslashes = (t)=>t.replace(o, (t)=>t === "\\" ? "" : t);
            e.escapeLast = (t, u, n)=>{
                const o = t.lastIndexOf(u, n);
                if (o === -1) return t;
                if (t[o - 1] === "\\") return e.escapeLast(t, u, o - 1);
                return `${t.slice(0, o)}\\${t.slice(o)}`;
            };
            e.removePrefix = (t, e = {})=>{
                let u = t;
                if (u.startsWith("./")) {
                    u = u.slice(2);
                    e.prefix = "./";
                }
                return u;
            };
            e.wrapOutput = (t, e = {}, u = {})=>{
                const n = u.contains ? "" : "^";
                const o = u.contains ? "" : "$";
                let s = `${n}(?:${t})${o}`;
                if (e.negated === true) {
                    s = `(?:^(?!${s}).*$)`;
                }
                return s;
            };
            e.basename = (t, { windows: e } = {})=>{
                const u = t.split(e ? /[\\/]/ : "/");
                const n = u[u.length - 1];
                if (n === "") {
                    return u[u.length - 2];
                }
                return n;
            };
        }
    };
    var e = {};
    function __nccwpck_require__(u) {
        var n = e[u];
        if (n !== undefined) {
            return n.exports;
        }
        var o = e[u] = {
            exports: {}
        };
        var s = true;
        try {
            t[u](o, o.exports, __nccwpck_require__);
            s = false;
        } finally{
            if (s) delete e[u];
        }
        return o.exports;
    }
    if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = ("TURBOPACK compile-time value", "/ROOT/spam-cloud-25-11-25/node_modules/next/dist/compiled/picomatch") + "/";
    var u = __nccwpck_require__(170);
    module.exports = u;
})();
}),
"[project]/spam-cloud-25-11-25/node_modules/next/dist/compiled/client-only/index.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
]);

//# sourceMappingURL=bb85f_next_dist_compiled_d8a98736._.js.map