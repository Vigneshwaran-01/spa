(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StableTiptapEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$react$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/react/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$starter$2d$kit$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/starter-kit/dist/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-table/dist/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2d$row$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-table-row/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2d$cell$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-table-cell/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2d$header$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-table-header/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$link$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-link/dist/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$image$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-image/dist/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$tiptap$2d$extension$2d$resize$2d$image$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/tiptap-extension-resize-image/esm/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$horizontal$2d$rule$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-horizontal-rule/dist/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$text$2d$align$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-text-align/dist/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2d$block$2d$lowlight$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/@tiptap/extension-code-block-lowlight/dist/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$lowlight$2f$lib$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/lowlight/lib/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$highlight$2e$js$2f$es$2f$languages$2f$javascript$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/spam-cloud-25-11-25/node_modules/highlight.js/es/languages/javascript.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function StableTiptapEditor({ value, onChange, placeholder = 'Write your content here...' }) {
    _s();
    const [showLinkDialog, setShowLinkDialog] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [linkUrl, setLinkUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [linkText, setLinkText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [imageUrl, setImageUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [imageWidth, setImageWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [imageHeight, setImageHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [showButtonDialog, setShowButtonDialog] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [buttonText, setButtonText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [buttonUrl, setButtonUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [buttonStyle, setButtonStyle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('primary');
    const [linkStyle, setLinkStyle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('default');
    const [isPreviewMode, setIsPreviewMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const lowlight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$lowlight$2f$lib$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createLowlight"])();
    lowlight.register('javascript', __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$highlight$2e$js$2f$es$2f$languages$2f$javascript$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"]);
    const editor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$react$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditor"])({
        extensions: [
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$starter$2d$kit$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"],
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Table"].configure({
                resizable: true
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["TableRow"],
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["TableHeader"],
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$table$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["TableCell"],
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$link$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Link"].configure({
                openOnClick: false
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$image$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Image"].configure({
                allowBase64: true,
                HTMLAttributes: {
                    class: 'editor-image'
                }
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$tiptap$2d$extension$2d$resize$2d$image$2f$esm$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].configure({
                allowBase64: true,
                defaultWidth: '300px',
                defaultHeight: 'auto'
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$horizontal$2d$rule$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["HorizontalRule"],
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$text$2d$align$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["TextAlign"].configure({
                types: [
                    'heading',
                    'paragraph'
                ]
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$extension$2d$code$2d$block$2d$lowlight$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["CodeBlockLowlight"].configure({
                lowlight
            })
        ],
        content: value || '',
        immediatelyRender: false,
        editorProps: {
            attributes: {
                class: 'prose max-w-none min-h-[200px] px-4 py-3 focus:outline-none tiptap-editor'
            }
        },
        onUpdate ({ editor }) {
            if (typeof onChange === 'function') {
                onChange(editor.getHTML());
            }
        }
    });
    const addLink = ()=>{
        if (linkUrl) {
            editor.chain().focus().setLink({
                href: linkUrl
            }).run();
            setShowLinkDialog(false);
            setLinkUrl('');
            setLinkText('');
        }
    };
    const addImage = ()=>{
        if (imageUrl) {
            const imageAttrs = {
                src: imageUrl
            };
            if (imageWidth) imageAttrs.width = imageWidth;
            if (imageHeight) imageAttrs.height = imageHeight;
            editor.chain().focus().setImage(imageAttrs).run();
            setImageUrl('');
            setImageWidth('');
            setImageHeight('');
        }
    };
    const addButton = ()=>{
        if (buttonText && buttonUrl) {
            const styleClasses = {
                primary: 'bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 inline-block',
                secondary: 'bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 inline-block',
                success: 'bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 inline-block',
                danger: 'bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 inline-block',
                outline: 'border-2 border-blue-500 text-blue-500 px-4 py-2 rounded hover:bg-blue-50 inline-block'
            };
            const buttonHtml = `<a href="${buttonUrl}" class="${styleClasses[buttonStyle]}" style="text-decoration: none; display: inline-block;">${buttonText}</a>`;
            editor.chain().focus().insertContent(buttonHtml).run();
            setShowButtonDialog(false);
            setButtonText('');
            setButtonUrl('');
            setButtonStyle('primary');
        }
    };
    const insertTable = ()=>{
        editor.chain().focus().insertTable({
            rows: 3,
            cols: 3,
            withHeaderRow: true
        }).run();
    };
    const addFaq = ()=>{
        const faqHtml = `
      <div style="margin: 1.5rem 0;">
        <div style="margin-bottom: 1rem; border: 1px solid #e5e7eb; border-radius: 0.5rem; overflow: hidden; background: white;">
          <div style="font-weight: 600; color: #111827; padding: 0.75rem 1rem; cursor: pointer; background: #f9fafb; border-bottom: 1px solid #e5e7eb; transition: all 0.2s ease; display: flex; justify-content: space-between; align-items: center;" 
               onmouseover="this.style.background='#f3f4f6'" 
               onmouseout="this.style.background='#f9fafb'"
               onclick="
                 var answer = this.nextElementSibling;
                 var icon = this.querySelector('.dropdown-icon');
                 if (answer.style.display === 'none' || answer.style.display === '') {
                   answer.style.display = 'block';
                   answer.style.maxHeight = '500px';
                   answer.style.opacity = '1';
                   icon.style.transform = 'rotate(180deg)';
                 } else {
                   answer.style.display = 'none';
                   answer.style.maxHeight = '0';
                   answer.style.opacity = '0';
                   icon.style.transform = 'rotate(0deg)';
                 }
               ">
            <div style="flex: 1;">
              <strong>Q:</strong> What is your question?
            </div>
            <span class="dropdown-icon" style="font-size: 1rem; color: #6b7280; transition: transform 0.2s ease; display: inline-block; margin-left: 0.5rem; flex-shrink: 0;">▼</span>
          </div>
          <div style="color: #374151; line-height: 1.6; padding: 0.75rem 1rem; display: none; max-height: 0; opacity: 0; transition: all 0.3s ease; overflow: hidden;">
            <strong>A:</strong> Your answer goes here...
          </div>
        </div>
      </div>
    `;
        editor.chain().focus().insertContent(faqHtml).run();
    };
    // Keep editor content in sync if "value" prop changes from outside
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StableTiptapEditor.useEffect": ()=>{
            if (!editor) return;
            const current = editor.getHTML();
            if (value != null && value !== current) {
                editor.commands.setContent(value, false);
            }
        }
    }["StableTiptapEditor.useEffect"], [
        value,
        editor
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StableTiptapEditor.useEffect": ()=>{
            return ({
                "StableTiptapEditor.useEffect": ()=>{
                    if (editor) {
                        editor.destroy();
                    }
                }
            })["StableTiptapEditor.useEffect"];
        }
    }["StableTiptapEditor.useEffect"], [
        editor
    ]);
    if (!editor) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-[200px] px-4 py-3 text-sm text-slate-500",
            children: "Loading editor..."
        }, void 0, false, {
            fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
            lineNumber: 187,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                dangerouslySetInnerHTML: {
                    __html: `
        .tiptap-editor table {
          border-collapse: collapse;
          width: 100%;
          margin: 1rem 0;
          border: 2px solid #374151 !important;
        }
        .tiptap-editor table td,
        .tiptap-editor table th {
          border: 1px solid #374151 !important;
          padding: 0.5rem;
          text-align: left;
        }
        .tiptap-editor table th {
          background-color: #f9fafb;
          font-weight: 600;
        }
        .tiptap-editor table tr:nth-child(even) {
          background-color: #f9fafb;
        }
        .tiptap-editor table tr:hover {
          background-color: #f3f4f6;
        }
        .preview-content {
          padding: 2rem;
          min-height: 400px;
        }
        .preview-content table {
          border-collapse: collapse;
          width: 100%;
          margin: 1rem 0;
          border: 2px solid #374151 !important;
        }
        .preview-content table td,
        .preview-content table th {
          border: 1px solid #374151 !important;
          padding: 0.5rem;
          text-align: left;
        }
        .preview-content table th {
          background-color: #f9fafb;
          font-weight: 600;
        }
        .preview-content table tr:nth-child(even) {
          background-color: #f9fafb;
        }
        .preview-content table tr:hover {
          background-color: #f3f4f6;
        }
        `
                }
            }, void 0, false, {
                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                lineNumber: 195,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full border-t border-gray-200 bg-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-gray-200 bg-gray-50 px-2 py-1 text-xs text-gray-500 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Rich text editor"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 249,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setIsPreviewMode(!isPreviewMode),
                                className: `px-2 py-1 text-xs border rounded ${isPreviewMode ? 'bg-blue-500 text-white' : 'bg-white hover:bg-gray-50'}`,
                                children: isPreviewMode ? 'Edit' : 'Preview'
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 250,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 248,
                        columnNumber: 7
                    }, this),
                    isPreviewMode ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "preview-content",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            dangerouslySetInnerHTML: {
                                __html: editor.getHTML()
                            }
                        }, void 0, false, {
                            fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                            lineNumber: 262,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 261,
                        columnNumber: 9
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-gray-200 bg-white p-2 flex gap-1 flex-wrap",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleBold().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('bold') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Bold"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleItalic().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('italic') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Italic"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleStrike().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('strike') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Strike"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 281,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleCode().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('code') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Code"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 288,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px bg-gray-300 mx-1"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 296,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleHeading({
                                        level: 1
                                    }).run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('heading', {
                                    level: 1
                                }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "H1"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 299,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleHeading({
                                        level: 2
                                    }).run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('heading', {
                                    level: 2
                                }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "H2"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 306,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px bg-gray-300 mx-1"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 314,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().setTextAlign('left').run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive({
                                    textAlign: 'left'
                                }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Left"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 317,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().setTextAlign('center').run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive({
                                    textAlign: 'center'
                                }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Center"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 324,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().setTextAlign('right').run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive({
                                    textAlign: 'right'
                                }) ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Right"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 331,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px bg-gray-300 mx-1"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 339,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleBulletList().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('bulletList') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Bullet List"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 342,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleOrderedList().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('orderedList') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Numbered List"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 349,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleBlockquote().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('blockquote') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Quote"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 356,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px bg-gray-300 mx-1"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 364,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setShowLinkDialog(true),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                                children: "Link"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 367,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setShowButtonDialog(true),
                                className: "px-2 py-1 text-xs border rounded bg-purple-500 text-white hover:bg-purple-600",
                                children: "Button"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 374,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().toggleCodeBlock().run(),
                                className: `px-2 py-1 text-xs border rounded ${editor.isActive('codeBlock') ? 'bg-gray-200' : 'bg-white hover:bg-gray-50'}`,
                                children: "Code Block"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 381,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().setHorizontalRule().run(),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                                children: "Divider"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 388,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: insertTable,
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50",
                                children: "Insert Table"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 395,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: addFaq,
                                className: "px-2 py-1 text-xs border rounded bg-orange-500 text-white hover:bg-orange-600",
                                children: "FAQ"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 402,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-px bg-gray-300 mx-1"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 409,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().addColumnBefore().run(),
                                disabled: !editor.can().addColumnBefore(),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50 disabled:opacity-50",
                                children: "+Col Before"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 411,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().addColumnAfter().run(),
                                disabled: !editor.can().addColumnAfter(),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50 disabled:opacity-50",
                                children: "+Col After"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 419,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().deleteColumn().run(),
                                disabled: !editor.can().deleteColumn(),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50 disabled:opacity-50",
                                children: "-Col"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 427,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().addRowBefore().run(),
                                disabled: !editor.can().addRowBefore(),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50 disabled:opacity-50",
                                children: "+Row Before"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 435,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().addRowAfter().run(),
                                disabled: !editor.can().addRowAfter(),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50 disabled:opacity-50",
                                children: "+Row After"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 443,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().deleteRow().run(),
                                disabled: !editor.can().deleteRow(),
                                className: "px-2 py-1 text-xs border rounded bg-white hover:bg-gray-50 disabled:opacity-50",
                                children: "-Row"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 451,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>editor.chain().focus().deleteTable().run(),
                                disabled: !editor.can().deleteTable(),
                                className: "px-2 py-1 text-xs border rounded bg-red-500 text-white hover:bg-red-600 disabled:opacity-50",
                                children: "Delete Table"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 459,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this),
                    showLinkDialog && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-gray-200 bg-gray-50 p-3 flex gap-2 items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                placeholder: "Enter URL",
                                value: linkUrl,
                                onChange: (e)=>setLinkUrl(e.target.value),
                                className: "flex-1 px-2 py-1 text-xs border rounded"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 489,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: addLink,
                                className: "px-2 py-1 text-xs border rounded bg-blue-500 text-white hover:bg-blue-600",
                                children: "Add Link"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 496,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setShowLinkDialog(false),
                                className: "px-2 py-1 text-xs border rounded bg-gray-300 hover:bg-gray-400",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 503,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 488,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-gray-200 bg-gray-50 p-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 items-center mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    placeholder: "Enter image URL",
                                    value: imageUrl,
                                    onChange: (e)=>setImageUrl(e.target.value),
                                    className: "flex-1 px-2 py-1 text-xs border rounded"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                    lineNumber: 516,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 515,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 items-center mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Width (e.g., 300px, 50%)",
                                        value: imageWidth,
                                        onChange: (e)=>setImageWidth(e.target.value),
                                        className: "flex-1 px-2 py-1 text-xs border rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                        lineNumber: 525,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Height (e.g., 200px, auto)",
                                        value: imageHeight,
                                        onChange: (e)=>setImageHeight(e.target.value),
                                        className: "flex-1 px-2 py-1 text-xs border rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                        lineNumber: 532,
                                        columnNumber: 11
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 524,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: addImage,
                                className: "px-2 py-1 text-xs border rounded bg-green-500 text-white hover:bg-green-600",
                                children: "Add Image"
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 540,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 514,
                        columnNumber: 7
                    }, this),
                    showButtonDialog && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-gray-200 bg-gray-50 p-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 items-center mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    placeholder: "Button text",
                                    value: buttonText,
                                    onChange: (e)=>setButtonText(e.target.value),
                                    className: "flex-1 px-2 py-1 text-xs border rounded"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                    lineNumber: 553,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 552,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 items-center mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    placeholder: "Button URL",
                                    value: buttonUrl,
                                    onChange: (e)=>setButtonUrl(e.target.value),
                                    className: "flex-1 px-2 py-1 text-xs border rounded"
                                }, void 0, false, {
                                    fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                    lineNumber: 562,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 561,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 items-center mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "text-xs",
                                        children: "Style:"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                        lineNumber: 571,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: buttonStyle,
                                        onChange: (e)=>setButtonStyle(e.target.value),
                                        className: "flex-1 px-2 py-1 text-xs border rounded",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "primary",
                                                children: "Primary (Blue)"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                                lineNumber: 577,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "secondary",
                                                children: "Secondary (Gray)"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                                lineNumber: 578,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "success",
                                                children: "Success (Green)"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                                lineNumber: 579,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "danger",
                                                children: "Danger (Red)"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                                lineNumber: 580,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "outline",
                                                children: "Outline"
                                            }, void 0, false, {
                                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                                lineNumber: 581,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                        lineNumber: 572,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 570,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: addButton,
                                        className: "px-2 py-1 text-xs border rounded bg-purple-500 text-white hover:bg-purple-600",
                                        children: "Add Button"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                        lineNumber: 585,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setShowButtonDialog(false),
                                        className: "px-2 py-1 text-xs border rounded bg-gray-300 hover:bg-gray-400",
                                        children: "Cancel"
                                    }, void 0, false, {
                                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                        lineNumber: 592,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 584,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 551,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-h-[200px]",
                        children: [
                            !value && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-4 pt-3 text-xs text-gray-400 select-none pointer-events-none",
                                children: placeholder
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 606,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$react$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["EditorContent"], {
                                editor: editor
                            }, void 0, false, {
                                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                                lineNumber: 610,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                        lineNumber: 604,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx",
                lineNumber: 247,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(StableTiptapEditor, "QNex6uZHtNIEwKIRBuqISjmSgUo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$spam$2d$cloud$2d$25$2d$11$2d$25$2f$node_modules$2f40$tiptap$2f$react$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useEditor"]
    ];
});
_c = StableTiptapEditor;
var _c;
__turbopack_context__.k.register(_c, "StableTiptapEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [client] (ecmascript)"));
}),
]);

//# sourceMappingURL=spam-cloud-25-11-25_components_StableTiptapEditor_jsx_7fc6034d._.js.map