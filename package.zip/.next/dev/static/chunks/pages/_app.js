__turbopack_load_page_chunks__("/_app", [
  "static/chunks/spam-cloud-25-11-25_5c0953c8._.js",
  "static/chunks/[root-of-the-server]__574bcd6e._.js",
  "static/chunks/bb85f_next_dist_compiled_98bed846._.js",
  "static/chunks/bb85f_next_dist_shared_lib_64748e05._.js",
  "static/chunks/bb85f_next_dist_client_aa07e0da._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_ce63c46b._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_7b228723._.js",
  "static/chunks/spam-cloud-25-11-25_260e5d7b._.css",
  "static/chunks/spam-cloud-25-11-25_pages__app_2da965e7._.js",
  "static/chunks/turbopack-spam-cloud-25-11-25_pages__app_874f5f05._.js"
])
