__turbopack_load_page_chunks__("/services/seqrite-endpoint-security", [
  "static/chunks/[root-of-the-server]__25443d53._.js",
  "static/chunks/bb85f_next_dist_compiled_478a8bd8._.js",
  "static/chunks/bb85f_next_dist_shared_lib_cbd6f651._.js",
  "static/chunks/bb85f_next_dist_client_261b0bf4._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_4c2fe7a4._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_a9571811._.js",
  "static/chunks/spam-cloud-25-11-25_pages_services_seqrite-endpoint-security_jsx_2da965e7._.js",
  "static/chunks/09117_bopack-spam-cloud-25-11-25_pages_services_seqrite-endpoint-security_jsx_b40219f0._.js"
])
