__turbopack_load_page_chunks__("/admin/posts/new", [
  "static/chunks/spam-cloud-25-11-25_components_StableTiptapEditor_jsx_4abb8dd2._.js",
  "static/chunks/bb85f_next_dist_compiled_615e306c._.js",
  "static/chunks/bb85f_next_dist_shared_lib_c34088d5._.js",
  "static/chunks/bb85f_next_dist_client_aa07e0da._.js",
  "static/chunks/bb85f_next_dist_fc047aea._.js",
  "static/chunks/bb85f_next_7e8bc862._.js",
  "static/chunks/bb85f_react_ee0360d4._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_7a28e42f._.js",
  "static/chunks/[root-of-the-server]__2844f883._.js",
  "static/chunks/spam-cloud-25-11-25_pages_admin_posts_new_jsx_2da965e7._.js",
  "static/chunks/turbopack-spam-cloud-25-11-25_pages_admin_posts_new_jsx_67349d61._.js"
])
