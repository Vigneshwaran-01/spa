(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/spam-cloud-25-11-25_components_StableTiptapEditor_jsx_7fc6034d._.js",
  "static/chunks/spam-cloud-25-11-25_components_StableTiptapEditor_jsx_5cfaf537._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/spam-cloud-25-11-25/components/StableTiptapEditor.jsx [client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);