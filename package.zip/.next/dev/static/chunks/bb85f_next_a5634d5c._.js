(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/spam-cloud-25-11-25/node_modules/next/router.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/client/router.js [client] (ecmascript)");
}),
"[project]/spam-cloud-25-11-25/node_modules/next/link.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/client/link.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=bb85f_next_a5634d5c._.js.map