(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/spam-cloud-25-11-25/node_modules/next/head.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/spam-cloud-25-11-25/node_modules/next/dist/shared/lib/head.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=bb85f_next_head_dc84fff5.js.map