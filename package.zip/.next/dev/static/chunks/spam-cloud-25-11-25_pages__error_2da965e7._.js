(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/bb85f_next_dist_compiled_615e306c._.js",
  "static/chunks/bb85f_next_dist_shared_lib_d376697e._.js",
  "static/chunks/bb85f_next_dist_client_86ac6ed4._.js",
  "static/chunks/bb85f_next_dist_ea90147d._.js",
  "static/chunks/bb85f_next_error_c3e4fbcd.js",
  "static/chunks/[next]_entry_page-loader_ts_6fcbc9aa._.js",
  "static/chunks/bb85f_react_82d96916._.js",
  "static/chunks/bb85f_react-dom_cjs_react-dom_development_52956ccc.js",
  "static/chunks/bb85f_react-dom_32881ed3._.js",
  "static/chunks/bb85f_7a28e42f._.js",
  "static/chunks/[root-of-the-server]__2110930f._.js"
],
    source: "entry"
});
