(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/spam-cloud-25-11-25/components/TawkMessenger.js [client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/spam-cloud-25-11-25_375bc0ff._.js",
  "static/chunks/spam-cloud-25-11-25_components_TawkMessenger_cd602ce6.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/spam-cloud-25-11-25/components/TawkMessenger.js [client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/spam-cloud-25-11-25/node_modules/bootstrap/dist/js/bootstrap.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/bb85f_f8c67687._.js",
  "static/chunks/bb85f_bootstrap_dist_js_bootstrap_6990ba53.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/spam-cloud-25-11-25/node_modules/bootstrap/dist/js/bootstrap.js [client] (ecmascript)");
    });
});
}),
"[project]/spam-cloud-25-11-25/node_modules/react-gtm-module/dist/index.js [client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/bb85f_react-gtm-module_dist_a7812c38._.js",
  "static/chunks/bb85f_react-gtm-module_dist_index_6990ba53.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/spam-cloud-25-11-25/node_modules/react-gtm-module/dist/index.js [client] (ecmascript)");
    });
});
}),
]);